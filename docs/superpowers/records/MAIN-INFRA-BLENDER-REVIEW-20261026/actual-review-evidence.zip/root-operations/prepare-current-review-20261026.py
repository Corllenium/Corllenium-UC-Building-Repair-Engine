from pathlib import Path
import copy,hashlib,importlib.util,json,shutil,struct,subprocess
root=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
old=Path('D:/LLM_BACKUP/Codex session/main-infra-blender-review-build-20261024/05-Corllenium-UC-Building-Repair-Engine')
tool=old/'tools/main_infra_blender_review.py'
spec=importlib.util.spec_from_file_location('review_builder',tool);builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
base=json.loads((old/'docs/superpowers/records/MAIN-INFRA-BLENDER-REVIEW-PLAN-20261024/floor-inventory.json').read_bytes())
current=json.loads((root/'data/main-infra-fresh/current.json').read_bytes())
dest=root/'data/blender-review/MAIN-INFRA-7FLOORS-NOT_FINAL-20261026-inputs';assert not dest.exists() or not any(dest.iterdir());dest.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def row(path):return dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)
def payload_obj(name,digest):
    packet=json.loads((root/('data/p571/packet-receipt.json' if name=='1F' else 'data/p7n/package.json')).read_bytes())
    matches=[r for r in packet['files'] if r['path'].endswith('.obj') and r['sha256']==digest]
    assert len(matches)==1
    return root/('data/p571' if name=='1F' else 'data/p7m')/matches[0]['path']
updates={'1F':(payload_obj('1F','d8ee718ff223049dc8eaa888b9be34a2448919f7d76910e4d15a43329ec7bdff'),10571),
 '4F':(Path('D:/LLM_BACKUP/Codex session/main-infra-4f-native-retention-20261026/05-Corllenium-UC-Building-Repair-Engine/data/main-infra-4f-native-retention/run-20261026/e3/4F/candidate.source.obj'),60496),
 '7F':(payload_obj('7F','849b082378f93055f723a2b23913473eebf94ab5094f56c58eb4a06830526328'),19695)}
for f in base['floors']:
    floor=f['floor'];source=Path(f['source']['path']);candidate=updates.get(floor,(Path(f['candidate']['path']),f['candidate_lexical']['faces']))[0]
    for role,path in [('source',source),('candidate',candidate)]:
        folder=dest/floor/role;folder.mkdir(parents=True)
        target=folder/(('before' if role=='source' else 'candidate')+'.source.obj');shutil.copyfile(path,target);assert sha(path)==sha(target)
        for asset in f['assets']:
            rel=Path(asset['relative'].replace('\\','/'));original=path.parent/rel
            assert sha(original)==asset['sha256'],str(original)
            copied=folder/rel;copied.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,copied);assert sha(copied)==asset['sha256']
        f[role]=row(target);n,libraries,materials=builder._obj(target)
        f[role+'_lexical']=dict(faces=n,all_faces_triangles=True,mtllib=libraries,used_materials=materials,material_count=len(materials))
    if floor in updates:assert f['candidate_lexical']['faces']==updates[floor][1]
    for asset in f['assets']:
        rel=Path(asset['relative'].replace('\\','/'));asset.update(row(dest/floor/'candidate'/rel),qualified_source_path=str(dest/floor/'source'/rel),qualified_source_sha256=sha(dest/floor/'source'/rel),qualified_source_bytes_unchanged=True)
    f['proofs']=[];f['not_final']=True;f['accepted']=False
    progress=current['floors'][floor]
    f['status']=dict(state=progress['state'],step=progress['step'],blocker=progress.get('blocker'),accepted=False,review_only=True,source_triangles=f['source_lexical']['faces'],candidate_triangles=f['candidate_lexical']['faces'])
    if floor=='4F':f['status'].update(stage='E3_PARTIAL',independent_validation='PENDING',E5_started=False,protected_original_triangles=19764)
base.update(job='MAIN-INFRA-BLENDER-REVIEW-REFRESH-20261026',selected_candidate_faces=sum(f['candidate_lexical']['faces'] for f in base['floors']),method='Lossless source/candidate snapshots; lexical face counts and exact qualified texture hashes; no repair performed',acceptance=False)
inventory=dest/'floor-inventory.json';inventory.write_text(json.dumps(base,indent=2)+'\n',encoding='utf-8')
importer=Path('D:/LLM_BACKUP/Codex session/main-infra-1f-e7-covered-ray-validate-20261024/05-Corllenium-UC-Building-Repair-Engine/docs/superpowers/records/MAIN-INFRA-1F-VALIDATE-ATTEMPT3/native-pairs.py')
assert sha(importer)=='065989bc85dfc713ce74ed766428b4a1c23789209796d5913e59224c9d6a7472'
output=root/'data/blender-review/MAIN-INFRA-7FLOORS-NOT_FINAL-20261026/MAIN-INFRA-NOT_FINAL.blend'
plan=builder.load_review_inputs(inventory,sha(inventory),importer,sha(importer),output,review_root=root/'data/blender-review')
wrapper=Path('D:/LLM_BACKUP/Codex session/main-infra-e7-covered-ray-retention-20261024/05-Corllenium-UC-Building-Repair-Engine/data/covered-ray-preflight/run-diagnostic-v5.ps1')
assert sha(wrapper)=='7a4a9e8111ff8d74f972c9ea104da3c449d618efa36dd49320831217e7976afc'
shutil.copyfile(wrapper,dest/'run-proof.ps1')
blender=Path('C:/Program Files/Blender Foundation/Blender 5.1/blender.exe')
args=['-B',str(tool),'--launch','--blender',str(blender),'--blender-sha',sha(blender),'--inventory',str(inventory),'--inventory-sha',sha(inventory),'--importer',str(importer),'--importer-sha',sha(importer),'--output',str(output),'--review-root',str(root/'data/blender-review'),'--build']
pins=plan['input_pins']+[row(tool),row(blender),row(dest/'run-proof.ps1')]
phase=dict(schema_version=1,phase='seven-floor-latest-NOT_FINAL-Blender-review',HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),args=args,pins=pins,acceptance=False,scope='Review file assembly only; no geometry repair, no original source modification')
p=dest/'phase-build.json';p.write_text(json.dumps(phase,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(phase=str(p),phase_sha256=sha(p),inventory_sha256=sha(inventory),pins=len(pins),candidate_counts={f['floor']:f['candidate_lexical']['faces'] for f in base['floors']},output=str(output))))
