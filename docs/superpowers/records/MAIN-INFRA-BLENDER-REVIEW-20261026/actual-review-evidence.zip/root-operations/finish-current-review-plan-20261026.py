from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,shutil,subprocess
root=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
wt=Path('D:/LLM_BACKUP/Codex session/main-infra-blender-review-build-20261024/05-Corllenium-UC-Building-Repair-Engine')
dest=root/'data/blender-review/MAIN-INFRA-7FLOORS-NOT_FINAL-20261026-inputs'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
tool=wt/'tools/main_infra_blender_review.py'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip()
assert head=='24bd28b361d2f674860fecb8912ad9643d6f7e5b'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=wt).strip()
assert hashlib.sha256(subprocess.check_output(['git','show','HEAD:tools/main_infra_blender_review.py'],cwd=wt)).hexdigest()==sha(tool)
inventory=dest/'floor-inventory.json';data=json.loads(inventory.read_bytes());data.update(measured_at=datetime.now(timezone.utc).isoformat(),writer_stop_confirmed=True,upper_writer_last_report=None)
inventory.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
importer=dest/'native-pairs.py';assert sha(importer)=='065989bc85dfc713ce74ed766428b4a1c23789209796d5913e59224c9d6a7472'
spec=importlib.util.spec_from_file_location('review_builder',tool);builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
output=root/'data/blender-review/MAIN-INFRA-7FLOORS-NOT_FINAL-20261026/MAIN-INFRA-NOT_FINAL.blend'
plan=builder.load_review_inputs(inventory,sha(inventory),importer,sha(importer),output,review_root=root/'data/blender-review')
wrapper=root/'data/siege-live-20261026/canvas-build/run-proof.ps1';assert sha(wrapper)=='7a4a9e8111ff8d74f972c9ea104da3c449d618efa36dd49320831217e7976afc'
shutil.copyfile(wrapper,dest/'run-proof.ps1')
blender=Path('C:/Program Files/Blender Foundation/Blender 5.1/blender.exe')
args=['-B',str(tool),'--launch','--blender',str(blender),'--blender-sha',sha(blender),'--inventory',str(inventory),'--inventory-sha',sha(inventory),'--importer',str(importer),'--importer-sha',sha(importer),'--output',str(output),'--review-root',str(root/'data/blender-review'),'--build']
extra=[tool,blender,dest/'run-proof.ps1',root/'.venv/Scripts/python.exe',Path('C:/Users/Future26/AppData/Local/Programs/Python/Python312/python.exe')]
pins=plan['input_pins']+[dict(path=str(p),sha256=sha(p)) for p in extra]
phase=dict(schema_version=1,phase='seven-floor-latest-NOT_FINAL-Blender-review',HEAD=head,gate_8gib=True,args=args,pins=pins,acceptance=False,scope='Saved-candidate review assembly only; no geometry repair or original source writes')
p=dest/'phase-build.json';p.write_text(json.dumps(phase,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(phase=str(p),sha256=sha(p),pins=len(pins),counts={f['floor']:f['candidate_lexical']['faces'] for f in data['floors']},output=str(output))))
