from pathlib import Path
import hashlib, json, os, tarfile, tempfile
from urllib.request import Request, urlopen
from urllib.parse import quote

A=Path('/tmp/main-infra-inspection-10446.tar.gz')
M=Path('/tmp/main-infra-inspection-10446.json')
archive_sha='0180f505608da38072837ea2bd2af9ca8aa922629d4258d39f15138efaf181ba'
assert hashlib.sha256(A.read_bytes()).hexdigest()==archive_sha
m=json.loads(M.read_bytes())
assert m['archive_sha256']==archive_sha and m['kind']=='corrective_inspection_strict_native_pass_full_signed_pending'
assert m['source_triangles']==15856 and m['candidate_triangles']==10446 and m['preservation_passed'] is False and m['strict_passed'] is True and m['native_qualified_passed'] is True and m['full_signed']=='NOT_RUN'
assert m['signed_targets_passed'] is m['acceptance'] is m['publication_eligible'] is False and m['remaining_target_counts']==5407
prefix='models/main-infra/7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511/1F/main-infra-clean-20261023/'
expected={r['path']:r for r in m['files']}
assert len(expected)==len(m['files'])==32 and all(p.startswith(prefix) and '..' not in p and '\\' not in p for p in expected)
roots=[Path('/home/devenvir/corllenium/web'),Path('/home/devenvir/corllenium/app/public')]
def fetch(url):
    with urlopen(Request(url,headers={'Cache-Control':'no-cache'}),timeout=25) as response:
        assert response.status==200
        return response.read()
health_before=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
assert health_before['sha']=='cedb7c53c35b0599585c17b214f3c29e1dfb7b9f' and health_before['db']['ok']
with tarfile.open(A,'r:gz') as tf:
    members=tf.getmembers()
    assert len(members)==32 and all(v.isfile() and v.name in expected for v in members)
    data={v.name:tf.extractfile(v).read() for v in members}
    assert len(data)==32 and all(len(b)==expected[p]['bytes'] and hashlib.sha256(b).hexdigest()==expected[p]['sha256'] for p,b in data.items())
    for root in roots:
        assert root.resolve()==root
        for rel,b in data.items():
            target=root/rel
            assert root in target.resolve().parents
            if target.exists():
                assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256'],rel
    for root in roots:
        for rel,b in data.items():
            target=root/rel
            if not target.exists():
                target.parent.mkdir(parents=True,exist_ok=True)
                fd,tmp=tempfile.mkstemp(prefix='.codex-inspection-10446-',dir=target.parent)
                try:
                    with os.fdopen(fd,'wb') as stream:
                        stream.write(b);stream.flush();os.fsync(stream.fileno())
                    os.chmod(tmp,0o644)
                    try:
                        os.link(tmp,target)
                    except FileExistsError:
                        assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256']
                finally:
                    os.unlink(tmp)
            assert hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256']
for rel,row in expected.items():
    b=fetch('https://corllenium.ai.dev-environment.site/'+quote(rel,safe='/')+'?inspection=10446-20261027')
    assert hashlib.sha256(b).hexdigest()==row['sha256'],rel
health_after=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
assert health_after['sha']==health_before['sha'] and health_after['db']['ok']
receipt=dict(files_per_root=32,http_hashes=32,preview=m['preview_url'],source_preview=m['source_preview_url'],source_triangles=15856,candidate_triangles=10446,preservation_passed=False,strict_passed=True,native_qualified_passed=True,full_signed='NOT_RUN',native_diagnostic_changed_pixels=129714,signed_targets_passed=False,remaining_target_counts=5407,accepted=False,archive_sha256=archive_sha,no_app_restart=True,api_sha_before_after=health_after['sha'],status_written=False,installer='exclusive hardlink; different existing bytes refused')
Path('/home/devenvir/corllenium/data/codex-inspection-10446-20261027-receipt.json').write_text(json.dumps(receipt)+'\n')
print(json.dumps(receipt))
