from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

root = Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
ops = root / 'data/siege-live-20261026'
package_path = root / '.claude/worktrees/v1n/data/transport-10446/package.json'
assert hashlib.sha256(package_path.read_bytes()).hexdigest() == 'b01a3d9032f050977d4d1fc0efcf6d7e96fec37211a817b16990b236557e5558'
package = json.loads(package_path.read_bytes())
deployment = json.loads((ops / 'inspection-10446-deployment.log').read_bytes())
assert deployment['files_per_root'] == deployment['http_hashes'] == 32
assert deployment['candidate_triangles'] == 10446 and deployment['source_triangles'] == 15856
assert deployment['strict_passed'] is deployment['native_qualified_passed'] is True
assert deployment['preservation_passed'] is deployment['accepted'] is deployment['status_written'] is False
assert deployment['full_signed'] == 'NOT_RUN' and deployment['remaining_target_counts'] == 5407
assert deployment['archive_sha256'] == '0180f505608da38072837ea2bd2af9ca8aa922629d4258d39f15138efaf181ba'
for row in package['files']:
    path = root / 'data/p446' / row['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
sys.path.insert(0, str(root / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023/tools'))
from main_infra_progress import load_progress, write_progress, utc_now

path = root / 'data/main-infra-fresh/current.json'
original_sha = hashlib.sha256(path.read_bytes()).hexdigest()
doc = load_progress(path)
other = copy.deepcopy({key: value for key, value in doc['floors'].items() if key != '1F'})
floor = doc['floors']['1F']
pending = copy.deepcopy(floor.get('pending_saved_candidate'))
assert pending['triangles'] == 10387 and pending['independent_validation'] == 'NOT_RUN'
floor.setdefault('prior_displayed_candidates', []).append({
    key: copy.deepcopy(floor.get(key)) for key in
    ('source_preview', 'candidate_preview', 'output_triangles', 'latest_saved_candidate',
     'validator_ref', 'validation_proof', 'evidence_refs')})
candidate = package['results']['candidate']
floor['latest_saved_candidate'] = dict(
    engine='E3', run_id='MAIN-INFRA-1F-THREE-SITE-RETENTION-20261027',
    builder_commit='426dd1cd718dbf4498b39982cd4f007f02a40b01', triangles=10446,
    original_triangles=15856, protected_original_parents=814,
    source_candidate_sha256=candidate['obj_sha256'],
    engine_candidate_sha256='400eb237b3427d9d19cf1ac47ae1b656557dbd5619aae040a34ce196267faf05',
    checkpoint_sha256='d0940450499114032219998b1c1fb47bedbb3d68f15866b1d88ee105ca26a1e0',
    independent_validation='strict_and_qualified_native_pass_full_signed_pending',
    strict_passed=True, native_qualified_passed=True, native_qualified_views=33,
    native_qualified_changed_pixels=0, native_diagnostic_changed_pixels=129714,
    preservation_passed=False, full_signed='NOT_RUN', full_signed_preservation='NOT_RUN',
    acceptance=False, displayed_candidate_triangles=10446, remaining_problems=candidate['counts'])
prefix = package['preview_url'].rsplit('/', 1)[0] + '/evidence-corrective10446-20261027/'
now = utc_now()
floor.update(
    source_preview=package['source_preview_url'], candidate_preview=package['preview_url'],
    output_triangles=10446, inspection_published=True, inspection_acceptance=False,
    inspection_receipt_sha256='b01a3d9032f050977d4d1fc0efcf6d7e96fec37211a817b16990b236557e5558',
    independent_before_triangles=15856, independent_after_triangles=10446,
    independent_guard_passed=True,
    independent_guard_sha256='08b3d62638837256158f7eb9175c4721cdd64c5ed924cac8c4e6a74194f05fc0',
    native_preservation_passed=True, native_qualified_changed_pixels=0, native_qualified_total_views=33,
    native_readback_sha256='bfd3c33ca9b1566ce12f3bdafcf2f4406618d21f0db3aed676ba91f57ce1c59c',
    native_diagnostic_changed_pixels=129714, validator_passed=False, validator_ref=None,
    evidence_refs=[prefix + name for name in
                   ('readback.json', 'guard.json', 'native.json', 'census.json', 'terminal.json',
                    'qualified.png', 'diagnostic.png', 'diagnostic_qualification.json', 'rgba_readback.json')],
    step='After now displays the corrective10,446-triangle model with original textures and all7measured error filters. Strict26 and33qualified textured views passed; full signed validation is pending. The newer10,387 E5 candidate remains separately queued for independent checks.',
    blocker='Displayed10446 still has5407 overlap/crack instances; fullsigned NOT_RUN. Diagnostic eye_0 differences are retained. Latest10387 needs its own checks.',
    last_work_event_at=now)
for key in ('validation_proof', 'signed_validation_sha256', 'validator_texture_preservation_passed',
            'validator_nothing_deleted_passed', 'validator_pixel_floor_passed',
            'retained_floor_passed', 'retained_floor_sha256'):
    floor.pop(key, None)
assert floor['accepted_preview'] is None and floor['owner_decision_ref'] is None
assert floor['pending_saved_candidate'] == pending
assert other == {key: value for key, value in doc['floors'].items() if key != '1F'}
floor.setdefault('activity_events', []).append(dict(
    at=now, phase='corrective10446_inspection_published',
    message='32assets verified in both static roots and byHTTP. Corrective10446 model and7real error maps replace old10549 inspection. Strict/native33 PASS; fullsigned pending; diagnostic eye_0 remains explicit. Newer10387 is a separate unvalidated candidate; no acceptance.'))
doc['updated_at'] = doc['last_work_event_at'] = now
draft = ops / 'inspection-10446-current.draft.json'
draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
subprocess.run(['node', str(ops / 'check-status-current.mjs'), str(draft)], check=True)
assert hashlib.sha256(path.read_bytes()).hexdigest() == original_sha, 'Concurrent canonical change; reload before writing'
write_progress(path, doc)
receipt = dict(displayed_1F=10446, pending_latest_1F=10387, measured_filters=7,
               strict26='PASS', native33='PASS', full_signed='NOT_RUN',
               native_diagnostic_changed_pixels=129714, remaining=5407,
               other_floors_unchanged=True, accepted=False,
               canonical_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(ops / 'inspection-10446-selection-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
