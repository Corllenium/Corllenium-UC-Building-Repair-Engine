"""Independent actual2F retained-output readback, default census and unchanged strict26."""
import argparse
from dataclasses import asdict, replace
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT.parents[2]
JOB = 'MAIN-INFRA-2F-NATIVE14-INDEPENDENT-20261027'
PRODUCER = 'MAIN-INFRA-2F-NATIVE14-RETENTION-20261027'
PRODUCER_BINDING = '968ec01a9e68ae64828901f5c7061fe1ce07c10aef04fc17490d2246468b2a28'
GUARDS = {'engine/guard/compare.py':'95cd6b9094025bd2776635cd65e7ad01d32577f7785199e825f4d090703d4e56',
          'engine/guard/exact_hits.py':'905a22cb0eb312eb5d81410c585a8ac6826524617e35d559e76fc9a7ac24c419'}
CENSUS_HELPER = '525f1430b17759824a9b339cab940457cb4d47f21987e4c666c2eaf7cef24551'


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')


def derive_actual(original_count, selected, checkpoint, data, run, marker, lineage, required, markers, prior_current, contacts):
    def ids(values, limit):
        need(values == sorted(set(values)) and all(type(i) is int and 0 <= i < limit for i in values), 'Invalid actual original/index partition')
    ids(required, original_count); ids(markers, original_count); ids(prior_current, original_count); ids(contacts, original_count)
    need(len(selected) == len(data['edits']) == checkpoint['planned'] == run['planned'], 'Actual selected count differs')
    seen = set()
    for expected, actual in zip(selected, data['edits']):
        need(all(actual.get(k) == expected[k] for k in ('engine','kind','legacy','site','faces','reason'))
             and actual['engine'] == 'E3' and actual['kind'] == 'remove' and actual['legacy'] is False
             and not seen.intersection(actual['faces']) and actual['faces']
             and all(actual.get(k) is None for k in ('new_faces','new_points','new_face_uv','new_face_normal')),
             'Actual complete original E3 edit changed')
        ids(sorted(actual['faces']), original_count); seen.update(actual['faces'])
    kept, rolled = data['kept'], data['rolled_back']; ids(kept, len(selected)); ids(rolled, len(selected))
    need(not set(kept) & set(rolled) and set(kept) | set(rolled) == set(range(len(selected)))
         and (len(kept),len(rolled)) == (checkpoint['kept'],checkpoint['rolled_back']) == (run['kept'],run['rolled_back']),
         'Actual kept/rollback partition differs')
    removed = {face for index in kept for face in data['edits'][index]['faces']}
    before_marker = [face for face in range(original_count) if face not in removed]
    need(checkpoint['output_triangles'] == marker['input_triangles'] == len(before_marker)
         and set(markers) <= set(before_marker), 'Actual checked survivor count/markers differ')
    current = [face for face in before_marker if face not in set(markers)]
    fresh = sorted({face for index in rolled for face in data['edits'][index]['faces']})
    mandatory = sorted(set(required) | set(fresh))
    need(not set(required) & set(markers) and set(mandatory) <= set(current)
         and set(prior_current) <= set(current) and set(contacts) <= set(required), 'Whole prior/protected/contact original lost')
    need(marker['removed_originals'] == markers and marker['source_faces'] == current
         and marker['selected_current'] == [i for i,face in enumerate(before_marker) if face in set(markers)]
         and marker['output_triangles'] == run['output_triangles'] == len(current)
         and run['reference_triangles'] == original_count-len(markers), 'Exact actual marker-only transition differs')
    need(run['original_source_survivors'] == current and run['old_protected_originals'] == required
         and run['fresh_rollback_originals'] == fresh and run['whole_required_originals'] == mandatory
         and run['source_priority_contacts'] == contacts and run['marker_receipt'] == marker
         and run['previous_verdict_transferred'] is False and run['acceptance'] is False, 'Producer self-report differs from independently derived actual')
    need(lineage['mode'] == 'original_source_survivors' and lineage['input_triangles'] == original_count
         and lineage['output_triangles'] == len(current) and lineage['source_faces'] == current, 'Actual cumulative saved ancestry differs')
    return dict(before_marker_originals=before_marker,current_originals=current,actual_triangles=len(current),
        mandatory_originals=mandatory,fresh_rollback_originals=fresh,numerical_K1_qualified=None,
        native='NOT_RUN',fullsigned='NOT_RUN',acceptance=False)


def bind_raw_quanta(expected, saved):
    return replace(saved, physical_quanta=expected.physical_quanta)


def verify_finite_whole_mesh(before, after, originals):
    from tools.main_infra_e3 import verify_survivor_mesh
    for mesh in (before,after):
        need(all(np.isfinite(getattr(mesh,name)).all() for name in ('positions','uvs','normals')),
             'Nonfinite original/saved arrays cannot establish direct preservation')
    verify_survivor_mesh(before,after,originals)
    return dict(method='direct_numpy_array_equal_no_K1',finite_original_and_saved=True,triangles=len(originals),
        exact_value_tables=['positions','uvs','normals'],exact_source_indexed_corners=['face_v','face_vt','face_vn'],
        exact_material_names=True,numerical_K1_qualified=None)


def verify_floor_fields(original, saved, originals):
    from tools.main_infra_e3 import _material_names
    direct = verify_finite_whole_mesh(original.mesh, saved.mesh, originals)
    need(saved.mesh.n_faces == len(originals), 'Complete saved SOURCE triangle partition required')
    for output, parent in enumerate(originals):
        left = original.polygons[original.triangle_polygon[parent]]
        right = saved.polygons[saved.triangle_polygon[output]]
        need((left.group,left.object_name) == (right.group,right.object_name), 'Original cut group/object lineage differs')
    return dict(triangles=len(originals),groups_and_objects_exact=True,corner_uv_normal_material_ancestry_exact=True,
                unassigned_material_faces=_material_names(saved.mesh).count(None),direct_whole_face_comparison=direct)


def module(pin, name):
    need(sha(pin['path']) == pin['sha256'], 'Paid helper changed')
    spec = importlib.util.spec_from_file_location(name,pin['path']); value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value; spec.loader.exec_module(value); return value


def verify_paid_context(role, producer, checkpoint, strict):
    helper = role['strict_helper']
    need(Path(helper['path']).resolve() == Path(strict['paths']['strict_guard_helper']).resolve()
         and helper['sha256'] == strict['hashes']['strict_guard_helper']
         and role['census_helper']['sha256'] == CENSUS_HELPER, 'Exact paid2F strict/default census helper required')
    pinned = {}
    for pin in role['pins']:
        path = Path(pin['path']).resolve()
        need(path not in pinned or pinned[path] == pin['sha256'], 'Conflicting actual2F frozen pin')
        pinned[path] = pin['sha256']
    paths = {str(i):pin['path'] for i,pin in enumerate(producer['pins'])}
    hashes = {str(i):pin['sha256'] for i,pin in enumerate(producer['pins'])}
    need(checkpoint['binding']['paths'] == paths and checkpoint['binding']['sha256'] == hashes,
         'Complete actual original E3 checkpoint input ancestry differs')
    need(set(checkpoint['files']) == {'arrays.npz','result.json','edit-log.jsonl'}, 'Complete actual E3 file inventory required')
    cp_folder = Path(role['refs']['checkpoint']['path']).parent
    consumed = [*producer['pins'],*producer['refs'].values(),*role['refs'].values(),helper,role['census_helper']]
    consumed += [dict(path=strict['paths'][key],sha256=strict['hashes'][key]) for key in ('reference','materials')]
    consumed += [dict(path=str(cp_folder/name),sha256=digest) for name,digest in checkpoint['files'].items()]
    need(all(pinned.get(Path(pin['path']).resolve()) == pin['sha256'] for pin in consumed),
         'Every actual2F consumed input/checkpoint/helper must be frozen')


def verify_asset_receipt(expected, reported):
    need(len(expected) == 10 and reported == expected, 'Actual2F asset names/hashes differ from qualified original')


def context(path, expected):
    need(sha(path) == expected, 'Independent actual2F role changed'); role = read(path)
    need(role['job_id'] == JOB and role['acceptance'] is False and role['producer_binding']['sha256'] == PRODUCER_BINDING
         and Path(role['out']).resolve() == ROOT/'data/iv2n/actual', 'Actual independent2F role required')
    for pin in [role['producer_binding'],*role['pins']]:
        need(sha(pin['path']) == pin['sha256'], 'Actual2F consumed role/input changed: '+pin['path'])
    for rel, expected_sha in GUARDS.items():
        need(sha(ROOT/rel) == expected_sha, 'Corrected paid2F strict guard bytes differ')
    b = read(role['producer_binding']['path']); refs = role['refs']
    run, cp, data, marker, lineage, terminal = (read(refs[k]['path']) for k in ('run','checkpoint','result','marker','lineage','terminal'))
    phase = read(refs['producer_phase']['path'])
    need(b['job_id'] == run['job_id'] == PRODUCER and run['input_binding_sha256'] == PRODUCER_BINDING
         and run['executing_HEAD'] == b['executing_HEAD'] == terminal['HEAD']
         and terminal['actual_exit_code'] == terminal['launcher_exit_code'] == 0 and terminal['all_owned_exited'] is True
         and terminal['abort_reason'] is None and terminal['actual_pid'] == role['producer_actual_pid']
         and terminal['phase_plan_sha256'] == refs['producer_phase']['sha256']
         and '--check-only' not in phase['args'] and PRODUCER_BINDING in phase['args'], 'Actual closed corrected2F producer terminal differs')
    need(cp['mode'] == 'actual_checked_e3_checkpoint' and cp['capture_only'] is True
         and cp['binding']['input_binding_sha256'] == PRODUCER_BINDING and cp['binding']['builder_commit'] == b['executing_HEAD']
         and run['checkpoint_sha256'] == marker['checkpoint_sha256'] == refs['checkpoint']['sha256'], 'Actual E3 capture role differs')
    verify_paid_context(role,b,cp,read(b['refs']['strict']['path']))
    closure = read(b['refs']['closure']['path']); records = [json.loads(line) for line in Path(b['refs']['original_log']['path']).read_text().splitlines()]
    from tools.main_infra_e3_replay import _original_edit
    restore = set(closure['conservative_restore_sites']); selected = []
    for row in records[:-1]:
        if row.get('rolled_back',False) or row['site'] in restore:
            continue
        edit = _original_edit(row,56828)
        selected.append(dict(engine=edit.engine,kind=edit.kind,legacy=edit.legacy,site=edit.site,faces=list(edit.faces),reason=edit.reason))
    required = closure['protected_originals']; contacts = closure['protected_contact_originals']
    prior = [row[0] for row in read(b['refs']['current_lineage']['path'])['original_source_faces']]
    need(len(selected) == 1045 and len(restore) == 20 and len(required) == 8717 and len(contacts) == 7,
         'Exact frozen corrected2F selected/protected/restored scope differs')
    facts = derive_actual(56828,selected,cp,data,run,marker,lineage,required,list(range(56804,56828)),prior,contacts)
    need(run['source_sha256'] == refs['source']['sha256'] and run['engine_sha256'] == refs['engine']['sha256']
         and len(run['assets']) == 10, 'Actual saved2F SOURCE/ENGINE/assets role differs')
    from tools.jobs import get
    claim = get(MAIN,JOB)
    need((claim['status'],claim['holder'],claim['branch']) == ('claimed','Codex-2F-Native14-IV',
         'codex/main-infra-2f-native14-independent-20261027'), 'Independent2F claim differs')
    return role,b,run,cp,facts


def readback(role,b,run,cp,facts):
    from engine.io.minecraft_floor import Frame,parse_floor
    from engine.io.obj_reader import read_obj
    from engine.io.mtl import parse_mtl
    from engine.validate.checks import load_looks
    from tools.main_infra_e3 import load_qualified_floor,source_survivors
    from tools.main_infra_e3_checkpoint import restore_e3_checkpoint
    r = b['refs']; refs = role['refs']; strict = read(r['strict']['path'])
    source,engine,original,receipt = load_qualified_floor(raw=r['raw']['path'],reference=strict['paths']['reference'],
        baseline=Path(r['before_engine']['path']).parent,qualification=r['qualification']['path'])
    need(source.mesh.n_faces == original.n_faces == 56828 and len(receipt['assets']) == 10, 'Original2F RAW/Frame/source context differs')
    verify_asset_receipt(receipt['assets'],run['assets'])
    raw_parent = Path(r['raw']['path']).parent
    looks = load_looks(strict['paths']['materials'],[(parse_mtl(raw_parent/source.mesh.mtllib),raw_parent)])
    actual = restore_e3_checkpoint(original,looks,Path(refs['checkpoint']['path']).parent,
        binding=cp['binding'],expected_receipt_sha256=refs['checkpoint']['sha256'])
    need(source_survivors(original,actual).tolist() == facts['before_marker_originals'], 'Actual typed E3 survivor geometry differs')
    checked_direct = verify_finite_whole_mesh(original,actual.mesh,facts['before_marker_originals'])
    final = facts['current_originals']; marker_free = list(range(56804)); proofs = {}
    for label,ids in [('candidate',final),('reference',marker_free)]:
        source_key,engine_key = ('source','engine') if label == 'candidate' else ('reference_source','reference_engine')
        saved_source = parse_floor(Path(refs[source_key]['path']).read_text(encoding='utf8'))
        saved_engine = parse_floor(Path(refs[engine_key]['path']).read_text(encoding='utf8'))
        proofs[label] = verify_floor_fields(source,saved_source,ids)
        proofs[label]['engine_direct_whole_face_comparison'] = verify_finite_whole_mesh(original,saved_engine.mesh,ids)
        for index,parent in enumerate(ids):
            expected_poly = source.polygons[source.triangle_polygon[parent]]
            actual_poly = saved_engine.polygons[saved_engine.triangle_polygon[index]]
            need((expected_poly.group,expected_poly.object_name) == (actual_poly.group,actual_poly.object_name), 'ENGINE group/object lineage differs')
        for asset in receipt['assets']:
            for parent in [raw_parent,Path(r['before_engine']['path']).parent,Path(refs[source_key]['path']).parent,Path(refs[engine_key]['path']).parent]:
                need(sha(parent/asset['path']) == asset['sha256'], 'Original2F asset changed')
    after = bind_raw_quanta(engine.mesh,read_obj(refs['engine']['path']))
    before = bind_raw_quanta(engine.mesh,read_obj(refs['reference_engine']['path']))
    need(len(final) == after.n_faces and before.n_faces == 56804 and original.physical_quanta == engine.mesh.physical_quanta
         and run['original_RAW_axis_quanta'] == list(original.physical_quanta), 'Original RAW precision or saved counts differ')
    proof = dict(facts,original_RAW_context=receipt,saved_pairs=proofs,actual_checkpoint_sha256=refs['checkpoint']['sha256'],
        actual_checkpoint_direct_whole_face_comparison=checked_direct,
        actual_default_checks=run['unchanged_default_checks'],numerical_K1_warning_is_not_a_verdict_or_waiver=True,
        before_sha256=refs['reference_engine']['sha256'],after_sha256=refs['engine']['sha256'])
    return source,engine.frame,original,before,after,proof


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('phase',choices=('metadata','readback','census','guard'))
    parser.add_argument('--role','--binding',dest='role',type=Path,required=True)
    parser.add_argument('--role-sha256','--binding-sha256',dest='role_sha256',required=True); args = parser.parse_args()
    role,b,run,cp,facts = context(args.role,args.role_sha256); out = Path(role['out'])
    if args.phase == 'metadata':
        print(json.dumps(dict(owner_geometry_loaded=False,actual_triangles=facts['actual_triangles'],whole_required=len(facts['mandatory_originals']),native='NOT_RUN',fullsigned='NOT_RUN',acceptance=False))); return 0
    source,frame,original,before,after,proof = readback(role,b,run,cp,facts)
    context(args.role,args.role_sha256)
    if args.phase == 'readback':
        save(out/'independent-readback.json',proof); print(json.dumps(dict(readback_sha256=sha(out/'independent-readback.json'),actual_triangles=after.n_faces,acceptance=False))); return 0
    if args.phase == 'guard':
        helper = module(role['strict_helper'],'unchanged_paid_independent2f_strict')
        names = {name:i for i,name in enumerate(before.materials)}
        need(set(after.materials) <= set(names), 'Saved guard material namespace differs')
        guarded = replace(after,materials=before.materials.copy(),face_material=np.array([-1 if i<0 else names[after.materials[int(i)]] for i in after.face_material],np.int64))
        report,tolerance = helper.strict_guard(before,guarded,source.mesh,read(b['refs']['provenance']['path']))
        context(args.role,args.role_sha256)
        result = dict(proof,guard=asdict(report),tolerance_inches=tolerance,corrected_numerical_components=GUARDS,
            views=26,resolution=[900,600],reference_triangles=56804,native='NOT_RUN',fullsigned='NOT_RUN',acceptance=False)
        save(out/'independent-guard.json',result); print(json.dumps(dict(passed=report.passed,guard_sha256=sha(out/'independent-guard.json'),totals=asdict(report)['totals'],acceptance=False)))
        return 0 if report.passed else 2
    shared = module(role['census_helper'],'unchanged_paid_default2f_census')
    raw = shared.save_raw_pair(original,after,out/'census'); results = {}
    for kind,label,mesh,display,pin,engine_pin,doc in [('source','before',original,source.mesh,b['refs']['before_source'],b['refs']['before_engine'],raw[0]),
            ('candidate','after',after,__import__('engine.io.obj_reader',fromlist=['read_obj']).read_obj(role['refs']['source']['path']),role['refs']['source'],role['refs']['engine'],raw[1])]:
        raw_path = out/'census'/('census-'+label+'.raw.json')
        binding = dict(source_revision=shared.REV,run_id=shared.RUN,floor_id='MAIN_INFRA_2F',kind=kind,obj_sha256=pin['sha256'])
        provenance = dict(raw_census_sha256=sha(raw_path),engine_obj_sha256=engine_pin['sha256'],source_obj_sha256=pin['sha256'],role_sha256=args.role_sha256)
        mapped = shared.bind_display(doc,mesh,display,frame,binding,provenance,floor_id='MAIN_INFRA_2F')
        target = out/'census'/('errors-'+kind+'.json'); save(target,mapped)
        results[kind] = dict(path=str(target),sha256=sha(target),raw_path=str(raw_path),raw_sha256=sha(raw_path),counts=doc['counts'],n_faces=mesh.n_faces)
    context(args.role,args.role_sha256); save(out/'census/census-receipt.json',dict(job_id=JOB,actual_triangles=after.n_faces,results=results,
        profile='unchanged default find_errors/FixProfile',native='NOT_RUN',fullsigned='NOT_RUN',acceptance=False))
    print(json.dumps(dict(results=results,native='NOT_RUN',fullsigned='NOT_RUN',acceptance=False))); return 0


if __name__ == '__main__':
    raise SystemExit(main())
