"""Root's independent readback of the exact owner-approved seven-floor dropout."""
import hashlib
import json
from pathlib import Path

from tools.main_infra_orange_survivor_proof import verify_survivors

ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT.parents[2]
BUILDER=MAIN/'.claude/worktrees/omb'
AUTH='81c02db5fca5eda121549533cca06a23e14c160860246af9613deedc652b6dfb'
PLAN='0ab4ddf4d12b50ec525e8f6bf8861decb3d4c755819b6259555f690e1d0eb970'


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def checked(row):
    p=Path(row['path'])
    if sha(p)!=row['sha256']:raise ValueError('Independent input hash mismatch: '+str(p))
    return p


def main():
    authority_path=ROOT/'docs/superpowers/records/MAIN-INFRA-ORANGE-BOX-VALIDATE-20261026/root-exact-selection.json'
    authority=json.loads(checked(dict(path=str(authority_path),sha256=AUTH)).read_bytes())
    plan_path=BUILDER/'data/orange-preflight/cleanup-plan.json'
    plan=json.loads(checked(dict(path=str(plan_path),sha256=PLAN)).read_bytes())
    if len(authority['floors'])!=7 or len(plan['engine_pairs'])!=7:raise ValueError('Seven roles required')
    inventory_plan=json.loads(checked(plan['inventory_plan']).read_bytes())
    inventory=json.loads(checked(inventory_plan['inventory']).read_bytes())
    outputs=BUILDER/'data/orange-cleanup/run-20261026'
    receipt=json.loads((outputs/'cleanup-receipt.json').read_bytes())
    if len(receipt['floors'])!=7 or receipt['root_selection_sha256']!=AUTH or receipt['plan_sha256']!=PLAN:raise ValueError('Actual seven-floor receipt differs')
    results=[]
    for selected,row,pair in zip(authority['floors'],inventory['floors'],plan['engine_pairs']):
        floor=selected['floor'];base=outputs/floor
        if floor!=row['floor'] or floor!=pair['floor']:raise ValueError('Ordered floor roles differ')
        audit=json.loads((base/'candidate/stage-audit.json').read_bytes());cp=base/'execution/checkpoint.json'
        capture=json.loads(cp.read_bytes())
        if sha(cp)!=audit['checkpoint_sha256'] or sha(cp.parent/'arrays.npz')!=capture['arrays_sha256'] or capture['checkpoint_before_model_writer'] is not True:raise ValueError('Actual prewriter checkpoint differs')
        roles=[('candidate_source',selected['candidate'],base/'candidate/candidate.source.obj',selected['selected_current']),
               ('candidate_engine',pair['candidate_engine'],base/'candidate/candidate.engine.obj',selected['selected_current']),
               ('reference_source',selected['source'],base/'reference/before.source.obj',selected['selected_original']),
               ('reference_engine',pair['source_engine'],base/'reference/before.engine.obj',selected['selected_original'])]
        proofs={}
        for name,before,after,removed in roles:
            if cp.stat().st_mtime_ns>after.stat().st_mtime_ns:raise ValueError('Checkpoint saved after model output')
            result=verify_survivors(checked(before).read_bytes(),after.read_bytes(),removed)
            if sha(after)!=audit[name+'_sha256']:raise ValueError('Saved OBJ audit binding differs')
            proofs[name]=dict(result,before_sha256=before['sha256'],after_sha256=sha(after),path=str(after))
        kept=proofs['candidate_source']['kept_faces']
        old=json.loads(checked(selected['lineage']).read_bytes())
        parents=old['source_faces'] if old['mode']=='original_source_survivors' else [f['original_source_triangle'] for f in old['faces']]
        lineage=json.loads((base/'candidate/source-faces.json').read_bytes())
        if lineage['source_faces']!=kept or lineage['original_source_faces']!=[[parents[i]] for i in kept]:raise ValueError('Independent original ancestry differs')
        if not set(selected['protected_contact_originals'])<={parents[i] for i in kept}:raise ValueError('Nonmarker touching facade faces were lost')
        assets=[]
        for asset in row['assets']:
            for folder in ('candidate','reference'):
                p=base/folder/asset['relative']
                if sha(p)!=asset['sha256']:raise ValueError('Original texture/material asset changed')
            assets.append(dict(relative=asset['relative'],sha256=asset['sha256']))
        results.append(dict(floor=floor,passed=True,approved_original_faces=selected['selected_original'],approved_input_faces=selected['selected_current'],
            proofs=proofs,assets=assets,protected_contact_originals=selected['protected_contact_originals'],full_floor_acceptance=False))
    for pin in plan['pins']:checked(pin)
    out=ROOT/'data/orange-independent/run-20261026';out.mkdir(parents=True,exist_ok=False)
    result=dict(job_id='MAIN-INFRA-ORANGE-BOX-VALIDATE-20261026',reviewer='/root',builder='/root/main_infra_delivery_review',
        authority_sha256=AUTH,builder_plan_sha256=PLAN,builder_receipt_sha256=sha(outputs/'cleanup-receipt.json'),
        removal_only_preservation_passed=True,components_removed=14,triangles_removed=168,floors=results,
        geometry_guard_not_replaced=True,full_floor_target_validation='NOT_REEVALUATED',full_floor_acceptance=False)
    path=out/'independent-marker-proof.json'
    with path.open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(path=str(path),sha256=sha(path),passed=True,floors=7,components_removed=14,triangles_removed=168,full_floor_acceptance=False)))


if __name__=='__main__':main()
