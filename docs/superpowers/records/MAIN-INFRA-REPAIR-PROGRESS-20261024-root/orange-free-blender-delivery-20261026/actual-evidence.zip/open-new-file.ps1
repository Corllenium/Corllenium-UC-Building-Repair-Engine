$ErrorActionPreference='Stop'
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskBlend="$taskRoot/data/blender-review/MAIN-INFRA-7FLOORS-NOT_FINAL-20261026-ORANGE-REMOVED-R3/MAIN-INFRA-NOT_FINAL-ALL-FLOORS.blend"
$taskExe='C:/Program Files/Blender Foundation/Blender 5.1/blender.exe'
if((Get-FileHash -LiteralPath $taskBlend -Algorithm SHA256).Hash.ToLowerInvariant() -ne '9b681781e68fd2715ab0a1cbe3f1588858ae1f70283ee92f397acdd9f32e3c47'){throw 'Verified overview file changed'}
if((Get-FileHash -LiteralPath $taskExe -Algorithm SHA256).Hash.ToLowerInvariant() -ne '1e6624af112b3c936f4b038b025ebd2bf00ae72c4b62881a6787166d71c58fa5'){throw 'Blender executable changed'}
$taskNative='D:/LLM_BACKUP/Codex session/main-infra-resource-monitor-v5-20261024/05-Corllenium-UC-Building-Repair-Engine/docs/superpowers/records/MAIN-INFRA-RESOURCE-MONITOR-V5-20261024/execute-resource-guard-v5.ps1'
if((Get-FileHash -LiteralPath $taskNative -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'f158802651c955b6b322140ff9567496c527cd1bac0e63598171c45eeea60e12'){throw 'Native memory observer changed'}
. $taskNative -FunctionsOnly
$taskSamples=@()
for($taskIndex=0;$taskIndex -lt 3;$taskIndex++){
 $taskMemory=[UcE7ExecNative]::SystemMemory();$taskHeadroom=$taskMemory[1]-$taskMemory[0]
 $taskSamples+=@{utc=[DateTime]::UtcNow.ToString('o');headroom_bytes=$taskHeadroom}
 if($taskHeadroom -lt 12GB){throw 'Interactive overview launch held for memory'}
 Start-Sleep -Milliseconds 500
}
$env:TEMP='D:/TEMP';$env:TMP='D:/TEMP'
$taskArgs=@('--factory-startup','--disable-autoexec',('"'+$taskBlend+'"'))
$taskProcess=Start-Process -FilePath $taskExe -ArgumentList $taskArgs -WindowStyle Normal -PassThru
$taskBirth=$taskProcess.StartTime.ToUniversalTime().ToString('o')
$taskWait=[Diagnostics.Stopwatch]::StartNew();$taskLoaded=$false;$taskTitle=''
while($taskWait.Elapsed.TotalSeconds -lt 30){
 if($taskProcess.HasExited){throw 'New Blender window exited before loading'}
 $taskProcess.Refresh();$taskTitle=$taskProcess.MainWindowTitle
 if($taskTitle.Contains('MAIN-INFRA-NOT_FINAL-ALL-FLOORS.blend')){$taskLoaded=$true;break}
 Start-Sleep -Milliseconds 250
}
$taskReceipt=[ordered]@{pid=$taskProcess.Id;start_utc=$taskBirth;observed_utc=[DateTime]::UtcNow.ToString('o');path=$taskBlend;sha256='9b681781e68fd2715ab0a1cbe3f1588858ae1f70283ee92f397acdd9f32e3c47';new_separate_process=$true;loaded_file_title_verified=$taskLoaded;window_title=$taskTitle;headroom_samples=$taskSamples;old_window_modified=$false;acceptance=$false}
[IO.File]::WriteAllText("$taskRoot/data/blender-review/MAIN-INFRA-7FLOORS-NOT_FINAL-20261026-ORANGE-REMOVED-R3/interactive-open.json",($taskReceipt|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
$taskReceipt|ConvertTo-Json -Depth 5 -Compress
if(-not $taskLoaded){exit 2}
