import hashlib
import json
import builtins
from types import SimpleNamespace

import pytest

from tools import main_infra_blender_review as review


def pin(path):
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)


def case(tmp_path):
    before = b'mtllib a.mtl\nv 0 0 0\nv 1 0 0\nv 0 1 0\nusemtl minecraft_wool_colored_orange_-1\n'
    marker = b'f 1 2 3\n'
    before += marker*24+b'usemtl facade\nf 1 3 2\n'
    old = tmp_path/'old.source.obj'; old.write_bytes(before)
    new = tmp_path/'new.source.obj'; new.write_bytes(before.replace(marker, b''))
    selection = dict(floor='1F', source=pin(old), candidate=pin(old), selected_current=list(range(24)))
    authority = dict(owner_quote='also you can delete the orange box okay thats fine to delete for all floors',
                     selection_reviewer='/root', full_floor_acceptance=False, all_other_geometry_protected=True,
                     marker_components=14, approved_candidate_faces=168, floors=[selection])
    p = tmp_path/'authority.json';p.write_text(json.dumps(authority))
    row = dict(floor='1F',source=pin(old),candidate=pin(new),
        source_lexical=dict(used_materials=['facade','minecraft_wool_colored_orange_-1']),
        candidate_lexical=dict(used_materials=['facade']),
        approved_marker_dropout=dict(authority=pin(p),input=pin(old)))
    return row,p


def test_obj_census_counts_only_materials_referenced_by_faces(tmp_path):
    p=tmp_path/'sample.source.obj'
    p.write_text('mtllib a.mtl\nusemtl unused_marker\nusemtl facade\nf 1 2 3\nusemtl another_unused\n')
    assert review._obj(p)==(1,['a.mtl'],['facade'])


def test_exact_authorized_marker_only_dropout_can_keep_original_before_materials(tmp_path):
    row,_=case(tmp_path)
    helper=getattr(review,'marker_dropout_pins',None)
    assert helper is not None,'Missing explicit orange-box review adapter'
    assert helper(row)==[row['approved_marker_dropout']['authority'],row['approved_marker_dropout']['input']]


def test_standalone_blender_script_does_not_require_repo_package_import(tmp_path,monkeypatch):
    row,_=case(tmp_path)
    original=builtins.__import__
    def standalone(name,*args,**kwargs):
        if name.startswith('tools'):raise ModuleNotFoundError('No repo package in standalone Blender')
        return original(name,*args,**kwargs)
    monkeypatch.setattr(builtins,'__import__',standalone)
    assert review.marker_dropout_pins(row)==[row['approved_marker_dropout']['authority'],row['approved_marker_dropout']['input']]


class Material(dict):
    def __init__(self,name):super().__init__();self.name=name


def test_unused_marker_slot_is_retained_without_treating_it_as_a_used_facade():
    used,unused=Material('facade.001'),Material('minecraft_wool_colored_orange_-1')
    obj=SimpleNamespace(data=SimpleNamespace(materials=[used,unused],polygons=[SimpleNamespace(material_index=0)]))
    helper=getattr(review,'bind_used_materials',None)
    assert helper is not None,'Missing polygon-used material identity binder'
    helper(obj,{'facade':{}})
    assert used['review_original_material']=='facade' and not unused and len(obj.data.materials)==2


def test_unexpected_used_material_still_fails():
    obj=SimpleNamespace(data=SimpleNamespace(materials=[Material('wrong')],polygons=[SimpleNamespace(material_index=0)]))
    helper=getattr(review,'bind_used_materials',None)
    assert helper is not None,'Missing polygon-used material identity binder'
    with pytest.raises(ValueError):helper(obj,{'facade':{}})


@pytest.mark.parametrize('kind',['wrong_quote','wrong_source','wrong_input','extra_loss','other_material','self_acceptance'])
def test_review_exception_never_permits_other_loss_or_unbound_authority(tmp_path,kind):
    row,p=case(tmp_path)
    if kind in ('wrong_quote','self_acceptance'):
        d=json.loads(p.read_bytes());d['owner_quote' if kind=='wrong_quote' else 'full_floor_acceptance']='wrong' if kind=='wrong_quote' else True
        p.write_text(json.dumps(d));row['approved_marker_dropout']['authority']=pin(p)
    elif kind=='wrong_source':row['source']['sha256']='0'*64
    elif kind=='wrong_input':row['approved_marker_dropout']['input']['sha256']='0'*64
    elif kind=='other_material':row['source_lexical']['used_materials'].append('another_facade')
    else:
        f=tmp_path/'new.source.obj';f.write_bytes(f.read_bytes().replace(b'f 1 3 2\n',b''));row['candidate']=pin(f)
    helper=getattr(review,'marker_dropout_pins',None)
    assert helper is not None,'Missing explicit orange-box review adapter'
    with pytest.raises(ValueError):helper(row)
