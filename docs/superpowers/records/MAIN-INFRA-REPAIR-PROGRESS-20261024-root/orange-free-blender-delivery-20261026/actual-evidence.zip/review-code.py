"""Create and inspect an isolated seven-floor file without granting repair acceptance."""
import argparse
from array import array
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import struct
import subprocess
import sys

FLOORS = [str(i)+"F" for i in range(1, 8)]


def _hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _checked(row):
    path = Path(row['path'])
    if not path.is_file() or _hash(path) != row['sha256'] or ('bytes' in row and path.stat().st_size != row['bytes']):
        raise ValueError('Review input changed: '+str(path))
    return path


def _write_new(path, data):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(data, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())


def _obj(path):
    faces, libraries, materials = 0, [], set()
    material = None
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if line.startswith('f '):
            if len(line.split()) != 4:
                raise ValueError('Review requires the saved triangular SOURCE OBJ')
            faces += 1
            if material is not None: materials.add(material)
        elif line.startswith('mtllib '): libraries.append(line[7:].strip())
        elif line.startswith('usemtl '): material = line[7:].strip()
    return faces, libraries, sorted(materials)


def marker_dropout_pins(row):
    helper_path = Path(__file__).with_name('main_infra_orange_survivor_proof.py')
    spec = importlib.util.spec_from_file_location('_review_marker_survivor_proof', helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    MARKER, verify_survivors = helper.MARKER, helper.verify_survivors
    source = set(row['source_lexical']['used_materials'])
    candidate = set(row['candidate_lexical']['used_materials'])
    if source-candidate != {MARKER} or candidate-source:
        raise ValueError('Only the explicitly approved orange marker look may become unused')
    binding = row.get('approved_marker_dropout', {})
    if set(binding) != {'authority', 'input'}:
        raise ValueError('Exact marker dropout authority and prior saved candidate required')
    authority = json.loads(_checked(binding['authority']).read_bytes())
    if (authority.get('owner_quote') != 'also you can delete the orange box okay thats fine to delete for all floors'
            or authority.get('selection_reviewer') != '/root' or authority.get('full_floor_acceptance') is not False
            or authority.get('all_other_geometry_protected') is not True
            or authority.get('marker_components') != 14 or authority.get('approved_candidate_faces') != 168):
        raise ValueError('Scoped reviewed marker authority required')
    rows = [r for r in authority['floors'] if r['floor'] == row['floor']]
    if (len(rows) != 1 or rows[0]['source']['sha256'] != row['source']['sha256']
            or rows[0]['candidate']['sha256'] != binding['input']['sha256']
            or len(rows[0]['selected_current']) != 24):
        raise ValueError('Reviewed original and saved candidate identities differ')
    before, after = _checked(binding['input']), _checked(row['candidate'])
    verify_survivors(before.read_bytes(), after.read_bytes(), rows[0]['selected_current'])
    return [binding['authority'], binding['input']]


def expected_materials(row, role):
    definitions = {}
    for library in row[role+'_lexical']['mtllib']:
        current = None
        for line in (Path(row[role]['path']).parent/library).read_text(encoding='utf-8-sig').splitlines():
            if line.startswith('newmtl '): current = line[7:].strip()
            elif line.startswith('map_Kd ') and current:
                texture = line[7:].strip().replace('\\', '/')
                if current in definitions and definitions[current] != texture:
                    raise ValueError('Ambiguous used material texture')
                definitions[current] = texture
    assets = {a['relative'].replace('\\', '/'): a for a in row['assets']}
    result = {}
    for name in row[role+'_lexical']['used_materials']:
        texture = definitions.get(name)
        if texture not in assets or not texture.lower().endswith('.png'):
            raise ValueError('Used material has no pinned qualified PNG: '+name)
        asset = assets[texture]
        result[name] = dict(sha256=asset['sha256'], dimensions=asset['dimensions'])
    return result


def validate_materials(expected, actual):
    if {m['original'] for m in actual} != set(expected):
        raise ValueError('Used material coverage differs')
    for material in actual:
        images = material['textures']
        wanted = dict(expected[material['original']], interpolation='Closest', packed=True)
        if material['double_sided'] is not True or images != [wanted]:
            raise ValueError('Used material must resolve its packed qualified nearest PNG on both sides')


def bind_used_materials(obj, expected):
    for index in sorted({p.material_index for p in obj.data.polygons}):
        material = obj.data.materials[index]
        if material is None: raise ValueError('Used imported material is missing')
        candidates = [name for name in expected if material.name == name or (
            material.name.startswith(name+'.') and material.name[len(name)+1:].isdigit())]
        if len(candidates) != 1: raise ValueError('Imported material identity is ambiguous')
        material['review_original_material'] = candidates[0]


def review_camera(bounds):
    if (len(bounds) != 2 or any(len(v) != 3 for v in bounds)
            or not all(math.isfinite(x) for v in bounds for x in v)
            or any(a > b for a, b in zip(*bounds))):
        raise ValueError('Finite ordered actual mesh bounds required')
    center = [(a+b)/2 for a, b in zip(*bounds)]
    span = max(math.dist(*bounds), .1)
    direction = (1., -1., .8)
    length = math.sqrt(sum(x*x for x in direction))
    return dict(target=center, position=[c+d/length*span*2 for c, d in zip(center, direction)],
        projection='ORTHO', ortho_scale=span*1.12, clip_start=.001, clip_end=span*12)


def validate_reopened_snapshot(receipt, actual):
    expected = receipt['snapshot']
    if ([r['floor'] for r in actual['floors']] != FLOORS or actual != expected
            or actual['start_scene'] != ('ALL_FLOORS_NOT_FINAL' if 'overview' in actual else '1F_NOT_FINAL') or not actual['viewport_shading']
            or any(v != 'MATERIAL' for v in actual['viewport_shading'])):
        raise ValueError('Reopened seven-floor meshes, material bindings or initial view differ')
    for floor in actual['floors']:
        if set(floor['roles']) != {'source', 'candidate'} or any(not floor['roles'][r] for r in floor['roles']):
            raise ValueError('Both saved mesh roles are required')
    if 'overview' in actual:
        overview = actual['overview']
        if (overview['scene'] != 'ALL_FLOORS_NOT_FINAL' or overview['floor_collections'] != FLOORS
                or [r['floor'] for r in overview['floors']] != FLOORS):
            raise ValueError('Seven named overview floor collections required')
        for row in overview['floors']:
            if row['world_bounds'] != [[v+row['translation'][i] for i, v in enumerate(p)] for p in row['local_bounds']]:
                raise ValueError('Overview must use only whole-floor translation')
            matrix = [[float(i == j) for j in range(4)] for i in range(4)]
            for i in range(3): matrix[i][3] = row['translation'][i]
            if set(row['roles']) != {'source', 'candidate'}: raise ValueError('Both overview roles required')
            for role, instance in row['roles'].items():
                if (instance['collection'] != row['floor']+'_'+role.upper()+'_NOT_FINAL'
                        or instance['instance_type'] != 'COLLECTION' or instance['matrix_world'] != matrix
                        or instance['hide_viewport'] != (role == 'source') or instance['hide_render'] != (role == 'source')):
                    raise ValueError('Overview instance role, rigid transform or visibility differs')
        for index, row in enumerate(overview['floors']):
            for other in overview['floors'][index+1:]:
                if not any(row['world_bounds'][1][i] < other['world_bounds'][0][i]
                           or other['world_bounds'][1][i] < row['world_bounds'][0][i] for i in (0, 1)):
                    raise ValueError('Overview floor footprints overlap')


def overview_layout(bounds):
    if set(bounds) != set(FLOORS): raise ValueError('Seven floor bounds required')
    for pair in bounds.values():
        if (len(pair) != 2 or any(len(p) != 3 for p in pair)
                or any(not math.isfinite(v) for p in pair for v in p)
                or any(pair[0][i] > pair[1][i] for i in range(3))):
            raise ValueError('Finite ordered floor bounds required')
    width = max(p[1][0]-p[0][0] for p in bounds.values())
    height = max(p[1][1]-p[0][1] for p in bounds.values())
    gap = max(width, height, 1.)*.15
    rows = []
    for index, floor in enumerate(FLOORS):
        local = bounds[floor]
        translation = [(index % 4)*(width+gap)-local[0][0], (index // 4)*(height+gap)-local[0][1], -local[0][2]]
        rows.append(dict(floor=floor, local_bounds=local, translation=translation,
            world_bounds=[[v+translation[i] for i, v in enumerate(p)] for p in local]))
    return rows


def snapshot_differences(expected, actual, path='$'):
    if expected == actual:
        return []
    if isinstance(expected, dict) and isinstance(actual, dict):
        return [row for key in sorted(set(expected) | set(actual)) for row in snapshot_differences(
            expected.get(key, '<missing>'), actual.get(key, '<missing>'), path+'.'+key)]
    if isinstance(expected, list) and isinstance(actual, list):
        result = [] if len(expected) == len(actual) else [dict(path=path+'.length', expected=len(expected), actual=len(actual))]
        return result + [row for i, (left, right) in enumerate(zip(expected, actual))
                         for row in snapshot_differences(left, right, path+'['+str(i)+']')]
    return [dict(path=path, expected=expected, actual=actual)]

def load_review_inputs(inventory_path, inventory_sha, importer_path, importer_sha, output, *, review_root):
    inventory_path, importer_path = Path(inventory_path), Path(importer_path)
    output, review_root = Path(output).resolve(), Path(review_root).resolve()
    if (not output.is_relative_to(review_root) or output.suffix != '.blend' or 'NOT_FINAL' not in output.name
            or output.exists() or output.with_suffix('.receipt.json').exists()):
        raise ValueError('New exclusive NOT_FINAL review output and receipt required')
    _checked(dict(path=str(inventory_path), sha256=inventory_sha))
    _checked(dict(path=str(importer_path), sha256=importer_sha))
    data = json.loads(inventory_path.read_bytes())
    rows = data.get('floors', [])
    if data.get('schema_version') != 1 or [r.get('floor') for r in rows] != FLOORS:
        raise ValueError('Exactly seven ordered floor roles required')
    pins = [dict(path=str(inventory_path), sha256=inventory_sha), dict(path=str(importer_path), sha256=importer_sha)]
    for row in rows:
        if (row.get('not_final') is not True or row.get('accepted') is not False
                or not row.get('frame', '').startswith('source-local metres, +Y up')):
            raise ValueError('SOURCE metres and NOT_FINAL status required')
        for role in ('source', 'candidate'):
            path = _checked(row[role])
            if not path.name.endswith('.source.obj'):
                raise ValueError('ENGINE OBJ cannot be used for review')
            faces, libraries, materials = _obj(path)
            lex = row[role+'_lexical']
            if (faces != lex['faces'] or libraries != lex['mtllib'] or materials != sorted(lex['used_materials'])
                    or len(materials) != lex['material_count'] or not lex['all_faces_triangles']):
                raise ValueError('Saved SOURCE OBJ census differs')
            pins.append(row[role])
        if 'approved_marker_dropout' in row:
            pins.extend(marker_dropout_pins(row))
        elif row['source_lexical']['used_materials'] != row['candidate_lexical']['used_materials']:
            raise ValueError('Source/candidate material identities differ')
        relatives = set()
        for asset in row['assets']:
            relative = PurePosixPath(asset['relative'].replace('\\', '/'))
            if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or str(relative) in relatives:
                raise ValueError('Unsafe or duplicate review asset')
            relatives.add(str(relative))
            path, original = _checked(asset), Path(asset['qualified_source_path'])
            if (path.resolve() != Path(row['candidate']['path']).parent.joinpath(*relative.parts).resolve()
                    or original.resolve() != Path(row['source']['path']).parent.joinpath(*relative.parts).resolve()
                    or asset['qualified_source_sha256'] != asset['sha256']):
                raise ValueError('Review asset role or source identity differs')
            _checked(dict(path=str(original), sha256=asset['sha256'], bytes=asset['bytes']))
            if path.suffix.lower() == '.png':
                raw = path.read_bytes()
                if raw[:8] != b'\x89PNG\r\n\x1a\n' or len(raw) < 24 or list(struct.unpack('>II', raw[16:24])) != asset['dimensions']:
                    raise ValueError('PNG dimensions differ')
            pins.extend([asset, dict(path=str(original), sha256=asset['sha256'], bytes=asset['bytes'])])
        for proof in row.get('proofs', []):
            _checked(proof)
            pins.append(proof)
        if any(library not in relatives for library in row['candidate_lexical']['mtllib']):
            raise ValueError('Missing pinned material library')
        for role in ('source', 'candidate'): expected_materials(row, role)
    total = sum(r['candidate_lexical']['faces'] for r in rows)
    if total != data['selected_candidate_faces']:
        raise ValueError('Seven-floor candidate total differs')
    return dict(inventory=dict(path=str(inventory_path), sha256=inventory_sha),
        importer=dict(path=str(importer_path), sha256=importer_sha), output=str(output), review_root=str(review_root),
        floors=rows, input_pins=pins, acceptance=False, placement='separate_floor_local_scenes', candidate_triangles=total)


def assert_isolated_blender():
    import bpy
    if not bpy.app.background or bpy.data.filepath:
        raise ValueError('Only a fresh background factory-startup Blender is permitted')


def install_exclusive(staging, destination):
    os.link(staging, destination)
    if _hash(staging) != _hash(destination):
        raise ValueError('Installed review file differs')


def _material_records(obj):
    result = []
    for index in sorted({p.material_index for p in obj.data.polygons}):
        material = obj.data.materials[index]
        if material is None or not material.use_nodes:
            raise ValueError('Used imported material is missing')
        output = next(n for n in material.node_tree.nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output)
        pending, visited, images = [output], set(), []
        while pending:
            node = pending.pop()
            if node in visited: continue
            visited.add(node)
            if node.type == 'TEX_IMAGE':
                image = node.image
                if image is None or image.packed_file is None:
                    raise ValueError('Connected texture is not packed')
                images.append(dict(sha256=hashlib.sha256(image.packed_file.data).hexdigest(), dimensions=list(image.size),
                    interpolation=node.interpolation, packed=True))
            for socket in node.inputs:
                pending.extend(link.from_node for link in socket.links)
        result.append(dict(original=material['review_original_material'], double_sided=not material.use_backface_culling,
            textures=sorted(images, key=lambda i:i['sha256'])))
    return result


def _mesh_record(obj):
    mesh = obj.data
    mesh.calc_loop_triangles()
    points = array('f', [0.]) * (len(mesh.vertices)*3)
    mesh.vertices.foreach_get('co', points)
    triangles = array('i', [0]) * (len(mesh.loop_triangles)*3)
    mesh.loop_triangles.foreach_get('vertices', triangles)
    indices = array('i', [0]) * len(mesh.polygons)
    mesh.polygons.foreach_get('material_index', indices)
    result = dict(object=obj.name, vertices=len(mesh.vertices), triangles=len(mesh.loop_triangles),
        display_float32_positions_sha256=hashlib.sha256(points.tobytes()).hexdigest(), indices_sha256=hashlib.sha256(triangles.tobytes()).hexdigest(),
        material_indices_sha256=hashlib.sha256(indices.tobytes()).hexdigest(), materials=[m.name if m else None for m in mesh.materials],
        used_materials=_material_records(obj), matrix_world=[list(v) for v in obj.matrix_world])
    if mesh.uv_layers.active:
        uv = array('f', [0.]) * (len(mesh.loops)*2)
        mesh.uv_layers.active.data.foreach_get('uv', uv)
        result['uv_sha256'] = hashlib.sha256(uv.tobytes()).hexdigest()
    return result


def _floor_bounds(floor):
    import bpy
    points = [obj.matrix_world @ vertex.co for role in ('source', 'candidate')
        for obj in bpy.data.collections[floor+'_'+role.upper()+'_NOT_FINAL'].objects if obj.type == 'MESH'
        for vertex in obj.data.vertices]
    return [[function(p[i] for p in points) for i in range(3)] for function in (min, max)]


def _overview_snapshot():
    import bpy
    scene = bpy.data.scenes['ALL_FLOORS_NOT_FINAL']
    hidden = [obj for floor in FLOORS for obj in bpy.data.collections[floor].objects if obj.hide_viewport]
    try:
        for obj in hidden: obj.hide_viewport = False
        scene.view_layers[0].update()
    finally:
        for obj in hidden: obj.hide_viewport = True
    rows = []
    for floor in FLOORS:
        collection = bpy.data.collections[floor]
        if len(collection.objects) != 2: raise ValueError('Only two role instances per overview floor required')
        roles = {obj['review_role']:dict(collection=obj.instance_collection.name, instance_type=obj.instance_type,
            matrix_world=[list(r) for r in obj.matrix_world], hide_viewport=obj.hide_viewport, hide_render=obj.hide_render)
            for obj in collection.objects}
        translation = [roles['candidate']['matrix_world'][i][3] for i in range(3)]
        bounds = _floor_bounds(floor)
        rows.append(dict(floor=floor, local_bounds=bounds, translation=translation,
            world_bounds=[[v+translation[i] for i, v in enumerate(p)] for p in bounds], roles=roles))
    return dict(scene=scene.name, floor_collections=sorted(c.name for c in scene.collection.children), floors=rows,
        camera_matrix=[list(r) for r in scene.camera.matrix_world], ortho_scale=scene.camera.data.ortho_scale)


def _create_overview():
    import bpy
    from mathutils import Vector
    scene = bpy.data.scenes.new('ALL_FLOORS_NOT_FINAL')
    scene.unit_settings.system, scene.unit_settings.scale_length = 'METRIC', 1.
    scene['acceptance'], scene['placement'] = False, 'rigid_floor_instances_in_grid'
    layout = overview_layout({f:_floor_bounds(f) for f in FLOORS})
    for row in layout:
        collection = bpy.data.collections.new(row['floor'])
        scene.collection.children.link(collection)
        for role in ('source', 'candidate'):
            instance = bpy.data.objects.new(row['floor']+'_'+role.upper()+'_INSTANCE_NOT_FINAL', None)
            instance.instance_type = 'COLLECTION'
            instance.instance_collection = bpy.data.collections[row['floor']+'_'+role.upper()+'_NOT_FINAL']
            instance.location = row['translation']
            instance['review_role'], instance['acceptance'] = role, False
            instance.hide_render = role == 'source'
            collection.objects.link(instance)
    scene.view_layers[0].update()
    for floor in FLOORS: bpy.data.objects[floor+'_SOURCE_INSTANCE_NOT_FINAL'].hide_viewport = True
    boxes = [[[p[i]+bpy.data.objects[row['floor']+'_CANDIDATE_INSTANCE_NOT_FINAL'].location[i]
               for i in range(3)] for p in row['local_bounds']] for row in layout]
    bounds = [[function(box[corner][i] for box in boxes) for i in range(3)]
              for corner, function in ((0, min), (1, max))]
    target = [(bounds[0][i]+bounds[1][i])/2 for i in range(3)]
    extent = max(bounds[1][0]-bounds[0][0], bounds[1][1]-bounds[0][1], 1.)
    spec = dict(target=target, position=[target[0], target[1], bounds[1][2]+extent*2],
        ortho_scale=max(bounds[1][0]-bounds[0][0], (bounds[1][1]-bounds[0][1])*960/720)*1.12,
        projection='ORTHO', clip_start=.001, clip_end=extent*10+100)
    camera = bpy.data.objects.new('ALL_FLOORS_REVIEW_CAMERA', bpy.data.cameras.new('all_floors_review'))
    scene.collection.objects.link(camera)
    scene.camera = camera
    camera.location = spec['position']
    camera.rotation_euler = (Vector(spec['target'])-camera.location).to_track_quat('-Z', 'Y').to_euler()
    camera.data.type, camera.data.ortho_scale = 'ORTHO', spec['ortho_scale']
    camera.data.clip_start, camera.data.clip_end = spec['clip_start'], spec['clip_end']
    scene['review_camera'] = json.dumps(spec)
    scene.render.engine = 'BLENDER_EEVEE'
    scene.render.resolution_x, scene.render.resolution_y, scene.render.resolution_percentage = 960, 720, 100
    scene.render.image_settings.file_format, scene.render.image_settings.color_mode = 'PNG', 'RGBA'
    scene.view_settings.view_transform, scene.view_settings.look = 'Standard', 'None'
    scene.render.film_transparent, scene.render.dither_intensity = True, 0
    return scene


def _snapshot():
    import bpy
    result = dict(start_scene=bpy.context.window.scene.name, viewport_shading=sorted(
        a.spaces.active.shading.type for s in bpy.data.screens for a in s.areas if a.type == 'VIEW_3D'), floors=[])
    overview = 'ALL_FLOORS_NOT_FINAL' in bpy.data.scenes
    if {s.name for s in bpy.data.scenes} != {f+'_NOT_FINAL' for f in FLOORS} | ({'ALL_FLOORS_NOT_FINAL'} if overview else set()):
        raise ValueError('Unexpected saved scene')
    for floor in FLOORS:
        scene = bpy.data.scenes[floor+'_NOT_FINAL']
        scene.view_layers[0].update()
        roles = {role: sorted((_mesh_record(o) for o in bpy.data.collections[floor+'_'+role.upper()+'_NOT_FINAL'].objects
            if o.type == 'MESH'), key=lambda o:o['object']) for role in ('source', 'candidate')}
        result['floors'].append(dict(floor=floor, scene=scene.name, roles=roles, camera=json.loads(scene['review_camera']),
            camera_matrix=[list(v) for v in scene.camera.matrix_world], ortho_scale=scene.camera.data.ortho_scale,
            acceptance=scene['acceptance'], placement=scene['placement']))
    if overview:
        bpy.data.scenes['ALL_FLOORS_NOT_FINAL'].view_layers[0].update()
        result['overview'] = _overview_snapshot()
    return result


def build_review(plan):
    assert_isolated_blender()
    import bpy
    from mathutils import Vector
    if bpy.app.version_string != '5.1.2': raise ValueError('Qualified Blender5.1.2 required')
    for pin in plan['input_pins']: _checked(pin)
    output = Path(plan['output'])
    output.parent.mkdir(parents=True, exist_ok=False)
    try:
        spec = importlib.util.spec_from_file_location('qualified_review_importer', plan['importer']['path'])
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        bpy.ops.wm.read_factory_settings(use_empty=True)
        for index, row in enumerate(plan['floors']):
            scene = bpy.context.scene if index == 0 else bpy.data.scenes.new('review')
            scene.name = row['floor']+'_NOT_FINAL'
            scene.unit_settings.system, scene.unit_settings.scale_length = 'METRIC', 1.
            for key, value in dict(floor=row['floor'], inventory_sha256=plan['inventory']['sha256'], acceptance=False,
                                  status_json=json.dumps(row['status'], sort_keys=True), placement=plan['placement']).items(): scene[key] = value
            coords = []
            for role in ('source', 'candidate'):
                collection = bpy.data.collections.new(row['floor']+'_'+role.upper()+'_NOT_FINAL')
                scene.collection.children.link(collection)
                expected = expected_materials(row, role)
                with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0], collection=scene.collection):
                    objects = helper.imported(Path(row[role]['path']), 'source')
                for number, obj in enumerate(objects):
                    obj.name = row['floor']+'_'+role+'_'+str(number)
                    obj['source_obj_sha256'], obj['review_role'], obj['acceptance'] = row[role]['sha256'], role, False
                    for previous in list(obj.users_collection): previous.objects.unlink(obj)
                    collection.objects.link(obj)
                    bind_used_materials(obj, expected)
                    coords.extend(tuple(obj.matrix_world @ v.co) for v in obj.data.vertices)
                if sum(len(o.data.polygons) for o in objects) != row[role+'_lexical']['faces']:
                    raise ValueError('Imported triangle count differs')
                collection.hide_viewport = collection.hide_render = role == 'source'
            bounds = [[min(p[i] for p in coords) for i in range(3)], [max(p[i] for p in coords) for i in range(3)]]
            spec_camera = review_camera(bounds)
            scene['review_camera'] = json.dumps(spec_camera)
            camera = bpy.data.objects.new(row['floor']+'_REVIEW_CAMERA', bpy.data.cameras.new(row['floor']+'_review'))
            scene.collection.objects.link(camera)
            scene.camera = camera
            camera.location = spec_camera['position']
            camera.rotation_euler = (Vector(spec_camera['target'])-camera.location).to_track_quat('-Z', 'Y').to_euler()
            camera.data.type, camera.data.ortho_scale = 'ORTHO', spec_camera['ortho_scale']
            camera.data.clip_start, camera.data.clip_end = spec_camera['clip_start'], spec_camera['clip_end']
            scene.render.engine = 'BLENDER_EEVEE'
            scene.render.resolution_x, scene.render.resolution_y, scene.render.resolution_percentage = 960, 720, 100
            scene.render.image_settings.file_format, scene.render.image_settings.color_mode = 'PNG', 'RGBA'
            scene.view_settings.view_transform, scene.view_settings.look = 'Standard', 'None'
            scene.render.film_transparent, scene.render.dither_intensity = True, 0
        local_snapshot = None
        if plan.get('overview'):
            bpy.ops.file.pack_all()
            local_snapshot = _snapshot()
            _create_overview()
        for saved_scene in bpy.data.scenes: saved_scene.view_layers[0].update()
        bpy.context.window.scene = bpy.data.scenes['ALL_FLOORS_NOT_FINAL' if plan.get('overview') else '1F_NOT_FINAL']
        first_camera = bpy.context.window.scene.camera
        first = json.loads(bpy.context.window.scene['review_camera'])
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.spaces.active.shading.type = 'MATERIAL'
                    region = area.spaces.active.region_3d
                    region.view_location, region.view_distance = first['target'], first['ortho_scale']*1.5
                    region.view_rotation, region.view_perspective = first_camera.rotation_euler.to_quaternion(), 'ORTHO'
        bpy.data.texts.new('READ_ME_NOT_FINAL').write(json.dumps(dict(acceptance=False,
            note='Inspection only. Overview uses rigid floor instances; local inspect scenes and SOURCE/CANDIDATE collections remain available. Floor origins and grid are not building placement.',
            inventory=plan['inventory'], floors=[dict(floor=r['floor'], status=r['status']) for r in plan['floors']]), indent=2))
        bpy.ops.file.pack_all()
        snapshot = _snapshot()
        if local_snapshot is not None and snapshot['floors'] != local_snapshot['floors']:
            raise ValueError('Overview changed an underlying floor mesh, material or camera')
        for row, actual in zip(plan['floors'], snapshot['floors']):
            for role in ('source', 'candidate'):
                validate_materials(expected_materials(row, role), [m for obj in actual['roles'][role] for m in obj['used_materials']])
        if local_snapshot is not None: _write_new(output.parent/'build-snapshot.json', snapshot)
        validate_reopened_snapshot({'snapshot': snapshot}, snapshot)
        for pin in plan['input_pins']: _checked(pin)
        staging = output.parent/'incomplete.blend'
        bpy.ops.wm.save_as_mainfile(filepath=str(staging), compress=True)
        receipt = dict(schema_version=1, mode='seven_floor_NOT_FINAL_review', state='SAVED_NOT_REOPENED', acceptance=False,
            inventory=plan['inventory'], importer=plan['importer'], blend=dict(path=str(output), sha256=_hash(staging)),
            input_pins=plan['input_pins'], blender_version=bpy.app.version_string, placement=plan['placement'], snapshot=snapshot,
            source_files_unchanged=True, saved_reopen_verified=False, visual_inspection_verified=False, candidate_triangles=plan['candidate_triangles'])
        if local_snapshot is not None: receipt['underlying_floor_fingerprints_unchanged'] = True
        _write_new(output.with_suffix('.receipt.json'), receipt)
        install_exclusive(staging, output)
        return receipt
    except Exception as error:
        _write_new(output.parent/'failure.json', dict(acceptance=False, state='INCOMPLETE', error_type=type(error).__name__, error=str(error)))
        raise


def readback_review(receipt_path, receipt_sha, render_out, *, snapshot_only=False):
    import bpy
    receipt_path, render_out = Path(receipt_path), Path(render_out)
    _checked(dict(path=str(receipt_path), sha256=receipt_sha))
    receipt = json.loads(receipt_path.read_bytes())
    blend = _checked(receipt['blend'])
    if (not bpy.app.background or Path(bpy.data.filepath).resolve() != blend.resolve() or receipt['acceptance'] is not False
            or receipt['mode'] != 'seven_floor_NOT_FINAL_review' or render_out.exists()
            or not render_out.resolve().is_relative_to(blend.parent.resolve())):
        raise ValueError('Exact owned review blend and exclusive evidence directory required')
    snapshot = _snapshot()
    if snapshot_only:
        render_out.mkdir()
        _write_new(render_out/'actual-snapshot.json', snapshot)
        differences = snapshot_differences(receipt['snapshot'], snapshot)
        _write_new(render_out/'exact-differences.json', differences)
        for pin in receipt['input_pins']: _checked(pin)
        result = dict(diagnostic_only=True, acceptance=False, rendered=False, snapshot_equal=not differences,
            difference_count=len(differences), blend=receipt['blend'], receipt=dict(path=str(receipt_path), sha256=receipt_sha))
        _write_new(render_out/'diagnostic.json', result)
        validate_reopened_snapshot(receipt, snapshot)
        return result
    validate_reopened_snapshot(receipt, snapshot)
    for pin in receipt['input_pins']: _checked(pin)
    render_out.mkdir()
    images = []
    for floor in FLOORS:
        scene = bpy.data.scenes[floor+'_NOT_FINAL']
        for role in ('source', 'candidate'):
            for other in ('source', 'candidate'):
                bpy.data.collections[floor+'_'+other.upper()+'_NOT_FINAL'].hide_render = other != role
            path = render_out/(floor+'-'+role+'.png')
            scene.render.filepath = str(path)
            bpy.ops.render.render(write_still=True, scene=scene.name)
            if not path.is_file(): raise ValueError('Review render missing')
            images.append(dict(path=str(path), sha256=_hash(path), bytes=path.stat().st_size))
    if 'overview' in snapshot:
        scene = bpy.data.scenes['ALL_FLOORS_NOT_FINAL']
        path = render_out/'all-floors-overview.png'
        scene.render.filepath = str(path)
        bpy.ops.render.render(write_still=True, scene=scene.name)
        if not path.is_file(): raise ValueError('Overview render missing')
        images.append(dict(path=str(path), sha256=_hash(path), bytes=path.stat().st_size))
    _checked(receipt['blend'])
    for pin in receipt['input_pins']: _checked(pin)
    result = dict(schema_version=1, acceptance=False, saved_reopen_verified=True, visual_inspection_verified=False,
        receipt=dict(path=str(receipt_path), sha256=receipt_sha), blend=receipt['blend'], snapshot=snapshot, images=images,
        render_purpose='Review only; generated camera does not constitute an independent guard or Validator pass')
    _write_new(render_out/'readback.json', result)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('inventory', 'importer', 'output', 'review-root', 'receipt', 'render-out', 'blender'): parser.add_argument('--'+name, type=Path)
    for name in ('inventory-sha', 'importer-sha', 'receipt-sha', 'blender-sha'): parser.add_argument('--'+name)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--readback', action='store_true')
    parser.add_argument('--snapshot-only', action='store_true')
    parser.add_argument('--launch', action='store_true')
    parser.add_argument('--overview', action='store_true')
    args = parser.parse_args(argv)
    if args.launch:
        _checked(dict(path=str(args.blender), sha256=args.blender_sha))
        forwarded = list(argv if argv is not None else sys.argv[1:])
        for option, count in (('--launch', 1), ('--blender', 2), ('--blender-sha', 2)):
            i = forwarded.index(option)
            del forwarded[i:i+count]
        file_args = ['--factory-startup', '--disable-autoexec']
        if args.readback:
            _checked(dict(path=str(args.receipt), sha256=args.receipt_sha))
            file_args.append(str(_checked(json.loads(args.receipt.read_bytes())['blend'])))
        command = [str(args.blender), '--background', *file_args, '--python-exit-code', '13', '--python', str(Path(__file__).resolve()), '--', *forwarded]
        return subprocess.run(command, check=False).returncode
    if args.readback:
        result = readback_review(args.receipt, args.receipt_sha, args.render_out, snapshot_only=args.snapshot_only)
    else:
        plan = load_review_inputs(args.inventory, args.inventory_sha, args.importer, args.importer_sha, args.output, review_root=args.review_root)
        plan['overview'] = args.overview
        result = build_review(plan) if args.build else dict(metadata_only=True, acceptance=False, candidate_triangles=plan['candidate_triangles'], floors=FLOORS, input_pin_count=len(plan['input_pins']))
    print(json.dumps(result))
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else None))
