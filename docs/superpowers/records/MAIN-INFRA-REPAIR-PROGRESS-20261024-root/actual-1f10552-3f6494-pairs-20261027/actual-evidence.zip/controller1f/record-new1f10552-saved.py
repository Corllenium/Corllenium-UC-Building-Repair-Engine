from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

R = Path(__file__).resolve().parents[2]
W = R / '.claude/worktrees/l1n'
raw = (W / 'data/10549-e7-preflight/saved-10552-readback.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'f6f30b5591d1404506eb6a16cfd61316b61cb82b5f170b8a064101d7685ff877'
proof = json.loads(raw)
base = W / 'data/10549-e7-checked/run-20261027'
for row in proof['files']:
    path = base / row['path']
    data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
t = json.loads((W / 'data/10549-e7-preflight/monitor-1F10549-one-admitted-E7-default-checked-execute-20261026T191832/result.json').read_bytes())
assert t['actual_pid'] == 32420 and t['actual_exit_code'] == 0 and t['all_owned_exited'] and t['abort_reason'] is None
assert proof['all_protected_whole_and_corner_attributes_unchanged'] and proof['all_asset_hashes_exact']
sys.path.insert(0, str(R / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress, write_progress, utc_now

path = R / 'data/main-infra-fresh/current.json'
original = load_progress(path)
doc = copy.deepcopy(original)
f = doc['floors']['1F']
assert f['output_triangles'] == 10549 and f['accepted_preview'] is None
now = utc_now()
message = ('New 1F engine model saved: 10,552 triangles after one checked E7 cut, zero rollbacks. '
           'Saved-file checks preserve all 10,548 untouched face rows, 754 whole original faces, 829 source-priority locks, 100 anchors and seven assets. '
           'Independent error maps and preservation checks are next; After still displays older 10,549. No final-clean or acceptance claim.')
f.update(state='validating', step=message, blocker='New 10,552 model needs independent preservation checks and fresh signed-target counts.',
    pending_output_triangles=10552, worker_pid=32420, worker_start_utc=t['actual_creation_utc'], worker_alive=False,
    engine_worker_alive=False, worker_cpu_seconds=None, worker_observed_at=t['ended_utc'], last_work_event_at=now)
f['pending_saved_candidate'] = dict(kind='ORANGE_FREE_CHECKED_E7_OUTPUT', triangles=10552,
    source_sha256=proof['source_sha256'], engine_sha256=proof['engine_sha256'], checkpoint_sha256=proof['checkpoint_sha256'],
    kept=1, rolled_back=0, protected_originals=754, locked_faces=829, anchors=100, assets=7,
    builder_readback_sha256=hashlib.sha256(raw).hexdigest(), independent_validation='PENDING',
    default_error_census='NOT_RUN', strict26='NOT_RUN', native='NOT_RUN', full_signed='NOT_RUN', acceptance=False)
f['worker_events'].append(dict(engine='E7', run_id='MAIN-INFRA-1F-10549-ONE-E7-20261027',
    phase='current_e7_new10552_pair_saved', pid=32420, start_utc=t['actual_creation_utc'],
    observed_at=t['ended_utc'], message=message))
doc.update(updated_at=now, last_work_event_at=now, step=message, state='validating')
draft = R / 'data/siege-live-20261026/new1f10552-status-draft.json'
draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
subprocess.run(['node', str(R / 'data/siege-live-20261026/check-status-current.mjs'), str(draft)], check=True)
assert load_progress(path)['updated_at'] == original['updated_at']
write_progress(path, doc)
actual = load_progress(path)
for floor in original['floors']:
    if floor != '1F':
        assert actual['floors'][floor] == original['floors'][floor]
    for key in ('source_preview', 'candidate_preview', 'accepted_preview', 'owner_decision_ref', 'output_triangles'):
        assert actual['floors'][floor].get(key) == original['floors'][floor].get(key)
receipt = dict(at=now, saved=10552, displayed=10549, actual_source_sha256=proof['source_sha256'],
    builder_files_rehashed=len(proof['files']), independent_validation='PENDING',
    all_display_refs_unchanged=True, other_floor_rows_unchanged=True, accepted=False)
(R / 'data/siege-live-20261026/new1f10552-status-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
