from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

R = Path(__file__).resolve().parents[3]
OPS = Path(__file__).resolve().parent
sys.path.insert(0, str(R / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress, write_progress, utc_now

t = json.loads((OPS / 'monitor-3f-two-witness-fresh-e3-attempt2-20261026T185754/result.json').read_bytes())
raw = (OPS / 'actual-checkpoint-readback.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == '99c92b90157be8879c6c19e0523d759320caad57c4bee02dbea0c8d1ef05d1c2'
proof = json.loads(raw)
assert t['actual_pid'] == 61836 and t['actual_exit_code'] == 0 and t['all_owned_exited'] and t['abort_reason'] is None
assert proof['planned'] == proof['kept'] == 1410 and proof['rolled_back'] == 0 and proof['output_triangles'] == 44977
assert proof['whole_required_originals'] == 6494 and proof['all_whole_required_survive']
assert proof['model_serialized'] is False
path = R / 'data/main-infra-fresh/current.json'
original = load_progress(path)
doc = copy.deepcopy(original)
f = doc['floors']['3F']
assert f['worker_pid'] == 61836 and f['accepted_preview'] is None
now = utc_now()
message = ('3F fresh E3 repair finished: 1,410 checked edits kept, zero rollbacks; all 6,494 protected original faces survive. '
           'The new 44,977-triangle checked checkpoint is saved. Model export, approved orange-box removal and fresh E5 planning are next; '
           'no new model pair or independent floor verdict exists yet. After still displays older 44,948.')
f.update(state='cleaning', step=message, blocker='New checked checkpoint still needs model export and complete independent validation.',
    worker_alive=False, engine_worker_alive=False, worker_observed_at=t['ended_utc'], worker_cpu_seconds=None,
    last_work_event_at=now, latest_checked_checkpoint=dict(triangles=44977, planned=1410, kept=1410, rolled_back=0,
        sha256=proof['checkpoint_sha256'], result_sha256=proof['result_sha256'], protected_originals=6494,
        model_serialized=False, independent_validation='PENDING', acceptance=False))
f['worker_events'].append(dict(engine='E3', run_id='MAIN-INFRA-3F-E3-TWO-WITNESS-20261027',
    phase='fresh_e3_6494_checkpoint_complete', pid=61836, start_utc=t['actual_creation_utc'],
    observed_at=t['ended_utc'], message=message))
doc.update(updated_at=now, last_work_event_at=now, step=message, state='cleaning')
draft = OPS / 'terminal-status-draft.json'
draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
subprocess.run(['node', str(R / 'data/siege-live-20261026/check-status-current.mjs'), str(draft)], check=True)
assert load_progress(path)['updated_at'] == original['updated_at']
write_progress(path, doc)
actual = load_progress(path)
for floor in original['floors']:
    if floor != '3F':
        assert actual['floors'][floor] == original['floors'][floor]
    for key in ('source_preview', 'candidate_preview', 'accepted_preview', 'owner_decision_ref', 'output_triangles'):
        assert actual['floors'][floor].get(key) == original['floors'][floor].get(key)
receipt = dict(at=now, actual_worker_exited=True, checked_checkpoint=proof['checkpoint_sha256'],
    typed_triangles=44977, kept=1410, protected_originals=6494, model_pair_saved=False,
    all_display_refs_unchanged=True, other_floor_rows_unchanged=True, accepted=False)
(OPS / 'terminal-status-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
