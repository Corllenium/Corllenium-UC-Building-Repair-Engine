"""Check only the measured current E7 subset, then use the paid checkpoint and paired writer."""
import argparse,hashlib,json,subprocess
from dataclasses import replace
from pathlib import Path
import numpy as np
from engine.io.minecraft_floor import FloorInput,SourcePolygon,Frame,parse_floor
from engine.repair.types import apply_edits,UnitState,RepairContext
from engine.fixes.pipeline import FixProfile
from engine.repair.engines.e7_thread import E7Thread,_source_weights,_attributes
from tools.main_infra_e3 import _source_digest
from tools.main_infra_e7_checkpoint import typed_plan_digest,save_e7_checkpoint,restore_e7_checkpoint
from tools.main_infra_e7_serialization import _dump,_array,_tables,_checked,_seal as pair_seal,CutPair,save_cut_pair,_prove_exact_source_coverage
from tools.main_infra_e7_subset import VerifiedSubset,_look_ids,_seal,run_checked_subset
from tools.main_infra_10571_e7_plan import qualify_proposals
from tools.main_infra_10549_e7_plan import need,read_bound,bind_documents,subset_typed,PARTIAL_CP,UNCHANGED,JOB

ROOT=Path(__file__).resolve().parents[1]

def admit_current(source,before,rows,edits,report,looks,mandatory,locked,anchors):
    need(set(anchors)<=set(locked),'Every priority anchor must remain locked')
    fresh=qualify_proposals(source,before,rows,edits,mandatory,locked)
    need(all(fresh[k]==report[k] for k in fresh),'Fresh measured current admission differs')
    need(report['source_digest']==_source_digest(source).hex() and report['engine_digest']==_source_digest(before).hex(),'Measured current SOURCE/typed context differs')
    selected=tuple(edits[i] for i in fresh['admitted_indices']);need(selected,'No admitted current edits; no repair permitted')
    proof=dict(before_digest=_source_digest(before).hex(),typed_plan_digest=typed_plan_digest(selected),
        look_ids={str(k):v for k,v in _look_ids(before,looks).items()},selected_indices=fresh['admitted_indices'],
        source_digest=_source_digest(source).hex(),old_verdict_is_not_reused=True,acceptance=False)
    return VerifiedSubset(selected,proof,_seal(proof,selected))

def write_current_pair(source,frame,before,looks,rows,checkpoint,sha,binding,out,mandatory,locked,anchors,original_count):
    actual=restore_e7_checkpoint(before,looks,checkpoint,binding=binding,expected_receipt_sha256=sha)
    need(source.mesh.n_faces==before.n_faces==len(rows),'Complete current partial ancestry required')
    _tables(source.in_frame(frame).mesh,before)
    touched={e.faces[0] for e in actual.kept};protected=set(mandatory)
    need(not touched&set(locked) and set(anchors)<=set(locked) and not any(rows[i]['original_source_triangle'] in protected for i in touched),'Protected current parent cannot be edited')
    source_edits=[]
    for e in actual.kept:
        _prove_exact_source_coverage(source.mesh,e.faces[0],e.new_faces)
        _,weights,_,_=_source_weights(before,e.faces[0],e.new_faces)
        source_edits.append(replace(e,new_face_uv=_attributes(source.mesh,e.faces[0],weights,'face_vt','uvs'),new_face_normal=_attributes(source.mesh,e.faces[0],weights,'face_vn','normals')))
    source_before=replace(source.mesh,materials=before.materials.copy(),face_material=before.face_material.copy())
    source_after,_=apply_edits(source_before,source_edits);engine_after=actual.mesh
    for mesh,old in ((source_after,source_before),(engine_after,before)):
        _array(mesh.positions,old.positions,'no new/moved E7 points')
        for n in ('uvs','normals'):_array(getattr(mesh,n)[:len(getattr(old,n))],getattr(old,n),'unchanged current '+n+' prefix')
    for n in ('face_v','face_vt','face_vn','face_material','uvs'):_array(getattr(source_after,n),getattr(engine_after,n),'paired current '+n)
    _array(source_after.positions@frame.rotation.T*frame.inches_per_unit,engine_after.positions,'exact forward current positions')
    _array(source_after.normals@frame.rotation.T,engine_after.normals,'exact forward current normals')
    origins=[(i,None,None) for i in range(before.n_faces) if i not in touched]
    rank={id(e):i for i,e in enumerate(actual.edits)}
    for e in actual.kept:origins.extend((e.faces[0],rank[id(e)],child) for child in range(len(e.new_faces)))
    mapped=[];polygons=[]
    for output,(parent,edit_index,child) in enumerate(origins):
        polygons.append(source.polygons[source.triangle_polygon[parent]])
        row=dict(rows[parent],output_face=output,e7_input_face=parent,vertex_ids=source_after.face_v[output].tolist(),source_uv=source_after.face_vt[output].tolist(),source_normal=source_after.face_vn[output].tolist(),engine_uv=engine_after.face_vt[output].tolist(),engine_normal=engine_after.face_vn[output].tolist())
        if child is not None:row.update(kind='cut_child',inherited_kind=rows[parent]['kind'],e7_site=parent,edit_index=edit_index,child=child)
        mapped.append(row)
    for original in mandatory:
        kept=[x for x in mapped if x['original_source_triangle']==original]
        need(len(kept)==1 and kept[0]['kind']=='unchanged','Mandatory original must remain whole')
    for parent in locked:
        kept=[x for x in mapped if x['e7_input_face']==parent]
        need(len(kept)==1 and all(kept[0][k]==rows[parent][k] for k in UNCHANGED if k in rows[parent]),'Priority face corner/UV/material/group changed')
    def floor(mesh,physical):
        polys=tuple(SourcePolygon(p.line,tuple(zip(mesh.face_v[i],mesh.face_vt[i],mesh.face_vn[i])),int(mesh.face_material[i]),p.group,p.object_name) for i,p in enumerate(polygons))
        return FloorInput(mesh,polys,np.arange(mesh.n_faces),np.tile([0,1,2],(mesh.n_faces,1)),physical)
    paired_source,paired_engine=floor(source_after,None),floor(engine_after,frame)
    paths=dict(binding['paths'],checkpoint=str(Path(checkpoint)/'checkpoint-receipt.json'),edit_log=str(Path(checkpoint)/'edit-log.jsonl'))
    hashes=dict(binding['sha256'],checkpoint=sha,edit_log=hashlib.sha256(Path(paths['edit_log']).read_bytes()).hexdigest())
    pair_binding=dict(binding,paths=paths,sha256=hashes);checked,records=_checked(before,actual,looks,pair_binding)
    checked['original_source_triangles']=original_count
    lineage=dict(schema_version=1,mode='current_partial_ancestry_existing_vertex_E7',checkpoint_sha256=sha,input_triangles=before.n_faces,faces=mapped)
    pair=CutPair(paired_source,paired_engine,lineage,checked,records,pair_binding,pair_seal(paired_source,paired_engine,lineage,checked))
    return save_cut_pair(pair,out)

def execute_current(source,frame,before,looks,rows,edits,report,out,*,binding,mandatory,locked,anchors,original_count):
    subset=admit_current(source.mesh,before,rows,edits,report,looks,mandatory,locked,anchors)
    out=Path(out);need(not out.exists(),'Exclusive current E7 output required');out.mkdir(parents=True)
    actual=run_checked_subset(before,looks,subset)
    need(typed_plan_digest(actual.edits)==subset.proof['typed_plan_digest'],'Actual checked stage changed the admitted plan')
    checkpoint=save_e7_checkpoint(before,actual,looks,out/'checked-outcome',binding=binding)
    pair=write_current_pair(source,frame,before,looks,rows,out/'checked-outcome',checkpoint['receipt_sha256'],binding,out/'candidate',mandatory,locked,anchors,original_count)
    return dict(checkpoint_sha256=checkpoint['receipt_sha256'],pair=pair,planned=len(actual.edits),kept=len(actual.kept),rolled_back=len(actual.rolled_back),output_triangles=actual.mesh.n_faces,acceptance=False,independent_validation='PENDING',repair_complete=False)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',type=Path,required=True);parser.add_argument('--input-sha256',required=True);a=parser.parse_args()
    spec=json.loads(read_bound(dict(path=str(a.input),sha256=a.input_sha256)));need(spec['job_id']==JOB and spec['acceptance'] is False,'Owned current E7 repair scope required')
    head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();need(not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True).strip(),'Committed clean execution required')
    from tools.jobs import get
    claim=get(ROOT.parents[2],JOB);need(claim['holder']=='Codex-1F-10549-E7-Plan' and claim['status']=='claimed','Current checked job claim differs')
    plan=json.loads(read_bound(spec['plan_input']));raw={k:read_bound(v) for k,v in plan['refs'].items()};docs={k:json.loads(raw[k]) for k in plan['documents']};ctx=bind_documents(docs)
    from tools.main_infra_1f_e5_validation import typed_after
    from engine.io.obj_reader import read_obj
    from engine.io.mtl import parse_mtl
    from engine.validate.checks import load_looks
    partial,_,_=typed_after(plan['refs']['partial_checkpoint']['path'],PARTIAL_CP,'actual_checked_E5_exact_SOURCE_partial')
    before=subset_typed(partial,docs['marker_drop']['kept_current']);_tables(read_obj(plan['refs']['engine']['path']),before)
    source=parse_floor(raw['source'].decode('utf-8'));frame=Frame(1000/25.4,json.loads(raw['provenance'])['frame_evidence']);_tables(source.in_frame(frame).mesh,before)
    need(before.n_faces==10549 and (len(ctx['mandatory']),len(ctx['locked']),len(ctx['anchors']))==(754,829,100),'Actual current/protected cohort differs')
    need(all(row['vertex_ids']==source.mesh.face_v[i].tolist() and row['source_uv']==source.mesh.face_vt[i].tolist() and row['source_normal']==source.mesh.face_vn[i].tolist() and row['material']==source.mesh.materials[int(source.mesh.face_material[i])] for i,row in enumerate(ctx['rows'])),'Current SOURCE ancestry differs')
    report=json.loads(read_bound(spec['measured_plan']));need(report['input_refs']==plan['refs'] and report['admitted_indices']==[459] and report['sites'][459]['site']==10544 and report['sites'][459]['original_source_parent']==10734,'Exact measured one-site cohort required')
    edits=E7Thread().plan(UnitState(before,None,{},None),RepairContext(FixProfile(),None,None))
    current=Path(plan['refs']['source']['path']).parent;read_bound(spec['materials']);looks=load_looks(spec['materials']['path'],[(parse_mtl(current/source.mesh.mtllib),current)])
    need(not looks.unknown(before) and all(looks.key_of(n) in looks.flat or looks.key_of(n) in looks.texel for n in before.materials),'All current material/texture looks required')
    refs=dict(plan['refs'],plan_input=spec['plan_input'],measured_plan=spec['measured_plan'],materials=spec['materials'])
    binding=dict(run_id=spec['run_id'],floor='1F',builder_commit=head,before_digest=_source_digest(before).hex(),paths={k:v['path'] for k,v in refs.items()},sha256={k:v['sha256'] for k,v in refs.items()},current_source_sha256=plan['refs']['source']['sha256'],current_engine_sha256=plan['refs']['engine']['sha256'],ancestor_partial_checkpoint=PARTIAL_CP,whole_originals=ctx['mandatory'],locked_current_faces=ctx['locked'],anchor_current_faces=ctx['anchors'],independent10549_validation='NOT_RUN')
    out=Path(spec['output']);need(out.resolve().is_relative_to(ROOT/'data') and not out.exists(),'Exclusive owned execution required')
    result=execute_current(source,frame,before,looks,ctx['rows'],edits,report,out,binding=binding,mandatory=ctx['mandatory'],locked=ctx['locked'],anchors=ctx['anchors'],original_count=docs['validation']['before']['faces'])
    assets=[]
    for key,ref in plan['refs'].items():
        if not key.startswith('asset_'):continue
        target=out/'candidate'/Path(ref['path']).relative_to(current);need(not target.exists(),'Asset exists');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(read_bound(ref));need(hashlib.sha256(target.read_bytes()).hexdigest()==ref['sha256'],'Saved asset differs');assets.append(dict(path=str(target.relative_to(out/'candidate')),sha256=ref['sha256']))
    for ref in refs.values():read_bound(ref)
    result.update(binding=binding,assets=assets,state='candidate_saved',unchanged_default_checks=json.loads((out/'checked-outcome/result.json').read_bytes())['checks'])
    with (out/'run-receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,sort_keys=True)
    print(json.dumps(dict(output=str(out/'candidate'),output_triangles=result['output_triangles'],kept=result['kept'],rolled_back=result['rolled_back'],checkpoint_sha256=result['checkpoint_sha256'],acceptance=False,independent_validation='PENDING')))
    return 0

if __name__=='__main__':raise SystemExit(main())
