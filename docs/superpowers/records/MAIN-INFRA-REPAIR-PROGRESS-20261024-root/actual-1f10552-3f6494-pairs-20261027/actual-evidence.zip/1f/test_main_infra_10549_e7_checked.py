import copy,json
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pytest

def api():
    from tools import main_infra_10549_e7_checked as m
    return m

def fixture(rolled=False):
    from engine.io.minecraft_floor import parse_floor,Frame
    from engine.repair.types import UnitState,RepairContext,apply_edits
    from engine.fixes.pipeline import FixProfile
    from engine.repair.engines.e7_thread import E7Thread
    from engine.repair.kernel import KernelResult,stage_records
    from tools.main_infra_10571_e7_plan import qualify_proposals
    from tools.main_infra_e3 import _source_digest
    source=parse_floor('mtllib wall.mtl\nv 0 0 0\nv 2 0 0\nv 0 2 0\nv 1 0 0\nv 1 -1 0\nv 2 -1 0\nvt 0 0\nvt 1 0\nvt 0 1\nvt .5 0\nvt .5 -.5\nvt 1 -.5\ng partial-child\nusemtl wall\nf 1/1 2/2 3/3\ng unchanged\nf 4/4 5/5 6/6\n')
    frame=Frame(1.,'synthetic SOURCE Y-up');before=source.in_frame(frame).mesh;looks=SimpleNamespace(key_of=lambda n:'wall-look')
    edits=E7Thread().plan(UnitState(before,None,{},None),RepairContext(FixProfile(),None,None));assert len(edits)==1 and edits[0].site==0
    rows=[dict(output_face=i,original_source_triangle=100+i,kind='cut_child' if i==0 else 'unchanged',group=p.group,object_name=p.object_name) for i,p in enumerate(source.polygons)]
    report=qualify_proposals(source.mesh,before,rows,edits,[101],[1]);report.update(source_digest=_source_digest(source.mesh).hex(),engine_digest=_source_digest(before).hex())
    kept=[] if rolled else edits;after,_=apply_edits(before,kept)
    check=dict(stage='E7',engine='E7',legacy=False,rollback=True,rolled_back=[{'site':0}] if rolled else [],final='NOTHING KEPT' if rolled else 'PASS',runs=[dict(status='PASS',failing=0,unknown=0)])
    records=stage_records(before,edits,{0:'wall-look'},'E7')
    if rolled:records[0]['rolled_back']=True
    records.append({'check':check});outcome=KernelResult(after,None,edits,[],None,kept,edits if rolled else [],[check],records)
    return source,frame,before,looks,rows,edits,report,outcome

def run_fixture(m,tmp_path,monkeypatch,rolled=False):
    source,frame,before,looks,rows,edits,report,outcome=fixture(rolled)
    monkeypatch.setattr(m,'run_checked_subset',lambda *args:outcome)
    binding=dict(run_id='tiny-current',before_digest=m._source_digest(before).hex(),paths={},sha256={})
    result=m.execute_current(source,frame,before,looks,rows,edits,report,tmp_path/'run',binding=binding,mandatory=[101],locked=[1],anchors=[1],original_count=102)
    return source,before,result

def test_paid_checkpoint_precedes_writer_and_partial_ancestry_survives(tmp_path,monkeypatch):
    m=api();events=[];capture=m.save_e7_checkpoint;writer=m.save_cut_pair
    def wrapped_capture(*a,**kw):
        result=capture(*a,**kw);events.append('checkpoint');return result
    def wrapped_writer(pair,out):
        assert events==['checkpoint'] and (Path(pair.binding['paths']['checkpoint'])).is_file();events.append('writer');return writer(pair,out)
    monkeypatch.setattr(m,'save_e7_checkpoint',wrapped_capture);monkeypatch.setattr(m,'save_cut_pair',wrapped_writer)
    source,before,result=run_fixture(m,tmp_path,monkeypatch)
    assert events==['checkpoint','writer'] and result['kept']==1 and result['output_triangles']==3
    rows=json.loads((tmp_path/'run/candidate/cut-lineage.json').read_bytes())['faces']
    assert [x['original_source_triangle'] for x in rows]==[101,100,100]
    assert all(x['inherited_kind']=='cut_child' for x in rows[1:])
    from engine.io.minecraft_floor import parse_floor
    saved=parse_floor((tmp_path/'run/candidate/candidate.source.obj').read_text())
    assert saved.mesh.positions.tobytes()==source.mesh.positions.tobytes()
    assert saved.mesh.uvs[:len(source.mesh.uvs)].tobytes()==source.mesh.uvs.tobytes()
    assert saved.polygons[0].group=='unchanged' and saved.polygons[-1].group=='partial-child'

@pytest.mark.parametrize('change',['digest','admitted','reason','site','parent','new_points'])
def test_measured_admission_or_protected_scope_cannot_change(change):
    m=api();s,f,b,l,rows,edits,report,_=fixture();report=copy.deepcopy(report)
    if change=='digest':report['typed_plan_digest']='0'*64
    elif change=='admitted':report['admitted_indices']=[]
    elif change=='reason':report['sites'][0]['reason']='new waiver'
    elif change=='site':report['sites'][0]['site']=1
    elif change=='parent':rows[0]['original_source_triangle']=101
    else:edits=[replace(edits[0],new_points=np.empty((0,3)))]
    with pytest.raises(ValueError):m.admit_current(s.mesh,b,rows,edits,report,l,[101],[1],[1])

@pytest.mark.parametrize('mandatory,locked,anchors',[([100,101],[1],[1]),([101],[0,1],[1]),([101],[1],[0])])
def test_whole_original_locks_and_anchor_membership_are_mandatory(mandatory,locked,anchors):
    m=api();s,f,b,l,rows,edits,report,_=fixture()
    with pytest.raises(ValueError):m.admit_current(s.mesh,b,rows,edits,report,l,mandatory,locked,anchors)

def test_rolled_back_checked_outcome_is_preserved_without_claiming_repair(tmp_path,monkeypatch):
    m=api();s,b,result=run_fixture(m,tmp_path,monkeypatch,True)
    assert result['kept']==0 and result['rolled_back']==1 and result['output_triangles']==2 and result['acceptance'] is False

def test_writer_requires_authentic_unchanged_checkpoint(tmp_path):
    m=api();s,f,b,l,rows,edits,report,_=fixture()
    with pytest.raises((ValueError,FileNotFoundError)):m.write_current_pair(s,f,b,l,rows,tmp_path/'missing','0'*64,{},tmp_path/'candidate',[101],[1],[1],102)
    assert not (tmp_path/'candidate').exists()
