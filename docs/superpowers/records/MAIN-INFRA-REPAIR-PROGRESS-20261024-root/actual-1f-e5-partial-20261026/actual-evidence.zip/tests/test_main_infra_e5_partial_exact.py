from dataclasses import replace
import numpy as np
import pytest
from engine.io.minecraft_floor import Frame
from engine.model import MeshData

def source():
    p=np.array([[0.,0.,0.],[2.,0.,0.],[0.,2.,0.],[1.,0.,0.],[3.,0.,0.],[1.,2.,0.]])
    faces=np.array([[0,1,2],[3,4,5]])
    return MeshData('source',p,np.array([[0.,0.],[1.,0.],[0.,1.]]),np.empty((0,3)),faces,np.array([[0,1,2],[0,1,2]]),np.full((2,3),-1),np.array([0,1]),np.array([1,2]),['loser','winner'],None,15,17)

def call(s=None):
    from tools.main_infra_e5_partial_exact import plan_geometry
    s=source() if s is None else s
    frame=Frame(1.,'synthetic test physical frame')
    e=replace(s,positions=s.positions@frame.rotation.T,normals=s.normals@frame.rotation.T)
    return plan_geometry(s,e,0,1,frame)

def test_partial_exact_border_cut_keeps_existing_prefix_and_has_smaller_area():
    s=source();before=s.positions.tobytes();a,b,p=call(s)
    assert a.engine==b.engine=='E5' and a.kind=='cut' and a.faces==(0,)
    assert p['exact_source_border'] is True and p['remaining_twice_area']=='3'
    assert s.positions.tobytes()==before and p['new_source_points']==1

def test_new_point_is_on_winner_border_and_both_frames_agree():
    a,b,p=call();assert a.new_points.tolist()==[[1.,1.,0.]]
    assert b.new_points.tolist()==[[1.,0.,1.]] and np.array_equal(a.new_face_uv,b.new_face_uv)

def test_source_winding_is_preserved():
    a,_,_=call();points=np.vstack((source().positions,a.new_points))
    triangles=points[a.new_faces]
    assert (np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])[:,2]>0).all()

def test_complete_existing_vertex_table_is_used_before_invention():
    s=source();s.positions=np.vstack((s.positions,[1.,1.,0.]))
    a,b,p=call(s);assert a.new_points is b.new_points is None and p['new_source_points']==0 and 6 in a.new_faces

def test_nonbinary_border_intersection_is_refused():
    s=source();s.positions[1]=[3.,0.,0.];s.positions[3:]=[[1.,0.,0.],[4.,0.,0.],[1.,3.,0.]]
    with pytest.raises(ValueError,match='binary64'):call(s)

def test_offplane_source_pair_is_refused():
    s=source();s.positions[5,2]=1e-12
    with pytest.raises(ValueError,match='plane'):call(s)

def test_uvs_are_interpolated_from_losing_surface():
    a,b,p=call();points=np.vstack((source().positions,a.new_points))
    assert np.array_equal(a.new_face_uv,points[a.new_faces][...,:2]/2)
    assert p['uv_rounding_max_abs']==0

def test_missing_uvs_stay_missing():
    s=source();s.face_vt[:]=-1
    a,b,_=call(s);assert a.new_face_uv is b.new_face_uv is None

def test_partial_corner_uvs_fail_closed():
    s=source();s.face_vt[0,1]=-1
    with pytest.raises(ValueError,match='partial'):call(s)

def test_nonfinite_corner_attribute_is_refused():
    s=source();s.uvs[0,0]=np.nan
    with pytest.raises(ValueError,match='finite'):call(s)

def test_nonoverlap_is_not_a_repair_proposal():
    s=source();s.positions[3:,0]+=10
    with pytest.raises(ValueError,match='partial'):call(s)
