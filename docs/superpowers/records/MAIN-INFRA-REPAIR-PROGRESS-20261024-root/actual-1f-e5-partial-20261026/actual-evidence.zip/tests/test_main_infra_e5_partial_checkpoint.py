from dataclasses import replace
import hashlib
import json
import numpy as np
import pytest
from engine.io.minecraft_floor import FloorInput, Frame, SourcePolygon
from engine.validate.checks import Looks
from tools.tests.test_main_infra_e5_partial_exact import source
from tools.main_infra_e5_partial_exact import plan_geometry

@pytest.fixture(scope='module')
def checked():
    from tools.main_infra_e5_partial_checkpoint import run_checked
    s=source();polys=tuple(SourcePolygon(i+1,tuple(zip(s.face_v[i],s.face_vt[i],s.face_vn[i])),int(s.face_material[i]),'owner-cut','facade') for i in range(s.n_faces))
    floor=FloorInput(s,polys,np.arange(s.n_faces),np.tile([0,1,2],(s.n_faces,1)))
    frame=Frame(1.,'synthetic physical frame');before=floor.in_frame(frame).mesh
    a,b,_=plan_geometry(s,before,0,1,frame);looks=Looks({'loser':'flat','winner':'flat'},flat=frozenset({'flat'}))
    actual=run_checked(before,looks,[b])
    assert len(actual.kept)==1 and not actual.rolled_back
    lineage=[dict(output_face=i,original_source_triangle=100+i,kind='unchanged',group='owner-cut',object_name='facade') for i in range(2)]
    return floor,frame,before,looks,a,actual,lineage

def test_real_default_kernel_checkpoint_roundtrips(checked,tmp_path):
    from tools.main_infra_e5_partial_checkpoint import capture,restore
    floor,frame,before,looks,a,actual,rows=checked
    cp=capture(before,actual,looks,[a],tmp_path/'cp',binding={'case':'real-default'})
    got,source_edits,_=restore(before,looks,tmp_path/'cp',cp['receipt_sha256'],binding={'case':'real-default'})
    assert np.array_equal(got.mesh.positions,actual.mesh.positions) and len(got.kept)==1
    assert np.array_equal(source_edits[0].new_points,a.new_points)

def test_checkpoint_tampering_is_refused(checked,tmp_path):
    from tools.main_infra_e5_partial_checkpoint import capture,restore
    _,_,before,looks,a,actual,_=checked
    cp=capture(before,actual,looks,[a],tmp_path/'cp',binding={})
    (tmp_path/'cp/result.json').write_text('{}')
    with pytest.raises(ValueError):restore(before,looks,tmp_path/'cp',cp['receipt_sha256'],binding={})

def test_false_outcome_is_refused_before_capture(checked,tmp_path):
    from tools.main_infra_e5_partial_checkpoint import capture
    _,_,before,looks,a,actual,_=checked
    mesh=replace(actual.mesh,positions=actual.mesh.positions.copy());mesh.positions[0,0]+=.1
    with pytest.raises(ValueError):capture(before,replace(actual,mesh=mesh),looks,[a],tmp_path/'cp',binding={})

def test_source_pair_writer_requires_saved_checkpoint(checked,tmp_path):
    from tools.main_infra_e5_partial_checkpoint import write_pair
    floor,frame,before,looks,a,actual,rows=checked
    with pytest.raises((ValueError,FileNotFoundError)):write_pair(floor,frame,before,looks,rows,tmp_path/'absent','0'*64,{},tmp_path/'candidate')
    assert not (tmp_path/'candidate').exists()

def test_saved_pair_preserves_original_tables_and_owner_group(checked,tmp_path):
    from tools.main_infra_e5_partial_checkpoint import capture,write_pair
    from engine.io.minecraft_floor import parse_floor
    floor,frame,before,looks,a,actual,rows=checked
    cp=capture(before,actual,looks,[a],tmp_path/'cp',binding={})
    receipt=write_pair(floor,frame,before,looks,rows,tmp_path/'cp',cp['receipt_sha256'],{},tmp_path/'candidate')
    after=parse_floor((tmp_path/'candidate/candidate.source.obj').read_text())
    assert np.array_equal(after.mesh.positions[:len(floor.mesh.positions)],floor.mesh.positions)
    assert np.array_equal(after.mesh.uvs[:len(floor.mesh.uvs)],floor.mesh.uvs)
    assert all(p.group=='owner-cut' and p.object_name=='facade' for p in after.polygons)
    assert receipt['checkpoint_sha256']==cp['receipt_sha256'] and receipt['kept']==1
    saved=json.loads((tmp_path/'candidate/source-faces.json').read_text())
    assert saved['faces'][0]['original_source_triangle']==101
    assert all(r['original_source_triangle']==100 and r['kind']=='cut_child' for r in saved['faces'][1:])
