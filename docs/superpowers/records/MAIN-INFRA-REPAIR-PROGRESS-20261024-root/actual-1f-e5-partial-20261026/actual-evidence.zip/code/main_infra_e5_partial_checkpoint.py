"""Capture genuine checked E5 cuts before paired SOURCE serialization and composed ancestry."""
from dataclasses import fields,replace
import hashlib,json,tempfile
from pathlib import Path
import numpy as np
from engine.fixes.pipeline import FixProfile
from engine.io.minecraft_floor import FloorInput,SourcePolygon,write_floor
from engine.model import MeshData
from engine.repair.kernel import KernelResult,repair_unit,stage_records,write_records
from engine.repair.types import Edit,RepairContext,UnitState,apply_edits
from engine.site_judge import SiteJudge
from tools.main_infra_e3 import _source_digest
from tools.main_infra_e7_checkpoint import MESH_ARRAYS,_digest,_partition,typed_edits
from tools.main_infra_e7_serialization import _dump,_readback
from tools.main_infra_e5_partial_exact import plan_geometry,need

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run_checked(before,looks,edits):
    class BoundPartialE5:
        name='E5'
        def plan(self,unit,ctx):
            need(_source_digest(unit.mesh)==_source_digest(before),'Current partial input differs')
            return list(edits)
    return repair_unit(UnitState(before,None,{i:looks.key_of(n) for i,n in enumerate(before.materials)},None),RepairContext(FixProfile(),None,SiteJudge(looks)),engines=[BoundPartialE5()],validate_sites=True)

def verify(before,outcome,looks):
    need(outcome.result is None and outcome.report is None and not outcome.stages and len(outcome.checks)==1 and outcome.edits,'One genuine nonlegacy E5 stage required')
    kept,rolled=_partition(outcome)
    need(all(e.engine=='E5' and e.kind=='cut' and not e.legacy and len(e.faces)==1 and e.site==e.faces[0] for e in outcome.edits),'Only disjoint partial E5 cuts required')
    need(len({e.site for e in outcome.edits})==len(outcome.edits),'Duplicate partial sites')
    expected,_=apply_edits(before,outcome.kept);need(_source_digest(expected)==_source_digest(outcome.mesh),'Actual E5 outcome differs from kept cuts')
    c=outcome.checks[0]
    need(all(c.get(k)==v for k,v in dict(stage='E5',engine='E5',legacy=False,rollback=True).items()),'Unchanged default E5 stage required')
    need({r['site'] for r in c.get('rolled_back',[])}=={e.site for e in outcome.rolled_back},'Default rollback partition differs')
    if kept:need(c.get('final')=='PASS' and not c.get('stage_rolled_back') and not c.get('rounds_exhausted',False) and c['runs'][-1].get('status')=='PASS' and c['runs'][-1].get('failing')==c['runs'][-1].get('unknown',0)==0,'Fresh default E5 confirmation required')
    records=stage_records(before,outcome.edits,{i:looks.key_of(n) for i,n in enumerate(before.materials)},'E5')
    for i in rolled:records[i]['rolled_back']=True
    need(records+[{'check':c}]==outcome.records,'Actual E5 K1 records differ')
    return kept,rolled

def capture(before,outcome,looks,source_edits,out,*,binding):
    kept,rolled=verify(before,outcome,looks);need(len(source_edits)==len(outcome.edits),'Complete paired source edits required')
    out=Path(out);need(not out.exists(),'Checkpoint output exists');out.parent.mkdir(parents=True,exist_ok=True)
    edits,arrays=typed_edits(outcome.edits);sources,source_arrays=typed_edits(source_edits)
    for row in sources:
        for field in ('new_faces','new_points','new_face_uv','new_face_normal'):
            if row[field] is not None:row[field]='source_'+row[field]
    arrays.update({'source_'+k:v for k,v in source_arrays.items()});arrays.update({'mesh_'+k:getattr(outcome.mesh,k) for k in MESH_ARRAYS})
    data=dict(mesh={f.name:getattr(outcome.mesh,f.name) for f in fields(MeshData) if f.name not in MESH_ARRAYS},edits=edits,source_edits=sources,kept=kept,rolled_back=rolled,checks=outcome.checks,records=outcome.records)
    staging=Path(tempfile.mkdtemp(prefix=out.name+'.incomplete-',dir=out.parent));np.savez(staging/'arrays.npz',**arrays)
    (staging/'result.json').write_text(_dump(data),encoding='utf-8');write_records(staging/'edit-log.jsonl',outcome.records)
    cp=dict(schema_version=1,mode='actual_checked_E5_exact_SOURCE_partial',capture_only=True,binding=binding,before_digest=_source_digest(before).hex(),after_digest=_source_digest(outcome.mesh).hex(),planned=len(edits),kept=len(kept),rolled_back=len(rolled),output_triangles=outcome.mesh.n_faces,files={n:digest(staging/n) for n in ('arrays.npz','result.json','edit-log.jsonl')},arrays={k:_digest(v) for k,v in arrays.items()})
    (staging/'checkpoint-receipt.json').write_text(_dump(cp),encoding='utf-8');staging.rename(out)
    return dict(cp,receipt_sha256=digest(out/'checkpoint-receipt.json'))

def restore(before,looks,out,sha,*,binding):
    out=Path(out);need(digest(out/'checkpoint-receipt.json')==sha,'Checkpoint receipt differs');cp=json.loads((out/'checkpoint-receipt.json').read_bytes())
    need(cp['mode']=='actual_checked_E5_exact_SOURCE_partial' and cp['capture_only'] is True and cp['binding']==binding and cp['before_digest']==_source_digest(before).hex(),'Typed checkpoint context differs')
    need(set(cp['files'])=={'arrays.npz','result.json','edit-log.jsonl'} and all(digest(out/n)==h for n,h in cp['files'].items()),'Typed checkpoint file differs')
    with np.load(out/'arrays.npz',allow_pickle=False) as z:
        need(set(z.files)==set(cp['arrays']),'Typed array inventory differs');arrays={k:z[k] for k in z.files}
    need(all(not a.dtype.hasobject and _digest(a)==cp['arrays'][k] for k,a in arrays.items()),'Typed array digest differs')
    data=json.loads((out/'result.json').read_bytes());mesh=MeshData(**data['mesh'],**{k:arrays['mesh_'+k] for k in MESH_ARRAYS})
    def decode(rows):
        return [Edit(**dict(row,faces=tuple(row['faces']),**{k:None if row[k] is None else arrays[row[k]] for k in ('new_faces','new_points','new_face_uv','new_face_normal')})) for row in rows]
    edits=decode(data['edits']);sources=decode(data['source_edits'])
    actual=KernelResult(mesh,None,edits,[],None,[edits[i] for i in data['kept']],[edits[i] for i in data['rolled_back']],data['checks'],data['records'])
    kept,rolled=verify(before,actual,looks)
    need(cp['after_digest']==_source_digest(mesh).hex() and (cp['planned'],cp['kept'],cp['rolled_back'],cp['output_triangles'])==(len(edits),len(kept),len(rolled),mesh.n_faces),'Typed after/count differs')
    need([json.loads(line) for line in (out/'edit-log.jsonl').read_text().splitlines()]==actual.records,'Typed edit log differs')
    return actual,sources,cp

def write_pair(source,frame,before,looks,lineage,checkpoint,sha,binding,out):
    actual,sources,cp=restore(before,looks,checkpoint,sha,binding=binding)
    need(len(lineage)==source.mesh.n_faces==before.n_faces,'Complete composed input ancestry required')
    for e,s in zip(actual.edits,sources):
        fresh_source,fresh_engine,proof=plan_geometry(source.mesh,before,e.faces[0],e.evidence['winner'],frame)
        for old,fresh in ((s,fresh_source),(e,fresh_engine)):
            need(old.faces==fresh.faces and old.site==fresh.site,'Paired cut site differs')
            for name in ('new_faces','new_points','new_face_uv','new_face_normal'):
                a,b=getattr(old,name),getattr(fresh,name);need((a is b is None) or (a is not None and b is not None and np.array_equal(a,b)),'Paired cut array differs: '+name)
        need(all(e.evidence.get(k)==v for k,v in proof.items()),'Source cut proof differs')
    kept_identities={id(e) for e in actual.kept}
    source_after,_=apply_edits(source.mesh,[sources[i] for i in range(len(sources)) if id(actual.edits[i]) in kept_identities])
    engine_after=actual.mesh
    for name in ('face_v','face_vt','face_vn','face_material','uvs'):
        need(np.array_equal(getattr(source_after,name),getattr(engine_after,name)),'Paired SOURCE field differs: '+name)
    need(np.array_equal(source_after.positions@frame.rotation.T*frame.inches_per_unit,engine_after.positions) and np.array_equal(source_after.normals@frame.rotation.T,engine_after.normals),'Paired physical frame differs')
    touched={e.faces[0] for e in actual.kept};origins=[(i,None) for i in range(before.n_faces) if i not in touched]
    for edit in actual.kept:origins.extend((edit.faces[0],child) for child in range(len(edit.new_faces)))
    rows=[];polygons=[]
    for output,(parent,child) in enumerate(origins):
        poly=source.polygons[source.triangle_polygon[parent]];polygons.append(poly)
        row=dict(lineage[parent],output_face=output,e5_partial_input_face=parent,vertex_ids=source_after.face_v[output].tolist(),source_uv=source_after.face_vt[output].tolist(),source_normal=source_after.face_vn[output].tolist(),engine_uv=engine_after.face_vt[output].tolist(),engine_normal=engine_after.face_vn[output].tolist())
        if child is not None:row.update(kind='cut_child',inherited_kind=lineage[parent]['kind'],e5_partial_site=parent,child=child)
        rows.append(row)
    def floor(mesh,physical):
        polys=tuple(SourcePolygon(p.line,tuple(zip(mesh.face_v[i],mesh.face_vt[i],mesh.face_vn[i])),int(mesh.face_material[i]),p.group,p.object_name) for i,p in enumerate(polygons))
        return FloorInput(mesh,polys,np.arange(mesh.n_faces),np.tile([0,1,2],(mesh.n_faces,1)),physical)
    source_floor,engine_floor=floor(source_after,None),floor(engine_after,frame)
    out=Path(out);need(not out.exists(),'Candidate output exists');out.parent.mkdir(parents=True,exist_ok=True);staging=Path(tempfile.mkdtemp(prefix=out.name+'.incomplete-',dir=out.parent))
    write_floor(source_floor,staging/'candidate.source.obj');write_floor(engine_floor,staging/'candidate.engine.obj')
    _readback(staging/'candidate.source.obj',source_floor);_readback(staging/'candidate.engine.obj',engine_floor)
    (staging/'source-faces.json').write_text(_dump(dict(schema_version=1,engine='E5',mode='exact_SOURCE_partial_composed_lineage',checkpoint_sha256=sha,faces=rows)),encoding='utf-8')
    receipt=dict(schema_version=1,mode='saved_exact_SOURCE_E5_partial',checkpoint_sha256=sha,input_triangles=before.n_faces,output_triangles=engine_after.n_faces,planned=len(actual.edits),kept=len(actual.kept),rolled_back=len(actual.rolled_back),exact_saved_readback=True,original_source_position_prefix_preserved=np.array_equal(source_after.positions[:len(source.mesh.positions)],source.mesh.positions),original_source_UV_prefix_preserved=np.array_equal(source_after.uvs[:len(source.mesh.uvs)],source.mesh.uvs),acceptance=False,files={n:digest(staging/n) for n in ('candidate.source.obj','candidate.engine.obj','source-faces.json')})
    (staging/'pair-receipt.json').write_text(_dump(receipt),encoding='utf-8');staging.rename(out)
    return receipt
