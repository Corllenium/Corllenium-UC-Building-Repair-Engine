"""Authenticate and measure the six saved1F partial overlaps before checked E5 execution."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil,subprocess
from engine.io.minecraft_floor import Frame
from tools.main_infra_10571_e7_plan import load_current_pair, read_bound
from tools.main_infra_e3 import _source_digest
from tools.main_infra_e5_neighbor_classification import classify_neighbor_winners
from tools.main_infra_e5_partial_exact import plan_geometry, need
from tools.main_infra_e7_serialization import _encode
from tools.main_infra_e7_checkpoint import typed_plan_digest

def measure(input_path,partial_path,partial_sha):
    need(partial_sha=='be21b3b338e46a2e915b8515a000fb82996400c39a0297339df9003a01458e7c','Specific composed partial cohort required')
    partial=json.loads(read_bound(dict(path=str(partial_path),sha256=partial_sha)))
    source,before,lineage,reference,prepared,pair_input=load_current_pair(input_path)
    need(partial['partial_rows']==6 and partial['current_triangles']==10571 and partial['all_losers_winners_and_supports_survive'] is True,'Complete current six-partial cohort required')
    materials_ref=dict(path=prepared['paths']['materials'],sha256=prepared['hashes']['materials']);materials=json.loads(read_bound(materials_ref))
    provenance=json.loads(read_bound(pair_input['refs']['provenance']));frame=Frame(1000/25.4,provenance['frame_evidence'])
    look_ids={i:materials['materials'][name]['look'] for i,name in enumerate(source.mesh.materials)}
    mandatory=set(reference['mandatory_originals']);locked=set(reference['current_locked_faces'])
    protected={i for i,row in enumerate(lineage) if row['original_source_triangle'] in mandatory}|locked
    cohort=partial['rows'];pairs=[(row['winner_10571'],row['loser_10571']) for row in cohort]
    priorities=classify_neighbor_winners(source.mesh,pairs,look_ids,protected_faces=protected)['rows']
    source_edits=[];engine_edits=[];rows=[]
    before_digest=(_source_digest(source.mesh).hex(),_source_digest(before).hex())
    for old,priority in zip(cohort,priorities):
        loser,winner,supports=old['loser_10571'],old['winner_10571'],old['support_10571']
        need(loser not in protected and lineage[loser]['original_source_triangle']==old['loser_original'],'Literal protected/current original cohort differs')
        need(priority['reason']=='unique_exact_neighbor_continuity' and priority['loser']==loser and priority['winner']==winner and priority['supports'][str(winner)]==supports,'Fresh exact neighbor winner/support differs')
        try:a,b,proof=plan_geometry(source.mesh,before,loser,winner,frame)
        except ValueError as exc:
            rows.append(dict(loser=loser,winner=winner,original_parent=old['loser_original'],admitted=False,reason=str(exc)));continue
        proof.update(priority='unique_exact_neighbor_continuity',supports=supports,protected_faces=sorted(protected),original_parent=old['loser_original'])
        source_edits.append(a);engine_edits.append(b)
        rows.append(dict(loser=loser,winner=winner,original_parent=old['loser_original'],admitted=True,proof=proof))
    removed={e.faces[0] for e in engine_edits};anchors={f for row in cohort for f in (row['winner_10571'],*row['support_10571'])}
    need(not removed&(anchors|protected),'Partial batch conflicts with protected winner/support')
    need(before_digest==(_source_digest(source.mesh).hex(),_source_digest(before).hex()),'Partial measurement mutated current pair')
    report=dict(schema_version=1,mode='1F10571_exact_SOURCE_border_E5_partial',input=str(input_path),input_sha256=hashlib.sha256(Path(input_path).read_bytes()).hexdigest(),partial_map=dict(path=str(partial_path),sha256=partial_sha),materials=materials_ref,before_source_digest=before_digest[0],before_engine_digest=before_digest[1],input_triangles=10571,protected_originals=sorted(mandatory),locked_current_faces=sorted(locked),priority_rows=priorities,rows=rows,source_edits=[dict(_encode(e),decision=e.decision) for e in source_edits],engine_edits=[dict(_encode(e),decision=e.decision) for e in engine_edits],typed_plan_digest=typed_plan_digest(engine_edits),planned=len(engine_edits),kernel_called=False,new_model_saved=False,acceptance=False)
    for ref in pair_input['refs'].values():read_bound(ref)
    read_bound(materials_ref);read_bound(report['partial_map'])
    return source,before,lineage,reference,prepared,pair_input,source_edits,engine_edits,report

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True,type=Path);p.add_argument('--partials',required=True,type=Path);p.add_argument('--partials-sha256',required=True);p.add_argument('--output',required=True,type=Path);p.add_argument('--execute',action='store_true');p.add_argument('--qualification',type=Path);args=p.parse_args(argv)
    measured=measure(args.input,args.partials,args.partials_sha256);report=measured[-1]
    if args.execute:return execute(args,measured)
    need(args.output.resolve().is_relative_to(Path(__file__).resolve().parents[1]/'data') and not args.output.exists(),'Exclusive owned partial report required');args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(dict(planned=report['planned'],excluded=[dict(loser=r['loser'],reason=r['reason']) for r in report['rows'] if not r['admitted']],report=str(args.output),report_sha256=hashlib.sha256(args.output.read_bytes()).hexdigest(),kernel_called=False,new_model_saved=False,acceptance=False)))
    return 0

def execute(args,measured):
    from engine.io.mtl import parse_mtl
    from engine.validate.checks import load_looks
    from tools.main_infra_e5_partial_checkpoint import run_checked,capture,restore,write_pair
    source,before,lineage,reference,prepared,pair_input,source_edits,engine_edits,report=measured
    need(args.qualification is not None and hashlib.sha256(args.qualification.read_bytes()).hexdigest()=='26377f8d6e150098c88298c76f19e01b219972c7ccef9d7247849d29baa013c1','Actual exact six-partial qualification required')
    need(json.loads(args.qualification.read_bytes())==report and report['planned']==4,'Fresh partial cohort differs from actual qualification')
    own=Path(__file__).resolve().parents[1];head=subprocess.check_output(['git','-C',str(own),'rev-parse','HEAD'],text=True).strip()
    need(not subprocess.check_output(['git','-C',str(own),'status','--porcelain','--untracked-files=no'],text=True).strip(),'Committed clean execution code required')
    out=args.output;need(out.resolve().is_relative_to(own/'data') and not out.exists(),'Exclusive owned execution output required')
    current=Path(pair_input['refs']['source']['path']).parent
    looks=load_looks(report['materials']['path'],[(parse_mtl(current/source.mesh.mtllib),current)])
    need(not looks.unknown(before) and all(looks.key_of(n) in looks.flat or looks.key_of(n) in looks.texel for n in before.materials),'All original material/texture looks required')
    binding=dict(run_id='MAIN-INFRA-1F-10571-E5-PARTIAL-20261026',floor='1F',builder_commit=head,qualification_sha256='26377f8d6e150098c88298c76f19e01b219972c7ccef9d7247849d29baa013c1',input_sha256=report['input_sha256'],source_sha256=pair_input['refs']['source']['sha256'],engine_sha256=pair_input['refs']['engine']['sha256'],typed_plan_digest=report['typed_plan_digest'])
    out.mkdir(parents=True)
    def save(name,data):(out/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    worker=dict(binding,state='checking',engine='E5',input_triangles=before.n_faces,planned=len(engine_edits),acceptance=False)
    save('worker.json',worker)
    actual=run_checked(before,looks,engine_edits)
    cp=capture(before,actual,looks,source_edits,out/'checked-outcome',binding=binding)
    restored,_,_=restore(before,looks,out/'checked-outcome',cp['receipt_sha256'],binding=binding)
    save('worker.json',dict(worker,state='checkpoint_saved',checkpoint_sha256=cp['receipt_sha256'],kept=len(actual.kept),rolled_back=len(actual.rolled_back)))
    pair=write_pair(source,Frame(1000/25.4,json.loads(read_bound(pair_input['refs']['provenance']))['frame_evidence']),before,looks,lineage,out/'checked-outcome',cp['receipt_sha256'],binding,out/'candidate')
    prior_run=json.loads(read_bound(pair_input['refs']['run_receipt']))
    for asset in prior_run['assets']:
        ref=dict(path=str(current/asset['path']),sha256=asset['sha256']);raw=read_bound(ref);target=out/'candidate'/asset['path'];need(not target.exists(),'Asset output exists');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);need(hashlib.sha256(target.read_bytes()).hexdigest()==asset['sha256'],'Copied asset differs')
    saved=json.loads((out/'candidate/source-faces.json').read_bytes());mandatory=set(reference['mandatory_originals'])
    for original in mandatory:
        rows=[r for r in saved['faces'] if r['original_source_triangle']==original]
        need(len(rows)==1 and rows[0]['kind']=='unchanged','Mandatory original is no longer whole')
    inherited={r['original_source_triangle']:r for r in lineage if r['original_source_triangle'] in mandatory}
    for r in saved['faces']:
        if r['original_source_triangle'] in mandatory:
            need(all(r[k]==inherited[r['original_source_triangle']][k] for k in ('vertex_ids','source_uv','source_normal','engine_uv','engine_normal','material','group','object_name')),'Mandatory original corner/group data changed')
    rolled_originals=[lineage[e.faces[0]]['original_source_triangle'] for e in restored.rolled_back]
    need(all(lineage[e.faces[0]]['kind']=='unchanged' for e in restored.rolled_back),'Rolled original was previously a cut child; explicit original restore required')
    for ref in pair_input['refs'].values():read_bound(ref)
    result=dict(worker,state='candidate_saved',output_triangles=actual.mesh.n_faces,kept=len(actual.kept),rolled_back=len(actual.rolled_back),checkpoint_sha256=cp['receipt_sha256'],pair=pair,mandatory_unchanged_original_parents=sorted(mandatory|set(rolled_originals)),fresh_rollback_originals=rolled_originals,assets=prior_run['assets'],files={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'candidate').rglob('*') if p.is_file()},unchanged_default_checks=actual.checks,independent_validation='PENDING',repair_complete=False)
    save('run-receipt.json',result);save('worker.json',result)
    print(json.dumps(dict(output=str(out/'candidate'),output_triangles=actual.mesh.n_faces,kept=len(actual.kept),rolled_back=len(actual.rolled_back),checkpoint_sha256=cp['receipt_sha256'],independent_validation='PENDING',accepted=False)))
    return 0

if __name__=='__main__':raise SystemExit(main())
