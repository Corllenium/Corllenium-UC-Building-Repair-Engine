"""E5 partial cuts with exact SOURCE winner-border points and measured corner interpolation."""
from fractions import Fraction
import math
import numpy as np
from engine.repair.types import Edit
from tools.main_infra_e4_source import _affine, _area
from tools.main_infra_e5_coverage import subtract_triangle
from tools.main_infra_e5_neighbor_classification import _plane, _fraction_point
from tools.main_infra_e3 import _source_digest

def need(ok,message):
    if not ok:raise ValueError(message)

def on_segment(point,a,b):
    d=tuple(y-x for x,y in zip(a,b));q=tuple(y-x for x,y in zip(a,point))
    axis=next((i for i,v in enumerate(d) if v),None)
    if axis is None:return point==a
    t=q[axis]/d[axis]
    return 0<=t<=1 and all(q[i]==t*d[i] for i in range(3))

def plan_geometry(source,engine,loser,winner,frame):
    need(type(loser) is type(winner) is int and loser!=winner and 0<=loser<source.n_faces and 0<=winner<source.n_faces,'Distinct E5 faces required')
    need(all(np.isfinite(getattr(m,n)).all() for m in (source,engine) for n in ('positions','uvs','normals')),'finite SOURCE tables required')
    original=(_source_digest(source),_source_digest(engine))
    need(source.n_faces==engine.n_faces and np.array_equal(engine.positions,source.positions@frame.rotation.T*frame.inches_per_unit),'Exact forward SOURCE frame required')
    for name in ('face_v','face_vt','face_vn','uvs','face_material'):
        need(np.array_equal(getattr(source,name),getattr(engine,name)),'Frame-invariant SOURCE table differs: '+name)
    a=[_fraction_point(p) for p in source.positions[source.face_v[loser]]]
    b=[_fraction_point(p) for p in source.positions[source.face_v[winner]]]
    plane=_plane(a);need(plane is not None and plane==_plane(b),'Exact SOURCE plane required')
    drop=max(range(3),key=lambda k:abs(plane[k]));axes=[k for k in range(3) if k!=drop]
    flat=lambda points:[tuple(p[k] for k in axes) for p in points]
    remaining=subtract_triangle(flat(a),flat(b));before_area=abs(_area(flat(a)));after_area=sum(abs(_area(p)) for p in remaining)
    need(0<after_area<before_area,'Nonempty partial overlap required')
    lookup={}
    for i,p in enumerate(source.positions):lookup.setdefault(_fraction_point(p),i)
    new=[];flat_triangles=[];triangles=[];border=[]
    def vertex(p):
        xyz=[Fraction(0)]*3
        for axis,value in zip(axes,p):xyz[axis]=value
        xyz[drop]=-(plane[3]+sum(plane[k]*xyz[k] for k in axes))/plane[drop]
        xyz=tuple(xyz)
        if xyz not in lookup:
            need(any(on_segment(xyz,left,right) for left,right in zip(b,b[1:]+b[:1])),'New point is off winning SOURCE border')
            value=tuple(float(x) for x in xyz)
            need(all(math.isfinite(x) and Fraction(x)==exact for x,exact in zip(value,xyz)),'Winner-border point is not exactly binary64')
            lookup[xyz]=len(source.positions)+len(new);new.append(value);border.append([str(x) for x in xyz])
        return lookup[xyz]
    for polygon in remaining:
        for i in range(1,len(polygon)-1):
            triangle=[polygon[0],polygon[i],polygon[i+1]]
            if not _area(triangle):continue
            triangles.append([vertex(p) for p in triangle]);flat_triangles.append(triangle)
    need(triangles,'Nonempty remainder triangulation required')
    uv_indices=source.face_vt[loser];normal_indices=source.face_vn[loser];uv=None;normal=None;uv_errors=[]
    if not (uv_indices<0).all():
        need((uv_indices>=0).all(),'Refuse partial SOURCE UV corners')
        values=source.uvs[uv_indices];need(np.isfinite(values).all(),'Finite SOURCE UVs required')
        field=_affine(flat(a),[[Fraction(float(v)) for v in row] for row in values]);uv_rows=[]
        for triangle in flat_triangles:
            row=[]
            for point in triangle:
                corner=[]
                for x,y,c in field:
                    exact=x*point[0]+y*point[1]+c;actual=float(exact);error=abs(Fraction(actual)-exact)
                    need(math.isfinite(actual) and error<=Fraction(math.ulp(actual))/2,'Nearest binary64 SOURCE UV required')
                    uv_errors.append(dict(exact=str(exact),binary64=actual.hex(),absolute_error=str(error)));corner.append(actual)
                row.append(corner)
            uv_rows.append(row)
        uv=np.asarray(uv_rows)
    if not (normal_indices<0).all():
        need((normal_indices>=0).all(),'Refuse partial SOURCE normals')
        values=source.normals[normal_indices];need(np.isfinite(values).all() and (values==values[0]).all(),'Finite constant SOURCE normals required')
        normal=np.broadcast_to(values[0],(len(triangles),3,3)).copy()
    points=None if not new else np.asarray(new,dtype=float)
    proof=dict(exact_source_border=True,new_source_points=len(new),new_border_rationals=border,source_twice_area=str(before_area),remaining_twice_area=str(after_area),winner=winner,loser=loser,source_digest=original[0].hex(),before_digest=original[1].hex(),uv_rounding=uv_errors,uv_rounding_max_abs=max((float(Fraction(e['absolute_error'])) for e in uv_errors),default=0),acceptance=False)
    source_edit=Edit('E5','cut',(loser,),np.asarray(triangles,dtype=np.int64),points,loser,'Exact winner-border partial subtraction',proof,new_face_uv=uv,new_face_normal=normal)
    engine_points=None if points is None else points@frame.rotation.T*frame.inches_per_unit
    engine_normal=None if normal is None else normal@frame.rotation.T
    engine_edit=Edit('E5','cut',(loser,),source_edit.new_faces,engine_points,loser,source_edit.decision,proof,new_face_uv=uv,new_face_normal=engine_normal)
    need(original==(_source_digest(source),_source_digest(engine)),'E5 planning mutated input')
    return source_edit,engine_edit,proof
