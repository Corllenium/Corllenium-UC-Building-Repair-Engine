from pathlib import Path
import hashlib,json,sys
root=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine');wt=root/'.claude/worktrees/p1e';run=wt/'data/e5-partial-execute/attempt1';monitor=wt/'data/e5-partial-preflight/monitor-1F10571-exact-SOURCE-E5-partial-execute-20261026T002633'
r=json.loads((run/'run-receipt.json').read_bytes());t=json.loads((monitor/'result.json').read_bytes())
assert hashlib.sha256((run/'run-receipt.json').read_bytes()).hexdigest()=='81b387b858106f1de9c643c15b4cdc202ed1bbbfb36401add8e50d6a6ad2b685'
assert t['actual_pid']==51712 and t['actual_exit_code']==0 and t['all_owned_exited'] is True and t['abort_reason'] is None
assert (r['planned'],r['kept'],r['rolled_back'],r['output_triangles'])==(4,4,0,10573)
for name,sha in r['files'].items():assert hashlib.sha256((run/name).read_bytes()).hexdigest()==sha
sys.path.insert(0,str(root/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
path=root/'data/main-infra-fresh/current.json';d=load_progress(path);now=utc_now();f=d['floors']['1F']
other=json.dumps({k:v for k,v in d['floors'].items() if k!='1F'},sort_keys=True)
assert f['output_triangles']==10571 and f['latest_saved_candidate']['triangles']==10571 and f['accepted_preview'] is None
f.update(state='validating',worker_pid=51712,worker_start_utc=t['actual_creation_utc'],worker_alive=False,worker_observed_at=t['ended_utc'],worker_cpu_seconds=None,last_work_event_at=t['ended_utc'],
    pending_output_triangles=10573,pending_source_candidate_sha256='9d8d3718dcd4f41f84483d0e2e1957cd96ac6a7bcc6627bce94c906d81d71008',pending_engine_candidate_sha256='446bd02d5d07a9352bd7aa4e34ba27ff1e7720ecdce38600eaf54d98c99fef74',pending_checkpoint_sha256=r['checkpoint_sha256'],
    pending_saved_candidate=dict(engine='E5',run_id=r['run_id'],builder_commit=r['builder_commit'],triangles=10573,base_triangles=10571,planned_edits=4,kept_edits=4,rolled_back_edits=0,protected_original_parents=754,source_candidate_sha256='9d8d3718dcd4f41f84483d0e2e1957cd96ac6a7bcc6627bce94c906d81d71008',engine_candidate_sha256='446bd02d5d07a9352bd7aa4e34ba27ff1e7720ecdce38600eaf54d98c99fef74',checkpoint_sha256=r['checkpoint_sha256'],independent_validation='PENDING',remaining_problems=None,acceptance=False),
    step='New1F10573 E5 candidate saved:4 exact winner-border partial cuts kept,0rolled. Original position/UV prefixes,754 whole originals and7MTL/texture assets read back. Independent strict/native/signed validation and fresh matching maps pending; current displayed candidate remains10571.',
    blocker='Independent preservation and fresh signed counts for10573 are pending. Current10571 displayed result still has5198 signed errors; these counts are not reused as10573 counts.')
f.setdefault('worker_events',[]).append(dict(engine='E5',run_id=r['run_id'],pid=51712,start_utc=t['actual_creation_utc'],observed_at=t['ended_utc'],phase='four_partial_E5_candidate_saved',message='Actual guarded E5 exit0/noabort/allgone in44.092s;4planned4kept0rolled,10571to10573triangles. True CPc6e2 saved before source writing; exact paired readback and7originalassets. Independent validation pending, not accepted.'))
assert other==json.dumps({k:v for k,v in d['floors'].items() if k!='1F'},sort_keys=True)
d['updated_at']=now;d['last_work_event_at']=now;write_progress(path,d)
print(json.dumps(dict(saved_1F=10573,kept=4,rolled_back=0,displayed_1F=f['output_triangles'],independent='PENDING',other_floors_unchanged=True,accepted=False)))
