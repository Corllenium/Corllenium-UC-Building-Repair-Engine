from copy import deepcopy
import importlib
import importlib.util
import unittest
import hashlib
import tempfile
from pathlib import Path


def fixture():
    parents=[100,101,102,103,104,105]
    edits=[dict(engine='E7',kind='cut',site=i,faces=[i],new_points=None,legacy=False,
        new_faces=f'edit_{j}_new_faces') for j,i in enumerate([1,3,4])]
    rows=[]
    for i in [0,2,5]:
        rows.append(dict(output_face=len(rows),e7_input_face=i,original_source_triangle=parents[i],kind='unchanged'))
    for j,i in enumerate([1,3,4]):
        for child in range(2):
            rows.append(dict(output_face=len(rows),e7_input_face=i,original_source_triangle=parents[i],kind='cut_child',edit_index=j,child=child,e7_site=i))
    return dict(result=dict(edits=edits,kept=[0,1,2],rolled_back=[]),lineage=rows,
        parents=parents,protected=[100,102],target=dict(edit_index=1,site=3,original=103,children=[5,6]),forbidden=[900,901])


class ScopeTests(unittest.TestCase):
    def subject(self):
        self.assertIsNotNone(importlib.util.find_spec('tools.main_infra_6f_e7_edit86_retention'),
            'Exact saved-edit retention adapter is missing')
        return importlib.import_module('tools.main_infra_6f_e7_edit86_retention')

    def test_only_target_is_excluded_and_saved_order_is_preserved(self):
        data=fixture(); untouched=deepcopy(data)
        result=self.subject().retained_scope(**data)
        self.assertEqual(result['retained_saved_edit_indices'],[0,2])
        self.assertEqual(result['new_to_saved_edit_index'],[0,2])
        self.assertEqual(result['saved_to_new_edit_index'],{'0':0,'2':1})
        self.assertEqual(result['mandatory_originals'],[100,102,103])
        self.assertEqual(result['excluded_saved_edit_indices'],[1])
        self.assertEqual(result['expected_triangles_if_saved'],8)
        self.assertFalse(result['prior_pass_transferred'])
        self.assertFalse(result['acceptance'])
        self.assertEqual(data,untouched)

    def test_fresh_outcome_keeps_every_retained_edit(self):
        scope=self.subject().retained_scope(**fixture())
        self.assertTrue(self.subject().require_complete_outcome([0,1],[],scope))

    def test_extra_fresh_rollback_stops_delivery(self):
        scope=self.subject().retained_scope(**fixture())
        with self.assertRaises(ValueError):self.subject().require_complete_outcome([0],[1],scope)

    def test_fresh_reordered_edits_stop_delivery(self):
        scope=self.subject().retained_scope(**fixture())
        with self.assertRaises(ValueError):self.subject().require_complete_outcome([1,0],[],scope)


def mutation_test(mutate):
    def test(self):
        data=fixture();mutate(data)
        with self.assertRaises(ValueError):self.subject().retained_scope(**data)
    return test


MUTATIONS={
    'bool_output_index':lambda d:d['lineage'][1].update(output_face=True),
    'bool_child_index':lambda d:d['lineage'][4].update(child=True),
    'bool_row_edit_index':lambda d:d['lineage'][5].update(edit_index=True),
    'bool_row_site':lambda d:d['lineage'][3].update(e7_site=True),
    'target_already_rolled':lambda d:d['result'].update(kept=[0,2],rolled_back=[1]),
    'missing_kept':lambda d:d['result']['kept'].pop(),
    'duplicate_kept':lambda d:d['result']['kept'].append(1),
    'reordered_kept':lambda d:d['result'].update(kept=[1,0,2]),
    'bool_edit_index':lambda d:d['target'].update(edit_index=True),
    'wrong_target_index':lambda d:d['target'].update(edit_index=0),
    'wrong_target_site':lambda d:d['target'].update(site=4),
    'wrong_original_parent':lambda d:d['target'].update(original=104),
    'aliased_parent':lambda d:d['parents'].__setitem__(0,103),
    'absent_protected_original':lambda d:d['protected'].append(999),
    'duplicate_protected_original':lambda d:d['protected'].append(100),
    'protected_edit':lambda d:d['protected'].append(101),
    'new_points':lambda d:d['result']['edits'][1].update(new_points='points'),
    'non_e7':lambda d:d['result']['edits'][1].update(engine='E5'),
    'legacy':lambda d:d['result']['edits'][1].update(legacy=True),
    'multiple_faces':lambda d:d['result']['edits'][1].update(faces=[3,5]),
    'foreign_site':lambda d:d['result']['edits'][1].update(site=2),
    'conflicting_edits':lambda d:d['result']['edits'][2].update(site=3,faces=[3]),
    'missing_child':lambda d:d['lineage'].pop(),
    'duplicate_child':lambda d:d['lineage'][6].update(child=0),
    'stale_output_index':lambda d:d['lineage'][5].update(output_face=15),
    'stale_edit_index':lambda d:d['lineage'][5].update(edit_index=2),
    'foreign_child_parent':lambda d:d['lineage'][5].update(original_source_triangle=104),
    'wrong_target_children':lambda d:d['target'].update(children=[7,8]),
    'missing_unchanged_parent':lambda d:d['lineage'][0].update(e7_input_face=2),
    'marker_present':lambda d:d['forbidden'].append(105),
}
for name,mutate in MUTATIONS.items():setattr(ScopeTests,'test_rejects_'+name,mutation_test(mutate))


def attribution_fixture():
    chosen=[0,9,10,15]; hits=[]; samples=[]
    for i in range(18):
        original=12695 if i<9 else 12696
        target=i in chosen
        children=[dict(output_face=26177+k,original_source_triangle=16843,e7_input_face=12172,
            edit_index=86,e7_site=12172,child=k,kind='cut_child') for k in range(2)] if target else [dict(
            output_face=12085,original_source_triangle=16842,e7_input_face=12171,kind='unchanged')]
        hits.append(dict(sample=i,sample_original=original,twin_reference_face=16843 if target else 16842,
            twin_original=16843 if target else 16842,old_output_faces=[12172 if target else 12171],
            old_original_parents=[16843 if target else 16842],current_children=children))
        if target:samples.append(dict(sample=i,original_source_triangle=original,paid_codes=dict(
            source_self=dict(present=0,allowed=False,tested=True,covered=False),
            old26127=dict(present=2,allowed=True,tested=True,covered=False),
            current26291=dict(present=2,allowed=False,tested=True,covered=False))))
    return dict(diagnostic_only=True,existing_fullsigned_verdict='FAIL',
        saved_failure_sha256='c922b5db21ffae9fd8291408b506a8a3069e4db4b1efa353e69a1ddb82f2be96',
        candidate_source_sha256='47feb1846f0f9993690a2f6fa11860f830a712dfd517811ce0f12c20f018f4b4',
        candidate_engine_sha256='379c84530e76a7136ade73e538c51be8725f3509f90fd8deb1d9fce3f24ab3b4',
        focus_before_faces=[12695,12696],old_CBR_paid_twin_ancestry=hits,current_failed_look_samples=samples,
        saved_four_samples_reproduced=True,required_originals_unchanged=4333,allowed_changes_unchanged=['coincident_backface_removed'],
        retention_changed=False,geometry_changed=False,guard_or_settings_changed=False,prior_verdict_transferred=False,acceptance=False)


class BindingTests(unittest.TestCase):
    def subject(self,name):
        module=importlib.import_module('tools.main_infra_6f_e7_edit86_retention')
        self.assertTrue(hasattr(module,name),'Missing binding behavior: '+name)
        return getattr(module,name)

    def test_diagnostic_only_binds_exact_four_samples_and_both_twins(self):
        self.assertTrue(self.subject('bind_attribution')(attribution_fixture()))

    def test_runtime_identity_accepts_only_owned_clean_branch_and_cwd(self):
        module=importlib.import_module('tools.main_infra_6f_e7_edit86_retention')
        spec=dict(job_id=module.JOB,branch=module.BRANCH,root='owned',HEAD='commit',acceptance=False)
        claim=dict(status='claimed',holder=module.HOLDER,branch=module.BRANCH)
        self.assertTrue(self.subject('runtime_identity')(spec,root='owned',branch=module.BRANCH,head='commit',dirty=False,claim=claim))


def attribution_mutation(mutate):
    def test(self):
        a=attribution_fixture();mutate(a)
        with self.assertRaises(ValueError):self.subject('bind_attribution')(a)
    return test


for name,mutate in {
    'wrong_current_source':lambda a:a.update(candidate_source_sha256='stale'),
    'wrong_current_engine':lambda a:a.update(candidate_engine_sha256='stale'),
    'wrong_failure':lambda a:a.update(saved_failure_sha256='stale'),
    'missing_failure_sample':lambda a:a['current_failed_look_samples'].pop(),
    'current_allowed':lambda a:a['current_failed_look_samples'][0]['paid_codes']['current26291'].update(allowed=True),
    'old_failed':lambda a:a['current_failed_look_samples'][0]['paid_codes']['old26127'].update(allowed=False),
    'wrong_twin':lambda a:a['old_CBR_paid_twin_ancestry'][0].update(twin_original=16842),
    'wrong_child':lambda a:a['old_CBR_paid_twin_ancestry'][0]['current_children'][0].update(output_face=26176),
    'wrong_edit':lambda a:a['old_CBR_paid_twin_ancestry'][0]['current_children'][0].update(edit_index=85),
    'untouched_twin_modified':lambda a:a['old_CBR_paid_twin_ancestry'][1]['current_children'][0].update(kind='cut_child'),
    'tolerance_changed':lambda a:a.update(guard_or_settings_changed=True),
    'accepted_diagnostic':lambda a:a.update(acceptance=True),
}.items():setattr(BindingTests,'test_diagnostic_rejects_'+name,attribution_mutation(mutate))


def identity_mutation(field,value):
    def test(self):
        m=importlib.import_module('tools.main_infra_6f_e7_edit86_retention')
        spec=dict(job_id=m.JOB,branch=m.BRANCH,root='owned',HEAD='commit',acceptance=False)
        args=dict(root='owned',branch=m.BRANCH,head='commit',dirty=False,claim=dict(status='claimed',holder=m.HOLDER,branch=m.BRANCH))
        if field.startswith('spec_'):spec[field[5:]]=value
        elif field.startswith('claim_'):args['claim'][field[6:]]=value
        else:args[field]=value
        with self.assertRaises(ValueError):self.subject('runtime_identity')(spec,**args)
    return test

for field,value in [('root','foreign'),('branch','foreign'),('head','stale'),('dirty',True),('spec_acceptance',True),
    ('claim_status','awaiting-review'),('claim_holder','foreign'),('claim_branch','foreign')]:
    setattr(BindingTests,'test_runtime_rejects_'+field,identity_mutation(field,value))


class ReadbackTests(unittest.TestCase):
    def subject(self,name):
        module=importlib.import_module('tools.main_infra_6f_e7_edit86_retention')
        self.assertTrue(hasattr(module,name),'Missing readback behavior: '+name)
        return getattr(module,name)

    def data(self):
        module=importlib.import_module('tools.main_infra_6f_e7_edit86_retention')
        old=fixture();scope=module.retained_scope(**old)
        rows=[dict(output_face=0,e7_input_face=0,original_source_triangle=100,kind='unchanged'),
            dict(output_face=1,e7_input_face=2,original_source_triangle=102,kind='unchanged'),
            dict(output_face=2,e7_input_face=3,original_source_triangle=103,kind='unchanged'),
            dict(output_face=3,e7_input_face=5,original_source_triangle=105,kind='unchanged')]
        for j,site,original in [(0,1,101),(1,4,104)]:
            for child in range(2):rows.append(dict(output_face=len(rows),e7_input_face=site,
                original_source_triangle=original,kind='cut_child',edit_index=j,child=child,e7_site=site))
        return dict(oldrows=old['lineage'],newrows=rows,scope=scope,
            old_values=['u0','u2','u5','c0.0','c0.1','c1.0','c1.1','c2.0','c2.1'],
            new_values=['u0','u2','u3','u5','c0.0','c0.1','c2.0','c2.1'],restored_value='u3')

    def test_decoded_values_survive_output_and_uv_index_renumbering(self):
        result=self.subject('prove_delta')(**self.data())
        self.assertEqual(result,dict(other_faces_exact=7,restored_original=103,protected_whole=3,old_children_removed=2))

    def test_bound_read_returns_authenticated_bytes(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()/'data') as directory:
            p=Path(directory)/'small.json';p.write_bytes(b'{}')
            pin=dict(path=str(p),bytes=2,sha256=hashlib.sha256(b'{}').hexdigest())
            self.assertEqual(self.subject('read_bound')(pin),b'{}')
            p.write_bytes(b'[]')
            with self.assertRaises(ValueError):self.subject('read_bound')(pin)

    def test_wrong_bound_byte_count_is_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()/'data') as directory:
            p=Path(directory)/'small.json';p.write_bytes(b'{}')
            with self.assertRaises(ValueError):self.subject('read_bound')(dict(path=str(p),bytes=3,sha256=hashlib.sha256(b'{}').hexdigest()))


def delta_mutation(mutate):
    def test(self):
        data=self.data();mutate(data)
        with self.assertRaises(ValueError):self.subject('prove_delta')(**data)
    return test

for name,mutate in {
    'other_corner_or_look_changed':lambda d:d['new_values'].__setitem__(7,'differentUV'),
    'restored_corner_changed':lambda d:d['new_values'].__setitem__(2,'differentUV'),
    'target_still_cut':lambda d:d['newrows'][2].update(kind='cut_child',edit_index=1,child=0),
    'wrong_original':lambda d:d['newrows'][2].update(original_source_triangle=999),
    'extra_face_missing':lambda d:d['newrows'].pop(),
    'saved_edit_reordered':lambda d:d['newrows'][6].update(edit_index=0),
    'duplicate_other_child':lambda d:d['newrows'][7].update(child=0),
    'wrong_output_number':lambda d:d['newrows'][0].update(output_face=2),
}.items():setattr(ReadbackTests,'test_delta_rejects_'+name,delta_mutation(mutate))


class RoleRefTests(unittest.TestCase):
    def fixture(self):
        pins=[dict(path=name+'.json',bytes=10,sha256=name) for name in ['cp','result','lineage','base','checked','extra']]
        cp,result,lineage,base,checked,extra=pins
        role=dict(checkpoint=cp,checkpoint_files={'result.json':result},current_ancestry=dict(output_lineage=lineage),
            input_plan=extra,checked_spec=checked,input_refs=dict(plan_input=base),roles={},assets=[],receipt_binding=dict(paths={},sha256={}))
        refs=dict(checkpoint=deepcopy(cp),result=deepcopy(result),lineage=deepcopy(lineage),base_plan=deepcopy(base),checked_spec=deepcopy(checked),extra=deepcopy(extra))
        return dict(refs=refs,role=role,pins=deepcopy(pins))

    def check(self,data):
        module=importlib.import_module('tools.main_infra_6f_e7_edit86_retention')
        self.assertTrue(hasattr(module,'role_ref_identity'),'Missing exact role-ref pin binding')
        return module.role_ref_identity(**data)

    def test_exact_consumed_refs_match_trusted_role_and_runtime_inventory(self):
        self.assertTrue(self.check(self.fixture()))


def ref_mutation(mutate):
    def test(self):
        data=self.fixture();mutate(data)
        with self.assertRaises(ValueError):self.check(data)
    return test

for name,mutate in {
    'foreign_result_sha':lambda d:d['refs']['result'].update(sha256='other'),
    'foreign_result_path':lambda d:d['refs']['result'].update(path='other.json'),
    'wrong_lineage_bytes':lambda d:d['refs']['lineage'].update(bytes=11),
    'foreign_baseplan':lambda d:d['refs']['base_plan'].update(sha256='other'),
    'foreign_checkpoint':lambda d:d['refs']['checkpoint'].update(sha256='other'),
    'omitted_consumed_ref':lambda d:d['pins'].pop(),
    'omitted_bound_member':lambda d:d['role']['checkpoint_files'].update(new=dict(path='new.json',bytes=4,sha256='new')),
}.items():setattr(RoleRefTests,'test_role_ref_rejects_'+name,ref_mutation(mutate))


class ContextTests(unittest.TestCase):
    def fixture(self):
        source=dict(path='base.source.obj',sha256='source');engine=dict(path='base.engine.obj',sha256='engine')
        base=dict(qualified_baseline='original',refs=dict(source=source,engine=engine))
        checked=dict(refs=dict(plan_input=dict(path='base.json',sha256='base')))
        role=dict(input_refs=deepcopy(checked['refs']),original_qualified_baseline='original',
            predecessor_roles=dict(source=deepcopy(source),engine=deepcopy(engine)))
        return dict(checked=checked,plan=base,role=role)

    def check(self,data):
        module=importlib.import_module('tools.main_infra_6f_e7_edit86_retention')
        self.assertTrue(hasattr(module,'context_identity'),'Missing wrapper/base-context binding')
        return module.context_identity(**data)

    def test_unwraps_authenticated_base_context_instead_of_plan_wrapper(self):
        self.assertTrue(self.check(self.fixture()))


def context_mutation(mutate):
    def test(self):
        data=self.fixture();mutate(data)
        with self.assertRaises(ValueError):self.check(data)
    return test

for name,mutate in {
    'wrapper_substituted_for_base':lambda d:d.update(plan=deepcopy(d['checked'])),
    'wrong_wrapper_refs':lambda d:d['checked']['refs']['plan_input'].update(sha256='other'),
    'wrong_original_baseline':lambda d:d['plan'].update(qualified_baseline='other'),
    'wrong_base_source':lambda d:d['plan']['refs']['source'].update(sha256='other'),
    'wrong_base_engine_path':lambda d:d['plan']['refs']['engine'].update(path='other.obj'),
}.items():setattr(ContextTests,'test_context_rejects_'+name,context_mutation(mutate))

if __name__=='__main__':unittest.main()




