"""Exclude one authenticated saved E7 edit, then recheck the remaining exact cuts."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT.parents[2]
JOB='MAIN-INFRA-6F-E7-EDIT86-RETENTION-20261028'
HOLDER='Codex-6F-E7-Edit86-Retention'
BRANCH='codex/main-infra-6f-e7-edit86-retention-20261028'
SOURCE='47feb1846f0f9993690a2f6fa11860f830a712dfd517811ce0f12c20f018f4b4'
ENGINE='379c84530e76a7136ade73e538c51be8725f3509f90fd8deb1d9fce3f24ab3b4'
CHECKPOINT='9cf0effc5a13321411f6ce38f336963a3e04a4edd6916fac1351e4eefec0a47e'
ATTRIBUTION='a85ba4bfaa92ed03bae16268789a2025df49c7670ba27a4a6a8874430d64eeec'
FAILURE='c922b5db21ffae9fd8291408b506a8a3069e4db4b1efa353e69a1ddb82f2be96'
ROLE='ebaf4e508056ff412f15350c0651629f75b9a434c22bf7681d98aa200cd78123'
TARGET=dict(edit_index=86,site=12172,original=16843,children=[26177,26178])


def need(ok,message):
    if not ok:raise ValueError(message)


def integers(values):
    return isinstance(values,list) and all(type(v) is int and v>=0 for v in values)


def retained_scope(*,result,lineage,parents,protected,target,forbidden):
    need(integers(parents) and len(set(parents))==len(parents),'Unique original input parents required')
    need(integers(protected) and protected==sorted(set(protected)) and set(protected)<=set(parents),'Complete ordered protected originals required')
    need(integers(forbidden) and not set(forbidden)&set(parents),'Forbidden marker original present')
    edits=result['edits'];indices=list(range(len(edits)))
    need(integers(result['kept']) and result['kept']==indices and result['rolled_back']==[],'Exact saved all-kept partition required')
    rank,site,original=target['edit_index'],target['site'],target['original']
    need(type(rank) is int and 0<=rank<len(edits) and type(site) is int and 0<=site<len(parents)
        and type(original) is int and parents[site]==original,'Target saved edit ancestry differs')
    touched=[]
    for edit in edits:
        faces=edit['faces']
        need(edit['engine']=='E7' and edit['kind']=='cut' and edit['legacy'] is False
            and edit['new_points'] is None and integers(faces) and len(faces)==1
            and 0<=faces[0]<len(parents) and type(edit['site']) is int and edit['site']==faces[0],
            'Only disjoint single-input existing-vertex E7 cuts required')
        touched.append(faces[0])
    need(len(set(touched))==len(touched) and touched[rank]==site,'Conflicting edits or stale target site')
    need(not set(protected)&{parents[i] for i in touched},'Saved cut touches protected original')
    expected=[];children={};touched_set=set(touched)
    for i in range(len(parents)):
        if i not in touched_set:expected.append((i,None,None,'unchanged'))
    for j,edit in enumerate(edits):
        rows=[r for r in lineage if r.get('edit_index')==j and r.get('kind')=='cut_child']
        need(len(rows)>=2 and [r['child'] for r in rows]==list(range(len(rows))),'Saved cut child partition differs')
        children[j]=[r['output_face'] for r in rows]
        expected.extend((edit['site'],j,k,'cut_child') for k in range(len(rows)))
    need(len(expected)==len(lineage),'Saved lineage count differs')
    for output,(row,wanted) in enumerate(zip(lineage,expected)):
        parent,edit_index,child,kind=wanted
        need(type(row['output_face']) is int and type(row['e7_input_face']) is int
            and (child is None or (type(row['edit_index']) is int and type(row['child']) is int and type(row['e7_site']) is int))
            and row['output_face']==output and row['e7_input_face']==parent and row['original_source_triangle']==parents[parent]
            and row['kind']==kind and row.get('edit_index')==edit_index and row.get('child')==child
            and (child is None or row['e7_site']==parent),'Saved exact output ancestry differs')
    need(integers(target['children']) and children[rank]==target['children'],'Target current children differ')
    selected=[i for i in indices if i!=rank]
    return dict(schema_version=1,policy='exact_saved_E7_edit_exclusion_v1',
        excluded_saved_edit_indices=[rank],excluded_saved_sites=[site],restored_original=original,
        retained_saved_edit_indices=selected,new_to_saved_edit_index=selected.copy(),
        saved_to_new_edit_index={str(old):new for new,old in enumerate(selected)},
        mandatory_originals=sorted(set(protected)|{original}),prior_required_count=len(protected),
        expected_triangles_if_saved=len(lineage)-len(children[rank])+1,
        policy_exclusion_is_kernel_rollback=False,prior_pass_transferred=False,acceptance=False)


def require_complete_outcome(kept,rolled,scope):
    need(integers(kept) and kept==list(range(len(scope['retained_saved_edit_indices']))) and rolled==[],
        'Every retained saved edit must be freshly kept; extra rollback stops delivery')
    return True


def bind_attribution(a):
    need(a['diagnostic_only'] is True and a['existing_fullsigned_verdict']=='FAIL'
        and a['saved_failure_sha256']==FAILURE and a['candidate_source_sha256']==SOURCE
        and a['candidate_engine_sha256']==ENGINE and a['focus_before_faces']==[12695,12696]
        and a['saved_four_samples_reproduced'] is True and a['required_originals_unchanged']==4333
        and a['allowed_changes_unchanged']==['coincident_backface_removed']
        and all(a[k] is False for k in ('retention_changed','geometry_changed','guard_or_settings_changed',
            'prior_verdict_transferred','acceptance')),'Exact diagnostic-only current failure authority required')
    chosen=[0,9,10,15];samples=a['current_failed_look_samples']
    need([r['sample'] for r in samples]==chosen,'Exact four failed samples required')
    for row in samples:
        need(row['original_source_triangle']==(12695 if row['sample']==0 else 12696),'Failed sample parent differs')
        expected=dict(source_self=dict(present=0,allowed=False,tested=True,covered=False),
            old26127=dict(present=2,allowed=True,tested=True,covered=False),
            current26291=dict(present=2,allowed=False,tested=True,covered=False))
        need(row['paid_codes']==expected,'Actual three-role sample attribution differs')
    hits=a['old_CBR_paid_twin_ancestry']
    need([r['sample'] for r in hits]==list(range(18)),'Complete eighteen old paid twin hits required')
    for hit in hits:
        target=hit['sample'] in chosen;original=16843 if target else 16842;site=12172 if target else 12171
        need(hit['sample_original']==(12695 if hit['sample']<9 else 12696)
            and hit['twin_reference_face']==hit['twin_original']==original
            and hit['old_output_faces']==[site] and hit['old_original_parents']==[original],
            'Exact paid twin original/input ancestry required')
        rows=hit['current_children']
        if target:
            need(len(rows)==2,'Exact two target children required')
            for child,row in enumerate(rows):
                need(row['output_face']==26177+child and row['original_source_triangle']==16843
                    and row['e7_input_face']==row['e7_site']==12172 and row['edit_index']==86
                    and row['child']==child and row['kind']=='cut_child','Target child/edit association differs')
        else:
            need(len(rows)==1 and rows[0]['output_face']==12085 and rows[0]['original_source_triangle']==16842
                and rows[0]['e7_input_face']==12171 and rows[0]['kind']=='unchanged','Untouched twin differs')
    return True


def runtime_identity(spec,*,root,branch,head,dirty,claim):
    need(spec['job_id']==JOB and spec['branch']==branch==BRANCH and spec['acceptance'] is False
        and Path(spec['root']).resolve()==Path(root).resolve() and spec['HEAD']==head and dirty is False,
        'Exact owned clean branch/HEAD/cwd required')
    need((claim['status'],claim['holder'],claim['branch'])==('claimed',HOLDER,BRANCH),'Owned corrective job claim differs')
    return True


def read_bound(pin):
    data=Path(pin['path']).read_bytes()
    need(hashlib.sha256(data).hexdigest()==pin['sha256'] and ('bytes' not in pin or len(data)==pin['bytes']),
        'Bound input bytes differ: '+pin['path'])
    return data


def prove_delta(*,oldrows,newrows,scope,old_values,new_values,restored_value):
    need(len(oldrows)==len(old_values) and len(newrows)==len(new_values)==scope['expected_triangles_if_saved'],
        'Complete saved decoded face inventories required')
    excluded=scope['excluded_saved_edit_indices'][0];site=scope['excluded_saved_sites'][0]
    target=scope['restored_original'];restored=[]
    def indexed(rows,values,fresh):
        result={}
        for output,(row,value) in enumerate(zip(rows,values)):
            need(type(row['output_face']) is int and row['output_face']==output,'Output lineage numbering differs')
            if fresh and row['original_source_triangle']==target:
                need(row['kind']=='unchanged' and row['e7_input_face']==site,'Restored original must be whole at exact input site')
                restored.append(value);continue
            if row['kind']=='cut_child':
                edit=row['edit_index']
                if fresh:
                    need(type(edit) is int and 0<=edit<len(scope['new_to_saved_edit_index']),'Fresh edit index differs')
                    edit=scope['new_to_saved_edit_index'][edit]
                elif edit==excluded:continue
                key=('cut_child',edit,row['child'])
            else:
                need(row['kind']=='unchanged','Unexpected saved face kind')
                key=('unchanged',row['e7_input_face'])
            need(key not in result,'Duplicate stable saved face identity')
            result[key]=(row['original_source_triangle'],row['e7_input_face'],row['kind'],value)
        return result
    old=indexed(oldrows,old_values,False);new=indexed(newrows,new_values,True)
    need(old==new and restored==[restored_value],'Other cuts/corners/looks or restored whole original differ')
    for original in scope['mandatory_originals']:
        rows=[r for r in newrows if r['original_source_triangle']==original]
        need(len(rows)==1 and rows[0]['kind']=='unchanged','Every protected original must remain whole')
    return dict(other_faces_exact=len(old),restored_original=target,protected_whole=len(scope['mandatory_originals']),
        old_children_removed=len(oldrows)-len(old))


def pin_matches(actual,expected):
    return (Path(actual['path']).resolve()==Path(expected['path']).resolve() and actual['sha256']==expected['sha256']
        and ('bytes' not in expected or actual.get('bytes')==expected['bytes']))


def require_pinned(pin,pins):
    need(any(pin_matches(p,pin) for p in pins),'Consumed input absent from exact runtime inventory: '+pin['path'])


def role_ref_identity(refs,role,pins):
    trusted=dict(checkpoint=role['checkpoint'],result=role['checkpoint_files']['result.json'],
        lineage=role['current_ancestry']['output_lineage'],base_plan=role['input_refs']['plan_input'],checked_spec=role['checked_spec'])
    for name,pin in trusted.items():need(pin_matches(refs[name],pin),'Consumed ref differs from trusted role: '+name)
    def consume(value):
        if isinstance(value,dict):
            if 'path' in value and 'sha256' in value:require_pinned(value,pins)
            else:
                for child in value.values():consume(child)
        elif isinstance(value,list):
            for child in value:consume(child)
    consume(refs)
    for key in ('checkpoint','checkpoint_files','current_ancestry','input_plan','checked_spec','input_refs','roles','assets'):
        consume(role[key])
    binding=role['receipt_binding']
    for name,path in binding['paths'].items():require_pinned(dict(path=path,sha256=binding['sha256'][name]),pins)
    return True


def context_identity(checked,plan,role):
    need(checked.get('refs')==role['input_refs'] and plan.get('qualified_baseline')==role['original_qualified_baseline'],
        'Authenticated checked wrapper and underlying original context required')
    for name in ('source','engine'):
        need(name in plan.get('refs',{}) and pin_matches(role['predecessor_roles'][name],plan['refs'][name]),
            'Underlying original26127 paired context differs: '+name)
    return True


def documents(path,expected):
    spec=json.loads(read_bound(dict(path=str(path),sha256=expected)))
    need(spec['mode']=='6F_saved_E7_exact_edit86_exclusion' and Path(spec['root']).resolve()==ROOT.resolve()
        and Path.cwd().resolve()==ROOT.resolve(),'Exact corrective execution root/mode required')
    from tools import jobs
    runtime_identity(spec,root=str(Path.cwd()),branch=subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip(),
        head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        dirty=bool(subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip()),
        claim=jobs.get(MAIN,JOB))
    need(len({str(Path(p['path']).resolve()).casefold() for p in spec['pins']})==len(spec['pins']),
        'Duplicate pinned runtime path')
    for pin in spec['pins']:read_bound(pin)
    refs=spec['refs'];role=json.loads(read_bound(refs['role']));attribution=json.loads(read_bound(refs['attribution']))
    need(refs['role']['sha256']==ROLE and refs['attribution']['sha256']==ATTRIBUTION
        and refs['failure']['sha256']==FAILURE and refs['checkpoint']['sha256']==CHECKPOINT,
        'Actual current role/diagnostic/failure/checkpoint authority required')
    bind_attribution(attribution);role_ref_identity(refs,role,spec['pins'])
    need(role['roles']['source']['sha256']==SOURCE and role['roles']['engine']['sha256']==ENGINE
        and (role['input_triangles'],role['source_triangles'],role['planned'],role['kept'],role['rolled_back'])==(26127,26291,133,133,0)
        and role['required_count']==len(role['required_whole_originals'])==4333
        and role['marker_original_indices']==list(range(34838,34862))
        and role['acceptance'] is False,'Exact actual current26291 roles/protection/mask required')
    checkpoint=json.loads(read_bound(refs['checkpoint']));result=json.loads(read_bound(refs['result']));lineage=json.loads(read_bound(refs['lineage']))
    need(checkpoint['binding']==role['receipt_binding'] and checkpoint['before_digest']==role['checkpoint_before_digest']
        and checkpoint['after_digest']==role['checkpoint_after_digest'] and checkpoint['schema_version']==1
        and checkpoint['mode']=='actual_checked_e7_checkpoint' and checkpoint['capture_only'] is True
        and (checkpoint['planned'],checkpoint['kept'],checkpoint['rolled_back'],checkpoint['output_triangles'])==(133,133,0,26291)
        and lineage['checkpoint_sha256']==CHECKPOINT and lineage['input_triangles']==26127
        and lineage['mode']=='current_partial_ancestry_existing_vertex_E7','Saved checkpoint/lineage binding differs')
    need(len(result['edits'])==133 and checkpoint['files']=={k:role['checkpoint_files'][k]['sha256'] for k in role['checkpoint_files']},
        'Actual checkpoint member inventory differs')
    for i,edit in enumerate(result['edits']):
        shape=checkpoint['arrays'][edit['new_faces']]['shape']
        rows=[r for r in lineage['faces'] if r.get('edit_index')==i and r['kind']=='cut_child']
        need(len(shape)==2 and shape[1]==3 and len(rows)==shape[0],'Actual typed cut child count differs')
    scope=retained_scope(result=result,lineage=lineage['faces'],parents=role['current_ancestry']['input_original_parents'],
        protected=role['required_whole_originals'],target=TARGET,forbidden=role['marker_original_indices'])
    need(len(scope['retained_saved_edit_indices'])==132 and len(scope['mandatory_originals'])==4334
        and scope['expected_triangles_if_saved']==26290,'Exact132 retained cuts/4334whole union required')
    checked=json.loads(read_bound(refs['checked_spec']));plan=json.loads(read_bound(refs['base_plan']))
    context_identity(checked,plan,role)
    for pin in plan['refs'].values():require_pinned(pin,spec['pins'])
    return spec,role,checkpoint,result,lineage,scope,plan


def decoded_faces(source,engine):
    need(source.mesh.n_faces==engine.n_faces,'Paired decoded inventory differs')
    values=[]
    for i in range(engine.n_faces):
        poly=source.polygons[source.triangle_polygon[i]]
        row=dict(group=poly.group,object_name=poly.object_name,
            material=source.mesh.materials[int(source.mesh.face_material[i])] if source.mesh.face_material[i]>=0 else None)
        for label,mesh in [('source',source.mesh),('engine',engine)]:
            row[label+'_positions']=mesh.positions[mesh.face_v[i]].tolist()
            for name,field in [('uvs','face_vt'),('normals','face_vn')]:
                row[label+'_'+name]=[None if index<0 else getattr(mesh,name)[index].tolist() for index in getattr(mesh,field)[i]]
        values.append(row)
    return values


def execute(spec,role,oldcp,result,lineage,scope,plan,input_pin):
    out=Path(spec['output']);need(out.resolve().is_relative_to(ROOT/'data') and not out.exists(),'Exclusive fresh owned output required')
    from datetime import datetime,timezone
    import os
    from engine.io.obj_reader import read_obj
    from engine.io.minecraft_floor import parse_floor
    from tools import main_infra_6f_26127_e7_plan as paid_plan
    from tools import main_infra_6f_26127_e7_checked as paid_checked
    from tools.main_infra_e3 import load_qualified_floor,_source_digest
    from tools.main_infra_e7_checkpoint import restore_e7_checkpoint,save_e7_checkpoint,typed_plan_digest
    from tools.main_infra_e7_current_pair import write_current_pair
    from tools.main_infra_e7_serialization import _tables
    from tools.main_infra_e7_subset import VerifiedSubset,_look_ids,_seal,run_checked_subset
    refs=plan['refs'];docs={k:json.loads(read_bound(refs[k])) for k in ('context','priority','current_E3_checkpoint',
        'current_E5_checkpoint','drop_lineage','cumulative_original_ancestry','marker_checkpoint')}
    ctx=paid_plan.bind_metadata(docs)
    need(ctx['parents']==role['current_ancestry']['input_original_parents'],'Original26127 parent context differs')
    original,physical,baseline,qualification=load_qualified_floor(raw=refs['original_owner_raw']['path'],
        reference=refs['native_triangulation_reference']['path'],baseline=plan['qualified_baseline'],qualification=refs['qualification']['path'])
    need(list(baseline.physical_quanta)==docs['context']['raw_frame_expected_physical_quanta'],'OriginalRAW physical precision differs')
    before=paid_plan.restore_context(baseline,docs['current_E3_checkpoint'],docs['current_E5_checkpoint'],docs['drop_lineage']['kept_current'])
    source=parse_floor(read_bound(refs['source']).decode('utf-8'))
    _tables(read_obj(refs['engine']['path']),before);_tables(source.in_frame(physical.frame).mesh,before)
    looks=paid_checked.load_current_looks(plan,before,role['materials_looks'])
    old=restore_e7_checkpoint(before,looks,Path(spec['refs']['checkpoint']['path']).parent,
        binding=role['receipt_binding'],expected_receipt_sha256=CHECKPOINT)
    current_source=parse_floor(read_bound(role['roles']['source']).decode('utf-8'));current_engine=read_obj(role['roles']['engine']['path'])
    _tables(current_engine,old.mesh);_tables(current_source.in_frame(physical.frame).mesh,old.mesh)
    selected=tuple(old.edits[i] for i in scope['retained_saved_edit_indices'])
    admission=paid_plan.qualify_current(source.mesh,before,ctx['parents'],selected,scope['mandatory_originals'],physical.frame)
    need(admission['admitted_indices']==list(range(132)),'All132 saved cuts must retain exact SOURCE look/UV qualification')
    proof=dict(before_digest=_source_digest(before).hex(),typed_plan_digest=typed_plan_digest(selected),
        look_ids={str(k):v for k,v in _look_ids(before,looks).items()},scope=scope,
        saved_checkpoint_sha256=CHECKPOINT,current_source_sha256=SOURCE,current_engine_sha256=ENGINE,
        attribution_sha256=ATTRIBUTION,old_verdict_is_not_reused=True,acceptance=False)
    subset=VerifiedSubset(selected,proof,_seal(proof,selected));out.mkdir(parents=True)
    def worker(state,**extra):
        value=dict(job_id=JOB,floor='6F',engine='E7',actual_pid=os.getpid(),updated_utc=datetime.now(timezone.utc).isoformat(),
            state=state,selected_sites=132,policy_excluded_saved_edit_indices=[86],acceptance=False,**extra)
        temp=out/'worker.tmp';temp.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8');temp.replace(out/'worker.json')
    worker('checking_saved_subset');actual=run_checked_subset(before,looks,subset)
    need(typed_plan_digest(actual.edits)==typed_plan_digest(selected),'Fresh engine changed a saved retained edit')
    indices={id(e):i for i,e in enumerate(actual.edits)}
    require_complete_outcome([indices[id(e)] for e in actual.kept],[indices[id(e)] for e in actual.rolled_back],scope)
    need(actual.mesh.n_faces==scope['expected_triangles_if_saved'],'Actual retained-subset triangle count differs')
    allpins=[input_pin]+spec['pins'];paths={f'input_{i}':pin['path'] for i,pin in enumerate(allpins)}
    hashes={f'input_{i}':pin['sha256'] for i,pin in enumerate(allpins)}
    binding=dict(run_id=JOB,floor='6F',builder_commit=spec['HEAD'],before_digest=_source_digest(before).hex(),paths=paths,sha256=hashes,
        source_sha256=role['predecessor_roles']['source']['sha256'],engine_sha256=role['predecessor_roles']['engine']['sha256'],
        whole_originals=scope['mandatory_originals'],saved_outcome_authority=spec['refs']['checkpoint'],retention_scope=scope,
        physical_context=dict(coord_decimals=before.coord_decimals,sig_digits=before.sig_digits,units=before.units,quanta=before.physical_quanta),
        frame_matrix=physical.frame.matrix.tolist(),cbr_winner_vector='UNENUMERATED',owner_cbr_authority=refs['base_owner_authority'],
        historical_transfer_locks=[],current_independent_validation_not_transferred=True)
    checkpoint=save_e7_checkpoint(before,actual,looks,out/'checked-outcome',binding=binding)
    worker('checkpoint_saved',kept=132,rolled_back=0,checkpoint_sha256=checkpoint['receipt_sha256'])
    rows=[]
    for i,parent in enumerate(ctx['parents']):
        poly=source.polygons[source.triangle_polygon[i]]
        rows.append(dict(output_face=i,original_source_triangle=parent,kind='unchanged',vertex_ids=source.mesh.face_v[i].tolist(),
            source_uv=source.mesh.face_vt[i].tolist(),source_normal=source.mesh.face_vn[i].tolist(),engine_uv=before.face_vt[i].tolist(),
            engine_normal=before.face_vn[i].tolist(),material=source.mesh.materials[int(source.mesh.face_material[i])],group=poly.group,object_name=poly.object_name))
    mandatory=set(scope['mandatory_originals']);locked=[i for i,p in enumerate(ctx['parents']) if p in mandatory]
    need(len(locked)==4334,'All4334 whole input faces required')
    pair=write_current_pair(source,physical.frame,before,looks,rows,out/'checked-outcome',checkpoint['receipt_sha256'],binding,
        out/'candidate',scope['mandatory_originals'],locked,[],34862)
    fresh_source=parse_floor((out/'candidate/candidate.source.obj').read_text(encoding='utf-8'));fresh_engine=read_obj(out/'candidate/candidate.engine.obj')
    newrows=json.loads((out/'candidate/cut-lineage.json').read_bytes())['faces']
    readback=prove_delta(oldrows=lineage['faces'],newrows=newrows,scope=scope,old_values=decoded_faces(current_source,current_engine),
        new_values=decoded_faces(fresh_source,fresh_engine),restored_value=decoded_faces(source,before)[12172])
    need(not set(role['marker_original_indices'])&{r['original_source_triangle'] for r in newrows},'Approved marker originals reappeared')
    assets=[]
    for asset in role['assets']:
        destination=out/'candidate'/asset['relative'];need(not destination.exists(),'Asset output exists')
        destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(read_bound(asset['candidate']))
        need(hashlib.sha256(destination.read_bytes()).hexdigest()==asset['candidate']['sha256'],'Saved asset differs')
        assets.append(dict(path=str(destination),sha256=asset['candidate']['sha256']))
    need(len(assets)==12,'All12 exact assets required')
    for pin in allpins:read_bound(pin)
    receipt=dict(job_id=JOB,state='candidate_saved',planned=132,kept=132,rolled_back=0,policy_excluded_saved_edit_indices=[86],
        output_triangles=actual.mesh.n_faces,required_whole_originals=scope['mandatory_originals'],scope=scope,
        checkpoint_sha256=checkpoint['receipt_sha256'],pair=pair,binding=binding,admission=admission,decoded_survivor_readback=readback,
        assets=assets,independent_validation='PENDING_ON_NEW_HASHES',prior_validation_transferred=False,repair_complete=False,acceptance=False)
    (out/'run-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
    worker('candidate_saved',kept=132,rolled_back=0,output_triangles=actual.mesh.n_faces,checkpoint_sha256=checkpoint['receipt_sha256'])
    return dict(output=str(out/'candidate'),output_triangles=actual.mesh.n_faces,planned=132,kept=132,rolled_back=0,acceptance=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('phase',choices=('metadata','execute'))
    parser.add_argument('--input',type=Path,required=True);parser.add_argument('--input-sha256',required=True);args=parser.parse_args()
    docs=documents(args.input,args.input_sha256);spec,role,checkpoint,result,lineage,scope,plan=docs
    if args.phase=='metadata':
        print(json.dumps(dict(geometry_loaded=False,numpy_imported=('numpy' in sys.modules),loaded_engine_modules=[name for name in sys.modules if name=='engine' or name.startswith('engine.')],kernel_called=False,model_saved=False,
            current_triangles=26291,retained_saved_edits=132,policy_excluded_saved_edit_indices=[86],mandatory_originals=4334,
            expected_triangles_if_saved=26290,independent_validation='PENDING_ON_NEW_HASHES',acceptance=False)))
        return 0
    print(json.dumps(execute(*docs,input_pin=dict(path=str(args.input),bytes=args.input.stat().st_size,sha256=args.input_sha256))))
    return 0


if __name__=='__main__':raise SystemExit(main())
