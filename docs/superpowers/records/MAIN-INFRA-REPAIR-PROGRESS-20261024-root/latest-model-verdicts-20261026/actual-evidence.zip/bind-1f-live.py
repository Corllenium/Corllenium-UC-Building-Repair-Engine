from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
deployment=json.loads((root/'data/siege-live-20261026/inspection-10571-deployment.log').read_text(encoding='utf-8-sig').strip())
assert deployment['files_per_root']==deployment['http_hashes']==29 and deployment['candidate_triangles']==10571 and deployment['remaining_target_counts']==5198
assert deployment['preservation_passed'] is True and deployment['signed_targets_passed'] is deployment['accepted'] is deployment['status_written'] is False
packet_path=root/'data/p571/packet-receipt.json';assert hashlib.sha256(packet_path.read_bytes()).hexdigest()=='15c97665df5c27f4d9b2e6e8508cc862ce9593975d210f99c3f56277b46d3571'
packet=json.loads(packet_path.read_bytes());candidate=packet['results']['candidate']
assert candidate['n_faces']==10571 and candidate['obj_sha256']=='d8ee718ff223049dc8eaa888b9be34a2448919f7d76910e4d15a43329ec7bdff'
for row in packet['files']:assert hashlib.sha256((root/'data/p571'/row['path']).read_bytes()).hexdigest()==row['sha256']
sys.path.insert(0,str(root/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
path=root/'data/main-infra-fresh/current.json';doc=load_progress(path);f=doc['floors']['1F'];now=utc_now()
other=json.dumps({k:v for k,v in doc['floors'].items() if k!='1F'},sort_keys=True)
assert f['pending_output_triangles']==10571 and f['pending_signed_validation_sha256']=='ec233f6d178c5e71755a61d360ecd92db5f6eca35e602bc3facc04480e755a80'
f.setdefault('prior_displayed_candidates',[]).append(f['latest_saved_candidate'])
f['latest_saved_candidate']=dict(engine='E5',run_id='MAIN-INFRA-1F-E5-fullcover-batch-20261025',builder_commit='d39ad3cb20ed0dc72ed13473da23669fe44f3434',triangles=10571,base_triangles=10651,original_triangles=15856,planned_edits=102,kept_edits=80,rolled_back_edits=22,protected_original_parents=754,
    source_candidate_sha256=candidate['obj_sha256'],engine_candidate_sha256='604b30ea35027c3475a2a3779ffb60b7d082fb216f21a908c06dd8c65c86e477',checkpoint_sha256='b9f8f990d34ef1079c22b07d6438ccb7e1a3c7d233c25a7fc3721dd49e795565',
    independent_validation='preservation_passed_problem_targets_failed',preservation_passed=True,full_signed='FAIL',full_signed_preservation='PASS',full_signed_sha256='ec233f6d178c5e71755a61d360ecd92db5f6eca35e602bc3facc04480e755a80',acceptance=False,displayed_candidate_triangles=10571,remaining_problems=candidate['counts'])
prefix=deployment['preview'].rsplit('/',1)[0]+'/evidence-10571/'
f.update(source_preview=deployment['source_preview'],candidate_preview=deployment['preview'],output_triangles=10571,state='blocked',independent_before_triangles=15856,independent_after_triangles=10571,
    independent_validator_stage='full_signed_complete_10571',independent_validator_worker_pid=18052,independent_validator_worker_alive=False,
    independent_guard_passed=True,independent_guard_sha256='f62244507ea5e97da76f7437db52f9313413c3d1525a5eed8272c8497691c343',
    retained_floor_passed=True,retained_floor_sha256='ec140141c2575ec953719cf3f9bef3fa4d8dd8661f326d54b1a096c27feff520',
    native_preservation_passed=True,native_readback_sha256='80eca258873402e290094554814ea715d99c93345adb7728398504d7b5a7f727',native_qualified_changed_pixels=0,native_qualified_total_views=33,
    validator_passed=False,validator_texture_preservation_passed=True,validator_nothing_deleted_passed=True,validator_pixel_floor_passed=True,
    signed_validation_sha256='ec233f6d178c5e71755a61d360ecd92db5f6eca35e602bc3facc04480e755a80',validator_ref=prefix+'validation.json',
    evidence_refs=[prefix+x for x in ('guard.json','native.json','floor.json','validation.json','review.json','terminal.json','native-paired.png')],inspection_published=True,inspection_acceptance=False,inspection_receipt_sha256='15c97665df5c27f4d9b2e6e8508cc862ce9593975d210f99c3f56277b46d3571',
    step='After now displays newest1F10571 with original textures and matching seven error filters. Independent strict26/native33/floor14/full signed preservation PASS. Signed problem targets FAIL5198;80 guarded edits kept,22 rolled back.',
    blocker='1708 different-look overlaps,1155 same-look overlaps and2335 cracks remain.104 fewer total target instances than10651, but same-look increased2. Not accepted.',last_work_event_at=now)
for key in list(f):
    if key.startswith('pending_'):del f[key]
assert f['accepted_preview'] is None and f['owner_decision_ref'] is None
f.setdefault('activity_events',[]).append(dict(at=now,phase='inspection_10571_published',message='Actual10571 E5 candidate, six original texture groups, all seven real maps and ec233 validation evidence now live.29 files verified in both roots and HTTP. Preservation PASS, targets FAIL5198, no acceptance.'))
assert other==json.dumps({k:v for k,v in doc['floors'].items() if k!='1F'},sort_keys=True)
doc['updated_at']=now;doc['last_work_event_at']=now
draft=root/'data/siege-live-20261026/inspection-10571-current.draft.json';draft.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8')
code="import fs from 'node:fs';import {parseFreshMainInfraStatus} from './dashboard/lib/buildings/freshMainInfraStatus.ts';import {freshFloorStages} from './dashboard/lib/buildings/freshMainInfraPipeline.ts';const d=parseFreshMainInfraStatus(JSON.parse(fs.readFileSync(process.argv[1],'utf8')));if(!d||d.floors['1F'].output_triangles!==10571||d.floors['1F'].accepted_preview!==null)process.exit(2);const p=d.floors['1F'];const s=freshFloorStages({before:15856,after:10571,sourceErrors:{},afterErrors:p.latest_saved_candidate.remaining_problems,candidateSha:p.latest_saved_candidate.source_candidate_sha256,progress:p});if(s[5].summary!=='Preservation PASS; independent validation FAIL'||!s[5].details[0].includes('5,198'))process.exit(3);"
subprocess.run(['node','--input-type=module','-e',code,str(draft)],cwd=root/'.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023',capture_output=True,check=True)
write_progress(path,doc)
print(json.dumps(dict(displayed_1F=10571,measured_filters=7,preservation='PASS',signed_targets='FAIL',remaining=5198,other_floors_unchanged=True,accepted=False)))
