from pathlib import Path
from datetime import datetime,timezone
import json,sys
root=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
wt=Path('D:/LLM_BACKUP/Codex session/main-infra-4f-native-retention-20261026/05-Corllenium-UC-Building-Repair-Engine')
o=json.loads((root/'data/siege-live-20261026/4f-engine-observation.json').read_bytes())
assert o['pid']==45704 and o['start_utc']=='2026-10-25T19:54:31.9480973Z' and o['alive'] is True and o['phase_sha256']=='1faabbdb973aa6fc8a20bed131fa886cacc9f7b5bc7a99227f4adaefc60f26ac'
assert (datetime.now(timezone.utc)-datetime.fromisoformat(o['observed_at'].replace('Z','+00:00'))).total_seconds()<15
w=json.loads((wt/'data/main-infra-4f-native-retention/run-20261026/execution-4F/worker.json').read_bytes())
assert w['actual_pid']==45704 and w['actual_creation_filetime']==134374316719480973 and w['floor']=='4F' and w['run_id']=='main-infra-4f-native-retention-20261026'
assert w['step'] in ('E3','E5') and w['state'] in ('checking_sites','stage_saved','candidate_saved')
sys.path.insert(0,str(root/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
p=root/'data/main-infra-fresh/current.json';d=load_progress(p);f=d['floors']['4F'];now=utc_now();phase=w['step']+'_'+w['state']
f.update(state='cleaning' if w['state']=='checking_sites' else 'validating',worker_pid=o['pid'],worker_start_utc=o['start_utc'],worker_alive=True,worker_observed_at=o['observed_at'],worker_cpu_seconds=o['cpu_seconds'],engine_stage=w['step'],
    step='Actual4F repair engine: '+w['step']+' '+w['state']+'; '+str(w['selected_sites'])+' selected sites.19764 original triangles protected; strict defaults and unsafe-site rollback active. Independent validation follows saved output.',blocker=None)
events=f.setdefault('worker_events',[])
if not any(e.get('phase')==phase and e.get('pid')==45704 for e in events):
    event=dict(engine=w['step'],run_id=w['run_id'],pid=45704,start_utc=o['start_utc'],observed_at=o['observed_at'],phase=phase,message=f['step'])
    event.update({k:w[k] for k in ('output_triangles','kept_edits','rolled_back_edits') if w.get(k) is not None});events.append(event)
    f['last_work_event_at']=w['updated_utc'];d['last_work_event_at']=w['updated_utc']
if w.get('output_triangles') is not None:f['pending_output_triangles']=w['output_triangles']
d['updated_at']=now;write_progress(p,d)
print(json.dumps(dict(floor='4F',actual_pid=45704,stage=w['step'],state=w['state'],selected_sites=w['selected_sites'],cpu_seconds=o['cpu_seconds'],accepted=False)))
