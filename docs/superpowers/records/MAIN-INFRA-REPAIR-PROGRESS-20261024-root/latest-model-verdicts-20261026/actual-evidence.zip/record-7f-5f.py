from pathlib import Path
import hashlib,json,sys
root=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
seven=Path('D:/LLM_BACKUP/Codex session/iv7n/05-Corllenium-UC-Building-Repair-Engine')
five=Path('D:/LLM_BACKUP/Codex session/f5n/05-Corllenium-UC-Building-Repair-Engine')
def bound(path,sha):
    raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==sha
    return json.loads(raw)
v=bound(seven/'data/iv7f-validation/attempt19695-target-local/validation-retry-20261026/validation.json','5abac22a931e88626ecff754c3fa065c8350c00c6434ac63efc865bb22d22750')
comparison=bound(seven/'data/iv7n-preflight/c7-versus-fullsigned-render-fields-20261026.json','e79597e0bb18d903a57b0103eee9130c69fb0b81728cad86e93b291bebf26121')
t=json.loads((seven/'data/iv7n-preflight/monitor-7F19695-default-fullsigned-retry-20261026-with-raw-capture-20261025T193931/result.json').read_bytes())
assert t['actual_pid']==59304 and t['actual_exit_code']==t['launcher_exit_code']==2 and t['all_owned_exited'] is True and t['abort_reason'] is None
assert v['inputs']['after_sha256']=='14fc2b0665630e56e7e579b0a858619cf4ba062679071ca90dea32c7bf2ae0a9'
assert v['checks']['textures']['status']==v['checks']['nothing_deleted']['status']=='PASS' and v['checks']['problems']['status']=='FAIL'
counts={k:r['after'] for k,r in v['checks']['problems']['kinds'].items()}
assert (counts['flicker_diff'],counts['flicker_same'],counts['cracks'])==(1522,2629,4550)
foot=bound(five/'data/5f-native-footprint/attempt1/footprint.json','2c8835aa44a637ebe1b8fcdc9e95587e8255d3814f30cee90c14844e17a2c3b2')
tf=json.loads((five/'data/5f-native-preflight/monitor-5F-all3pixel-conservative-whole-site-footprint-20261025T195015/result.json').read_bytes())
assert tf['actual_pid']==59024 and tf['actual_exit_code']==0 and tf['all_owned_exited'] is True
assert foot['qualified_changed_pixels']==3 and len(foot['conservative_whole_sites']['E3'])==7 and len(foot['prospective_E5_whole_sites'])==3
sys.path.insert(0,str(root/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
p=root/'data/main-infra-fresh/current.json';d=load_progress(p);now=utc_now();f=d['floors']['7F']
assert f['output_triangles']==19695 and f['latest_saved_candidate']['source_candidate_sha256']=='849b082378f93055f723a2b23913473eebf94ab5094f56c58eb4a06830526328'
f.update(state='blocked',worker_pid=59304,worker_start_utc=t['actual_creation_utc'],worker_alive=False,worker_observed_at=t['ended_utc'],worker_cpu_seconds=None,last_work_event_at=t['ended_utc'],
    step='7F19695 full independent validation complete: texture and visible preservation PASS; signed problem targets FAIL8701. Actual model and all7 measured filters remain available in Before/After.',
    blocker='1522 different-look overlaps,2629 same-look overlaps and4550 cracks remain; no acceptance. New signed evidence is being published.',
    validator_passed=False,validator_texture_preservation_passed=True,validator_nothing_deleted_passed=True,validator_pixel_floor_passed=True,signed_validation_sha256='5abac22a931e88626ecff754c3fa065c8350c00c6434ac63efc865bb22d22750')
f['latest_saved_candidate'].update(full_signed='FAIL',full_signed_preservation='PASS',full_signed_sha256='5abac22a931e88626ecff754c3fa065c8350c00c6434ac63efc865bb22d22750',preservation_passed=True,remaining_problems=counts)
f.setdefault('worker_events',[]).append(dict(engine='Validator',run_id='MAIN-INFRA-7F-19695-VALIDATE-20261025',pid=59304,start_utc=t['actual_creation_utc'],observed_at=t['ended_utc'],phase='full_signed_19695_complete',message='Genuine full Validator completed exit2 without resource abort.217384 texture samples0failed; visible preservation PASS;27 floor faces0failed. Targets FAIL1522diff/2629same/4550cracks. Maps render fields match captured signed raws exactly; not accepted.'))
f=d['floors']['5F'];f.update(state='blocked',worker_pid=59024,worker_start_utc=tf['actual_creation_utc'],worker_alive=False,worker_observed_at=tf['ended_utc'],worker_cpu_seconds=None,last_work_event_at=tf['ended_utc'],
    step='5F fresh native33 check: source control exact;3 changed candidate pixels. Whole-site trace complete:7 E3 sites/492 originals plus3 prospective E5 sites/8 originals; guarded repair policy is being prepared.',
    blocker='Historical5F candidate has3 measured changed pixels. New protected engine candidate not yet saved; no acceptance.',native_diagnostic_changed_pixels=3,native_diagnostic_changed_views=3,footprint_sha256='2c8835aa44a637ebe1b8fcdc9e95587e8255d3814f30cee90c14844e17a2c3b2')
f.setdefault('worker_events',[]).append(dict(engine='Validator',run_id='MAIN-INFRA-5F-NATIVE-RETENTION-20261026',pid=59024,start_utc=tf['actual_creation_utc'],observed_at=tf['ended_utc'],phase='native3_whole_site_trace_complete',message='Actual fresh33 source-control pairs exact; candidate3changedpixels. Conservative original-source footprints identify7 E3 whole sites/492 originals and3 prospective E5 sites/8 originals. Historical rollback originals remain mandatory. No repair/pass claim.'))
d['updated_at']=now;d['last_work_event_at']=now;write_progress(p,d)
print(json.dumps(dict(floor7_preservation='PASS',floor7_targets=8701,floor5_changed_pixels=3,floor5_E3_whole_sites=7,accepted=False)))
