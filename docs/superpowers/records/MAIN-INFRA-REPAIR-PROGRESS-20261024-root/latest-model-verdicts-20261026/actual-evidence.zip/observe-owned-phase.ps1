param([Parameter(Mandatory=$true)][int]$ExpectedPid,[Parameter(Mandatory=$true)][string]$ExpectedStart,[Parameter(Mandatory=$true)][int]$ExpectedParent,[Parameter(Mandatory=$true)][string]$PhasePath,[Parameter(Mandatory=$true)][string]$PhaseSha,[Parameter(Mandatory=$true)][string]$Out)
$ErrorActionPreference='Stop'
$taskNative='D:/LLM_BACKUP/Codex session/main-infra-resource-monitor-v5-20261024/05-Corllenium-UC-Building-Repair-Engine/docs/superpowers/records/MAIN-INFRA-RESOURCE-MONITOR-V5-20261024/execute-resource-guard-v5.ps1'
if((Get-FileHash -LiteralPath $taskNative -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'f158802651c955b6b322140ff9567496c527cd1bac0e63598171c45eeea60e12'){throw 'Native observer changed'}
if((Get-FileHash -LiteralPath $PhasePath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $PhaseSha){throw 'Phase changed'}
. $taskNative -FunctionsOnly
$taskArgs=(Get-Content -LiteralPath $PhasePath -Raw|ConvertFrom-Json).args
$taskProc=[Diagnostics.Process]::GetProcessById($ExpectedPid);$taskHandle=$taskProc.Handle
$taskBirth=[UcE7ExecNative]::Times($taskHandle)[0]
if($taskBirth.ToString('o') -ne $ExpectedStart -or [UcE7ExecNative]::Parent($taskHandle) -ne $ExpectedParent){throw 'Owned native lifetime differs'}
$taskImage='C:/Users/Future26/AppData/Local/Programs/Python/Python312/python.exe'
if([UcE7ExecNative]::Image($taskHandle).Replace('\','/') -ine $taskImage){throw 'Owned image differs'}
if((Normalize-ExecCommand ([UcE7ExecNative]::Command($taskHandle))) -ne (Normalize-ExecCommand ($taskImage+' '+($taskArgs -join ' ')))){throw 'Owned native command differs'}
$taskProc.Refresh()
$taskObserved=[ordered]@{pid=$ExpectedPid;start_utc=$taskBirth.ToString('o');observed_at=[DateTime]::UtcNow.ToString('o');alive=[UcE7ExecNative]::Alive($taskHandle);cpu_seconds=$taskProc.TotalProcessorTime.TotalSeconds;phase_sha256=$PhaseSha}
[IO.File]::WriteAllText($Out,($taskObserved|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
$taskObserved|ConvertTo-Json -Compress
