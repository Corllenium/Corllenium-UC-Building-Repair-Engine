from pathlib import Path
import sys,json,hashlib,tarfile,io
from urllib.parse import quote

ROOT=Path(__file__).resolve().parents[2]
REV='7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511'
INV=ROOT/'data/blender-review/MAIN-INFRA-7FLOORS-NOT_FINAL-20261026-ORANGE-REMOVED-inputs/floor-inventory.json'
PROOF=ROOT/'.claude/worktrees/omv/data/orange-independent/run-20261026/independent-marker-proof.json'
AUTH=ROOT/'.claude/worktrees/omv/docs/superpowers/records/MAIN-INFRA-ORANGE-BOX-VALIDATE-20261026/root-exact-selection.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(row):
    b=Path(row['path']).read_bytes();assert sha(b)==row['sha256'];return b
def js(d):return (json.dumps(d,indent=2,allow_nan=False)+'\n').encode()
assert sha(INV.read_bytes())=='3033c4ee856bf56ba1015728bc636584b175151d400fda1f005610e16f851db4'
assert sha(PROOF.read_bytes())=='d8b5dc6bd6be262d0e2522ffd787b2f9e1692d31f3d772588248cacbce5c4f57'
assert sha(AUTH.read_bytes())=='81c02db5fca5eda121549533cca06a23e14c160860246af9613deedc652b6dfb'
inventory=json.loads(INV.read_bytes());proof=json.loads(PROOF.read_bytes());authority=json.loads(AUTH.read_bytes())
for floor in sys.argv[1:]:
    index=int(floor[:-1])-1;row=inventory['floors'][index];verified=proof['floors'][index];selected=authority['floors'][index]
    assert row['floor']==verified['floor']==selected['floor']==floor and verified['passed'] and not verified['full_floor_acceptance']
    census=ROOT/'.claude/worktrees/ocn/data/orange-free-census/run-20261026'/floor
    receipt=json.loads((census/'census-receipt.json').read_bytes());assert receipt['floor']==floor and receipt['no_model_mutation'] and not receipt['acceptance']
    prefix=f'models/main-infra/{REV}/{floor}/main-infra-clean-20261023/'
    package_root=ROOT/'data/olr'/floor;stage=package_root/'s';stage.mkdir(parents=True,exist_ok=False);files={};results={}
    def add(path,b):
        assert path.startswith(prefix) and '..' not in path and '\\' not in path and path not in files
        p=stage/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert p.read_bytes()==b
        files[path]=dict(path=path,sha256=sha(b),bytes=len(b));return '/'+quote(path,safe='/')
    counts=receipt['results']['candidate']['counts'];remaining=sum(counts[k] for k in ('flicker_diff','flicker_same','reversed','cracks'))
    summary=dict(kind='derived_independent_marker_only_readback',floor=floor,parent_proof_sha256=sha(PROOF.read_bytes()),authority_sha256=sha(AUTH.read_bytes()),
        candidate_source_sha256=row['candidate']['sha256'],components_removed=2,approved_original_faces=selected['selected_original'],
        approved_input_faces=selected['selected_current'],nonmarker_OBJ_bytes_exact=True,all_original_assets_unchanged=True,
        protected_nonmarker_contact_originals=selected['protected_contact_originals'],full_floor_validation='PENDING',accepted=False)
    summary_url=add(prefix+'candidate/evidence-orange-20261026/marker-summary.json',js(summary))
    census_url=add(prefix+'candidate/evidence-orange-20261026/census-receipt.json',(census/'census-receipt.json').read_bytes())
    for role,label in [('source','before'),('candidate','after')]:
        binding=receipt['results'][role];base_map=json.loads(raw(binding));raw_map=json.loads(raw(dict(path=binding['raw_path'],sha256=binding['raw_sha256'])))
        assert base_map['binding']['obj_sha256']==row[role]['sha256'] and base_map['binding']['floor_id']=='MAIN_INFRA_'+floor
        assert base_map['n_faces']==binding['n_faces']==row[role+'_lexical']['faces']==raw_map['n_faces']
        assert base_map['counts']==raw_map['counts']==binding['counts']
        for layer,ids in raw_map['layers'].items():assert len(ids)==len(set(ids)) and all(type(i) is int and 0<=i<base_map['n_faces'] for i in ids)
        rendered=dict(base_map,layers=raw_map['layers'],layer_counts=raw_map['layer_counts'],
            layer_provenance=dict(facade='Existing default detector facade diagnostic; not a preservation verdict.'))
        assets=[]
        for asset in row['assets']:
            source=Path(asset['qualified_source_path']) if role=='source' else Path(asset['path']);b=source.read_bytes();assert sha(b)==asset['sha256']
            url=add(prefix+role+'/'+asset['relative'].replace('\\','/'),b);assets.append(dict(url=url,sha256=sha(b)))
        model=raw(row[role]);obj_url=add(prefix+role+'/model-orange-20261026.obj',model);assets.append(dict(url=obj_url,sha256=sha(model)))
        map_bytes=js(rendered);map_url=add(prefix+role+'/errors-orange-20261026.json',map_bytes);assets.append(dict(url=map_url,sha256=sha(map_bytes)))
        mtl=[a for a in row['assets'] if a['relative'].lower().endswith('.mtl')];assert len(mtl)==1
        preview=dict(schema_version=1,building_id='MAIN_INFRA',source_revision=REV,run_id='main-infra-clean-20261023',floor=floor,
            floor_id='MAIN_INFRA_'+floor,kind=role,display_frame=dict(up_axis='Y',units='metres',source_local=True),bounds=row['source_bounds'],
            obj_url=obj_url,mtl_url='/'+quote(prefix+role+'/'+mtl[0]['relative'].replace('\\','/'),safe='/'),assets=assets,errors_url=map_url)
        if role=='candidate':preview['inspection']=dict(validation_state='PENDING',inspection_only=True,accepted=False,acceptance=False,
            publication_eligible=False,guard=None,native=None,signed=None,preservation_status='EXACT_APPROVED_MARKER_DROPOUT_ONLY_PASS',
            input_triangles=row['source_lexical']['faces'],stage_input_triangles=verified['proofs']['candidate_source']['before_faces'],
            output_triangles=base_map['n_faces'],engine_run_id='MAIN-INFRA-ORANGE-BOX-CLEANUP-20261026',remaining_target_counts=remaining,
            problem_targets=dict(status='FAIL' if remaining else 'PENDING',remaining=remaining,basis='Fresh default error census; complete signed validation pending'),
            label=f'Orange boxes removed; {remaining:,} target instances remain; not accepted',
            census=dict(url=census_url,sha256=sha((census/'census-receipt.json').read_bytes())),
            marker_dropout=dict(url=summary_url,sha256=sha(js(summary)),passed=True,scope='Exact approved box deletion only; all other OBJ bytes and original assets preserved'))
        preview_url=add(prefix+role+'/preview-orange-20261026.json',js(preview))
        results[role]=dict(preview=preview_url,preview_sha256=sha(js(preview)),obj_sha256=sha(model),triangles=base_map['n_faces'],
            errors_url=map_url,errors_sha256=sha(map_bytes),facade_faces=raw_map['layer_counts']['facade'],counts=base_map['counts'])
    archive=package_root/'models.tar.gz'
    with tarfile.open(archive,'w:gz') as tf:
        for name,rowfile in files.items():
            b=(stage/name).read_bytes();assert sha(b)==rowfile['sha256'];info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;tf.addfile(info,io.BytesIO(b))
    with tarfile.open(archive) as tf:
        assert len(tf.getmembers())==len(files)
        for member in tf.getmembers():assert member.isfile() and sha(tf.extractfile(member).read())==files[member.name]['sha256']
    result=dict(floor=floor,archive=str(archive),archive_sha256=sha(archive.read_bytes()),files=list(files.values()),results=results,
        source_revision=REV,marker_components_removed=2,approved_removed_triangles=24,remaining_target_instances=remaining,
        full_floor_validation='PENDING',accepted=False,no_model_parse=True,no_detector_rerun=True)
    manifest=package_root/'package.json';manifest.write_bytes(js(result));print(json.dumps(dict(floor=floor,files=len(files),archive_sha256=result['archive_sha256'],
        package_sha256=sha(manifest.read_bytes()),candidate_triangles=results['candidate']['triangles'],remaining=remaining)))
