$ErrorActionPreference='Stop'
$taskSite='devenvir@sv70.ifastnet.com'
$taskCommon=@('-i','C:/Users/Future26/.ssh/corllenium_siege_ed25519','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=1','-o','LogLevel=ERROR','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=deploy/known_hosts')
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskRows=@(
 @{Source="$taskRoot/data/olr/all.tar.gz";Name='main-infra-orange-role.tar.gz';Sha='66e2e3d35c45f030c4f9dcc3027fe52f344af72a97bd0548f8e369bf3776dd0e'},
 @{Source="$taskRoot/data/olr/all-package.json";Name='main-infra-orange-role.json';Sha='17103f45ccbc9cfabe8bcd89c201a804274bf481a24e722ccdf8e4c245dd680d'},
 @{Source="$taskRoot/data/siege-live-20261026/publish-orange-role.py";Name='publish-orange-role.py';Sha='b6841798622a36de649118cf806fed934a5d212552a563dc563e54db777ac5c6'}
)
foreach($taskRow in $taskRows){
 if((Get-FileHash -Algorithm SHA256 -LiteralPath $taskRow.Source).Hash.ToLowerInvariant() -ne $taskRow.Sha){throw 'Publication input changed'}
 & scp -q -P 27015 @taskCommon $taskRow.Source ($taskSite+':/tmp/'+$taskRow.Name)
 if($LASTEXITCODE -ne 0){throw ('Upload failed: '+$taskRow.Name)}
}
$taskRemote='python3 -c "import hashlib,runpy; p=''/tmp/publish-orange-role.py''; assert hashlib.sha256(open(p,''rb'').read()).hexdigest()==''b6841798622a36de649118cf806fed934a5d212552a563dc563e54db777ac5c6''; p2=''/tmp/main-infra-orange-role.json''; assert hashlib.sha256(open(p2,''rb'').read()).hexdigest()==''17103f45ccbc9cfabe8bcd89c201a804274bf481a24e722ccdf8e4c245dd680d''; runpy.run_path(p,run_name=''__main__'')"'
& ssh -p 27015 @taskCommon $taskSite $taskRemote
if($LASTEXITCODE -ne 0){throw 'Inspection assets not verified; current live model selection stays unchanged'}
