from pathlib import Path
import json,hashlib,sys,subprocess
ROOT=Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=ROOT/'data/olr/all-package.json';assert sha(p)=='17103f45ccbc9cfabe8bcd89c201a804274bf481a24e722ccdf8e4c245dd680d'
manifest=json.loads(p.read_bytes());published=json.loads((ROOT/'data/siege-live-20261026/orange-role-deployment.log').read_text(encoding='utf-8-sig').strip())
assert published['files_per_root']==published['http_hashes']==216 and published['archive_sha256']==manifest['archive_sha256'] and not published['accepted']
assert json.loads((ROOT/'data/olr/preview-loader-qa.json').read_bytes())['all14PreviewsLoadedWithBoundErrors'] is True
sys.path.insert(0,str(ROOT/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
path=ROOT/'data/main-infra-fresh/current.json';doc=load_progress(path);now=utc_now();models={}
for row in manifest['floors']:
    floor=row['floor'];f=doc['floors'][floor];candidate=row['results']['candidate'];source=row['results']['source']
    assert f['output_triangles']==candidate['triangles'] and f['latest_saved_candidate']['source_candidate_sha256']==candidate['obj_sha256']
    assert f['accepted_preview'] is None and f['owner_decision_ref'] is None
    f.setdefault('inspection_manifest_history',[]).append(dict(at=now,source=f['source_preview'],candidate=f['candidate_preview'],reason='URL layout correction only; exact same model and maps'))
    f['source_preview']=source['preview'];f['candidate_preview']=candidate['preview'];f['evidence_refs']=[candidate['preview'].rsplit('/',1)[0]+'/evidence-orange-20261026/'+name for name in ('marker-summary.json','census-receipt.json')]
    f['last_work_event_at']=now
    events=f.setdefault('worker_events',[])
    additions=[dict(engine='E3',run_id='MAIN-INFRA-ORANGE-BOX-CLEANUP-20261026',pid=19260,start_utc='2026-10-26T03:01:54.1191828Z',observed_at='2026-10-26T03:02:23.9839057Z',phase='approved_orange_boxes_removed',
        message=f"{floor}: engine saved {candidate['triangles']:,} triangles after removing exactly24 approved orange cube triangles. Source exports/cuts/other geometry untouched; actualexit0/noabort/allownedgone."),
      dict(engine='Validator',run_id='MAIN-INFRA-ORANGE-BOX-VALIDATE-20261026',pid=17008,start_utc='2026-10-26T03:04:34.6810482Z',observed_at='2026-10-26T03:04:39.1506510Z',phase='marker_only_exact_survivors_verified',
        message='Independent saved SOURCE/ENGINE/reference byte readback passed for the exact approved marker dropout. All nonmarker face/vertex/UV/normal/material/group bytes and texture assets unchanged. This is not full-floor validation or acceptance.')]
    ops=ROOT/'.claude/worktrees/ocn/data/orange-census-preflight'
    monitors=list(ops.glob('monitor-orange-free-default-census-'+floor+'-*'));valid=[]
    for directory in monitors:
        terminal=directory/'result.json'
        if terminal.exists():
            t=json.loads(terminal.read_bytes())
            if t.get('actual_exit_code')==0 and t.get('all_owned_exited') and t.get('abort_reason') is None:valid.append((directory,t))
    assert len(valid)==1
    directory,t=valid[0];identity=json.loads((directory/'actual-identity.json').read_bytes())
    additions.append(dict(engine='Validator',run_id='MAIN-INFRA-ORANGE-FREE-CENSUS-20261026',pid=t['actual_pid'],start_utc=t['actual_creation_utc'],observed_at=t['ended_utc'],phase='orange_free_default_error_and_facade_maps_saved',
        message=f"{floor}: actual default detector measured original{source['triangles']:,}/candidate{candidate['triangles']:,}, two calls. Seven error maps and {candidate['facade_faces']:,} candidate facade IDs saved. {row['remaining_target_instances']:,} signed target instances remain; not accepted."))
    for event in additions:
        if not any(e.get('pid')==event['pid'] and e.get('phase')==event['phase'] for e in events):events.append(event)
    f.update(worker_pid=t['actual_pid'],worker_start_utc=t['actual_creation_utc'],worker_observed_at=t['ended_utc'],worker_alive=False)
    f.pop('worker_cpu_seconds',None)
    models[floor]=dict(triangles=candidate['triangles'],candidate_preview=candidate['preview'],source_preview=source['preview'],new_worker_events=len(additions),current_worker_exited=True)
doc['updated_at']=now;doc['last_work_event_at']=now
draft=ROOT/'data/siege-live-20261026/orange-role-current.draft.json';draft.write_text(json.dumps(doc,indent=2)+'\n')
code="import fs from 'node:fs';import {parseFreshMainInfraStatus} from './dashboard/lib/buildings/freshMainInfraStatus.ts';const d=parseFreshMainInfraStatus(JSON.parse(fs.readFileSync(process.argv[1],'utf8')));if(!d)process.exit(2);for(const [i,n]of[10549,38110,44948,58064,34977,27084,19671].entries()){const p=d.floors[(i+1)+'F'];if(p.output_triangles!==n||!p.candidate_preview.endsWith('/candidate/preview-orange-20261026.json')||p.accepted_preview!==null||p.worker_alive)process.exit(3);}"
subprocess.run(['node','--input-type=module','-e',code,str(draft)],cwd=ROOT/'.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023',capture_output=True,check=True)
write_progress(path,doc);result=dict(at=now,models=models,geometry_or_counts_changed=False,all216_HTTP_assets_verified=True,all14_preview_loader_checks_passed=True,accepted=False)
(ROOT/'data/siege-live-20261026/orange-role-canonical-readback.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
