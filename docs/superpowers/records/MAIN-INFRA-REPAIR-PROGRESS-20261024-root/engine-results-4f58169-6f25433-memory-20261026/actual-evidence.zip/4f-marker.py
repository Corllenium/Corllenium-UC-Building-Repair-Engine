"""Map only the approved original boxes through a fresh checked survivor pair."""
import hashlib
import importlib
import json
from pathlib import Path

from tools.main_infra_4f_guard105_run import need

ROOT = Path(__file__).resolve().parents[1]
AUTHORITY = '81c02db5fca5eda121549533cca06a23e14c160860246af9613deedc652b6dfb'
PAID = {'main_infra_orange_box_cleanup.py': 'eff40a6ec138e51cee3c8ed576555d487a69109e6243645f2b8d7baf2f956ea0',
        'main_infra_orange_box_inventory.py': 'c61d23a99da8cd91820d7b1bfdb3b3ddd4ecc86e00d9c7c44c50d81a3776361c',
        'main_infra_orange_boxes.py': '96c3b0c13fbe14750b6d07d6f7da9de36b188d37294fcb71b62147369dbbeed5'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def marker_groups(original_ids, *, approval, report, authority_sha256):
    need(authority_sha256 == AUTHORITY and approval['floor'] == report['floor'] == '4F'
         and report['original_count'] == 78160 and report['material'] == 'minecraft_wool_colored_orange_-1',
         'Exact owner-selected original 4F marker context required')
    need(all(type(i) is int and 0 <= i < 78160 for i in original_ids)
         and len(set(original_ids)) == len(original_ids), 'Fresh original ancestry must be unique and bounded')
    selected = approval['selected_original']
    need(selected == list(range(78136, 78160)) and len(approval['components']) == len(set(approval['components'])) == 2,
         'Only the exact two approved marker components may be removed')
    components = {r['component_id']: r for r in report['original_components']}
    need(len(components) == len(report['original_components']) and set(approval['components']) <= components.keys(),
         'Unknown or ambiguous original marker component')
    inverse = {original: i for i, original in enumerate(original_ids)}
    need(set(selected) <= inverse.keys(), 'Approved marker original is missing from the fresh checked outcome')
    groups = []
    for component in approval['components']:
        faces = components[component]['faces']
        need(len(faces) == len(set(faces)) and set(faces) <= set(selected), 'Unapproved or partial marker component')
        groups.append(dict(component_id=component, original_faces=faces.copy(), faces=[inverse[f] for f in faces]))
    all_faces = [f for g in groups for f in g['original_faces']]
    need(sorted(all_faces) == selected and len(set(all_faces)) == 24, 'Complete approved marker union required')
    return groups


def paid_engine():
    for name, expected in PAID.items():
        need(sha(ROOT/'tools'/name) == expected, 'Qualified marker engine component changed: ' + name)
    return importlib.import_module('tools.main_infra_orange_box_cleanup')


def save_marker_pair(source_path, engine_path, original_ids, *, approval, report, authority_sha256,
                     out, upstream, assets=()):
    import numpy as np
    from engine.io.obj_reader import read_obj
    from engine.io.snapshot import copy_verified
    paid = paid_engine()
    groups = marker_groups(original_ids, approval=approval, report=report, authority_sha256=authority_sha256)
    source_path, engine_path, out = Path(source_path), Path(engine_path), Path(out)
    need(not out.exists(), 'Exclusive final marker output required')
    source, engine = read_obj(source_path), read_obj(engine_path)
    need(source.n_faces == engine.n_faces == len(original_ids), 'Fresh paired model and original ancestry differ')
    for mesh in (source, engine):
        for group in groups:
            need(all(mesh.materials[int(mesh.face_material[i])] == 'minecraft_wool_colored_orange_-1'
                     for i in group['faces']), 'Approved marker no longer has its qualified source material')
    after, kept, edits = paid.apply_marker_removals(source, groups, AUTHORITY)
    eng_after, eng_kept, _ = paid.apply_marker_removals(engine, groups, AUTHORITY)
    need(np.array_equal(kept, eng_kept), 'SOURCE/ENGINE marker survivor vectors differ')
    selected = sorted(i for g in groups for i in g['faces'])
    before_hashes = dict(source=sha(source_path), engine=sha(engine_path))
    checkpoint, checkpoint_sha = paid._checkpoint(out/'execution',
        dict(source_before=source, source_after=after, engine_before=engine, engine_after=eng_after),
        dict(selected_original=np.array(approval['selected_original'], np.int64),
             selected_current=np.array(selected, np.int64), kept_current=kept,
             original_before=np.array(original_ids, np.int64)), dict(current=edits),
        dict(root_selection_sha256=AUTHORITY, floor='4F', upstream=upstream, inputs=before_hashes,
             reference_is_existing_root_approved_original_minus24=True))
    outputs = dict(source=out/'candidate.source.obj', engine=out/'candidate.engine.obj')
    for role, before, expected in (('source', source_path, after), ('engine', engine_path, eng_after)):
        paid.write_survivor_obj(before, outputs[role], selected, len(original_ids), checkpoint, checkpoint_sha)
        paid._verify_saved(outputs[role], expected)
    copied = []
    for asset in assets:
        relative = Path(asset['path'].replace(chr(92), '/'))
        need(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe qualified asset path')
        original = source_path.parent/relative
        need(sha(original) == asset['sha256'], 'Checked E5 asset differs before marker copy')
        target = out/relative; target.parent.mkdir(parents=True, exist_ok=True)
        need(not target.exists(), 'Final asset path already exists')
        copy_verified(original, target, interval_s=0)
        need(sha(target) == asset['sha256'], 'Final asset bytes differ')
        copied.append(dict(path=relative.as_posix(), sha256=asset['sha256']))
    mapping = out/'source-faces.json'
    paid.write_new(mapping, dict(schema_version=1, mode='owner_approved_marker_survivors', input_triangles=len(original_ids),
        output_triangles=len(kept), source_faces=kept.tolist(),
        original_source_faces=[[original_ids[int(i)]] for i in kept], upstream=upstream))
    audit = out/'marker-audit.json'
    paid.write_new(audit, dict(floor='4F', root_selection_sha256=AUTHORITY, groups=groups, removed_faces=24,
        input_triangles=len(original_ids), output_triangles=len(kept), checkpoint_sha256=checkpoint_sha,
        source_candidate_sha256=sha(outputs['source']), engine_candidate_sha256=sha(outputs['engine']),
        source_faces_sha256=sha(mapping), assets=copied, allowed_changes=['explicit_owner_orange_box_faces_only'],
        independent_validation='PENDING', acceptance=False))
    need(before_hashes == dict(source=sha(source_path), engine=sha(engine_path)), 'Checked input pair changed')
    return dict(**outputs, mapping=mapping, checkpoint=checkpoint, audit=audit, original_ids=[original_ids[int(i)] for i in kept])
