import http.client
import json
import pathlib
import sys
import tempfile
import threading
import time
import unittest
from dataclasses import replace
from unittest.mock import patch

HERE=pathlib.Path(__file__).resolve().parent
TEMP=HERE/'test-temp'
TEMP.mkdir(exist_ok=True)


def module():
    import codex_memory_bridge
    return codex_memory_bridge


def config():
    return module().Config(codex_exe=pathlib.Path(sys.executable),codex_home=HERE/'auth-home',cwd=HERE/'empty-cwd',temp_root=TEMP,token='unit-token-only',port=0)


def request(server,body=None,path='/v1/chat/completions',method='POST',token='unit-token-only',host=None):
    c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
    headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'}
    if host:headers['Host']=host
    c.request(method,path,None if body is None else json.dumps(body),headers)
    response=c.getresponse();data=response.read();c.close()
    return response.status,json.loads(data)


BODY={'model':'gpt-6.1-sol','messages':[{'role':'system','content':'Record memory facts only.'},{'role':'user','content':'Synthetic fact: the test cube is blue.'}],'max_tokens':4096}


class TestRequest(unittest.TestCase):
    def test_valid_text_only_request(self):
        messages,tokens=module().validate_request(BODY)
        self.assertEqual(messages,BODY['messages']);self.assertEqual(tokens,4096)

    def test_reject_other_model_stream_tool_and_external_route(self):
        bad=[{**BODY,'model':'gemini-flash-latest'},{**BODY,'stream':True},{**BODY,'tools':[{'type':'function'}]},
             {**BODY,'api_base':'https://example.com'}, {**BODY,'messages':[{'role':'tool','content':'x'}]},
             {**BODY,'messages':[{'role':'user','content':[{'type':'image_url'}]}]}, {**BODY,'max_tokens':0}]
        for body in bad:
            with self.subTest(body=body),self.assertRaises(module().BridgeError):module().validate_request(body)

    def test_bounded_request_and_no_prompt_in_cli_arguments(self):
        with self.assertRaises(module().BridgeError):module().validate_request({**BODY,'messages':[{'role':'user','content':'x'*(module().MAX_PROMPT_CHARS+1)}]})
        c=config();args=module().build_command(c,TEMP/'final.txt')
        for flag in ('--ephemeral','--ignore-user-config','--strict-config','--json','--sandbox','read-only'):
            self.assertIn(flag,args)
        self.assertEqual(args[-1],'-');self.assertNotIn('unit-token-only',repr(args))
        self.assertNotIn('--dangerously-bypass-approvals-and-sandbox',args)
        disabled=[args[i+1]for i,a in enumerate(args[:-1])if a=='--disable']
        for feature in ('hooks','shell_tool','unified_exec','code_mode_host','apps','multi_agent','computer_use','browser_use','image_generation','view_image','memories'):
            self.assertIn(feature,disabled)
        self.assertIn('project_doc_max_bytes=0',args)
        self.assertIn('suppress_unstable_features_warning=true',args)

    def test_environment_keeps_auth_home_without_forwarding_other_provider_secrets(self):
        env=module().build_environment(config(),TEMP,{'PATH':'synthetic','SystemRoot':'C:/Windows','GEMINI_API_KEY':'private','OPENAI_API_KEY':'private','CLAUDE_MEM_PROVIDER':'gemini','CODEX_SESSION_ID':'parent'})
        for key in ('GEMINI_API_KEY','OPENAI_API_KEY','CLAUDE_MEM_PROVIDER','CODEX_SESSION_ID'):self.assertNotIn(key,env)
        self.assertEqual(env['CODEX_HOME'],str(HERE/'auth-home'));self.assertEqual(env['TEMP'],str(TEMP))
        self.assertNotIn('unit-token-only',repr(config()))

    def test_memory_prompt_separates_data_and_forbids_tools(self):
        prompt=module().render_prompt(BODY['messages'],4096)
        self.assertIn('conversation_json',prompt);self.assertIn('Do not use tools',prompt)
        self.assertIn('Synthetic fact:',prompt)


class TestEvents(unittest.TestCase):
    NOTICE='Code Mode is unavailable because code-mode host is disabled. Code mode will fail closed; enable `features.code_mode_host` and install `codex-code-mode-host`.'
    def events(self,item=None):
        rows=[{'type':'thread.started','thread_id':'synthetic'}, {'type':'turn.started'},
              {'type':'item.completed','item':{'type':'reasoning','text':'PRIVATE REASONING NOT TO STORE'}},
              item or {'type':'item.completed','item':{'type':'agent_message','text':'<observation>Blue cube.</observation>'}},
              {'type':'turn.completed','usage':{'input_tokens':100,'cached_input_tokens':20,'output_tokens':10}}]
        return '\n'.join(json.dumps(r)for r in rows).encode()

    def test_response_uses_actual_usage_and_redacts_reasoning(self):
        result,trace=module().completion_from_events(self.events(),'<observation>Blue cube.</observation>')
        self.assertEqual(result['model'],'gpt-6.1-sol');self.assertEqual(result['usage']['prompt_tokens'],100)
        self.assertEqual(result['usage']['completion_tokens'],10);self.assertEqual(result['usage']['total_tokens'],110)
        self.assertEqual(result['choices'][0]['message']['content'],'<observation>Blue cube.</observation>')
        self.assertNotIn('PRIVATE REASONING',json.dumps(trace))

    def test_reject_any_tool_event_or_final_message_mismatch(self):
        for kind in ('command_execution','mcp_tool_call','file_change','web_search','collab_tool_call'):
            with self.subTest(kind=kind),self.assertRaises(module().BridgeError):
                module().completion_from_events(self.events({'type':'item.started','item':{'type':kind}}),'x')
        with self.assertRaises(module().BridgeError):module().completion_from_events(self.events(),'changed')

    def test_rejection_preserves_event_kinds_without_payloads(self):
        raw=self.events({'type':'item.completed','item':{'type':'command_execution','command':'SECRET_COMMAND','aggregated_output':'PRIVATE_OUTPUT'}})
        with self.assertRaises(module().BridgeError) as caught:module().completion_from_events(raw,'x')
        self.assertIn({'type':'item.completed','item_type':'command_execution'},caught.exception.trace)
        self.assertNotIn('SECRET',json.dumps(caught.exception.trace));self.assertNotIn('PRIVATE',json.dumps(caught.exception.trace))

    def test_native_error_is_classified_without_payload_or_tool_claim(self):
        raw=self.events({'type':'item.completed','item':{'type':'error','message':'Under-development features enabled: synthetic. PRIVATE'}})
        with self.assertRaises(module().BridgeError) as caught:module().completion_from_events(raw,'x')
        self.assertEqual(caught.exception.code,'codex_item_error')
        self.assertEqual(caught.exception.trace[3]['error_category'],'startup_unstable_features_warning')
        self.assertNotIn('PRIVATE',json.dumps(caught.exception.trace))

    def test_failure_diagnostics_include_later_tool_kinds_without_accepting_completion(self):
        rows=[{'type':'thread.started'}, {'type':'item.completed','item':{'type':'error','message':'private error'}},
              {'type':'item.started','item':{'type':'command_execution','command':'PRIVATE'}},
              {'type':'turn.completed','usage':{'input_tokens':5,'output_tokens':2}}]
        with self.assertRaises(module().BridgeError) as caught:
            module().completion_from_events('\n'.join(json.dumps(r)for r in rows).encode(),'x')
        self.assertEqual(caught.exception.code,'codex_item_error')
        self.assertEqual(caught.exception.trace[-1]['type'],'turn.completed')
        self.assertIn({'type':'item.started','item_type':'command_execution'},caught.exception.trace)
        self.assertNotIn('PRIVATE',json.dumps(caught.exception.trace))

    def test_synthetic_only_unclassified_error_diagnostic_is_bounded_and_scrubbed(self):
        raw=self.events({'type':'item.completed','item':{'type':'error','message':'Unknown startup: Bearer synthetic-secret '+('x'*500)}})
        with self.assertRaises(module().BridgeError) as caught:
            module().completion_from_events(raw,'x',diagnostic_errors=True)
        message=caught.exception.trace[3]['synthetic_error_diagnostic']
        self.assertLessEqual(len(message),400);self.assertNotIn('synthetic-secret',message)
        with self.assertRaises(module().BridgeError) as caught:module().completion_from_events(raw,'x')
        self.assertNotIn('synthetic_error_diagnostic',json.dumps(caught.exception.trace))

    def test_exact_disabled_host_notice_is_only_pre_turn_metadata(self):
        rows=[{'type':'thread.started'}, {'type':'item.completed','item':{'type':'error','message':self.NOTICE}},
              {'type':'turn.started'}, {'type':'item.completed','item':{'type':'agent_message','text':'<observation>Blue cube.</observation>'}},
              {'type':'turn.completed','usage':{'input_tokens':5,'output_tokens':2}}]
        raw=lambda entries:'\n'.join(json.dumps(r)for r in entries).encode()
        response,trace=module().completion_from_events(raw(rows),'<observation>Blue cube.</observation>')
        self.assertEqual(response['choices'][0]['message']['content'],'<observation>Blue cube.</observation>')
        self.assertTrue(trace[1]['nonexecution_metadata'])
        for message in (self.NOTICE+' ',self.NOTICE+' Additional text',self.NOTICE.replace('disabled','enabled')):
            altered=[*rows];altered[1]={'type':'item.completed','item':{'type':'error','message':message}}
            with self.subTest(message=message),self.assertRaises(module().BridgeError):module().completion_from_events(raw(altered),'<observation>Blue cube.</observation>')
        after=[rows[0],rows[2],rows[1],*rows[3:]]
        with self.assertRaises(module().BridgeError):module().completion_from_events(raw(after),'<observation>Blue cube.</observation>')

    def test_reject_failed_turn_and_malformed_json(self):
        for raw in (b'not JSON',b'{"type":"turn.failed","error":{"message":"private"}}'):
            with self.assertRaises(module().BridgeError):module().completion_from_events(raw,'x')


class TestHTTP(unittest.TestCase):
    def setUp(self):
        self.calls=[]
        def infer(messages,max_tokens):
            self.calls.append((messages,max_tokens))
            return {'id':'synthetic','object':'chat.completion','model':'gpt-6.1-sol','choices':[{'index':0,'message':{'role':'assistant','content':'<observation>Blue cube.</observation>'},'finish_reason':'stop'}]}
        self.server=module().make_server(config(),infer)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()

    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join(2)

    def test_only_loopback_and_authenticated_model_requests(self):
        self.assertEqual(self.server.server_address[0],'127.0.0.1')
        self.assertEqual(request(self.server,BODY,token='wrong')[0],401);self.assertEqual(self.calls,[])
        status,response=request(self.server,BODY)
        self.assertEqual(status,200);self.assertEqual(len(self.calls),1);self.assertEqual(response['model'],'gpt-6.1-sol')

    def test_models_and_health_do_not_invoke_model(self):
        self.assertEqual(request(self.server,path='/v1/models',method='GET')[1]['data'][0]['id'],'gpt-6.1-sol')
        self.assertEqual(request(self.server,path='/health',method='GET')[0],200);self.assertEqual(self.calls,[])

    def test_reject_external_host_and_unknown_fields(self):
        self.assertEqual(request(self.server,BODY,host='example.com')[0],403)
        self.assertEqual(request(self.server,{**BODY,'model':'gemini'})[0],400)
        self.assertEqual(request(self.server,BODY,path='https://example.com/v1/chat/completions')[0],400)
        self.assertEqual(self.calls,[])

    def test_serializes_inference_and_waits_for_second_request(self):
        entered,released=threading.Event(),threading.Event()
        calls=[]
        def infer(messages,tokens):
            calls.append(len(calls));entered.set();released.wait(3);return {'choices':[],'model':'gpt-6.1-sol'}
        self.server.infer=infer
        result=[];worker=threading.Thread(target=lambda:result.append(request(self.server,BODY)),daemon=True);worker.start()
        self.assertTrue(entered.wait(2))
        second=[];other=threading.Thread(target=lambda:second.append(request(self.server,BODY)),daemon=True);other.start()
        time.sleep(.1)
        try:
            self.assertEqual(second,[],'The second request must wait instead of receiving immediate503')
            self.assertEqual(self.server.singleflight.snapshot()['pending'],1)
        finally:released.set();worker.join(3);other.join(3)
        self.assertEqual([result[0][0],second[0][0]],[200,200]);self.assertEqual(len(calls),2)

    def test_health_reports_only_bounded_flight_counts(self):
        status,health=request(self.server,path='/health',method='GET')
        self.assertEqual(status,200);self.assertEqual(health['inference_gate'],{'active':0,'pending':0,'max_pending':4,'queue_wait_seconds':15})
        self.assertEqual(self.calls,[])

    def test_saturated_http_queue_has_retry_after_and_expires_without_inference(self):
        self.server.singleflight=module().FlightGate(max_pending=1,wait_seconds=.2)
        entered,released=threading.Event(),threading.Event();calls=[]
        def infer(*_):calls.append(1);entered.set();released.wait(2);return {'choices':[]}
        self.server.infer=infer;first=[];waiting=[]
        active=threading.Thread(target=lambda:first.append(request(self.server,BODY)),daemon=True);active.start()
        self.assertTrue(entered.wait(1))
        pending=threading.Thread(target=lambda:waiting.append(request(self.server,BODY)),daemon=True);pending.start()
        deadline=time.monotonic()+1
        while self.server.singleflight.snapshot()['pending']!=1 and time.monotonic()<deadline:time.sleep(.005)
        client=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=2)
        try:
            client.request('POST','/v1/chat/completions',json.dumps(BODY),{'Authorization':'Bearer unit-token-only','Content-Type':'application/json'})
            response=client.getresponse();payload=json.loads(response.read())
            self.assertEqual(response.status,503);self.assertEqual(payload['error']['code'],'memory_queue_full')
            self.assertEqual(response.getheader('Retry-After'),'1')
            pending.join(1);self.assertEqual(waiting[0][1]['error']['code'],'memory_queue_timeout')
            self.assertEqual(len(calls),1);self.assertEqual(self.server.singleflight.snapshot()['pending'],0)
        finally:client.close();released.set();active.join(2);pending.join(2)

    def test_generic_backend_exception_does_not_leak_input_or_secret(self):
        def infer(messages,tokens):raise RuntimeError('SECRET DO NOT RETURN')
        self.server.infer=infer
        status,response=request(self.server,BODY)
        self.assertEqual(status,502);self.assertNotIn('SECRET',json.dumps(response))
        self.assertEqual(self.server.singleflight.snapshot()['active'],0)


class TestFlightGate(unittest.TestCase):
    def wait_pending(self,gate,count):
        deadline=time.monotonic()+1
        while time.monotonic()<deadline:
            if gate.snapshot()['pending']==count:return
            time.sleep(.005)
        self.fail('Pending count did not reach expected bound')

    def test_fifo_single_flight_with_bounded_pending(self):
        gate=module().FlightGate(max_pending=2,wait_seconds=1);gate.acquire();order=[];workers=[]
        def run(value):
            gate.acquire()
            try:order.append(value);time.sleep(.02)
            finally:gate.release()
        for value in (1,2):
            worker=threading.Thread(target=run,args=(value,),daemon=True);worker.start();workers.append(worker)
            self.wait_pending(gate,value)
        with self.assertRaises(module().BridgeError) as caught:gate.acquire()
        self.assertEqual((caught.exception.status,caught.exception.code),(503,'memory_queue_full'))
        self.assertEqual(gate.snapshot()['pending'],2);gate.release()
        for worker in workers:worker.join(2)
        self.assertEqual(order,[1,2]);self.assertEqual(gate.snapshot()['active'],0)

    def test_expired_waiter_is_removed_and_does_not_block_next_request(self):
        gate=module().FlightGate(max_pending=1,wait_seconds=.05);gate.acquire();started=time.monotonic()
        with self.assertRaises(module().BridgeError) as caught:gate.acquire()
        self.assertEqual(caught.exception.code,'memory_queue_timeout')
        self.assertLess(time.monotonic()-started,.5);self.assertEqual(gate.snapshot()['pending'],0)
        gate.release();gate.acquire();gate.release()

    def test_queue_configuration_cannot_expand_hard_caps(self):
        for kwargs in ({'max_pending':5},{'max_pending':0},{'wait_seconds':16},{'wait_seconds':0}):
            with self.subTest(kwargs=kwargs),self.assertRaises(ValueError):module().FlightGate(**kwargs)

    def test_configured_queue_is_used_by_http_server(self):
        server=module().make_server(replace(config(),max_pending_requests=2,queue_wait_seconds=.1),lambda *_:{})
        try:self.assertEqual(server.singleflight.snapshot(),{'active':0,'pending':0,'max_pending':2,'queue_wait_seconds':.1})
        finally:server.server_close()


class TestOwnedProcess(unittest.TestCase):
    def test_native_memory_admission_fails_closed_below_threshold(self):
        with patch.object(module(),'windows_commit_headroom',return_value=1024):
            with self.assertRaises(module().BridgeError) as caught:module().require_memory_headroom(2048)
        self.assertEqual(caught.exception.code,'memory_headroom_low')
        with patch.object(module(),'windows_commit_headroom',return_value=4096):
            self.assertEqual(module().require_memory_headroom(2048),4096)
        with patch.object(module(),'windows_commit_headroom',side_effect=OSError):
            with self.assertRaises(module().BridgeError) as caught:module().require_memory_headroom(2048)
        self.assertEqual(caught.exception.code,'memory_admission_unavailable')

    def test_real_owned_process_output_is_bounded(self):
        result=module().run_bounded([sys.executable,'-c','print("synthetic")'],b'',timeout_seconds=5,max_output_bytes=1000,max_stderr_bytes=1000,job_memory_bytes=256*1024*1024)
        self.assertEqual(result.returncode,0);self.assertEqual(result.stdout.strip(),b'synthetic')
        with self.assertRaises(module().BridgeError):
            module().run_bounded([sys.executable,'-c','print("x"*10000)'],b'',timeout_seconds=5,max_output_bytes=100,max_stderr_bytes=1000,job_memory_bytes=256*1024*1024)

    def test_real_owned_timeout_terminates_only_its_process(self):
        with self.assertRaises(module().BridgeError) as error:
            module().run_bounded([sys.executable,'-c','import time;time.sleep(30)'],b'',timeout_seconds=.2,max_output_bytes=1000,max_stderr_bytes=1000,job_memory_bytes=256*1024*1024)
        self.assertEqual(error.exception.code,'codex_timeout')


if __name__=='__main__':unittest.main()
