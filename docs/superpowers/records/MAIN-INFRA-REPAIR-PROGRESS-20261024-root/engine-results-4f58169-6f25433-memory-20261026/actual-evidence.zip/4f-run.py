"""Scope the unchanged checked producer to the separately owned guard105 job."""
from contextlib import contextmanager
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JOB = 'MAIN-INFRA-4F-GUARD105-RETENTION-20261026'
_active = False


def need(value, message):
    if not value:
        raise ValueError(message)


def owned_scope():
    return dict(run_id='main-infra-4f-guard105-retention-20261026',
                out=ROOT/'data/main-infra-4f-guard105/run-20261026', job=JOB,
                owner='Codex-4F-Guard105-Retention', branch='codex/main-infra-4f-guard105-retention-20261026')


def identity_writer(engine_floor, source_floor, before, outcome, stage, ancestry, checkpoint, out,
                    *, input_context_transition=None):
    need(stage == 'E5' and input_context_transition is not None, 'Explicit E5 identity checkpoint required')
    from tools.main_infra_4f_e5_continue import save_identity_stage
    return save_identity_stage(engine_floor, source_floor, before, outcome, ancestry, checkpoint, out,
                               input_context_transition)


@contextmanager
def runtime_scope(plan_provider):
    global _active
    need(not _active and callable(plan_provider), 'Nested or missing guard105 policy is not allowed')
    from tools import main_infra_7f_restore as shared
    from tools import main_infra_7f_checked_restore as checked
    original = shared._scope, shared._plan, shared.write_worker, checked.save_cumulative_stage
    def scope(native97=False, four_f=False):
        need(four_f is True and native97 is False, 'Only the explicit new 4F scope is allowed')
        return owned_scope()
    def plan(data):
        return plan_provider(original[1](data))
    def worker(directory, state, stage, *args, **kwargs):
        actual = 'stage_saved' if state == 'candidate_saved' and stage == 'E5' else state
        return original[2](directory, actual, stage, *args, **kwargs)
    try:
        _active = True
        shared._scope, shared._plan, shared.write_worker, checked.save_cumulative_stage = scope, plan, worker, identity_writer
        yield original[2]
    finally:
        shared._scope, shared._plan, shared.write_worker, checked.save_cumulative_stage = original
        _active = False


def read_pin(row):
    from tools.main_infra_7f_restore_plan import _sha
    need(_sha(row['path']) == row['sha256'], 'Guard105 bound artifact changed: ' + str(row['path']))
    return json.loads(Path(row['path']).read_text(encoding='utf-8'))


def bound_policy(binding):
    from tools.main_infra_4f_guard105_marker import AUTHORITY
    from tools.main_infra_4f_guard105_plan import build_policy
    need(binding['job_id'] == JOB and binding['floor'] == '4F' and binding['acceptance'] is False
         and binding['producer_HEAD'] == '64a4ef5939a834706b496035f0d376400cff4883', 'Owned guard105 binding required')
    pins = binding['pins']
    expected = dict(old_plan='a245a65091da5d64206b379123a34467fc22302646e7b93b1890defe45257a4c',
        closure='e406130412570c11218ae1e3628514f3d974713b0d98a9dad5d366b22434c220',
        cp3='6cd1b01158451bf325adbadfc7f7934d094f50a80dcd9043f57998ebd2820764',
        cp5='203e34e571f2516057014ca3e03ac00f8aa966ad17de7e4676c87c50d459c968',
        authority=AUTHORITY, marker_proof='d8b5dc6bd6be262d0e2522ffd787b2f9e1692d31f3d772588248cacbce5c4f57')
    need(all(pins[k]['sha256'] == value for k, value in expected.items()), 'Authenticated current cohort/authority required')
    values = {k: read_pin(row) for k, row in pins.items()}
    authority = values['authority']; approval = authority['floors'][3]
    need(authority['all_other_geometry_protected'] is True and authority['full_floor_acceptance'] is False
         and approval['floor'] == '4F' and approval['report'] == pins['marker_report'], 'Literal owner marker scope differs')
    marker = values['marker_proof']['floors'][3]
    need(marker['floor'] == '4F' and marker['passed'] is True
         and marker['approved_original_faces'] == approval['selected_original'], 'Independent marker authority proof differs')
    terminal = values['producer_terminal']
    need(terminal['HEAD'] == binding['producer_HEAD'] and terminal['actual_pid'] == 3028
         and terminal['actual_exit_code'] == terminal['launcher_exit_code'] == 0
         and terminal['all_owned_exited'] is True and terminal['abort_reason'] is None, 'Actual completed producer required')
    policy = build_policy(values['old_plan'], values['closure'], values['cp3'], values['cp5'], approval)
    need((len(policy['e3_selected_rows']), len(policy['e5_selected_rows']), len(policy['protected_original_faces']))
         == (2789, 593, 19908), 'Literal guard105 selection/protection differs')
    return values, approval, policy


@contextmanager
def inputs(path, expected):
    from tools import main_infra_7f_restore as shared
    from tools.main_infra_4f_e5_resume import bind_signed_targets
    spec = read_pin(dict(path=str(path), sha256=expected))
    binding = read_pin(spec['guard105_binding'])
    values, approval, policy = bound_policy(binding)
    def provider(old):
        need(old == values['old_plan'], 'Authentic inherited planner differs from the captured old plan')
        return policy
    with runtime_scope(provider) as final_worker:
        actual, data, selected = shared.read_spec(path, expected, four_f=True)
        pinned = {(str(Path(r['path']).resolve()), r['sha256']) for r in actual['pins']}
        required = [actual['guard105_binding'], actual['signed_targets'], *binding['pins'].values()]
        need(all((str(Path(r['path']).resolve()), r['sha256']) in pinned for r in required), 'Bound guard105 input omitted from runtime pins')
        bind_signed_targets(actual['signed_targets'])
        need(selected == policy, 'Scoped runtime policy differs')
        yield shared, actual, data, policy, binding, values, approval, final_worker


def metadata(args):
    with inputs(args.spec, args.spec_sha256) as values:
        policy = values[3]
        print(json.dumps(dict(geometry_loaded=False, job_id=JOB, planned_E3=len(policy['e3_selected_rows']),
            planned_E5=len(policy['e5_selected_rows']), mandatory_originals=len(policy['protected_original_faces']),
            separate_owner_marker_originals=24, new_candidate=None, acceptance=False)), flush=True)


def prepare(args):
    with inputs(args.spec, args.spec_sha256) as values:
        shared, spec, data, plan, binding, saved, _, _ = values
        out = owned_scope()['out']; shared.require_absent([out])
        *_, proof = shared.load_context(spec, data, plan)
        need(proof['before_digest'] == saved['cp3']['input_digest']
             and proof['e5_key_context']['derived_field'] == 'identity'
             and proof['e5_key_context']['donor_rows_checked'] == 876
             and proof['e5_key_context']['donor_keys_exact'] is True, 'Authentic original/876-key identity context required')
        shared.read_spec(args.spec, args.spec_sha256, four_f=True)
        record = dict(schema_version=1, job_id=JOB, run_id=owned_scope()['run_id'], floor='4F',
            spec=str(Path(args.spec).resolve()), spec_sha256=args.spec_sha256, proof=proof,
            guard105_binding=spec['guard105_binding'], producer_HEAD=binding['producer_HEAD'],
            owner_marker_stage='PENDING_AFTER_FRESH_CHECKED_E3_E5', new_candidate=None, acceptance=False)
        out.mkdir(parents=True); path = out/'preparation-4F.json'
        with path.open('x', encoding='utf-8') as stream: json.dump(record, stream, indent=2); stream.write('\n')
        print(json.dumps(dict(preparation=str(path), sha256=shared._sha(path), proof=proof, acceptance=False)), flush=True)


def execute(args):
    prepared = read_pin(dict(path=args.prepared, sha256=args.prepared_sha256))
    need(prepared['job_id'] == JOB and prepared['acceptance'] is False, 'New owned preparation required')
    with inputs(prepared['spec'], prepared['spec_sha256']) as values:
        shared, spec, data, plan, _, _, approval, final_worker = values
        need(prepared['guard105_binding'] == spec['guard105_binding'], 'Prepared guard105 binding differs')
        out = owned_scope()['out']; final = out/'final/4F'; execution = out/'execution-4F'
        shared.require_absent([final])
        shared.execute(args, four_f=True)
        try:
            e5 = out/'e5/4F'
            checkpoint3 = read_pin(dict(path=execution/'checkpoint-E3.json', sha256=shared._sha(execution/'checkpoint-E3.json')))
            checkpoint5 = read_pin(dict(path=execution/'checkpoint-E5.json', sha256=shared._sha(execution/'checkpoint-E5.json')))
            originals = json.loads((e5/'baseline-source-faces.json').read_text())['source_faces']
            fresh3 = {f for row in checkpoint3['selected'] if row['site'] in set(checkpoint3['rolled_back_sites']) for f in row['faces']}
            fresh5 = {checkpoint3['survivors'][f] for row in checkpoint5['selected']
                      if row['site'] in set(checkpoint5['rolled_back_sites']) for f in row['faces']}
            mandatory = set(plan['protected_original_faces']) | fresh3 | fresh5
            need(mandatory <= set(originals) and not mandatory.intersection(approval['selected_original']),
                 'Fresh checked outcome removed mandatory/rollback originals or overlaps marker authority')
            upstream = dict(job_id=JOB, preparation_sha256=args.prepared_sha256,
                stage_audit=dict(path=str(e5/'stage-audit.json'), sha256=shared._sha(e5/'stage-audit.json')),
                E3_checkpoint=dict(path=str(execution/'checkpoint-E3.json'), sha256=shared._sha(execution/'checkpoint-E3.json')),
                E5_checkpoint=dict(path=str(execution/'checkpoint-E5.json'), sha256=shared._sha(execution/'checkpoint-E5.json')),
                baseline_mapping=dict(path=str(e5/'baseline-source-faces.json'), sha256=shared._sha(e5/'baseline-source-faces.json')),
                required_originals=sorted(mandatory), fresh_rollback_originals=dict(E3=sorted(fresh3), E5=sorted(fresh5)))
            from tools.main_infra_4f_guard105_marker import save_marker_pair, AUTHORITY
            files = save_marker_pair(e5/'candidate.source.obj', e5/'candidate.engine.obj', originals,
                approval=approval, report=values[5]['marker_report'], authority_sha256=AUTHORITY,
                out=final, upstream=upstream, assets=data['provenance']['assets'])
            need(mandatory <= set(files['original_ids']), 'Marker stage removed a protected original')
            shared.read_spec(prepared['spec'], prepared['spec_sha256'], four_f=True)
            final_worker(execution, 'candidate_saved', 'E5', len(plan['e5_selected_rows']),
                kept=len(checkpoint5['kept_sites']), rolled=len(checkpoint5['rolled_back_sites']),
                output_triangles=len(files['original_ids']), checkpoint=files['checkpoint'], four_f=True)
            print(json.dumps(dict(candidate=str(final), output_triangles=len(files['original_ids']),
                marker_removed=24, checkpoint_sha256=shared._sha(files['checkpoint']), acceptance=False)), flush=True)
        except Exception:
            final_worker(execution, 'failed', 'E5', len(plan['e5_selected_rows']), four_f=True)
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    for name in ('metadata', 'prepare'):
        command = sub.add_parser(name); command.add_argument('--spec', required=True); command.add_argument('--spec-sha256', required=True)
    command = sub.add_parser('execute'); command.add_argument('--prepared', required=True); command.add_argument('--prepared-sha256', required=True)
    args = parser.parse_args()
    dict(metadata=metadata, prepare=prepare, execute=execute)[args.command](args)


if __name__ == '__main__':
    main()
