# 3F44953 independent validation handoff

Status: **UNACCEPTED**. Source/candidate readback passed. The unchanged strict26 guard failed. Native and full signed validation were not run. No engine, guard or target tolerance was loosened and this independent agent wrote no model files.

Actual caller commit99fde911a380a42c325eca9791e9c36936a815d5; binding6af99e6ee9c2a9a177a51c49b25a5699a9002e75bcdbaebbda4bcca1fb19a96a; all626 pins authenticated before/after actual phases. Candidate SOURCEeec9d229b74d7f659583df054c608fd4602a446ae98bd898facee4d26328d14f / ENGINE1de6464db8fca20ed231b7a7dea6ad0c76a0f88ecf864f4649980fa6fe95344c. Producer repair checkpoint remains original16planned/14kept/2rolled; no E3 or kernel recapture/rerun.

Readback54348 exited0 at17:24:14.8341972Z. Original53602→marker44948→candidate44953; all6489 protected originals remain whole. Fourteen E5 border cuts and16 appended unused reference rows verified, original used corners/bbox/common center exact. Original native physical quanta[3.937007874015748e-5,3.937007874015748e-5,3.937007874015748e-6]in derive guard depth5.9055118110236214e-5in. Original53578 reference excludes ONLY24 authenticated orange faces. All8 assets in3packages and exact17 captured K1 records pass. This is source/candidate identity proof, not visible preservation acceptance.

Census66156 exited0 at17:27:11.3154294Z. Fresh maps bind actual original53602 and candidate44953 SOURCE order, source revision7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511/runmain-infra-clean-20261023.

| Kind | Original | Candidate |
|---|---:|---:|
| flicker_diff | 12147 | 8297 |
| flicker_same | 20205 | 14699 |
| reversed | 0 | 0 |
| hidden | 32278 | 23653 |
| loose | 0 | 0 |
| open_edges | 8745 | 10555 |
| cracks | 13782 | 12591 |

The four signed-target detector subtotal is **35,587** (flicker_diff8297+flicker_same14699+reversed0+cracks12591). All seven detector instances total **69,795**, including hidden23653/open_edges10555/loose0. These are distinct labels; no repaired-floor claim is supported.

Strict58756 exited2 at17:28:58.3000152Z, no monitor abort, all owned processes exited. All26 Before and26 After callbacks ran at900x600 using original RAW precision. Totals: holes0/grown0; material_changed1 at[-0.987,-0.993,1.011]; moved_other1 at[-0.987,0.007,-0.989]; zfight_tie3; edge_flicker1 (edge_flicker_moved1). Other loss/growth categories0. The failure stands; no waiver or native/full-signed promotion.

Earned output paths:
- `D:\LLM_BACKUP\Codex session\i3p\05-Corllenium-UC-Building-Repair-Engine\data\44953-independent\attempt6\readback\independent-proof.json`
- `D:\LLM_BACKUP\Codex session\i3p\05-Corllenium-UC-Building-Repair-Engine\data\44953-independent\attempt6\census\errors-source.json`
- `D:\LLM_BACKUP\Codex session\i3p\05-Corllenium-UC-Building-Repair-Engine\data\44953-independent\attempt6\census\errors-candidate.json`
- `D:\LLM_BACKUP\Codex session\i3p\05-Corllenium-UC-Building-Repair-Engine\data\44953-independent\attempt6\strict\independent-proof.json`
- Artifact hash inventory: `D:\LLM_BACKUP\Codex session\i3p\05-Corllenium-UC-Building-Repair-Engine\docs\superpowers\records\MAIN-INFRA-3F-44953-INDEPENDENT-VALIDATE-20261026\EARNED-ARTIFACTS-44953.json`
- Local earned-output/model review archive: `D:\LLM_BACKUP\Codex session\i3p\05-Corllenium-UC-Building-Repair-Engine\data\44953-independent\delivery-20261027\main-infra-3f-44953-earned-independent-20261027.zip` (hash in ARCHIVE-RECEIPT-44953.json).

Prior failed attempts1–5 and all diagnostics remain immutable. Records-only handoff seal may follow executing commit; immutable actual phase plans/terminals retain executing99fde911. Queue awaits controller review; owner acceptance remains false. Next work proposed only: unchanged paid two-view read-only face/material/UV/depth attribution, under a new reviewed invocation. No new parse/ray phase has been authorized yet.
