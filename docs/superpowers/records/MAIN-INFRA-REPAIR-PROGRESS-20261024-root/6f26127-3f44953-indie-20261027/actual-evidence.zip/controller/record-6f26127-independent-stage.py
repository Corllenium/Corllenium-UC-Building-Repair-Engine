from pathlib import Path
from datetime import datetime
import copy
import hashlib
import json
import subprocess
import sys

R = Path(__file__).resolve().parents[2]
W = R / '.claude/worktrees/v6i'
sys.path.insert(0, str(R / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress, write_progress, utc_now

def checked(path, digest):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest, str(path)
    return json.loads(raw)

guard = checked(W / 'data/iv6i/independent-guard.json', '67a42a2c9c947886a1c42ad1633866a707e59abede38bac456f6fcc5c2d95256')
census = checked(W / 'data/iv6i/census/census-receipt.json', '00270b9fd43d95f40558c9a2aa79943d71059aaef9b272f2ea36f8e9f7ea58c2')
terminal = checked(W / 'data/iv6i-preflight/monitor-6F26127-independent-guard-20261026T173247/result.json', '782d37d8a4e95343ff18f2236db6de2c2664ca95769fdd27a87d72d5dc094ea2')
readback = checked(W / 'data/iv6i/independent-saved-readback.json', '73f8ca264ee97f2874fd35fcfa9c82fe3503069d5140e861f6c0543107584e0b')
assert terminal['actual_pid'] == 6792 and terminal['actual_exit_code'] == terminal['launcher_exit_code'] == 0
assert terminal['all_owned_exited'] and terminal['abort_reason'] is None and guard['guard']['passed']
assert guard['candidate_source_sha256'] == '5a38f6453f635b9bba64ff25a7a2540a80be1a661dc12a7934a0c8ad659fd548'
assert guard['candidate_engine_sha256'] == 'dca6f69a8cb91f8c5ee7678b36cda64bce549044ef83ef01174513b960b089fd'
assert readback['protected_original_count'] == 4240 and not readback['acceptance']
counts = census['results']['candidate']['counts']
remaining = sum(counts[k] for k in ('flicker_diff', 'flicker_same', 'reversed', 'cracks'))
assert remaining == 12917 and census['results']['candidate']['n_faces'] == 26127
assert not any(v for k, v in guard['guard']['totals'].items() if k not in ('model_px', 'zfight_tie'))
path = R / 'data/main-infra-fresh/current.json'
original = load_progress(path)
doc = copy.deepcopy(original)
f = doc['floors']['6F']
assert f['accepted_preview'] is None and f['output_triangles'] == 25433 and f['pending_output_triangles'] == 26127
now = utc_now()
message = ('New 6F orange-free 26,127 output passed independent saved-byte/ancestry/12-asset readback and strict 26-view preservation guard. '
           'All gating pixel totals are zero. Fresh census still has 12,917 signed-target instances. '
           'Native texture views and full signed validation are being prepared; they have not run. '
           'After currently shows older 25,433, not this pending new model; neither is accepted.')
f.update(state='validating', step=message, blocker='New 26,127 native and full signed checks remain pending; signed error targets still fail.',
         worker_pid=6792, worker_start_utc=terminal['actual_creation_utc'], worker_observed_at=terminal['ended_utc'],
         worker_alive=False, engine_worker_alive=False, worker_cpu_seconds=None)
p = f['pending_saved_candidate']
assert p['source_sha256'] == guard['candidate_source_sha256'] and p['engine_sha256'] == guard['candidate_engine_sha256']
p.update(independent_readback='PASS', independent_readback_sha256='73f8ca264ee97f2874fd35fcfa9c82fe3503069d5140e861f6c0543107584e0b',
         independent_validation='PARTIAL_COMPONENT_PASS_ONLY', default_error_census='MEASURED',
         strict26='PASS', strict26_sha256='67a42a2c9c947886a1c42ad1633866a707e59abede38bac456f6fcc5c2d95256',
         strict_totals=guard['guard']['totals'], remaining_problems=counts, remaining_target_instances=remaining,
         census_sha256='00270b9fd43d95f40558c9a2aa79943d71059aaef9b272f2ea36f8e9f7ea58c2',
         error_map_sha256='2f82134298eb60ac6fe49e545c6c4d907704254181124d34f06231574115fa4f', native='PENDING', full_signed='PENDING', acceptance=False)
f['last_work_event_at'] = max((f.get('last_work_event_at', now), now), key=lambda x: datetime.fromisoformat(x.replace('Z', '+00:00')))
if not any(e.get('phase') == 'new26127_independent_readback_census_strict_pass' for e in f.setdefault('worker_events', [])):
    f['worker_events'].append(dict(engine='Validator', run_id=census['job_id'], phase='new26127_independent_readback_census_strict_pass',
        pid=6792, start_utc=terminal['actual_creation_utc'], observed_at=terminal['ended_utc'], message=message))
doc.update(updated_at=now, last_work_event_at=max((doc.get('last_work_event_at', now), now), key=lambda x: datetime.fromisoformat(x.replace('Z', '+00:00'))),
           step='New 6F 26,127 passed independent readback and strict26; native/full signed checks pending, 12,917 target errors remain. New 3F and 5F strict checks failed; exact causes are under review.')
draft = R / 'data/siege-live-20261026/status-6f26127-independent-draft.json'
draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
subprocess.run(['node', str(R / 'data/siege-live-20261026/check-status-current.mjs'), str(draft)], check=True, capture_output=True)
assert load_progress(path)['updated_at'] == original['updated_at'], 'Concurrent canonical change; no stale replacement'
write_progress(path, doc)
actual = load_progress(path)
for floor in original['floors']:
    if floor != '6F':
        assert actual['floors'][floor] == original['floors'][floor]
    for key in ('source_preview', 'candidate_preview', 'accepted_preview', 'output_triangles', 'latest_saved_candidate'):
        assert actual['floors'][floor].get(key) == original['floors'][floor].get(key)
receipt = dict(at=now, floor='6F', pending=26127, displayed=25433, readback='PASS', strict26='PASS', signed_target_remaining=12917,
               native='PENDING', full_signed='PENDING', other_floor_rows_untouched=True, all_display_and_acceptance_refs_unchanged=True)
(R / 'data/siege-live-20261026/status-6f26127-independent-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
