from pathlib import Path
from datetime import datetime
import copy
import hashlib
import json
import subprocess
import sys

R = Path(__file__).resolve().parents[2]
W = Path('D:/LLM_BACKUP/Codex session/i3p/05-Corllenium-UC-Building-Repair-Engine')
sys.path.insert(0, str(R / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress, write_progress, utc_now

def checked(path, digest):
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, str(path)
    return json.loads(data)

proof = checked(W / 'data/44953-independent/attempt6/strict/independent-proof.json', 'f7d207e160419e0cd154fae0f02071a38521ff02fafb02fd343466e459808bb1')
census = checked(W / 'data/44953-independent/attempt6/census/independent-proof.json', 'a3d3c1d21b775bd9158b63060dc7f4dd61949bffe9881b2258df0e98590ea3e1')
terminal = checked(R / 'data/3f-44953-independent-phases-20261026/attempt6/monitor-3f-44953-strict-attempt6-20261026T172827/result.json', 'd8e241c4f6100b480f62b41e0055e9e11530a020fbb7bf6e85f3d5d9391d72cc')
assert terminal['actual_pid'] == 58756 and terminal['actual_exit_code'] == terminal['launcher_exit_code'] == 2
assert terminal['all_owned_exited'] and terminal['abort_reason'] is None and not proof['guard']['passed']
assert proof['source_sha256'] == census['source_sha256'] == 'eec9d229b74d7f659583df054c608fd4602a446ae98bd898facee4d26328d14f'
assert proof['engine_sha256'] == census['engine_sha256'] == '1de6464db8fca20ed231b7a7dea6ad0c76a0f88ecf864f4649980fa6fe95344c'
counts = census['after']
signed = sum(counts[k] for k in ('flicker_diff', 'flicker_same', 'reversed', 'cracks'))
assert signed == 35587 and sum(counts.values()) == 69795
totals = proof['guard']['totals']
assert totals['material_changed'] == totals['moved_other'] == totals['edge_flicker_moved'] == 1
assert totals['holes'] == totals['grown'] == 0
path = R / 'data/main-infra-fresh/current.json'
original = load_progress(path)
doc = copy.deepcopy(original)
f = doc['floors']['3F']
assert f['accepted_preview'] is None and f['output_triangles'] == 44948
now = utc_now()
message = ('New 3F 44,953 saved output passed independent literal/ancestry/asset readback. '
           'Fresh strict check FAIL: one material-change pixel, one moved-surface pixel, and one edge-flicker movement. '
           'Default census leaves 35,587 signed-target instances. Exact failed-view attribution is next; '
           'native and full signed checks have not run. Displayed 44,948 remains an older unaccepted candidate.')
f.update(state='blocked', step=message, blocker=message, worker_pid=58756,
         worker_start_utc=terminal['actual_creation_utc'], worker_observed_at=terminal['ended_utc'],
         worker_alive=False, engine_worker_alive=False, worker_cpu_seconds=None, pending_output_triangles=44953)
f['pending_saved_candidate'] = dict(triangles=44953, source_sha256=proof['source_sha256'], engine_sha256=proof['engine_sha256'],
    protected_originals=6489, independent_readback='PASS', independent_readback_sha256='2744e73cbc34f02eaa578a56b0bdca2cf7b29f12ad8a3abb574bedcff660e68d',
    strict26='FAIL', strict26_sha256='f7d207e160419e0cd154fae0f02071a38521ff02fafb02fd343466e459808bb1',
    strict_totals=totals, default_error_census='MEASURED', remaining_problems=counts, remaining_target_instances=signed,
    all_detector_instances=69795, native='NOT_RUN', full_signed='NOT_RUN', acceptance=False)
f['last_work_event_at'] = max((f.get('last_work_event_at', now), now), key=lambda x: datetime.fromisoformat(x.replace('Z', '+00:00')))
if not any(e.get('phase') == 'new44953_actual_strict_fail' for e in f.setdefault('worker_events', [])):
    f['worker_events'].append(dict(engine='Validator', run_id=proof['job_id'], phase='new44953_actual_strict_fail',
        pid=58756, start_utc=terminal['actual_creation_utc'], observed_at=terminal['ended_utc'], message=message))
doc.update(updated_at=now, last_work_event_at=max((doc.get('last_work_event_at', now), now), key=lambda x: datetime.fromisoformat(x.replace('Z', '+00:00'))))
draft = R / 'data/siege-live-20261026/status-3f44953-result-draft.json'
draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
subprocess.run(['node', str(R / 'data/siege-live-20261026/check-status-current.mjs'), str(draft)], check=True, capture_output=True)
assert load_progress(path)['updated_at'] == original['updated_at'], 'Concurrent canonical change; retry only from a fresh read'
write_progress(path, doc)
actual = load_progress(path)
for floor in original['floors']:
    if floor != '3F':
        assert actual['floors'][floor] == original['floors'][floor]
    for key in ('source_preview', 'candidate_preview', 'accepted_preview', 'output_triangles', 'latest_saved_candidate'):
        assert actual['floors'][floor].get(key) == original['floors'][floor].get(key)
receipt = dict(at=now, floor='3F', pending=44953, displayed=44948, strict='FAIL', signed_target_remaining=35587,
               all_detector_instances=69795, other_floors_untouched=True, all_display_and_acceptance_refs_unchanged=True)
(R / 'data/siege-live-20261026/status-3f44953-result-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
