from pathlib import Path
from datetime import datetime
import copy
import hashlib
import json
import subprocess
import sys
import time

R = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(R / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress, write_progress, utc_now


def checked(path, expected):
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected, str(path)
    return json.loads(data)


six = checked(R / '.claude/worktrees/r6h/docs/superpowers/records/MAIN-INFRA-6F-4240-RETENTION-20261026/independent-26127-role-packet.json',
              '9d9045dc4e0ed5b6184f14597833a0ef6d6fa38bc0c50ae6a4a6b8681cac2f2c')
readback = checked(Path(six['four_pair_builder_readback']['path']),
                   'de7e0f9f50538224c2faf7d61223d5e341274df33449c552dec8d47bf326a3fb')
terminal = checked(Path(six['actual_marker_terminal']['path']),
                   'defcc75a772d2dc89d8467f0eb680121693496010c209b6d6ae22ad0142428ca')
assert terminal['actual_exit_code'] == 0 and terminal['all_owned_exited'] and terminal['abort_reason'] is None
assert six['candidate_triangles'] == readback['saved_candidate_triangles'] == 26127
assert readback['all_four_pairs_literal_only24_removal'] and readback['all_nonselected_face_lines_and_tables_exact']
assert readback['all_protected_originals_present'] and readback['protected_count'] == 4240
assert readback['all_assets_exact'] and readback['asset_pairs'] == 12
for name in ('source', 'engine'):
    role = six['roles'][name]
    contents = Path(role['path']).read_bytes()
    assert hashlib.sha256(contents).hexdigest() == role['sha256']
    assert sum(line.startswith(b'f ') for line in contents.splitlines()) == 26127
five = checked(R / '.claude/worktrees/v5h/data/iv5h-preflight/live-inspection-row-35343.json',
               '9077340e2c041ba2f4dd35e6f3bfbf063e56809228a27ecbdd32133a96dd7eec')
strict = checked(R / '.claude/worktrees/v5h/data/iv5h/independent-guard.json',
                 '8069dbbd2d61f62b1f2c1cc9e75443e5f6467c6f351ab3a133d4cdae37d584d7')
assert not strict['guard']['passed'] and strict['guard']['totals']['material_changed'] == 1
assert five['inspection']['output_triangles'] == 35343 and five['inspection']['census']['signed_kind_total'] == 17096
assert strict['candidate_source_sha256'] == five['candidate']['sha256']
assert strict['candidate_engine_sha256'] == five['candidate_engine']['sha256']

def later(old, new):
    return max((old or new, new), key=lambda value: datetime.fromisoformat(value.replace('Z', '+00:00')))

path = R / 'data/main-infra-fresh/current.json'
for attempt in range(6):
    original = load_progress(path)
    doc = copy.deepcopy(original)
    now = utc_now()
    f = doc['floors']['6F']
    assert f['output_triangles'] == 25433 and f['accepted_preview'] is None
    message6 = ('New 6F engine output saved: 26,127 triangles after exact removal of the two approved orange boxes. '
                'Builder readback confirms 4,240 protected original faces and all 12 material/texture files. '
                'Independent validation of these new hashes is pending; displayed 25,433 remains an unaccepted older candidate.')
    f.update(state='validating', step=message6, blocker='New orange-free 26,127 model awaits independent census, preservation and signed checks.',
             pending_output_triangles=26127, worker_alive=False, engine_worker_alive=False, worker_cpu_seconds=None)
    f['pending_saved_candidate'] = dict(kind='ORANGE_FREE_ENGINE_OUTPUT', triangles=26127,
        source_sha256=six['roles']['source']['sha256'], engine_sha256=six['roles']['engine']['sha256'],
        checkpoint_sha256=six['marker_checkpoint']['sha256'], protected_originals=4240, marker_removed_triangles=24,
        marker_poststage='EXACT_24_ONLY_BUILDER_READBACK', builder_readback_sha256=six['four_pair_builder_readback']['sha256'],
        independent_validation='PENDING', default_error_census='PENDING', strict26='PENDING', native='PENDING', full_signed='PENDING', acceptance=False)
    f['last_work_event_at'] = later(f.get('last_work_event_at'), now)
    event6 = dict(engine='Validator', run_id='MAIN-INFRA-6F-4240-RETENTION-20261026', phase='new26127_orange_free_saved', pid=terminal['actual_pid'],
                  start_utc=terminal['actual_creation_utc'], observed_at=terminal['ended_utc'], message=message6)
    if not any(e.get('phase') == event6['phase'] for e in f.setdefault('worker_events', [])):
        f['worker_events'].append(event6)
    f = doc['floors']['5F']
    assert f['output_triangles'] == 34977 and f['accepted_preview'] is None
    message5 = ('New 5F engine output saved: 35,343 triangles, orange boxes removed. '
                'Independent strict check FAIL: one material-change pixel; fresh census has 17,096 signed-target instances. '
                'New model and seven error filters are prepared locally; their live upload awaits your specific approval. '
                'Displayed 34,977 remains an older unaccepted candidate.')
    f.update(state='blocked', step=message5, blocker='New model fails strict material preservation and signed error targets; separate live inspection upload approval is pending.',
             pending_output_triangles=35343, worker_alive=False, engine_worker_alive=False, worker_cpu_seconds=None)
    f['pending_saved_candidate'] = dict(kind='ORANGE_FREE_ENGINE_OUTPUT', triangles=35343,
        source_sha256=five['candidate']['sha256'], engine_sha256=five['candidate_engine']['sha256'], protected_originals=4641,
        marker_removed_triangles=24, marker_poststage='EXACT_24_ONLY_INDEPENDENT_READBACK',
        independent_readback_sha256='24ec81aa27b79d1bf845f60baa4dfe8008b4205b688342dbd29ebed3a7e52c43',
        strict26='FAIL', strict26_sha256='8069dbbd2d61f62b1f2c1cc9e75443e5f6467c6f351ab3a133d4cdae37d584d7',
        material_changed_pixels=1, other_gating_pixels=0, default_error_census='MEASURED',
        remaining_problems=five['inspection']['census']['candidate']['counts'], remaining_target_instances=17096,
        native='NOT_RUN', full_signed='NOT_RUN', live_upload='SPECIFIC_APPROVAL_PENDING', acceptance=False)
    f['last_work_event_at'] = later(f.get('last_work_event_at'), now)
    if not any(e.get('phase') == 'new35343_independent_fail_local_package' for e in f.setdefault('activity_events', [])):
        f['activity_events'].append(dict(phase='new35343_independent_fail_local_package', at=now, message=message5))
    doc.update(updated_at=now, last_work_event_at=later(doc.get('last_work_event_at'), now),
               step='New orange-free 6F 26,127 awaits independent validation. New 5F 35,343 fails one material pixel and signed targets; live inspection upload approval pending.')
    draft = R / 'data/siege-live-20261026/status-5f35343-6f26127-draft.json'
    draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
    subprocess.run(['node', str(R / 'data/siege-live-20261026/check-status-current.mjs'), str(draft)], check=True, capture_output=True)
    for floor in doc['floors']:
        if floor not in ('5F', '6F'):
            assert doc['floors'][floor] == original['floors'][floor]
        for key in ('source_preview', 'candidate_preview', 'accepted_preview', 'output_triangles', 'latest_saved_candidate'):
            assert doc['floors'][floor].get(key) == original['floors'][floor].get(key)
    if load_progress(path)['updated_at'] != original['updated_at']:
        continue
    try:
        write_progress(path, doc)
        break
    except PermissionError:
        if attempt == 5:
            raise
        time.sleep(.1)
else:
    raise RuntimeError('Canonical changed during all bounded attempts; no stale overwrite')

actual = load_progress(path)
assert actual == doc
receipt = dict(at=now, pending_5F=35343, pending_6F=26127, displayed_5F=34977, displayed_6F=25433,
               other_floor_rows_unchanged=True, all_display_and_acceptance_refs_unchanged=True,
               production_schema_validated=True, accepted=False, model_files_uploaded=False)
(R / 'data/siege-live-20261026/status-5f35343-6f26127-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
