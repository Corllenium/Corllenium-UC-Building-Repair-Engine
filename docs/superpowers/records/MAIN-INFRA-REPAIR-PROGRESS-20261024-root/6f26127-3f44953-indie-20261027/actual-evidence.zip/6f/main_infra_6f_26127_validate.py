"""Authenticate new6F26127; execute unchanged paid physical context, census and strict26."""
import argparse
import json
from pathlib import Path
from tools import main_infra_6f_25210_validate as paid

ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT.parents[2]
JOB='MAIN-INFRA-6F-26127-INDEPENDENT-20261027'
AUTH='6995bd2b8ae60adca36277a79a502b88dac3f0632a32a350a5144618c1119569'
ROLE_SHA='9d9045dc4e0ed5b6184f14597833a0ef6d6fa38bc0c50ae6a4a6b8681cac2f2c'
CP_SHA='7fe50dc426b83f41c62b343b378bb083fa51db188a8dbf69b073b9219ba73499'
need,read,sha=paid.need,paid.read,paid.sha


def bind_scope(selection,old_lineage,lineage,protected):
    a=selection
    need(a['floor']=='6F' and a['selection_approved'] is True and a['acceptance'] is False
         and (a['original_source_triangles'],a['current_input_triangles'],a['expected_output_triangles'])==(34862,26151,26127),'Exact new26127 selection required')
    original,current=a['approved_original'],a['selected_current']
    need(original==list(range(34838,34862)) and current==list(range(26127,26151))
         and len(a['components'])==2 and a['protected_marker_intersection']==[],'Exact24 marker scope required')
    old,final=old_lineage['source_faces'],lineage['source_faces']
    for doc,ids,count in ((old_lineage,old,26151),(lineage,final,26127)):
        need(doc['mode']=='original_source_survivors' and doc['input_triangles']==34862
             and doc['output_triangles']==len(ids)==count and ids==sorted(set(ids))
             and all(type(i) is int and 0<=i<34862 for i in ids),'Original-source ancestry differs')
    chosen=set(current)
    need([old[i] for i in current]==original and final==[v for i,v in enumerate(old) if i not in chosen],'New original marker composition differs')
    need(protected==sorted(set(protected)) and len(protected)==4240 and all(type(i) is int for i in protected)
         and set(protected)<=set(final) and not set(protected)&set(original)
         and protected==a['protected_contact_originals'],'Mandatory4240 originals not all preserved')
    return dict(floor='6F',original_triangles=34862,reference_triangles=34838,candidate_triangles=26127,
        approved_original_faces=original,candidate_originals=final,protected_original_count=4240,acceptance=False)


def bind_roles(refs,roles):
    need(roles['floor']=='6F' and roles['candidate_triangles']==26127 and roles['reference_triangles']==34838
         and roles['protected_original_count']==4240 and roles['donor_identity_keys']==608 and roles['acceptance'] is False
         and roles['strict_guard_extension'] is False and roles['guard_or_tolerance_changed'] is False,'New26127 role scope differs')
    for key in ('default_detector_maps','strict26','qualified_native_views','full_signed_validator'):
        need(roles[key]=='PENDING_ON_NEW_HASHES','Historical verdict cannot qualify new26127')
    for key,pin in dict(roles['roles'],**roles['original_qualified_pair']).items():
        need(refs[key]==pin,'Authenticated SOURCE/ENGINE role differs: '+key)
    for key,field in (('raw','original_owner_raw'),('protected','corrective_whole_site_closure'),
                      ('arrays','marker_arrays'),('lineage','cumulative_original_ancestry')):
        need(refs[key]==roles[field],'Authenticated precision/protection/capture role differs: '+key)
    need(refs['selection']==roles['root_seal'] and refs['checkpoint']==roles['marker_checkpoint'],'New marker authority/capture differs')


def saved_pairs(refs,selection,builder):
    need(builder['root_selection']['sha256']==AUTH and builder['acceptance'] is False and len(builder['assets'])==12
         and builder['checkpoint']['sha256']==refs['checkpoint']['sha256']==CP_SHA
         and builder['checkpoint_before_all_four_model_files'] is True,'Actual new marker capture/assets differ')
    need(refs['original_source']==selection['original_source'],'Original SOURCE role differs')
    pairs={}
    for role,before in (('source',selection['current_source']),('engine',selection['current_engine']),
                        ('reference_source',refs['original_source']),('reference_engine',refs['original_engine'])):
        proof=builder['proofs'][role]
        need(proof['before']['sha256']==before['sha256'] and proof['after']['sha256']==refs[role]['sha256']
             and proof['removed_faces']==(selection['selected_current'] if role in ('source','engine') else selection['approved_original']),
             'Saved role identity differs: '+role)
        pairs[role]=dict(before=before,after=refs[role])
    return pairs


def bind_capture(p,c3,c5,closure,old_lineage):
    protected=closure['protected_original_faces'];historical=closure['historical_rollback_originals'];t=c5['input_context_transition']
    need(p['proof']['protected_original_faces']==protected and len(historical)==2844 and historical==sorted(set(historical))
         and set(historical)<=set(protected),'Historical whole-original protection differs')
    need(p['proof']['before_digest']==c3['input_digest'] and c3['outcome_digest']==c5['input_digest']==t['before_digest']==t['after_digest']
         and t['changed_fields']==[] and t['before_metadata']==t['after_metadata'] and t['donor_rows_rebound']==608
         and t['donor_keys_exact'] is True and t['historical_context']['donor_rows_checked']==608
         and t['historical_context']['donor_keys_exact'] is True,'608 identity capture differs')
    need([c3['survivors'][i] for i in c5['survivors']]==old_lineage['source_faces'],'Checked E3/E5 original ancestry differs')
    return dict(donor_rows=608,identity=True,historical_originals=2844)


def context(path,expected):
    need(sha(path)==expected,'Invocation specification differs');s=read(path)
    need(s['job_id']==JOB and s['acceptance'] is False and Path(s['out']).resolve()==ROOT/'data/iv6i','Owned new6F independent scope differs')
    for pin in s['refs'].values():need(sha(pin['path'])==pin['sha256'],'Consumed input changed: '+pin['path'])
    rp=s['role_packet'];need(rp['sha256']==ROLE_SHA and sha(rp['path'])==ROLE_SHA,'Exact new26127 role graph required')
    roles=read(rp['path']);refs=s['refs'];bind_roles(refs,roles)
    need(refs['selection']['sha256']==AUTH and refs['paid_strict']['sha256']=='bc7d45e280950df37e23f4bca38d2a78ce6007969dec9e6a2edeab72fdba39b2','Reviewed authority/helper differs')
    for rel,digest in paid.COMPONENTS.items():need(sha(ROOT/rel)==digest,'Paid numerical component differs')
    for key,rel in (('paid_caller','tools/main_infra_6f_25210_validate.py'),('main_infra_1f_error_census','tools/main_infra_1f_error_census.py'),('main_infra_orange_free_census','tools/main_infra_orange_free_census.py')):
        need(sha(ROOT/rel)==refs[key]['sha256'],'Paid executing caller/detector context differs')
    a=read(refs['selection']['path']);closure=read(refs['protected']['path'])
    scope=bind_scope(a,read(refs['old_lineage']['path']),read(refs['lineage']['path']),closure['protected_original_faces'])
    saved_pairs(refs,a,read(refs['builder_readback']['path']))
    for pin in s['capture_chain'].values():need(sha(pin['path'])==pin['sha256'],'Checked builder capture changed')
    bind_capture(*(read(s['capture_chain'][k]['path']) for k in ('preparation','checkpoint_E3','checkpoint_E5')),closure,read(refs['old_lineage']['path']))
    for key,head in (('kernel_terminal','engine_executed_HEAD'),('marker_terminal','marker_executed_HEAD')):
        t=read(refs[key]['path']);need(t['actual_exit_code']==t['launcher_exit_code']==0 and t['abort_reason'] is None
            and t['all_owned_exited'] is True and t['HEAD']==roles[head] and t['acceptance'] is False,'Actual builder terminal binding differs')
    from tools.jobs import get
    claim=get(MAIN,JOB);need((claim['status'],claim['holder'],claim['branch'])==('claimed','Codex-6F-26127-Independent','codex/main-infra-6f-26127-independent-20261027'),'Independent job claim differs')
    return s,scope


def readback(s,scope):
    refs=s['refs'];a=read(refs['selection']['path']);pairs=saved_pairs(refs,a,read(refs['builder_readback']['path']));proofs={}
    for role,pair in pairs.items():
        for pin in pair.values():need(sha(pin['path'])==pin['sha256'],'Actual saved OBJ hash differs')
        removed=a['selected_current'] if role in ('source','engine') else a['approved_original']
        proofs[role]=paid.verify_survivors(Path(pair['before']['path']).read_bytes(),Path(pair['after']['path']).read_bytes(),removed)
    removed=sorted(set(range(34862))-set(scope['candidate_originals']))
    for role,original in (('source','original_source'),('engine','original_engine')):
        proofs['cumulative_'+role]=paid.verify_ancestry(Path(refs[original]['path']).read_bytes(),Path(refs[role]['path']).read_bytes(),removed)
    assets=read(refs['provenance']['path'])['assets'];need(len(assets)==12,'Exact original12 assets required')
    for asset in assets:
        for role in ('source','reference_source','original_engine'):
            p=Path(refs[role]['path']).parent/asset['path'];need(sha(p)==asset['sha256'],'Original material/texture asset changed')
    return dict(kind='independent_exact_new6F26127_readback',obj_pairs=proofs,assets=assets,protected_original_count=4240,
        approved_marker_originals_absent=True,native='NOT_RUN',fullsigned='NOT_RUN',acceptance=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('phase',choices=('metadata','readback','guard','census'))
    parser.add_argument('--spec',type=Path,required=True);parser.add_argument('--spec-sha256',required=True);args=parser.parse_args()
    if args.phase in ('guard','census'):
        paid.JOB,paid.AUTH,paid.context=JOB,AUTH,context
        return paid.main()
    s,scope=context(args.spec,args.spec_sha256)
    if args.phase=='metadata':print(json.dumps(dict(geometry_loaded=False,counts=[34862,34838,26127],protected_originals=4240,acceptance=False)));return 0
    out=Path(s['out']);out.mkdir(exist_ok=True);result=readback(s,scope);context(args.spec,args.spec_sha256)
    target=out/'independent-saved-readback.json'
    with target.open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
    print(json.dumps(dict(path=str(target),sha256=sha(target),protected_originals=4240,acceptance=False)));return 0


if __name__=='__main__':raise SystemExit(main())
