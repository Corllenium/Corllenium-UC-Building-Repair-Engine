"""The new26127/4240 roles cannot inherit the old25433 validation scope."""
import json,zipfile,hashlib
from pathlib import Path
import pytest

REC=Path(__file__).parents[2]/'docs/superpowers/records/MAIN-INFRA-6F-26127-INDEPENDENT-20261027'
def fixture():
    with zipfile.ZipFile(REC/'actual26127-schema.zip') as z:d={Path(n).stem:json.loads(z.read(n)) for n in z.namelist()}
    for key,field in [('raw','original_owner_raw'),('protected','corrective_whole_site_closure'),('arrays','marker_arrays'),('lineage','cumulative_original_ancestry')]:d['refs'][key]=dict(d['roles'][field])
    return d
def api():
    from tools import main_infra_6f_26127_validate as m
    return m
def bound(d):return api().bind_scope(d['selection'],d['old_lineage'],d['lineage'],d['protected']['protected_original_faces'])

def test_actual26127_scope_requires_all4240_whole_originals():
    s=bound(fixture());assert (s['original_triangles'],s['reference_triangles'],s['candidate_triangles'],s['protected_original_count'])==(34862,34838,26127,4240)
    assert s['acceptance'] is False

@pytest.mark.parametrize('mutation',['old_count','old_protection','extra_marker','lost_required','duplicate_parent','bool_parent','wrong_floor'])
def test_scope_rejects_stale_or_incomplete_ancestry(mutation):
    d=fixture()
    if mutation=='old_count':d['selection']['expected_output_triangles']=25433
    elif mutation=='old_protection':d['protected']['protected_original_faces']=d['protected']['protected_original_faces'][:3546]
    elif mutation=='extra_marker':d['selection']['selected_current'][0]=0
    elif mutation=='lost_required':d['protected']['protected_original_faces'][-1]=34838
    elif mutation=='duplicate_parent':d['lineage']['source_faces'][-1]=d['lineage']['source_faces'][-2]
    elif mutation=='bool_parent':d['lineage']['source_faces'][0]=True
    else:d['selection']['floor']='5F'
    with pytest.raises(ValueError):bound(d)

def test_four_pairs_are_authenticated_from_new_role_packet():
    d=fixture();api().bind_roles(d['refs'],d['roles']);p=api().saved_pairs(d['refs'],d['selection'],d['builder_readback'])
    assert set(p)=={'source','engine','reference_source','reference_engine'}
    assert p['source']['before']==d['selection']['current_source'] and p['source']['after']==d['refs']['source']
    assert p['reference_source']['before']==d['refs']['original_source']

@pytest.mark.parametrize('mutation',['source_hash','role_swap','checkpoint','original','oracle_pass','asset_loss','old_native_pass'])
def test_new_packet_and_pair_roles_reject_substitution(mutation):
    d=fixture();r=d['refs'];b=d['builder_readback']
    if mutation=='source_hash':r['source']['sha256']='0'*64
    elif mutation=='role_swap':r['source'],r['engine']=r['engine'],r['source']
    elif mutation=='checkpoint':r['checkpoint']['sha256']='0'*64
    elif mutation=='original':r['original_source']['sha256']='0'*64
    elif mutation=='oracle_pass':b['acceptance']=True
    elif mutation=='asset_loss':b['assets'].pop()
    else:d['roles']['qualified_native_views']='PASS'
    with pytest.raises(ValueError):
        api().bind_roles(r,d['roles']);api().saved_pairs(r,d['selection'],b)

def captured(d):return api().bind_capture(d['preparation'],d['checkpoint_E3'],d['checkpoint_E5'],d['protected'],d['old_lineage'])
def test_actual_capture_retains608_identity_and_historical2844():
    c=captured(fixture());assert c=={'donor_rows':608,'identity':True,'historical_originals':2844}

@pytest.mark.parametrize('mutation',['donor607','keys_unproven','metadata_drift','digest_chain','survivor_parent','lost_historical'])
def test_capture_chain_cannot_waive_identity_or_original_protection(mutation):
    d=fixture();t=d['checkpoint_E5']['input_context_transition']
    if mutation=='donor607':t['donor_rows_rebound']=607
    elif mutation=='keys_unproven':t['donor_keys_exact']=False
    elif mutation=='metadata_drift':t['after_metadata']['coord_decimals']-=1
    elif mutation=='digest_chain':d['checkpoint_E5']['input_digest']='0'*64
    elif mutation=='survivor_parent':d['checkpoint_E5']['survivors'][0]=d['checkpoint_E5']['survivors'][1]
    else:d['protected']['historical_rollback_originals'][0]=34838
    with pytest.raises(ValueError):captured(d)

def test_paid_context_guard_and_default_census_remain_exact():
    m=api();w=Path(__file__).parents[2]
    assert hashlib.sha256((w/'tools/main_infra_6f_25210_validate.py').read_bytes()).hexdigest()=='360370062c78eaa04947d74af654310c44f24a8d5ad032ace46f8a73156ef459'
    for rel,digest in m.paid.COMPONENTS.items():assert hashlib.sha256((w/rel).read_bytes()).hexdigest()==digest

@pytest.mark.parametrize('key',['raw','protected','arrays','lineage'])
def test_consumed_precision_protection_capture_and_parent_pins_match_packet(key):
    d=fixture();d['refs'][key]['sha256']='0'*64
    with pytest.raises(ValueError):api().bind_roles(d['refs'],d['roles'])
