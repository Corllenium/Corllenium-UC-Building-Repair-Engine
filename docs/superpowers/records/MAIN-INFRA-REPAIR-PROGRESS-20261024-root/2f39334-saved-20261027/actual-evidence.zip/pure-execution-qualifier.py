"""Pure identity qualification for the already launched 2F attempt2 worker."""
from datetime import datetime

PHASE='ca8c2a5a8fa517c9f8a56225131b8581fe6c4e3263958241cae6d9f5e548a9b9'
HEAD='ebbac00859e6fb9f89981272a7d1e79cff07ff38'
BIRTH='2026-10-27T09:16:25.8211623Z'
MON=r'D:\PROJECTS\05-Corllenium-UC-Building-Repair-Engine\.claude\worktrees\r2n\data\retention-preflight-v2\monitor-2F-native14-retention-attempt2-engine-20261027T091624'
IDENTITY=dict(state='RUNNING',phase='2F-native14-retention-attempt2-engine',actual_pid=52304,actual_creation_utc=BIRTH,
    launcher_pid=72856,monitor_pid=58544,HEAD=HEAD,phase_plan_sha256=PHASE,evidence=MON)
ACQUIRED=dict(exclusive_operator='/root/resume_1f_delivery',original_phase_sha256=PHASE,monitor_pid=58544,
    coordination_sha256='86a20113a90ce0a9aabb7e64da030284ce924689a86afc04bb52c53f5f3aaba0',
    monitor_creation_utc='2026-10-27T09:16:22.8683553Z',nonce='58cc9ad6-608a-411c-b519-3228fc4caedd',
    lease_acquired_utc='2026-10-27T09:16:23.8640970Z',lease_released=False,
    profile_sha256='f9a9f0712b4aed5e20a172f61c8db2ce891384894579a2f5d5eb63b53889e812')

def require(value,message):
    if not value:raise ValueError(message)

def exact_fields(actual,expected,label):
    require(isinstance(actual,dict),label+' object required')
    for key,value in expected.items():
        require(key in actual and type(actual[key]) is type(value) and actual[key]==value,label+' differs: '+key)

def utc(value):
    require(isinstance(value,str),'UTC timestamp required')
    result=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(result.tzinfo is not None,'Timezone required')
    return result

def qualify_execution(identity,terminal,acquired,released):
    exact_fields(identity,IDENTITY,'Pinned original identity')
    exact_fields(acquired,ACQUIRED,'Pinned acquired lease')
    expected={key:value for key,value in IDENTITY.items() if key not in ('state','launcher_pid','monitor_pid')}
    expected.update(state='PROCESS_EXITED_ZERO',actual_exit_code=0,launcher_exit_code=0,all_owned_exited=True,abort_reason=None)
    exact_fields(terminal,expected,'Successful terminal')
    expected_release=dict(ACQUIRED,lease_released=True)
    exact_fields(released,expected_release,'Released original lease')
    require(utc(terminal.get('ended_utc'))>=utc(BIRTH),'Terminal predates actual worker')
    require(utc(released.get('ended_utc'))>=utc(terminal['ended_utc']),'Lease release predates terminal')
    return dict(execution_identity_verified=True,actual_pid=52304,actual_creation_utc=BIRTH,monitor_pid=58544,
        executing_HEAD=HEAD,phase_plan_sha256=PHASE,released_original_lease=True,builder_readback_only=True,
        independent_validation='PENDING',acceptance=False)
