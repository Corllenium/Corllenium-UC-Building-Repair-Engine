from pathlib import Path
import hashlib,json,subprocess
from qualify_attempt2_execution import qualify_execution
W=Path(__file__).resolve().parents[2];M=W.parents[2];O=Path(__file__).resolve().parent;R=W/'docs/superpowers/records/MAIN-INFRA-2F-NATIVE14-RETENTION-20261027'
OUT=W/'data/native14-retention/attempt2';MON=O/'monitor-2F-native14-retention-attempt2-engine-20261027T091624'
def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)

def main():
    assert pin(MON/'actual-identity.json')['sha256']=='fd60cfe1cdc6326f3048d69b7bf9058e16807b1a10516a84e8554052d171c6e2'
    assert pin(MON/'single-owner-lease.json')['sha256']=='9622fb5ac2664634b851df47c18f5442369ab7beaf2f0aa43ae951d0f4e12329'
    identity=read(MON/'actual-identity.json');acquired=read(MON/'single-owner-lease.json');terminal=read(MON/'result.json')
    lease_path=M/'data/siege-live-20261026/single-owner-8gib.lock';lease_raw=lease_path.read_bytes();lease=json.loads(lease_raw)
    qualification=qualify_execution(identity,terminal,acquired,lease)
    release=O/'attempt2-single-owner-release.json';assert not release.exists();release.write_bytes(lease_raw)
    b=read(O/'owner-binding.json');result=read(OUT/'run-receipt.json');marker=read(OUT/'marker-receipt.json');mapping=read(OUT/'candidate/source-faces.json')
    assert result['executing_HEAD']==b['executing_HEAD']=='ebbac00859e6fb9f89981272a7d1e79cff07ff38'
    assert result['planned']==1045 and result['kept']+result['rolled_back']==1045
    parents=result['original_source_survivors'];count=result['output_triangles'];assert parents==sorted(set(parents))==mapping['source_faces']==marker['source_faces']
    assert len(parents)==count and 39334<=count<=56804 and result['reference_triangles']==56804
    assert marker['removed_originals']==list(range(56804,56828)) and len(marker['selected_current'])==24
    assert set(result['old_protected_originals'])<=set(result['whole_required_originals'])<=set(parents) and len(result['old_protected_originals'])==8717
    assert set(result['fresh_rollback_originals'])<=set(result['whole_required_originals'])
    old=read(b['refs']['current_lineage']['path']);old_parents=[x[0] for x in old['original_source_faces']];assert set(old_parents)<=set(parents)
    assert not set(parents)&set(range(56804,56828)) and result['previous_verdict_transferred'] is False
    assert result['independent_validation']=='PENDING' and result['new_error_census']=='NOT_RUN' and result['repair_complete'] is result['acceptance'] is False
    source=OUT/'candidate/candidate.source.obj';engine=OUT/'candidate/candidate.engine.obj'
    assert pin(source)['sha256']==result['source_sha256'] and pin(engine)['sha256']==result['engine_sha256']
    lexical={}
    for kind,folder,expected in [('candidate','candidate',count),('reference','reference',56804)]:
     for name in ('candidate.source.obj','candidate.engine.obj'):
      p=OUT/folder/name;faces=[line for line in p.read_text().splitlines() if line.startswith('f ')];assert len(faces)==expected and all(len(line.split())==4 for line in faces)
      lexical[kind+'/'+name]=dict(triangles=len(faces),sha256=pin(p)['sha256'])
     for row in result['assets']:
      p=OUT/folder/row['path'].replace('\\','/');assert pin(p)['sha256']==row['sha256']
    assert len(result['assets'])==10
    for row in b['pins']:assert pin(row['path'])==row
    assert not subprocess.check_output(['git','-C',str(W),'status','--porcelain','--untracked-files=no'],text=True).strip()
    outputs=[pin(p) for p in OUT.rglob('*') if p.is_file()]
    proof=dict(readback_role='BUILDER_BYTE_AND_RECEIPT_READBACK',execution_qualification=qualification,independent_corner_UV_preservation_proven=False,actual_identity=pin(MON/'actual-identity.json'),acquired_lease=pin(MON/'single-owner-lease.json'),actual_terminal=pin(MON/'result.json'),global_release=pin(release),original_binding=pin(O/'owner-binding.json'),output_triangles=count,
     planned=result['planned'],kept=result['kept'],rolled_back=result['rolled_back'],SOURCE=pin(source),ENGINE=pin(engine),
     checkpoint_sha256=result['checkpoint_sha256'],lexical_triangle_readback=lexical,builder_receipts_assert_old38110_originals_retained=True,
     required_whole_originals=len(result['whole_required_originals']),builder_receipts_assert8717_original_locks_retained=True,all10_assets_exact_in_candidate_and_reference=True,
     exact24_marker_exception=True,input_pins_rehashed=len(b['pins']),saved_files=len(outputs),numeric_guard_qualification='CONCERN_NOT_VERDICT; boundK1coord16 warning; owner collisions NOT_MEASURED',
     independent_validation='PENDING',new_error_census='NOT_RUN',owner_OBJ_parser_or_NPZ_reader_used_in_this_readback=False,repair_complete=False,acceptance=False)
    proof_path=R/'actual-attempt2-byte-readback.json';assert not proof_path.exists();proof_path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
    role_path=R/'independent-attempt2-role-inputs.json';assert not role_path.exists()
    role=dict(role='BUILDER_DELIVERY_INPUTS_NOT_INDEPENDENT_VALIDATION',execution_qualification=qualification,builder_job='MAIN-INFRA-2F-NATIVE14-RETENTION-20261027',builder='Codex-2F-Native14-Retention',builder_commit=b['executing_HEAD'],
     original_binding=pin(O/'owner-binding.json'),refs=b['refs'],runtime_pins=b['pins'],outputs=outputs,terminal=pin(MON/'result.json'),global_release=pin(release),
     measured_builder_readback=pin(proof_path),original_source_survivors=parents,whole_required_originals=result['whole_required_originals'],
     source_priority_contacts=result['source_priority_contacts'],assets=result['assets'],original_RAW_axis_quanta=result['original_RAW_axis_quanta'],
     exact_marker_authority=b['refs']['authority'],marker_receipt=pin(OUT/'marker-receipt.json'),actual_checked_run=pin(OUT/'run-receipt.json'),
     guarded_before='Fresh original marker-free56804 reference; original source/RAW frame remains authority; no predecessor PASS transfer',
     numeric_guard_qualification=dict(state='CONCERN_NOT_VERDICT',metadata_proof=pin(O/'numeric-investigation/metadata-int64-range-proof-v2.json'),owner_key_collisions='NOT_MEASURED'),
     independent_validation='PENDING',new_error_census='NOT_RUN',native='NOT_RUN',full_signed='NOT_RUN',repair_complete=False,acceptance=False)
    role_path.write_text(json.dumps(role,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(proof=pin(proof_path),role=pin(role_path),count=count,kept=result['kept'],rolled_back=result['rolled_back'],source=pin(source),engine=pin(engine),independent='PENDING',acceptance=False),indent=2))

if __name__=='__main__':main()
