# 3F corrective builder handoff — new44958 role

## 2 Current state

Saved/reopened candidate44958 is a builder result; independent validation, new default error maps, signed targets and owner acceptance are PENDING. Root assigns a different agent to those phases. No builder census was requested after this handoff.

SOURCE: `D:\PROJECTS\05-Corllenium-UC-Building-Repair-Engine\.claude\worktrees\r3w\data\3f-two-witness\serialization-resume-attempt1\candidate\candidate.source.obj`
SHA256 `e5a300ef12918aaeb4cb48128d9eab4c2a6f37478a09ddf0c3b627a49cbbee65`

ENGINE: `D:\PROJECTS\05-Corllenium-UC-Building-Repair-Engine\.claude\worktrees\r3w\data\3f-two-witness\serialization-resume-attempt1\candidate\candidate.engine.obj`
SHA256 `a986bc912f6c847a26edd4d2ce922636905b0286cd100c1546b489aaa36f1cd3`

Lineage: `D:\PROJECTS\05-Corllenium-UC-Building-Repair-Engine\.claude\worktrees\r3w\data\3f-two-witness\serialization-resume-attempt1\candidate\source-faces.json`
SHA256 `8104cddb54e261e7d5dc48a3b0a1c8012135343fc92f6c7728f5c6d2a375f904`

Actual final writer51956 exited0/noabort/allownedgone2026-10-26T19:54:11.4763808Z,30.41s. The unchanged paid writer reopened both models. All8original assets are byte-identical. Face lineage44958 =44939 unchanged whole originals +19cut children from14cut parents. All6494required whole originals survive, including3221,9138,9139,38508,38509. All24authorized marker originals53318..53341 are absent; actual orange-material faces0.

## Earned chain

Fresh original53602/native tessellation/RAW precision → actual fresh E3CP84880ec064312a6a8b8c16a2af7eff0b068b7951a0bd7b4c143a512b4ef46d2b:1410checked/kept,0rolled,44977faces → exact24marker exception under AUTH81c02db5fca5eda121549533cca06a23e14c160860246af9613deedc652b6dfb → corrected marker-free44953 SOURCEeac7d813/ENGINEdeb717d5 → fresh SOURCE-E5reporteb719c1f,14partial/0remove/276priorityanchors, typedplanc84a6045503341a2d8f8f0540fca8eb6f76a2fce31942708046585af436f73d3 → actual E5CPb5ec759bac23a43b3ce6f9042839d295a310168e479d55b1c7b2e4372a808a69:14checked/kept,0rolled,44958typedfaces.

Original E5 kernel commit3b600f82331572e486c5d419ea3b2ca7634d7e88/inputbinding23c080a6 is preserved. Its first paired writer rejected only receipt original_axis_quanta tuple/list. Actual readonly diagnostic60412 proved exactly that path with identical3positive float values; all other binding fields, typedbefore58d7f879/after54665b2f digests, Frame and RAWquanta unchanged. Writer-only commit8cecdd73e86ea7bba61090451fc69473e329cdd0 strictly matched every other field/type, supplied actual captured JSON to unchanged paid resume_pair, and reused CPb5ec without kernel rerun/recapture. All CP bytes remain unchanged.

## Independent validation inputs

Frozen writer binding `D:\PROJECTS\05-Corllenium-UC-Building-Repair-Engine\.claude\worktrees\r3w\data\3f-two-witness-inputs\v5-writer-resume\binding.json` SHA256 `7996110e0f7f1f1d2bbd8eecf01f7aa60853987d7b570c30913a80b1205749c2` contains85reference roles/289runtime pins, including original source/native reference/provenance/materials/targets, actual E3/E5 checkpoints, marker authority, current proposal, saved models and terminals. Required original vector is `data/3f-two-witness/attempt2/e3/selection.json` under r3w. Use its6494vector, rather than old6489.

Original source RAWf63c0794; normalized SOURCEf9f2f90e; normalized ENGINE740103bb. Frame1000/25.4 inches/metre; original RAW-derived physical quanta[3.937007874015748e-05,3.937007874015748e-05,3.937007874015748e-06]in; do not derive tolerances from candidate serialization. Original point table22434→22450after E5:16winning-border appended points. The strict original53578-face reference excludes exactly24approved marker rows; extending BEFORE with append-only unused points must not touch any original used row, UV/corner/material or physical context. The SOURCE writer omits only the unused orange material slot; prove resolved material names/arrays before any validation-only ordinal view.

This is NEW44958. The corrected pre-E5 marker-free model also had44953faces, matching the count of OLD eec9d229/1de6464d partial candidate with different geometry. Never reuse its old44953 maps/guard PASS/FAIL or fixed16-proposal qualification. Both old snapshots/failedattempts remain immutable. A new independent caller must own its job and authenticate this new role; do not use the builder's claimed-job entrypoint as a validation ownership gate.

Full local archive and SHA are in companion DELIVERY-ARCHIVE-RECEIPT.json. No public push, dashboard publication, Blender replacement, signed-target pass or owner acceptance is claimed here.
