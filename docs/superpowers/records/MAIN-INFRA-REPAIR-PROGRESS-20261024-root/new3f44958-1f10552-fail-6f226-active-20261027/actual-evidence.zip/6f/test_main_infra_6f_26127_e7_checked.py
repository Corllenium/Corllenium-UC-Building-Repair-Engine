import copy,hashlib,json
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pytest

def api():
    from tools import main_infra_6f_26127_e7_checked as m
    return m

def fixture(m,rolled=False):
    from engine.io.minecraft_floor import parse_floor,Frame
    from engine.repair.types import UnitState,RepairContext,apply_edits
    from engine.fixes.pipeline import FixProfile
    from engine.repair.engines.e7_thread import E7Thread
    from engine.repair.kernel import KernelResult,stage_records
    source=parse_floor('mtllib wall.mtl\nv 0 0 0\nv 2 0 0\nv 0 2 0\nv 1 0 0\nv 1 -1 0\nv 2 -1 0\nvt 0 0\nvt 1 0\nvt 0 1\nvt .5 0\nvt .5 -.5\nvt 1 -.5\ng retained\nusemtl wall\nf 1/1 2/2 3/3\ng protected\nf 4/4 5/5 6/6\n')
    frame=Frame(1.,'synthetic SOURCE Y-up');before=source.in_frame(frame).mesh;looks=SimpleNamespace(key_of=lambda n:'wall-look')
    edits=E7Thread().plan(UnitState(before,None,{},None),RepairContext(FixProfile(),None,None));assert len(edits)==1
    rows=[dict(output_face=i,original_source_triangle=100+i,kind='unchanged',group=p.group,object_name=p.object_name) for i,p in enumerate(source.polygons)]
    report=m.qualify_current(source.mesh,before,[100,101],edits,[101],frame);report.update(source_digest=m._source_digest(source.mesh).hex(),engine_digest=m._source_digest(before).hex())
    kept=[] if rolled else edits;after,_=apply_edits(before,kept);check=dict(stage='E7',engine='E7',legacy=False,rollback=True,rolled_back=[{'site':0}] if rolled else [],final='NOTHING KEPT' if rolled else 'PASS',runs=[dict(status='PASS',failing=0,unknown=0)])
    records=stage_records(before,edits,{0:'wall-look'},'E7')
    if rolled:records[0]['rolled_back']=True
    records.append({'check':check});outcome=KernelResult(after,None,edits,[],None,kept,edits if rolled else [],[check],records)
    return source,frame,before,looks,rows,edits,report,outcome

def test_receipt_json_canonicalization_does_not_rewrite_typed_context():
    m=api();s,f,b,l,rows,edits,report,o=fixture(m);before=m._source_digest(b)
    value=dict(quanta=b.physical_quanta,nested={'tuple':(1,(2,3))},frame=f.matrix.tolist());actual=m.receipt_binding(value)
    assert isinstance(actual['quanta'],list) and actual['nested']['tuple']==[1,[2,3]]
    assert isinstance(value['quanta'],tuple) and isinstance(b.physical_quanta,tuple) and m._source_digest(b)==before

def execute_fixture(m,tmp_path,monkeypatch,rolled=False):
    s,f,b,l,rows,edits,report,o=fixture(m,rolled);monkeypatch.setattr(m,'run_checked_subset',lambda *a:o)
    binding=dict(run_id='tiny6F',before_digest=m._source_digest(b).hex(),paths={},sha256={},physical_context={'quanta':b.physical_quanta},frame_matrix=f.matrix.tolist())
    result=m.execute_checked(s,f,b,l,rows,edits,report,tmp_path/'run',binding=binding,mandatory=[101],original_count=102)
    return s,b,result

def test_real_paid_checkpoint_before_current_pair_writer_and_canonical_binding(tmp_path,monkeypatch):
    m=api();events=[];capture=m.save_e7_checkpoint;writer=m.write_current_pair
    def captured(*a,**kw):
        assert isinstance(kw['binding']['physical_context']['quanta'],list)
        result=capture(*a,**kw);events.append('checkpoint');return result
    def written(*a,**kw):
        assert events==['checkpoint'];events.append('writer');return writer(*a,**kw)
    monkeypatch.setattr(m,'save_e7_checkpoint',captured);monkeypatch.setattr(m,'write_current_pair',written)
    source,before,result=execute_fixture(m,tmp_path,monkeypatch)
    assert events==['checkpoint','writer'] and result['kept']==1 and result['rolled_back']==0 and result['output_triangles']==3
    saved=json.loads((tmp_path/'run/candidate/cut-lineage.json').read_bytes())['faces']
    assert [x['original_source_triangle'] for x in saved]==[101,100,100] and result['next_mandatory_originals']==[101]
    from engine.io.minecraft_floor import parse_floor
    after=parse_floor((tmp_path/'run/candidate/candidate.source.obj').read_text())
    assert after.mesh.positions.tobytes()==source.mesh.positions.tobytes() and after.mesh.uvs[:len(source.mesh.uvs)].tobytes()==source.mesh.uvs.tobytes()

@pytest.mark.parametrize('bad',['digest','selected','UV','mandatory','CBR_empty'])
def test_report_scope_or_universal_partition_cannot_be_bypassed(bad):
    m=api();s,f,b,l,rows,edits,report,o=fixture(m);report=copy.deepcopy(report);required=[101]
    if bad=='digest':report['typed_plan_digest']='0'*64
    elif bad=='selected':report['admitted_indices']=[]
    elif bad=='UV':edits=[replace(edits[0],new_face_uv=np.zeros_like(edits[0].new_face_uv))]
    elif bad=='mandatory':required=[100,101]
    else:report['cbr_winner_vector']='EMPTY'
    with pytest.raises(ValueError):m.bind_subset(s.mesh,b,rows,edits,report,l,required,f)

def test_fresh_rollback_parent_remains_whole_and_is_added_to_next_protection(tmp_path,monkeypatch):
    m=api();s,b,result=execute_fixture(m,tmp_path,monkeypatch,True)
    assert result['kept']==0 and result['rolled_back']==1 and result['output_triangles']==2
    assert result['fresh_rollback_originals']==[100] and result['next_mandatory_originals']==[100,101] and result['repair_complete'] is False

def test_unknown_current_look_is_not_invented_or_borrowed(tmp_path,monkeypatch):
    m=api();s,f,b,l,rows,edits,report,o=fixture(m);catalog=tmp_path/'6F-looks.json';catalog.write_text('{}');calls=[]
    plan={'refs':{'source':{'path':str(tmp_path/'current/candidate.source.obj')},'original_engine':{'path':str(tmp_path/'original/before.engine.obj')}}};ref={'path':str(catalog),'sha256':hashlib.sha256(catalog.read_bytes()).hexdigest()}
    monkeypatch.setattr(m,'parse_mtl',lambda p: ('definitions',str(p)))
    def loader(path,sources):calls.append((path,sources));return SimpleNamespace(unknown=lambda mesh:['missing6Flook'])
    monkeypatch.setattr(m,'load_looks',loader)
    with pytest.raises(ValueError):m.load_current_looks(plan,b,ref)
    assert calls[0][0]==str(catalog) and [str(x[1]) for x in calls[0][1]]==[str(tmp_path/'original'),str(tmp_path/'current')]

def test_nonfinite_receipt_binding_is_rejected():
    m=api()
    with pytest.raises(ValueError):m.receipt_binding({'quanta':(float('nan'),1.,1.)})
