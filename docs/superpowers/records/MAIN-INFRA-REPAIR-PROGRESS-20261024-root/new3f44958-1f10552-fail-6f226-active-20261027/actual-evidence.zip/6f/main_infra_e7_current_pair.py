"""Paid current-SOURCE CutPair boundary; serialization remains save_cut_pair."""
from dataclasses import replace
from pathlib import Path
import hashlib
import numpy as np
from engine.io.minecraft_floor import FloorInput,SourcePolygon
from engine.repair.types import apply_edits
from engine.repair.engines.e7_thread import _source_weights,_attributes
from tools.main_infra_e7_checkpoint import restore_e7_checkpoint
from tools.main_infra_e7_serialization import _tables,_array,_prove_exact_source_coverage,_checked,CutPair,_seal as pair_seal,save_cut_pair
UNCHANGED=('original_source_triangle','kind','vertex_ids','source_uv','source_normal','engine_uv','engine_normal','material','group','object_name')
def need(ok,message):
    if not ok:raise ValueError(message)

def write_current_pair(source,frame,before,looks,rows,checkpoint,sha,binding,out,mandatory,locked,anchors,original_count):
    actual=restore_e7_checkpoint(before,looks,checkpoint,binding=binding,expected_receipt_sha256=sha)
    need(source.mesh.n_faces==before.n_faces==len(rows),'Complete current partial ancestry required')
    _tables(source.in_frame(frame).mesh,before)
    touched={e.faces[0] for e in actual.kept};protected=set(mandatory)
    need(not touched&set(locked) and set(anchors)<=set(locked) and not any(rows[i]['original_source_triangle'] in protected for i in touched),'Protected current parent cannot be edited')
    source_edits=[]
    for e in actual.kept:
        _prove_exact_source_coverage(source.mesh,e.faces[0],e.new_faces)
        _,weights,_,_=_source_weights(before,e.faces[0],e.new_faces)
        source_edits.append(replace(e,new_face_uv=_attributes(source.mesh,e.faces[0],weights,'face_vt','uvs'),new_face_normal=_attributes(source.mesh,e.faces[0],weights,'face_vn','normals')))
    source_before=replace(source.mesh,materials=before.materials.copy(),face_material=before.face_material.copy())
    source_after,_=apply_edits(source_before,source_edits);engine_after=actual.mesh
    for mesh,old in ((source_after,source_before),(engine_after,before)):
        _array(mesh.positions,old.positions,'no new/moved E7 points')
        for n in ('uvs','normals'):_array(getattr(mesh,n)[:len(getattr(old,n))],getattr(old,n),'unchanged current '+n+' prefix')
    for n in ('face_v','face_vt','face_vn','face_material','uvs'):_array(getattr(source_after,n),getattr(engine_after,n),'paired current '+n)
    _array(source_after.positions@frame.rotation.T*frame.inches_per_unit,engine_after.positions,'exact forward current positions')
    _array(source_after.normals@frame.rotation.T,engine_after.normals,'exact forward current normals')
    origins=[(i,None,None) for i in range(before.n_faces) if i not in touched]
    rank={id(e):i for i,e in enumerate(actual.edits)}
    for e in actual.kept:origins.extend((e.faces[0],rank[id(e)],child) for child in range(len(e.new_faces)))
    mapped=[];polygons=[]
    for output,(parent,edit_index,child) in enumerate(origins):
        polygons.append(source.polygons[source.triangle_polygon[parent]])
        row=dict(rows[parent],output_face=output,e7_input_face=parent,vertex_ids=source_after.face_v[output].tolist(),source_uv=source_after.face_vt[output].tolist(),source_normal=source_after.face_vn[output].tolist(),engine_uv=engine_after.face_vt[output].tolist(),engine_normal=engine_after.face_vn[output].tolist())
        if child is not None:row.update(kind='cut_child',inherited_kind=rows[parent]['kind'],e7_site=parent,edit_index=edit_index,child=child)
        mapped.append(row)
    for original in mandatory:
        kept=[x for x in mapped if x['original_source_triangle']==original]
        need(len(kept)==1 and kept[0]['kind']=='unchanged','Mandatory original must remain whole')
    for parent in locked:
        kept=[x for x in mapped if x['e7_input_face']==parent]
        need(len(kept)==1 and all(kept[0][k]==rows[parent][k] for k in UNCHANGED if k in rows[parent]),'Priority face corner/UV/material/group changed')
    def floor(mesh,physical):
        polys=tuple(SourcePolygon(p.line,tuple(zip(mesh.face_v[i],mesh.face_vt[i],mesh.face_vn[i])),int(mesh.face_material[i]),p.group,p.object_name) for i,p in enumerate(polygons))
        return FloorInput(mesh,polys,np.arange(mesh.n_faces),np.tile([0,1,2],(mesh.n_faces,1)),physical)
    paired_source,paired_engine=floor(source_after,None),floor(engine_after,frame)
    paths=dict(binding['paths'],checkpoint=str(Path(checkpoint)/'checkpoint-receipt.json'),edit_log=str(Path(checkpoint)/'edit-log.jsonl'))
    hashes=dict(binding['sha256'],checkpoint=sha,edit_log=hashlib.sha256(Path(paths['edit_log']).read_bytes()).hexdigest())
    pair_binding=dict(binding,paths=paths,sha256=hashes);checked,records=_checked(before,actual,looks,pair_binding)
    checked['original_source_triangles']=original_count
    lineage=dict(schema_version=1,mode='current_partial_ancestry_existing_vertex_E7',checkpoint_sha256=sha,input_triangles=before.n_faces,faces=mapped)
    pair=CutPair(paired_source,paired_engine,lineage,checked,records,pair_binding,pair_seal(paired_source,paired_engine,lineage,checked))
    return save_cut_pair(pair,out)
