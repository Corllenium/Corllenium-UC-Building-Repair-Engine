"""Freshly check the measured226 current6F E7 partitions; checkpoint before paid serialization."""
import argparse,hashlib,json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
from engine.io.obj_reader import read_obj
from engine.io.minecraft_floor import parse_floor
from engine.io.mtl import parse_mtl
from engine.validate.checks import load_looks
from engine.repair.engines.e7_thread import E7Thread
from engine.repair.types import UnitState,RepairContext
from engine.fixes.pipeline import FixProfile
from tools.main_infra_e3 import _source_digest,load_qualified_floor
from tools.main_infra_e7_checkpoint import save_e7_checkpoint,typed_plan_digest
from tools.main_infra_e7_serialization import _tables
from tools.main_infra_e7_current_pair import write_current_pair
from tools.main_infra_e7_subset import VerifiedSubset,_look_ids,_seal,run_checked_subset
from tools.main_infra_6f_26127_e7_plan import ROOT,JOB,CONTEXT,PRIORITY,SOURCE,ENGINE,need,read_bound,bind_metadata,restore_context,qualify_current

def receipt_binding(value):
    return json.loads(json.dumps(value,sort_keys=True,allow_nan=False))

def bind_subset(source,before,rows,edits,report,looks,mandatory,frame):
    fresh=qualify_current(source,before,[r['original_source_triangle'] for r in rows],edits,mandatory,frame)
    need(all(fresh[k]==report[k] for k in fresh),'Fresh measured universal SOURCE admission differs')
    need(report['source_digest']==_source_digest(source).hex() and report['engine_digest']==_source_digest(before).hex(),'Measured SOURCE/typed context differs')
    selected=tuple(edits[i] for i in fresh['admitted_indices']);need(selected,'No admitted current edits; no repair permitted')
    proof=receipt_binding(dict(before_digest=_source_digest(before).hex(),typed_plan_digest=typed_plan_digest(selected),
        look_ids={str(k):v for k,v in _look_ids(before,looks).items()},selected_indices=fresh['admitted_indices'],
        source_digest=_source_digest(source).hex(),cbr_winner_vector='UNENUMERATED',old_verdict_is_not_reused=True,acceptance=False))
    return VerifiedSubset(selected,proof,_seal(proof,selected))

def load_current_looks(plan,before,materials):
    read_bound(materials);original=Path(plan['refs']['original_engine']['path']).parent;current=Path(plan['refs']['source']['path']).parent
    looks=load_looks(materials['path'],[(parse_mtl(original/before.mtllib),original),(parse_mtl(current/before.mtllib),current)])
    need(not looks.unknown(before),'Unknown current6F look; no guessed Tint or borrowed catalogue')
    need(all(looks.key_of(n) in looks.flat or looks.key_of(n) in looks.texel for n in before.materials),'All actual6F material/texture looks required')
    return looks

def execute_checked(source,frame,before,looks,rows,edits,report,out,*,binding,mandatory,original_count):
    binding=receipt_binding(binding);subset=bind_subset(source.mesh,before,rows,edits,report,looks,mandatory,frame)
    out=Path(out);need(not out.exists(),'Exclusive current6F output required');out.mkdir(parents=True)
    def worker(state,**extra):
        value=dict(job_id=JOB,run_id=binding['run_id'],floor='6F',engine='E7',actual_pid=os.getpid(),updated_utc=datetime.now(timezone.utc).isoformat(),state=state,selected_sites=len(subset.edits),acceptance=False,**extra)
        temp=out/'worker.tmp';temp.write_text(json.dumps(value,indent=2),encoding='utf-8');temp.replace(out/'worker.json')
    worker('checking_sites');actual=run_checked_subset(before,looks,subset)
    need(typed_plan_digest(actual.edits)==subset.proof['typed_plan_digest'],'Actual checked stage changed admitted plan')
    checkpoint=save_e7_checkpoint(before,actual,looks,out/'checked-outcome',binding=binding)
    worker('checkpoint_saved',checkpoint_sha256=checkpoint['receipt_sha256'],kept=len(actual.kept),rolled_back=len(actual.rolled_back))
    wanted=set(mandatory);locked=[i for i,r in enumerate(rows) if r['original_source_triangle'] in wanted]
    pair=write_current_pair(source,frame,before,looks,rows,out/'checked-outcome',checkpoint['receipt_sha256'],binding,out/'candidate',mandatory,locked,[],original_count)
    saved=json.loads((out/'candidate/cut-lineage.json').read_bytes())['faces'];rolled=sorted({rows[e.faces[0]]['original_source_triangle'] for e in actual.rolled_back});required=sorted(set(mandatory)|set(rolled))
    for original in required:
        remaining=[r for r in saved if r['original_source_triangle']==original]
        need(len(remaining)==1 and remaining[0]['kind']=='unchanged','All protected/fresh rollback originals must remain whole')
    result=dict(checkpoint_sha256=checkpoint['receipt_sha256'],pair=pair,planned=len(actual.edits),kept=len(actual.kept),rolled_back=len(actual.rolled_back),output_triangles=actual.mesh.n_faces,fresh_rollback_originals=rolled,next_mandatory_originals=required,unchanged_default_checks=actual.checks,independent_validation='PENDING',repair_complete=False,acceptance=False)
    worker('candidate_saved',checkpoint_sha256=checkpoint['receipt_sha256'],kept=len(actual.kept),rolled_back=len(actual.rolled_back),output_triangles=actual.mesh.n_faces)
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',type=Path,required=True);parser.add_argument('--input-sha256',required=True);a=parser.parse_args()
    spec=json.loads(read_bound(dict(path=str(a.input),sha256=a.input_sha256)));need(spec['job_id']==JOB and spec['mode']=='6F26127_checked226_existing_vertex_E7' and spec['acceptance'] is False,'Owned checked226 scope required')
    head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();need(not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True).strip(),'Committed clean execution required')
    from tools.jobs import get
    claim=get(ROOT.parents[2],JOB);need(claim['status']=='claimed' and claim['holder']=='Codex-6F-26127-E7-Plan','Current checked job claim differs')
    plan=json.loads(read_bound(spec['plan_input']));refs=plan['refs'];raw={k:read_bound(v) for k,v in refs.items()}
    need(refs['context']['sha256']==CONTEXT and refs['priority']['sha256']==PRIORITY and refs['source']['sha256']==SOURCE and refs['engine']['sha256']==ENGINE,'Authentic current6F context roles required')
    docs={k:json.loads(raw[k]) for k in ('context','priority','current_E3_checkpoint','current_E5_checkpoint','drop_lineage','cumulative_original_ancestry','marker_checkpoint')};ctx=bind_metadata(docs)
    original,physical,baseline,receipt=load_qualified_floor(raw=refs['original_owner_raw']['path'],reference=refs['native_triangulation_reference']['path'],baseline=plan['qualified_baseline'],qualification=refs['qualification']['path'])
    need(list(baseline.physical_quanta)==docs['context']['raw_frame_expected_physical_quanta'],'Original RAW/Frame precision authority differs')
    before=restore_context(baseline,docs['current_E3_checkpoint'],docs['current_E5_checkpoint'],docs['drop_lineage']['kept_current']);need(before.n_faces==26127,'Actual current typed26127 required')
    _tables(read_obj(refs['engine']['path']),before);source=parse_floor(raw['source'].decode('utf-8'));_tables(source.in_frame(physical.frame).mesh,before)
    report=json.loads(read_bound(spec['measured_plan']));need(spec['measured_plan']['sha256']=='d751eeb46ed799b8c2a1f890b6f78b73e4e96f41c7c52f91b9e31e32104b691f'
        and report['input_refs']==refs and report['planned']==1966 and len(report['admitted_indices'])==226 and len(ctx['mandatory'])==4240,'Exact measured226 current SOURCE cohort required')
    role=json.loads(raw['role_packet']);need(spec['materials']['sha256']==role['materials_looks']['sha256'],'Actual6F material catalogue role required');looks=load_current_looks(plan,before,spec['materials'])
    edits=E7Thread().plan(UnitState(before,None,{},None),RepairContext(FixProfile(),None,None));rows=[]
    for i,parent in enumerate(ctx['parents']):
        poly=source.polygons[source.triangle_polygon[i]];rows.append(dict(output_face=i,original_source_triangle=parent,kind='unchanged',vertex_ids=source.mesh.face_v[i].tolist(),source_uv=source.mesh.face_vt[i].tolist(),source_normal=source.mesh.face_vn[i].tolist(),engine_uv=before.face_vt[i].tolist(),engine_normal=before.face_vn[i].tolist(),material=source.mesh.materials[int(source.mesh.face_material[i])],group=poly.group,object_name=poly.object_name))
    allrefs=dict(refs,plan_input=spec['plan_input'],measured_plan=spec['measured_plan'],materials=spec['materials'])
    binding=receipt_binding(dict(run_id=spec['run_id'],floor='6F',builder_commit=head,before_digest=_source_digest(before).hex(),paths={k:v['path'] for k,v in allrefs.items()},sha256={k:v['sha256'] for k,v in allrefs.items()},source_sha256=SOURCE,engine_sha256=ENGINE,whole_originals=ctx['mandatory'],cbr_winner_vector='UNENUMERATED',historical_transfer_locks=[],owner_cbr_authority=refs['base_owner_authority'],physical_context=dict(coord_decimals=before.coord_decimals,sig_digits=before.sig_digits,units=before.units,quanta=before.physical_quanta),frame_matrix=physical.frame.matrix.tolist(),current_independent_validation_not_transferred=True))
    out=Path(spec['output']);need(out.resolve().is_relative_to(ROOT/'data') and not out.exists(),'Exclusive owned checked output required')
    result=execute_checked(source,physical.frame,before,looks,rows,edits,report,out,binding=binding,mandatory=ctx['mandatory'],original_count=34862)
    current=Path(refs['source']['path']).parent;assets=[]
    for key,pin in refs.items():
        if not key.startswith('current_asset_'):continue
        target=out/'candidate'/Path(pin['path']).relative_to(current);need(not target.exists(),'Asset exists');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(read_bound(pin));need(hashlib.sha256(target.read_bytes()).hexdigest()==pin['sha256'],'Saved asset differs');assets.append(dict(path=str(target.relative_to(out/'candidate')),sha256=pin['sha256']))
    need(len(assets)==12,'All12 actual6F assets required')
    for pin in allrefs.values():read_bound(pin)
    result.update(binding=binding,assets=assets,state='candidate_saved')
    with (out/'run-receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,sort_keys=True,allow_nan=False)
    print(json.dumps(dict(output=str(out/'candidate'),output_triangles=result['output_triangles'],kept=result['kept'],rolled_back=result['rolled_back'],checkpoint_sha256=result['checkpoint_sha256'],independent_validation='PENDING',acceptance=False)))
    return 0

if __name__=='__main__':raise SystemExit(main())
