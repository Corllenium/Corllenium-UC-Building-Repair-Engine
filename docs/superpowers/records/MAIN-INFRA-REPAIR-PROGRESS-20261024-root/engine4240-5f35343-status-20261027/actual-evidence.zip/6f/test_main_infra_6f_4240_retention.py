import copy
import importlib.util
import json

import pytest


def adapter():
    name = 'tools.main_infra_6f_4240_retention'
    assert importlib.util.find_spec(name) is not None, 'Owned whole-site corrective adapter is required'
    return __import__(name, fromlist=['make_plan'])


def fixture():
    n = 34862
    donor = [i for i in range(n) if i not in {1, 2, 3}]
    rows = [dict(site=40, faces=[donor.index(4), donor.index(5)], reason='same look'),
            dict(site=41, faces=[donor.index(6)], reason='same look')]
    base = dict(floor='6F', acceptance=False, strict_guard_extension=False,
        e3_selected_rows=[dict(site=10, faces=[1, 2], reason='hidden'), dict(site=11, faces=[3], reason='hidden')],
        e5_selected_rows=rows,
        e5_remapped_rows=[dict(site=40, original_faces=[4, 5]), dict(site=41, original_faces=[6])],
        requested_e3_original_survivors=donor,
        requested_final_original_survivors=[i for i in donor if i not in {4, 5, 6}],
        protected_original_faces=[7, 8], historical_rollback_closure=dict(mandatory_originals=[7]),
        restored_sites=dict(E3=[20], E5=[30]), original_rollback_sites=dict(E3=[21], E5=[31]),
        physical_context=dict(raw='original RAW', physical_quanta=0.000000000123, uv='untouched'))
    closure = dict(kind='independent_metadata_whole_site_6F25433_fullsigned_retention_closure',
        standard_failed_originals=[1], owner_floor_failed_originals=[4], conservative_within_floor_originals=[2],
        witnessed_originals=[1, 2, 4],
        direct_whole_sites=[dict(stage='E3', site=10, original_faces=[1, 2], witnessed_originals=[1, 2]),
                            dict(stage='E5', site=40, original_faces=[4, 5], witnessed_originals=[4])],
        direct_whole_originals=[1, 2, 4, 5], old_protected_originals=[7, 8], historical_rollback_originals=[7],
        all_historical_retained=True, protected_original_faces=[1, 2, 4, 5, 7, 8], protected_original_count=6,
        new_originals=[1, 2, 4, 5], restore_sites=dict(E3=[10, 20], E5=[30, 31, 40]),
        additional_restore_sites_from_current=dict(E3=[10], E5=[40]), markers_intersection=[],
        all_witnesses_exactly_one_current_site=True, candidate_mutated=False, execution_performed=False,
        prediction_if_only_restored_originals=n-26, prediction_is_not_saved_output=True,
        strict_guard_passed=True, native_passed=True, fullsigned_preservation_passed=False, acceptance=False)
    return base, closure, donor


def test_complete_sites_historical_originals_and_attribute_context_survive():
    m = adapter(); base, closure, donor = fixture()
    plan = m.make_plan(base, closure, donor)
    assert plan['protected_original_faces'] == [1, 2, 4, 5, 7, 8]
    assert plan['restored_sites'] == closure['restore_sites']
    assert [r['site'] for r in plan['e3_selected_rows']] == [11]
    assert [r['site'] for r in plan['e5_selected_rows']] == [41]
    assert plan['e3_selected_rows'][0] is base['e3_selected_rows'][1]
    assert plan['e5_selected_rows'][0] is base['e5_selected_rows'][1]
    assert plan['physical_context'] is base['physical_context']
    assert plan['e5_remapped_rows'][0]['original_faces'] == [6]
    assert plan['e5_remapped_rows'][0]['faces'] == [5]
    assert set(plan['protected_original_faces']) <= set(plan['requested_final_original_survivors'])
    assert plan['conditional_after_marker_triangles'] == 34836
    assert plan['counts_are_saved_outputs'] is False and plan['acceptance'] is False


@pytest.mark.parametrize('change', ['partial_site', 'wrong_site', 'extra_site', 'lost_old', 'lost_historical',
    'lost_witness', 'forgot_conservative_floor', 'marker_protected', 'partial_union', 'changed_prediction',
    'preservation_pass', 'changed_originals', 'lost_E5_rollback', 'duplicate_seed'])
def test_changed_or_incomplete_whole_site_authority_is_rejected(change):
    m = adapter(); base, c, donor = fixture()
    if change == 'partial_site': c['direct_whole_sites'][0]['original_faces'].pop()
    elif change == 'wrong_site': c['direct_whole_sites'][0]['site'] = 11
    elif change == 'extra_site': c['direct_whole_sites'].append(copy.deepcopy(c['direct_whole_sites'][0]))
    elif change == 'lost_old': c['protected_original_faces'].remove(8)
    elif change == 'lost_historical': c['historical_rollback_originals'] = []
    elif change == 'lost_witness': c['witnessed_originals'].remove(1)
    elif change == 'forgot_conservative_floor': c['conservative_within_floor_originals'] = []
    elif change == 'marker_protected': c['protected_original_faces'].append(34838)
    elif change == 'partial_union': c['restore_sites']['E3'].remove(20)
    elif change == 'changed_prediction': c['prediction_if_only_restored_originals'] -= 1
    elif change == 'preservation_pass': c['fullsigned_preservation_passed'] = True
    elif change == 'changed_originals': c['new_originals'].pop()
    elif change == 'lost_E5_rollback': c['restore_sites']['E5'].remove(31)
    else: c['witnessed_originals'].append(1)
    with pytest.raises(ValueError): m.make_plan(base, c, donor)


def test_current_saved_ancestry_controls_marker_indices_even_with_extra_rollbacks():
    m = adapter(); ids = list(range(34862)); protected = list(range(4240))
    lineage = dict(mode='original_source_survivors', input_triangles=34862, output_triangles=len(ids), source_faces=ids)
    first = m.derive_marker_selection(lineage, protected)
    assert first['selected_current'] == list(range(34838, 34862))
    lineage['source_faces'] = ids[1:]; lineage['output_triangles'] -= 1; protected = list(range(1, 4241))
    second = m.derive_marker_selection(lineage, protected)
    assert second['selected_current'] == list(range(34837, 34861))
    assert second['expected_output_triangles'] == 34837
    assert second['selection_approved'] is False


@pytest.mark.parametrize('change', ['missing_marker', 'lost_protected', 'wrong_mode', 'bad_count', 'wrong_protection'])
def test_marker_selection_rejects_wrong_actual_ancestry(change):
    m = adapter(); ids = list(range(34862)); protected = list(range(4240))
    lineage = dict(mode='original_source_survivors', input_triangles=34862, output_triangles=len(ids), source_faces=ids)
    if change == 'missing_marker': ids.pop(); lineage['output_triangles'] -= 1
    elif change == 'lost_protected': ids.remove(0); lineage['output_triangles'] -= 1
    elif change == 'wrong_mode': lineage['mode'] = 'forecast'
    elif change == 'bad_count': lineage['output_triangles'] -= 1
    else: protected.pop()
    with pytest.raises(ValueError): m.derive_marker_selection(lineage, protected)


def test_runtime_rejects_foreign_job_branch_output_and_tolerance_policy():
    m = adapter()
    spec = dict(schema_version=1, job_id=m.JOB, branch=m.BRANCH, run_id=m.RUN, floor='6F',
        execution_root=str(m.ROOT), output_root=str(m.OUT), allowed_changes=['coincident_backface_removed'],
        strict_guard_extension=False, identity_checkpoint_writer=dict(module='tools.main_infra_6f_4240_retention',
            function='save_identity', protected_originals=4240, donor_rows=608, changed_fields=[]))
    m.validate_identity(spec)
    for key, value in [('job_id', 'old'), ('branch', 'wrong'), ('output_root', str(m.ROOT/'wrong')),
                       ('allowed_changes', []), ('strict_guard_extension', True), ('identity_checkpoint_writer', {})]:
        with pytest.raises(ValueError): m.validate_identity(dict(spec, **{key: value}))


@pytest.mark.parametrize('change', ['report', 'producer', 'checkpoint', 'identity', 'source'])
def test_role_hash_drift_is_rejected_before_metadata_or_geometry_loading(tmp_path, change):
    m = adapter()
    good = tmp_path/'good.json'; good.write_text('{}')
    changed = tmp_path/'changed.json'; changed.write_text('{"drift":true}')
    pin = dict(path=str(good), sha256=m.sha(good))
    roles = {k: dict(pin) for k in ('report', 'producer', 'checkpoint', 'identity', 'source')}
    roles[change]['path'] = str(changed)
    with pytest.raises(ValueError): m.verify_roles(roles)


def test_worker_carries_current_process_and_corrected_protection(tmp_path):
    import os
    m=adapter();m.write_worker(tmp_path,'checking_sites','E3',1272)
    row=json.loads((tmp_path/'worker.json').read_bytes())
    assert row['actual_pid']==os.getpid() and type(row['actual_creation_filetime'])is int
    assert (row['job_id'],row['owner'],row['run_id'])==(m.JOB,m.OWNER,m.RUN)
    assert row['protected_originals']==4240 and row['acceptance'] is False


@pytest.mark.parametrize('change', ['count', 'keys', 'fields', 'output', 'checkpoint'])
def test_identity_writer_rejects_changed_context_before_paid_serialization(monkeypatch,change):
    m=adapter()
    from tools import main_infra_5f_identity_stage as paid
    monkeypatch.setattr(paid,'save_identity_stage',lambda *args: pytest.fail('Invalid identity reached serialization'))
    args=[object(),object(),object(),object(),[],m.OUT/'execution-6F/checkpoint-E5.json',m.OUT/'e5/6F']
    transition=dict(donor_rows_rebound=608,donor_keys_exact=True,changed_fields=[],kind='source_forward_E5_K1_identity_context')
    if change=='count':transition['donor_rows_rebound']=607
    elif change=='keys':transition['donor_keys_exact']=False
    elif change=='fields':transition['changed_fields']=['physical_quanta']
    elif change=='output':args[-1]=m.ROOT/'wrong'
    else:args[-2]=m.ROOT/'wrong.json'
    with pytest.raises(ValueError):m.save_identity(*args,transition=transition)


def test_identity_writer_delegates_unchanged_objects_and_all_608_keys(monkeypatch):
    m=adapter()
    from tools import main_infra_5f_identity_stage as paid
    seen=[];sentinel=object()
    monkeypatch.setattr(paid,'save_identity_stage',lambda *args: seen.append(args) or sentinel)
    args=(object(),object(),object(),object(),[],m.OUT/'execution-6F/checkpoint-E5.json',m.OUT/'e5/6F')
    transition=dict(donor_rows_rebound=608,donor_keys_exact=True,changed_fields=[],kind='source_forward_E5_K1_identity_context')
    assert m.save_identity(*args,transition=transition)is sentinel
    assert all(a is b for a,b in zip(seen[0][:-1],args)) and seen[0][-1]is transition


@pytest.mark.parametrize('change', ['hash','namespace'])
def test_execute_rejects_foreign_preparation_before_any_owner_model_loading(tmp_path,monkeypatch,change):
    m=adapter()
    from tools import main_infra_7f_restore as paid
    monkeypatch.setattr(paid,'load_context',lambda *args: pytest.fail('Invalid preparation reached owner geometry'))
    path=tmp_path/'foreign.json';path.write_text('{}')
    with pytest.raises(ValueError):m.execute(path,'0'*64 if change=='hash' else m.sha(path))
