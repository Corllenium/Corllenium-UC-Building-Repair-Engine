"""Owned corrective 6F policy; numerical replay and writers come from f004/d776."""
import argparse
import ctypes
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT.parents[2]
JOB='MAIN-INFRA-6F-4240-RETENTION-20261026'
OWNER='Codex-6F-4240-Retention'
BRANCH='codex/main-infra-6f-4240-retention-20261026'
RUN='main-infra-6f-4240-retention-20261026-r1'
OUT=ROOT/'data/main-infra-6f-4240-retention/run-20261026-r1'
MARKERS=list(range(34838,34862))
CLOSURE='26c452474cd90c072681482bd91d5a2873108dbe13806355888efe8a76c7ab8e'
PRODUCER='cd8231055df4f46752ce756c77d2dbfedefd98a539d6bb1f481236a73548906b'
PREVIOUS='2594117a281320876476f14f60400edd1b81d103af0f56492f012016710fb41c'
PREVIOUS_CLOSURE='372f9d41436a698348b2c1281da9d8c4256b476548448032becd72ebe4488717'
REPORT='f193b86f787d6e03025274359dcbee119217cc9686aa34ee67ad873807a7be8b'


def need(test,message):
    if not test:raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def read(path):return json.loads(Path(path).read_bytes())


def write(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2);stream.write('\n')


def make_plan(previous_plan,closure,donor_survivors):
    from tools.main_infra_7f_restore_plan import remap_e5_rows
    base=previous_plan;c=closure
    need(base['floor']=='6F' and base['acceptance'] is False and base['strict_guard_extension'] is False
         and c['kind']=='independent_metadata_whole_site_6F25433_fullsigned_retention_closure'
         and c['fullsigned_preservation_passed'] is False and c['acceptance'] is False
         and c['candidate_mutated'] is False and c['execution_performed'] is False
         and c['all_historical_retained'] is True and c['all_witnesses_exactly_one_current_site'] is True
         and c['prediction_is_not_saved_output'] is True,'Independent failed preservation closure required')
    for key in ('standard_failed_originals','owner_floor_failed_originals','conservative_within_floor_originals',
                'witnessed_originals','old_protected_originals','historical_rollback_originals','new_originals',
                'direct_whole_originals','protected_original_faces'):
        need(c[key]==sorted(set(c[key])) and all(type(i)is int and 0<=i<34862 for i in c[key]),'Unique original rows required: '+key)
    witnesses=set(c['standard_failed_originals'])|set(c['owner_floor_failed_originals'])|set(c['conservative_within_floor_originals'])
    need(sorted(witnesses)==c['witnessed_originals'],'Every measured floor and standard witness required')
    old=set(base['protected_original_faces']);protected=c['protected_original_faces']
    historical=set(base['historical_rollback_closure']['mandatory_originals'])
    need(c['old_protected_originals']==sorted(old) and c['historical_rollback_originals']==sorted(historical)
         and historical<=old and len(protected)==c['protected_original_count']
         and old<=set(protected) and not set(MARKERS)&set(protected) and c['markers_intersection']==[],
         'Previous, historical and marker protection differ')
    fresh=c['additional_restore_sites_from_current']
    need(set(fresh)=={'E3','E5'} and all(v==sorted(set(v)) for v in fresh.values()),'Unique added site sets required')
    expected={(stage,site) for stage in ('E3','E5') for site in fresh[stage]};rows=c['direct_whole_sites']
    need(len(rows)==len(expected) and {(r['stage'],r['site']) for r in rows}==expected,'Exact complete fresh sites required')
    parents={('E3',r['site']):r['faces'] for r in base['e3_selected_rows']}
    parents.update({('E5',r['site']):r['original_faces'] for r in base['e5_remapped_rows']})
    added=set();attributed=set()
    for row in rows:
        key=(row['stage'],row['site']);need(key in parents,'Fresh site was not selected by the previous policy')
        ids=parents[key]
        need(row['original_faces']==ids and len(ids)==len(set(ids)) and not added&set(ids),'Partial, overlapping or changed fresh whole site')
        seen=set(ids)&witnesses
        need(seen and row['witnessed_originals']==sorted(seen) and not attributed&seen,'Changed whole-site witness attribution')
        attributed.update(seen)
        added.update(ids)
    need(attributed==witnesses and sorted(added)==c['direct_whole_originals']
         and sorted(added-old)==c['new_originals'] and sorted(old|added)==protected,'Lost complete sites or witnessed originals')
    e3=[r for r in base['e3_selected_rows'] if r['site']not in fresh['E3']]
    e5=[r for r in base['e5_selected_rows'] if r['site']not in fresh['E5']]
    removed={i for row in e3 for i in row['faces']};new3=[i for i in range(34862) if i not in removed]
    remap=remap_e5_rows(e5,donor_survivors,new3)
    removed5={i for row in remap for i in row['original_faces']};final=[i for i in new3 if i not in removed5]
    need(set(protected)<=set(final) and set(MARKERS)<=set(final),'Selected E5 site intersects protected originals or markers')
    restored={k:sorted(set(base['restored_sites'][k])|set(fresh[k])|
        (set(base['original_rollback_sites'][k]) if k=='E5' else set())) for k in ('E3','E5')}
    need(restored==c['restore_sites'] and len(final)-len(MARKERS)==c['prediction_if_only_restored_originals'],
         'Complete restoration union or conditional count differs')
    return dict(base,protected_original_faces=protected,restored_sites=restored,e3_selected_rows=e3,e5_selected_rows=e5,
        e5_remapped_rows=remap,requested_e3_original_survivors=new3,requested_final_original_survivors=final,
        conditional_after_marker_triangles=len(final)-len(MARKERS),counts_are_saved_outputs=False,acceptance=False)


def derive_marker_selection(lineage,protected):
    ids=lineage['source_faces']
    need(lineage['mode']=='original_source_survivors' and lineage['input_triangles']==34862
         and lineage['output_triangles']==len(ids) and ids==sorted(set(ids))
         and all(type(i)is int and 0<=i<34862 for i in ids),'Actual cumulative source ancestry required')
    need(len(protected)==len(set(protected))==4240 and set(protected)<=set(ids)
         and not set(protected)&set(MARKERS) and set(MARKERS)<=set(ids),'Protected originals or exact markers missing')
    current=[i for i,original in enumerate(ids) if original in set(MARKERS)]
    return dict(kind='fresh6F_actual_ancestry_marker_selection',floor='6F',approved_original=MARKERS,
        selected_current=current,current_input_triangles=len(ids),expected_output_triangles=len(ids)-24,
        protected_originals=4240,protected_marker_intersection=[],selection_approved=False,acceptance=False)


def validate_identity(s):
    need(s['schema_version']==1 and s['job_id']==JOB and s['branch']==BRANCH and s['run_id']==RUN and s['floor']=='6F'
         and Path(s['execution_root']).resolve()==ROOT and Path(s['output_root']).resolve()==OUT
         and s['allowed_changes']==['coincident_backface_removed'] and s['strict_guard_extension'] is False
         and s['identity_checkpoint_writer']==dict(module='tools.main_infra_6f_4240_retention',function='save_identity',
             protected_originals=4240,donor_rows=608,changed_fields=[]),'Exact owned corrective identity required')


def claim():
    from tools.main_infra_7f_checked_restore import assert_current_claim
    return assert_current_claim(MAIN/'data/jobs/queue.json',job_id=JOB,holder=OWNER,branch=BRANCH)


def read_spec(path,expected):
    need(sha(path)==expected,'External corrective spec changed');s=read(path);validate_identity(s)
    paths={Path(p['path']).resolve() for p in s['pins']}
    need(len(paths)==len(s['pins']),'Duplicate explicit runtime pin')
    for p in s['pins']:need(sha(p['path'])==p['sha256'],'Runtime/source pin changed: '+p['path'])
    need(s['producer']['sha256']==PRODUCER and s['closure']['sha256']==CLOSURE and s['previous']['sha256']==PREVIOUS,
         'Exact producer, previous policy and independent closure required')
    verify_roles({k:s[k] for k in ('producer','closure','previous')})
    producer=read(s['producer']['path'])
    previous=read(s['previous']['path'])
    need(previous['producer']==s['producer'] and previous['closure']['sha256']==PREVIOUS_CLOSURE,
         'Previous measured policy authority differs')
    verify_roles({'previous_closure':previous['closure']})
    for p in producer['pins']:need(sha(p['path'])==p['sha256'],'Original producer input changed')
    for key in ('raw','reference','baseline','materials'):
        need(Path(s[key]).resolve()==Path(producer[key]).resolve(),'Original physical/source role differs')
    from tools.main_infra_6f_restore_plan import read_bound_inputs,plan_records,consumed_paths
    from tools.main_infra_6f_e5_identity_context import verify_measurement
    data=read_bound_inputs(producer['metadata'],producer['metadata_sha256'])
    evidence=producer['measured_identity_evidence']
    need(sha(evidence['path'])==evidence['sha256']=='b1df99c0f3a6b111e79d59171bff0e37315d8743be63bb80e86622a4750529fa','Original identity measurement differs')
    verify_measurement(read(evidence['path']),data['_pins'])
    need(sha(evidence['historical_context_runtime'])==evidence['historical_context_runtime_sha256']=='305c4a735d0d30105e48cb6865bec2d58dca881ddf90736c24017a4b5bea9964','Original historical runtime differs')
    closure=read(s['closure']['path'])
    verify_roles(closure['inputs'])
    need(closure['inputs']['report']['sha256']==REPORT and closure['inputs']['runtime']==s['previous']
         and closure['inputs']['previous_protection']==previous['closure'],'Actual full signed authority differs')
    from tools.main_infra_6f_3546_retention import make_plan as previous_plan
    old=previous_plan(plan_records(data),read(previous['closure']['path']),data['e3_survivors'])
    plan=make_plan(old,closure,data['e3_survivors'])
    need((len(old['protected_original_faces']),len(plan['protected_original_faces']),len(closure['witnessed_originals']),
         len(closure['new_originals']),len(plan['restored_sites']['E3']),len(plan['restored_sites']['E5']))==
         (3546,4240,73,694,47,154),'Exact measured corrective cohort differs')
    closure_refs=list(closure['inputs'].values())+[previous['closure']]
    required={Path(p).resolve() for p in consumed_paths(data)}
    required.update(Path(p['path']).resolve() for p in producer['pins'])
    required.update(Path(p['path']).resolve() for p in previous['pins'])
    required.update(Path(s[k]['path']).resolve() for k in ('producer','closure','previous'))
    required.update(Path(p['path']).resolve() for p in closure_refs)
    required.update(Path(evidence[k]).resolve() for k in ('path','historical_context_runtime'))
    tracked=subprocess.check_output(['git','ls-files','engine','tools'],cwd=ROOT,text=True)
    required.update((ROOT/p).resolve() for p in tracked.splitlines() if p.endswith('.py') or p.endswith('targets.json'))
    required.add(Path(__file__).resolve())
    need(required<=paths,'Consumed input/component omitted from explicit pins')
    need(subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()==BRANCH,'Owned execution branch differs')
    claim()
    return s,data,plan


def verify_roles(roles):
    for name,pin in roles.items():
        need(sha(pin['path'])==pin['sha256'],'Role-bound input changed: '+name)


def write_worker(directory,state,stage,selected,*,kept=None,rolled=None,output_triangles=None,checkpoint=None):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetCurrentProcess.restype=ctypes.c_void_p
    kernel.GetProcessTimes.argtypes=[ctypes.c_void_p]+[ctypes.POINTER(ctypes.c_ulonglong)]*4
    values=[ctypes.c_ulonglong() for _ in range(4)]
    if not kernel.GetProcessTimes(kernel.GetCurrentProcess(),*(ctypes.byref(x) for x in values)):raise ctypes.WinError(ctypes.get_last_error())
    seconds,ticks=divmod(values[0].value,10000000)
    birth=datetime(1601,1,1,tzinfo=timezone.utc)+timedelta(seconds=seconds)
    row=dict(schema_version=1,job_id=JOB,owner=OWNER,floor='6F',run_id=RUN,actual_pid=os.getpid(),actual_creation_filetime=values[0].value,
        actual_creation_utc=birth.strftime('%Y-%m-%dT%H:%M:%S')+f'.{ticks:07d}Z',updated_utc=datetime.now(timezone.utc).isoformat(),
        state=state,step=stage,activity=f'{stage} {state}; selected sites {selected}',selected_sites=selected,kept_sites=kept,
        rolled_back_sites=rolled,output_triangles=output_triangles,protected_originals=4240,
        checkpoint_sha256=sha(checkpoint) if checkpoint else None,acceptance=False)
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    tmp=directory/'worker.tmp';tmp.write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');os.replace(tmp,directory/'worker.json')


def save_identity(engine,source,before,outcome,ancestry,checkpoint,out,*,transition):
    need(Path(checkpoint).resolve()==OUT/'execution-6F/checkpoint-E5.json' and Path(out).resolve()==OUT/'e5/6F'
         and transition.get('donor_rows_rebound')==608 and transition.get('donor_keys_exact') is True
         and transition.get('changed_fields')==[] and transition.get('kind')=='source_forward_E5_K1_identity_context','Owned 6F identity checkpoint and all608 keys required')
    from tools.main_infra_5f_identity_stage import save_identity_stage
    return save_identity_stage(engine,source,before,outcome,ancestry,checkpoint,out,transition)


def prepare(path,expected):
    from tools import main_infra_7f_restore as paid
    s,data,plan=read_spec(path,expected);need(not OUT.exists(),'Exclusive preparation output required')
    *_,proof=paid.load_context(s,data,plan)
    read_spec(path,expected)
    result=dict(schema_version=1,run_id=RUN,floor='6F',spec=str(Path(path).resolve()),spec_sha256=expected,proof=proof,
        new_candidate=None,acceptance=False,note='Original source/K1 preparation only; no site checks or preservation verdict.')
    OUT.mkdir(parents=True);write(OUT/'preparation-6F.json',result)
    print(json.dumps(dict(preparation=str(OUT/'preparation-6F.json'),sha256=sha(OUT/'preparation-6F.json'),e3_selected=proof['e3_selected'],
        e5_selected=proof['e5_selected'],protected_originals=len(proof['protected_original_faces']),acceptance=False)),flush=True)
    return result


def audit(s,data,plan,receipt,stage,outcome,files,e3_binding,prepared_sha,transition=None):
    from tools import main_infra_7f_restore as paid
    result=paid._stage_audit(s,data,receipt,stage,outcome,files,e3_binding,prepared_sha,input_context_transition=transition)
    path=files['source'].parent/'stage-audit.json';saved=read(path)
    saved.update(restored_whole_sites=plan['restored_sites'],protected_original_faces=plan['protected_original_faces'],builder_job_id=JOB,
        builder_run_id=RUN,corrective_closure_sha256=CLOSURE,independent_validation='PENDING',accepted=False)
    path.write_text(json.dumps(saved,indent=2)+'\n',encoding='utf-8');result['stage_audit_sha256']=sha(path)
    return result


def marker_selection(plan):
    out=OUT/'e5/6F';lineage=out/'baseline-source-faces.json'
    selected=derive_marker_selection(read(lineage),plan['protected_original_faces'])
    selected.update(current_source=dict(path=str(out/'candidate.source.obj'),sha256=sha(out/'candidate.source.obj')),
        current_engine=dict(path=str(out/'candidate.engine.obj'),sha256=sha(out/'candidate.engine.obj')),
        current_original_ancestry=dict(path=str(lineage),sha256=sha(lineage)),input_checkpoint=dict(path=str(OUT/'execution-6F/checkpoint-E5.json'),sha256=sha(OUT/'execution-6F/checkpoint-E5.json')),
        corrective_closure_sha256=CLOSURE,root_seal_required=True)
    target=OUT/'fresh-marker-selection.json';write(target,selected)
    return dict(path=str(target),sha256=sha(target),current_input_triangles=selected['current_input_triangles'],expected_output_triangles=selected['expected_output_triangles'])


def execute(prepared_path,expected):
    from tools import main_infra_7f_restore as paid
    need(sha(prepared_path)==expected,'External prepared input pin differs')
    need(Path(prepared_path).resolve()==OUT/'preparation-6F.json','Owned actual preparation required')
    prepared=read(prepared_path);need(prepared['run_id']==RUN,'Actual corrective run identity differs')
    s,data,plan=read_spec(prepared['spec'],prepared['spec_sha256'])
    execution=OUT/'execution-6F';e3_out=OUT/'e3/6F';e5_out=OUT/'e5/6F'
    need(not any(p.exists() for p in (execution,e3_out,e5_out)),'Exclusive corrective execution outputs required')
    source,engine,before,looks,receipt,proof=paid.load_context(s,data,plan)
    need(proof==prepared['proof'],'Actual typed/source preparation changed');execution.mkdir()
    from engine.io.obj_reader import read_obj
    from tools.main_infra_e3_binding import bind_saved_e3
    from tools.main_infra_e5_binding import bind_saved_e5
    from tools.main_infra_e3_replay import run_checked_replay
    from tools.main_infra_7f_checked_restore import run_e5_rows,save_checked_stage,bind_e5_rows
    from tools.main_infra_6f_e5_identity_context import apply_e5_context
    stage='E3';selected=len(plan['e3_selected_rows'])
    try:
        claim();write_worker(execution,'checking_sites',stage,selected)
        outcome3,ancestry,_=run_checked_replay(before,looks,Path(data['_pins']['e3_audit']['path']).parent,
            expected_audit_sha256=data['_pins']['e3_audit']['sha256'],restore_sites=tuple(plan['restored_sites']['E3']))
        need(set(plan['requested_e3_original_survivors'])<=set(ancestry.tolist()),'E3 removed unselected originals')
        need(set(plan['protected_original_faces'])<=set(ancestry.tolist()),'E3 removed a protected original')
        files3=save_checked_stage(engine,source,outcome3,'E3',execution/'checkpoint-E3.json',e3_out,before=before)
        binding3=audit(s,data,plan,receipt,'E3',outcome3,files3,None,expected)
        bind_saved_e3(candidate=e3_out,audit=read(e3_out/'stage-audit.json'),before_engine=before,after_engine=read_obj(files3['engine']),before_source=source.mesh,after_source=read_obj(files3['source']))
        write_worker(execution,'stage_saved','E3',selected,kept=len(outcome3.kept),rolled=len(outcome3.rolled_back),output_triangles=outcome3.mesh.n_faces,checkpoint=files3['checkpoint'])
        read_spec(prepared['spec'],prepared['spec_sha256']);claim();stage='E5';selected=len(plan['e5_selected_rows'])
        e5_before,transition=apply_e5_context(outcome3.mesh,proof['e5_key_context'])
        bind_e5_rows(e5_before,looks,data['e5_log'][:-1],data['e3_map']['source_faces'],ancestry.tolist())
        transition.update(donor_rows_rebound=len(data['e5_log'])-1,donor_keys_exact=True)
        transition_path=execution/'E3-to-E5-key-context.json';write(transition_path,transition)
        write_worker(execution,'checking_sites',stage,selected)
        outcome5,local,remap=run_e5_rows(e5_before,looks,plan['e5_selected_rows'],data['e3_map']['source_faces'],ancestry.tolist())
        originals=[int(ancestry[i]) for i in local]
        need(set(plan['protected_original_faces'])<=set(originals),'E5 removed a protected original')
        files5=save_identity(engine,source,e5_before,outcome5,ancestry.tolist(),execution/'checkpoint-E5.json',e5_out,transition=transition)
        audit(s,data,plan,receipt,'E5',outcome5,files5,binding3,expected,dict(path=str(transition_path),sha256=sha(transition_path)))
        bind_saved_e5(candidate=e5_out,audit=read(e5_out/'stage-audit.json'),before_engine=before,after_engine=read_obj(files5['engine']),before_source=source.mesh,after_source=read_obj(files5['source']),require_guard=False)
        read_spec(prepared['spec'],prepared['spec_sha256']);write(execution/'remapped-E5.json',remap)
        markers=marker_selection(plan)
        write_worker(execution,'candidate_saved','E5',selected,kept=len(outcome5.kept),rolled=len(outcome5.rolled_back),output_triangles=outcome5.mesh.n_faces,checkpoint=files5['checkpoint'])
        result=dict(candidate=str(e5_out),output_triangles=outcome5.mesh.n_faces,protected_originals=4240,marker_selection=markers,marker_poststage='PENDING_ROOT_SEAL',acceptance=False)
        print(json.dumps(result),flush=True);return result
    except Exception:
        write_worker(execution,'failed',stage,selected);raise


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('phase',choices=('metadata','prepare','execute'))
    parser.add_argument('--spec');parser.add_argument('--spec-sha256');parser.add_argument('--prepared');parser.add_argument('--prepared-sha256');a=parser.parse_args()
    if a.phase=='execute':execute(a.prepared,a.prepared_sha256);return 0
    if a.phase=='prepare':prepare(a.spec,a.spec_sha256);return 0
    s,data,plan=read_spec(a.spec,a.spec_sha256)
    print(json.dumps(dict(floor='6F',protected_originals=4240,E3_selected=len(plan['e3_selected_rows']),E5_selected=len(plan['e5_selected_rows']),
        requested_E3=len(plan['requested_e3_original_survivors']),requested_final=len(plan['requested_final_original_survivors']),
        conditional_after_marker=plan['conditional_after_marker_triangles'],geometry_loaded=False,acceptance=False)))
    return 0


if __name__=='__main__':raise SystemExit(main())
