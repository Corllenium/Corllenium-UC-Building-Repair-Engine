$ErrorActionPreference='Stop'
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskOwnedRoot="$taskRoot"
$taskObserver="$taskOwnedRoot/data/r6h-live-status/observe.ps1"
$taskTerminal="$taskRoot/.claude/worktrees/r6h/data/r6h-preflight/monitor-6F4240-r1-execute-20261026T155826/result.json"
$taskHealth="$taskOwnedRoot/data/r6h-live-status/health.json"
$env:PYTHONPATH=$taskOwnedRoot
$taskMutex=[Threading.Mutex]::new($false,'Local\MAIN-INFRA-6F-4240-LIVE-STATUS')
if(-not $taskMutex.WaitOne(0)){throw 'Duplicate corrective6F status watcher refused'}
$taskPins=@(@{Path='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/data/r6h-live-status/binding.py';Sha='d63d7784534b81a1d2bc04e789b57766bc8b9e8226146cc943c140ec4ca0a4b3'},@{Path='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/data/r6h-live-status/observe.ps1';Sha='ca366fb470955ed07a92bf24004788b34a6f2b562a708ed009564a114b5610d7'})
$taskIteration=0
try {
 while(-not (Test-Path -LiteralPath $taskTerminal)) {
  foreach($taskPin in $taskPins){if((Get-FileHash -LiteralPath $taskPin.Path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskPin.Sha){throw 'Owned status source changed'}}
  & $taskObserver -Out "$taskOwnedRoot/data/r6h-live-status/observation.json"
  $taskBound=$false
  for($taskAttempt=0;$taskAttempt -lt 6;$taskAttempt++){
   $taskBinderOutput=@(& "$taskRoot/.venv/Scripts/python.exe" -B "$taskOwnedRoot/data/r6h-live-status/binding.py" 2>&1)
   $taskBindExit=$LASTEXITCODE
   $taskBinderOutput|ForEach-Object {Write-Output $_}
   if($taskBindExit -eq 0){$taskBound=$true;break}
   $taskBindText=$taskBinderOutput -join "`n"
   if(-not ($taskBindText.Contains('[WinError 5]') -and $taskBindText.Contains('os.replace') -and $taskBindText.Contains('current.json'))){throw 'Actual worker metadata binding failed for a non-lock reason'}
   Start-Sleep -Milliseconds (50*($taskAttempt+1))
  }
  if(-not $taskBound){throw 'Canonical Windows read lock persisted through six bounded fresh-document retries'}
  $taskIteration++
  [IO.File]::WriteAllText($taskHealth,(@{state='LIVE';utc=[DateTime]::UtcNow.ToString('o');iterations=$taskIteration;worker_pid=40844;watcher_pid=$PID}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
  if((Get-Process -Id $PID).PrivateMemorySize64 -ge 250MB){throw 'Status observer private memory at250MiB'}
  Start-Sleep -Seconds 15
 }
 [IO.File]::WriteAllText($taskHealth,(@{state='ENGINE_TERMINAL_OBSERVED';utc=[DateTime]::UtcNow.ToString('o');iterations=$taskIteration;worker_pid=40844;watcher_pid=$PID}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
} catch {
 if(Test-Path -LiteralPath $taskTerminal){
  [IO.File]::WriteAllText($taskHealth,(@{state='ENGINE_TERMINAL_OBSERVED';utc=[DateTime]::UtcNow.ToString('o');iterations=$taskIteration;worker_pid=40844;watcher_pid=$PID}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
 } else {
  [IO.File]::WriteAllText($taskHealth,(@{state='OBSERVER_STOPPED';utc=[DateTime]::UtcNow.ToString('o');iterations=$taskIteration;worker_pid=40844;watcher_pid=$PID;reason=$_.Exception.Message}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
  throw
 }
} finally {$taskMutex.ReleaseMutex();$taskMutex.Dispose()}
