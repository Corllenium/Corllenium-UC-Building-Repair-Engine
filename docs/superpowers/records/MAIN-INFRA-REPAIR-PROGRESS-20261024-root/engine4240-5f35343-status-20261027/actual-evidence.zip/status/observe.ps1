param([Parameter(Mandatory=$true)][string]$Out)
$ErrorActionPreference='Stop'
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskPhase="$taskRoot/.claude/worktrees/r6h/data/r6h-preflight/phase-execute.json"
$taskMonitor="$taskRoot/.claude/worktrees/r6h/data/r6h-preflight/monitor-6F4240-r1-execute-20261026T155826"
$taskObserver='D:/LLM_BACKUP/Codex session/main-infra-resource-monitor-v5-20261024/05-Corllenium-UC-Building-Repair-Engine/docs/superpowers/records/MAIN-INFRA-RESOURCE-MONITOR-V5-20261024/execute-resource-guard-v5.ps1'
if((Get-FileHash -LiteralPath $taskObserver -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'f158802651c955b6b322140ff9567496c527cd1bac0e63598171c45eeea60e12'){throw 'Paid native observer changed'}
if((Get-FileHash -LiteralPath $taskPhase -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'b0c70f4c95fb5f07f0e38e298182c7134769c8208456f9c836143c4be812a036'){throw '6F phase changed'}
. $taskObserver -FunctionsOnly
$taskIdentity=Get-Content -Raw -LiteralPath "$taskMonitor/actual-identity.json"|ConvertFrom-Json
if($taskIdentity.actual_pid -ne 40844 -or $taskIdentity.actual_creation_utc.ToUniversalTime().Ticks -ne ([DateTimeOffset]'2026-10-26T15:58:28.3753658Z').UtcTicks){throw 'Native6F identity changed'}
$taskProcess=[Diagnostics.Process]::GetProcessById(40844);$taskHandle=$taskProcess.Handle
$taskBirth=[UcE7ExecNative]::Times($taskHandle)[0]
if($taskBirth.Ticks -ne ([DateTimeOffset]'2026-10-26T15:58:28.3753658Z').UtcTicks){throw 'Reused6F PID'}
$taskImage='C:/Users/Future26/AppData/Local/Programs/Python/Python312/python.exe'
if([UcE7ExecNative]::Image($taskHandle).Replace('\','/') -ine $taskImage){throw '6F executable differs'}
$taskArgs=(Get-Content -Raw -LiteralPath $taskPhase|ConvertFrom-Json).args
if((Normalize-ExecCommand ([UcE7ExecNative]::Command($taskHandle))) -ne (Normalize-ExecCommand ($taskImage+' '+($taskArgs -join ' ')))){throw '6F actual command differs'}
$taskFrame=Get-Content -LiteralPath "$taskMonitor/resources.jsonl" -Tail 1|ConvertFrom-Json
if([DateTime]::UtcNow - $taskFrame.utc.ToUniversalTime() -gt [TimeSpan]::FromSeconds(15)){throw 'Native monitor sample stale'}
$taskParent=[UcE7ExecNative]::Parent($taskHandle)
if($taskParent -ne 49936 -or $taskIdentity.launcher_pid -ne 49936 -or $taskParent -notin @($taskFrame.owned|ForEach-Object pid)){throw '6F native parent outside exact V5 owned tree'}
$taskParentProcess=[Diagnostics.Process]::GetProcessById($taskParent)
$taskParentRow=@($taskFrame.owned|Where-Object pid -eq $taskParent)
if($taskParentRow.Count -ne 1 -or [UcE7ExecNative]::Times($taskParentProcess.Handle)[0].Ticks -ne $taskParentRow[0].creation_utc.ToUniversalTime().Ticks){throw '6F native parent lifetime differs'}
$taskProcess.Refresh();$taskWorker=Get-Content -Raw -LiteralPath "$taskRoot/.claude/worktrees/r6h/data/main-infra-6f-4240-retention/run-20261026-r1/execution-6F/worker.json"|ConvertFrom-Json
if($taskWorker.actual_pid -ne 40844 -or $taskWorker.actual_creation_filetime -ne $taskBirth.ToFileTimeUtc()){throw 'Worker/native lifetime differs'}
if($taskWorker.job_id -ne 'MAIN-INFRA-6F-4240-RETENTION-20261026' -or $taskWorker.run_id -ne 'main-infra-6f-4240-retention-20261026-r1' -or $taskWorker.protected_originals -ne 4240){throw 'Owned corrective worker scope differs'}
$taskResult=[ordered]@{pid=40844;start_utc=$taskBirth.ToString('o');observed_at=[DateTime]::UtcNow.ToString('o');alive=[UcE7ExecNative]::Alive($taskHandle);cpu_seconds=$taskProcess.TotalProcessorTime.TotalSeconds;parent=$taskParent;phase_sha256='b0c70f4c95fb5f07f0e38e298182c7134769c8208456f9c836143c4be812a036';job_id=$taskWorker.job_id;run_id=$taskWorker.run_id;image=$taskImage;stage=$taskWorker.step;state=$taskWorker.state;selected_sites=$taskWorker.selected_sites;kept_sites=$taskWorker.kept_sites;rolled_back_sites=$taskWorker.rolled_back_sites;worker_updated_utc=$taskWorker.updated_utc}
[IO.File]::WriteAllText($Out,($taskResult|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false));$taskResult|ConvertTo-Json -Compress
