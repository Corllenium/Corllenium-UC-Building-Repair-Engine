$ErrorActionPreference='Stop'
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskStatus="$taskRoot/data/r6h-live-status"
$taskPins=@{
 'binding.py'='d63d7784534b81a1d2bc04e789b57766bc8b9e8226146cc943c140ec4ca0a4b3'
 'observe.ps1'='ca366fb470955ed07a92bf24004788b34a6f2b562a708ed009564a114b5610d7'
 'watch.ps1'='a669351fbbc79b1f1838538da0b56bf8826d0a600dcc260d1a31f4cf2774ecf6'
}
foreach($taskName in $taskPins.Keys){
 if((Get-FileHash -LiteralPath "$taskStatus/$taskName" -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskPins[$taskName]){throw 'Reviewed status source changed'}
 $taskTokens=$null;$taskErrors=$null
 if($taskName.EndsWith('.ps1')){
  [void][Management.Automation.Language.Parser]::ParseFile("$taskStatus/$taskName",[ref]$taskTokens,[ref]$taskErrors)
  if($taskErrors.Count){throw 'Status PowerShell did not parse'}
 }
}
if(Test-Path -LiteralPath "$taskStatus/identity.json"){throw 'Existing status observer identity must be inspected first'}
& "$taskStatus/observe.ps1" -Out "$taskStatus/observation.json"
& "$taskRoot/.venv/Scripts/python.exe" -B "$taskStatus/binding.py"
if($LASTEXITCODE -ne 0){throw 'Initial real status binding failed'}
$taskShell='C:/Users/Future26/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
$taskProcess=Start-Process -FilePath $taskShell -ArgumentList @('-NoProfile','-File',"$taskStatus/watch.ps1") -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput "$taskStatus/stdout.log" -RedirectStandardError "$taskStatus/stderr.log"
$taskIdentity=@{pid=$taskProcess.Id;birth_utc=$taskProcess.StartTime.ToUniversalTime().ToString('o');worker_pid=40844;worker_birth='2026-10-26T15:58:28.3753658Z';phase_sha256='b0c70f4c95fb5f07f0e38e298182c7134769c8208456f9c836143c4be812a036';source_pins=$taskPins;numeric_status_only=$true;evidence_payload_uploaded=$false}
[IO.File]::WriteAllText("$taskStatus/identity.json",($taskIdentity|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
$taskIdentity|ConvertTo-Json -Compress -Depth 5
