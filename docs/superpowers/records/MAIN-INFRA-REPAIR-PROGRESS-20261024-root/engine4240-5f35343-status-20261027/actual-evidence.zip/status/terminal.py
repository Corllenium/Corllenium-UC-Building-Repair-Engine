from pathlib import Path
from datetime import datetime
import hashlib,json,sys

R=Path(__file__).resolve().parents[2];W=R/'.claude/worktrees/r6h'
sys.path.insert(0,str(R/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
tpath=W/'data/r6h-preflight/monitor-6F4240-r1-execute-20261026T155826/result.json'
raw=tpath.read_bytes();assert hashlib.sha256(raw).hexdigest()=='fe24bbe2621f116d8c8e8ac0621982e81ebedfbd8d3aa8ed9d052e84395e7024'
t=json.loads(raw);assert t['actual_pid']==40844 and t['actual_creation_utc']=='2026-10-26T15:58:28.3753658Z'
assert t['actual_exit_code']==t['launcher_exit_code']==0 and t['all_owned_exited'] and t['abort_reason'] is None
worker=json.loads((W/'data/main-infra-6f-4240-retention/run-20261026-r1/execution-6F/worker.json').read_bytes())
assert worker['actual_pid']==40844 and worker['state']=='candidate_saved' and worker['step']=='E5'
assert (worker['selected_sites'],worker['kept_sites'],worker['rolled_back_sites'],worker['output_triangles'],worker['protected_originals'])==(454,454,0,26151,4240)
saved=W/'data/main-infra-6f-4240-retention/run-20261026-r1/e5/6F'
hashes={}
for role,expected in [('source','232cad132958ee4cefeca390e063cfce6e4312a24b18a58a8381e6fd51334f6d'),('engine','797be6b20c80879e1c5c42282078982fd2a47041e0e24e169425ba914dfd7cb1')]:
    b=(saved/('candidate.'+role+'.obj')).read_bytes();assert hashlib.sha256(b).hexdigest()==expected and sum(line.startswith(b'f ')for line in b.splitlines())==26151;hashes[role]=expected
later=lambda old,new:max((old or new,new),key=lambda s:datetime.fromisoformat(s.replace('Z','+00:00')))
p=R/'data/main-infra-fresh/current.json';d=load_progress(p);f=d['floors']['6F'];now=utc_now()
assert f['output_triangles']==25433 and f['worker_pid']==40844 and f['accepted_preview'] is None
message='Corrective 6F engine finished: E3 saved28,243 and E5 saved26,151; all1,272 E3 and454 E5 selected sites kept, zero rollbacks. This new saved model still has the approved orange boxes. Exact24 poststage and new independent checks are pending; displayed25,433 remains unaccepted.'
f.update(state='validating',step=message,blocker='Exact orange-box poststage and independent validation of the new saved hashes are pending.',
    worker_alive=False,engine_worker_alive=False,worker_observed_at=t['ended_utc'],worker_cpu_seconds=None,
    worker_selected_sites=454,worker_kept_sites=454,worker_rolled_back_sites=0,pending_output_triangles=26151)
f['pending_saved_candidate']=dict(kind='PRE_MARKER_CHECKED_ENGINE_OUTPUT',triangles=26151,source_sha256=hashes['source'],engine_sha256=hashes['engine'],
    checkpoint_sha256=worker['checkpoint_sha256'],protected_originals=4240,marker_poststage='PENDING_ROOT_SEAL',independent_validation='PENDING',default_error_census='PENDING',acceptance=False)
f['last_work_event_at']=later(f.get('last_work_event_at'),t['ended_utc'])
phase='new4240_engine_terminal_saved26151'
if not any(e.get('phase')==phase for e in f.setdefault('worker_events',[])):
    f['worker_events'].append(dict(engine='E5',run_id=worker['run_id'],pid=40844,start_utc=t['actual_creation_utc'],observed_at=t['ended_utc'],phase=phase,message=message))
d.update(state='validating',step=message,updated_at=now,last_work_event_at=later(d.get('last_work_event_at'),t['ended_utc']))
write_progress(p,d);actual=load_progress(p)['floors']['6F']
assert actual['worker_alive'] is False and actual['engine_worker_alive'] is False and actual['worker_cpu_seconds'] is None and actual['output_triangles']==25433
receipt=dict(at=now,worker_pid=40844,all_owned_exited=True,current_displayed_triangles=25433,pending_pre_marker_triangles=26151,marker_removed=False,accepted=False,evidence_payload_uploaded=False)
(R/'data/r6h-live-status/terminal-readback.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(receipt))
