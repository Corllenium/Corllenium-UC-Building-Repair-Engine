"""Bind only exact corrective-worker metadata; keep displayed model evidence intact."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sys

MAIN=Path(__file__).resolve().parents[2]
ROOT=MAIN
STATUS=Path(__file__).resolve().parent
PID=40844
START='2026-10-26T15:58:28.3753658Z'
PHASE='b0c70f4c95fb5f07f0e38e298182c7134769c8208456f9c836143c4be812a036'
JOB='MAIN-INFRA-6F-4240-RETENTION-20261026'
RUN='main-infra-6f-4240-retention-20261026-r1'


def need(test,message):
    if not test:raise ValueError(message)


def bind_document(doc,o,*,now=None):
    now=now or datetime.now(timezone.utc)
    need(o['pid']==PID and o['start_utc']==START and o['alive'] is True and o['parent']==49936
         and o['phase_sha256']==PHASE and o['job_id']==JOB and o['run_id']==RUN,'Exact live corrective identity required')
    age=(now-datetime.fromisoformat(o['observed_at'].replace('Z','+00:00'))).total_seconds()
    need(0<=age<15 and isinstance(o['cpu_seconds'],(int,float)) and o['cpu_seconds']>=0,'Fresh actual CPU observation required')
    need(o['stage'] in ('E3','E5') and o['state'] in ('checking_sites','stage_saved','candidate_saved')
         and o['selected_sites']==({'E3':1272,'E5':454}[o['stage']]),'Actual owned stage/count required')
    for name in ('kept_sites','rolled_back_sites'):
        need(o[name] is None or (type(o[name])is int and 0<=o[name]<=o['selected_sites']),'Actual kept/rollback count differs')
    f=doc['floors']['6F'];saved=f['latest_saved_candidate']
    need(f['output_triangles']==25433 and saved['source_candidate_sha256']=='17773017d245976c66328172900db83608505fb13a811b9c776e18e48350cc8c'
         and saved['engine_candidate_sha256']=='3ff8f6c396c35e1cb488d84f963e6e03d3e8697ef305d21e20bb25982be0fb54'
         and saved['acceptance'] is False,'Current displayed25433 role differs')
    kept='not reported' if o['kept_sites'] is None else str(o['kept_sites'])
    rolled='not reported' if o['rolled_back_sites'] is None else str(o['rolled_back_sites'])
    message=f"Actual 6F corrective engine: {o['stage']} {o['state']}; {o['selected_sites']} selected, {kept} kept, {rolled} rolled back; 4,240 originals protected. Displayed 25,433 remains unaccepted after full signed preservation failure."
    phase=o['stage']+'_'+o['state'];events=f.setdefault('worker_events',[])
    if not any(e.get('pid')==PID and e.get('phase')==phase for e in events):
        events.append(dict(engine=o['stage'],run_id=RUN,pid=PID,start_utc=START,observed_at=o['observed_at'],phase=phase,message=message))
        latest=lambda previous:max((previous or o['observed_at'],o['observed_at']),key=lambda stamp:datetime.fromisoformat(stamp.replace('Z','+00:00')))
        f['last_work_event_at']=latest(f.get('last_work_event_at'));doc['last_work_event_at']=latest(doc.get('last_work_event_at'))
    f.update(state='cleaning' if o['state']=='checking_sites' else 'validating',step=message,blocker='Displayed candidate failed full signed preservation and targets; corrective engine is running.',worker_pid=PID,worker_start_utc=START,
        worker_alive=True,worker_observed_at=o['observed_at'],worker_cpu_seconds=o['cpu_seconds'],engine_stage=o['stage'],
        worker_selected_sites=o['selected_sites'],worker_kept_sites=o['kept_sites'],worker_rolled_back_sites=o['rolled_back_sites'])
    f.update(engine_worker_pid=PID,engine_worker_start_utc=START,engine_worker_alive=True)
    doc.update(state=f['state'],step=message,heartbeat_at=o['observed_at'])
    samples=f.setdefault('worker_cpu_samples',[]);samples.append(dict(pid=PID,start_utc=START,observed_at=o['observed_at'],cpu_seconds=o['cpu_seconds']))
    f['worker_cpu_samples']=samples[-100:];doc['updated_at']=now.isoformat()
    return doc


def main():
    helper=MAIN/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023/tools/main_infra_progress.py'
    need(hashlib.sha256(helper.read_bytes()).hexdigest()=='b7aca8d75355af86202be6782d08509efe81668007d596b4ac3e77bd7d872cea','Paid progress helper changed')
    sys.path.insert(0,str(helper.parents[1]))
    from tools.main_infra_progress import load_progress,write_progress
    path=MAIN/'data/main-infra-fresh/current.json'
    o=json.loads((STATUS/'observation.json').read_bytes());doc=bind_document(load_progress(path),o)
    write_progress(path,doc)
    readback=load_progress(path);f=readback['floors']['6F']
    need(f['worker_pid']==PID and f['output_triangles']==25433 and f['latest_saved_candidate']['acceptance'] is False,'Canonical status readback differs')
    result=dict(at=datetime.now(timezone.utc).isoformat(),floor='6F',actual_worker=o,state=f['state'],step=f['step'],current_displayed_triangles=25433,accepted=False)
    (STATUS/'bind-readback.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))


if __name__=='__main__':main()
