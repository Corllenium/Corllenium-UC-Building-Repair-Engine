import copy
from datetime import datetime
import json
from pathlib import Path

import pytest

HERE=Path(__file__).parent

def load():
    import importlib.util
    p=HERE/'binding.py'
    assert p.exists(), 'New exact 6F binding required'
    s=importlib.util.spec_from_file_location('root6h_binding',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m.bind_document


def actual():
    return json.loads((HERE/'current-fixture.json').read_bytes()),json.loads((HERE/'actual-observation-fixture.json').read_bytes())


def test_actual_worker_status_preserves_every_display_and_acceptance_reference():
    bind_document=load()
    doc,obs=actual();before=copy.deepcopy(doc)
    result=bind_document(doc,obs,now=datetime.fromisoformat(obs['observed_at']))
    old,new=before['floors']['6F'],result['floors']['6F']
    for key in ('source_preview','candidate_preview','accepted_preview','output_triangles','latest_saved_candidate','inspection_acceptance','publication_eligible','validator_passed','independent_guard_passed','pending_output_triangles'):
        assert new.get(key)==old.get(key)
    assert new['worker_pid']==40844 and new['worker_alive'] is True
    assert new['worker_selected_sites']==obs['selected_sites']
    assert new['worker_kept_sites']==obs['kept_sites'] and new['worker_rolled_back_sites']==obs['rolled_back_sites']
    assert new['worker_cpu_seconds']==obs['cpu_seconds']
    assert all(result['floors'][key]==value for key,value in before['floors'].items() if key!='6F')


@pytest.mark.parametrize('mutation',['pid','birth','phase','display','stale'])
def test_wrong_or_stale_identity_and_changed_display_are_rejected(mutation):
    bind_document=load()
    doc,obs=actual();now=datetime.fromisoformat(obs['observed_at'])
    if mutation=='pid':obs['pid']+=1
    elif mutation=='birth':obs['start_utc']='2026-10-26T00:00:00Z'
    elif mutation=='phase':obs['phase_sha256']='0'*64
    elif mutation=='display':doc['floors']['6F']['output_triangles']=1
    else:obs['observed_at']='2026-10-26T00:00:00Z'
    with pytest.raises(ValueError):bind_document(doc,obs,now=now)


def test_actual_r2_updates_global_step_and_required_worker_event_fields():
    bind_document=load()
    doc,obs=actual()
    result=bind_document(doc,obs,now=datetime.fromisoformat(obs['observed_at']))
    assert result['state']=='cleaning'
    assert result['step']==result['floors']['6F']['step']
    assert result['heartbeat_at']==obs['observed_at']
    event=result['floors']['6F']['worker_events'][-1]
    assert set(('engine','run_id','pid','start_utc','observed_at','phase','message'))<=set(event)
    assert event['pid']==40844 and event['run_id']=='main-infra-6f-4240-retention-20261026-r1'


def test_previous_5f_worker_lifetime_is_rejected():
    bind_document=load()
    doc,obs=actual()
    old=json.loads(Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/.claude/worktrees/r6g/data/main-infra-6f-3546-retention/run-20261026-r2/execution-6F/worker.json').read_bytes())
    obs.update(pid=old['actual_pid'],start_utc=old['actual_creation_utc'],run_id=old['run_id'])
    with pytest.raises(ValueError):bind_document(doc,obs,now=datetime.fromisoformat(obs['observed_at']))




def test_new_floor_event_does_not_regress_newer_work_timestamps():
    bind_document=load();doc,obs=actual()
    future="2026-10-27T23:59:59+00:00"
    doc["last_work_event_at"]=future;doc["floors"]["6F"]["last_work_event_at"]=future
    out=bind_document(doc,obs,now=datetime.fromisoformat(obs["observed_at"]))
    assert out["last_work_event_at"]==future and out["floors"]["6F"]["last_work_event_at"]==future
