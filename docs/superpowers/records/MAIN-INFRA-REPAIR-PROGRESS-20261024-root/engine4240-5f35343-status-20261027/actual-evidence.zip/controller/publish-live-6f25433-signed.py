from pathlib import Path
import hashlib,json,os,tarfile,tempfile
from urllib.request import Request,urlopen
from urllib.parse import quote
M=Path('/tmp/main-infra-6f25433-signed.json');A=Path('/tmp/main-infra-6f25433-signed.tar.gz')
assert hashlib.sha256(M.read_bytes()).hexdigest()=='88c8290e33c05973852d568ab5959b25c97ac51d467f86067d414e4a9e10bcb6'
m=json.loads(M.read_bytes());assert hashlib.sha256(A.read_bytes()).hexdigest()==m['archive_sha256']
assert m['inspection_assets_only'] is True and m['accepted'] is False and m['floor']=='6F'
rows={r['path']:r for r in m['files']};assert len(rows)==75
prefix='models/main-infra/7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511/6F/main-infra-clean-20261023/candidate/'
assert all(p.startswith(prefix) and '..' not in p and '\\' not in p for p in rows)
with tarfile.open(A) as tf:
    members=tf.getmembers();assert len(members)==75 and len({x.name for x in members})==75 and all(x.isfile() and x.name in rows for x in members)
    data={x.name:tf.extractfile(x).read() for x in members}
assert all(len(b)==rows[p]['bytes'] and hashlib.sha256(b).hexdigest()==rows[p]['sha256'] for p,b in data.items())
def fetch(url):
    with urlopen(Request(url,headers={'Cache-Control':'no-cache'}),timeout=25) as response:
        assert response.status==200;return response.read()
health=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
assert health['sha']=='cedb7c53c35b0599585c17b214f3c29e1dfb7b9f' and health['db']['ok']
def install(target,b,sha):
    if target.exists():
        assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==sha;return
    target.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.codex-6f25433-signed-',dir=target.parent)
    try:
        with os.fdopen(fd,'wb') as stream:stream.write(b);stream.flush();os.fsync(stream.fileno())
        os.chmod(tmp,0o644)
        try:os.link(tmp,target)
        except FileExistsError:assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==sha
    finally:os.unlink(tmp)
roots=[Path('/home/devenvir/corllenium/web'),Path('/home/devenvir/corllenium/app/public')]
for root in roots:
    assert root.resolve()==root
    for rel,row in rows.items():
        target=root/rel;assert root in target.resolve().parents
        if target.exists():assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256']
for root in roots:
    for rel,row in rows.items():install(root/rel,data[rel],row['sha256'])
for root in roots:
    for rel,row in rows.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==row['sha256']
from concurrent.futures import ThreadPoolExecutor
def verify_http(item):
    rel,row=item;assert hashlib.sha256(fetch('https://corllenium.ai.dev-environment.site/'+quote(rel,safe='/')+'?repair=6f25433-signed-20261026')).hexdigest()==row['sha256'];return rel
with ThreadPoolExecutor(max_workers=4) as pool:verified_http=list(pool.map(verify_http,rows.items()))
after=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'));assert after['sha']==health['sha'] and after['db']['ok']
receipt=dict(files_per_root=75,http_hashes=len(verified_http),floor='6F',triangles=25433,accepted=False,no_app_restart=True,api_sha=after['sha'],archive_sha256=m['archive_sha256'])
raw=(json.dumps(receipt,sort_keys=True)+'\n').encode();install(Path('/home/devenvir/corllenium/data/codex-6f25433-signed-deployment-20261026.json'),raw,hashlib.sha256(raw).hexdigest())
print(json.dumps(receipt))
