from pathlib import Path
from datetime import datetime
import hashlib,json,subprocess,sys

R=Path(__file__).resolve().parents[2];D=R/'data/s6s3'
b=(D/'package.json').read_bytes();assert hashlib.sha256(b).hexdigest()=='88c8290e33c05973852d568ab5959b25c97ac51d467f86067d414e4a9e10bcb6'
m=json.loads(b);deployed=json.loads((D/'deployment.log').read_text(encoding='utf-8-sig').strip())
assert deployed['files_per_root']==deployed['http_hashes']==75 and deployed['archive_sha256']==m['archive_sha256']=='52b1c969aea92e68505925882281ee847b9a71c51880e2a58068532027087bf5'
assert deployed['no_app_restart'] and not deployed['accepted'] and m['preservation']=='FAIL'
sys.path.insert(0,str(R/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
later=lambda a,b:max((a or b,b),key=lambda s:datetime.fromisoformat(s.replace('Z','+00:00')))
p=R/'data/main-infra-fresh/current.json'
for attempt in range(6):
    d=load_progress(p);before=json.loads(json.dumps(d));now=utc_now();f=d['floors']['6F']
    assert f['output_triangles']==25433 and f['latest_saved_candidate']['source_candidate_sha256']==m['candidate_source_sha256']
    assert f['latest_saved_candidate']['full_signed']=='FAIL' and f['accepted_preview'] is None and f['owner_decision_ref'] is None
    f['validator_ref']=m['validator_ref']
    f['evidence_refs']=list(dict.fromkeys(f.get('evidence_refs',[])+m['evidence_refs']))
    f['latest_saved_candidate']['full_signed_report_url']=m['validator_ref']
    phase='displayed25433_failed_validation_evidence_published'
    if not any(e.get('phase')==phase for e in f.setdefault('worker_events',[])):
        f['worker_events'].append(dict(engine='Validator',run_id='MAIN-INFRA-6F-25433-INDEPENDENT-20261026',pid=67480,start_utc='2026-10-26T13:54:08.4567266Z',observed_at=now,phase=phase,
            message='Owner-approved failed25433 validation evidence published:71 actual QA images and4 validation/retention JSON files; all75 HTTP hashes verified. PreservationFAIL retained; this report is for displayed25433, not the pending new26151 engine output.'))
    f['last_work_event_at']=later(f.get('last_work_event_at'),now);d.update(updated_at=now,last_work_event_at=later(d.get('last_work_event_at'),now))
    assert all(d['floors'][k]==v for k,v in before['floors'].items()if k!='6F')
    draft=D/'status-draft.json';draft.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
    subprocess.run(['node',str(R/'data/siege-live-20261026/check-status-current.mjs'),str(draft)],check=True,capture_output=True)
    if load_progress(p)['updated_at']!=before['updated_at']:continue
    write_progress(p,d);break
else:raise RuntimeError('Concurrent status changes prevented bounded safe update')
f=load_progress(p)['floors']['6F'];assert f['validator_ref']==m['validator_ref'] and f['output_triangles']==25433 and f['accepted_preview'] is None
receipt=dict(at=now,floor='6F',displayed_triangles=25433,validator_ref=f['validator_ref'],HTTP_hashes=75,other_floors_untouched=True,step_and_pending_model_unchanged=True,accepted=False)
(D/'canonical-readback.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(receipt))
