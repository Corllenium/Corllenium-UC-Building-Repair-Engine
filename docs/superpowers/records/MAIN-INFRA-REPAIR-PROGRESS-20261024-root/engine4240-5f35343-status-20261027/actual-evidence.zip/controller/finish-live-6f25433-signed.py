from pathlib import Path
import hashlib,json,tarfile

R=Path(__file__).resolve().parents[2];D=R/'data/s6s3';sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(D/'package.json').read_bytes();m=json.loads(raw);package_sha=sha(raw)
assert m['floor']=='6F' and m['inspection_assets_only'] and not m['accepted'] and m['preservation']=='FAIL'
assert len(m['files'])==75 and sha((D/'models.tar.gz').read_bytes())==m['archive_sha256']
rows={r['path']:r for r in m['files']};assert len(rows)==75
for rel,row in rows.items():
    assert sha((Path(m['stage'])/rel).read_bytes())==row['sha256']
with tarfile.open(D/'models.tar.gz')as tf:
    assert len(tf.getmembers())==75
    for member in tf.getmembers():assert member.isfile() and sha(tf.extractfile(member).read())==rows[member.name]['sha256']
assert rows[m['validator_ref'].lstrip('/')]['sha256']=='f193b86f787d6e03025274359dcbee119217cc9686aa34ee67ad873807a7be8b'
old=(R/'data/siege-live-20261026/publish-live-6f25433.py').read_bytes()
assert sha(old)=='7c3c10547700693bd2ae9021c5f8257fbe9fea55e512df4724eb454dbb4dc57b'
remote=old.decode('utf8').replace('6f25433','6f25433-signed').replace('2d417346e5c247175dda96392a97434d20a5d2872a96a09ad2b2b23631580be6',package_sha)
assert remote.count('==19')==3 and remote.count('files_per_root=19')==1
remote=remote.replace('==19','==75').replace('files_per_root=19','files_per_root=75')
compile(remote,'publish-live-6f25433-signed.py','exec')
rp=R/'data/siege-live-20261026/publish-live-6f25433-signed.py';assert not rp.exists();rp.write_bytes(remote.encode());remote_sha=sha(rp.read_bytes())
shell=(R/'data/siege-live-20261026/publish-live-6f25433.ps1').read_text().replace('6f25433','6f25433-signed').replace('/data/live-6f25433-signed/','/data/s6s3/')
for a,b in [('425c5deb4fc77588e5722a08f825391bb883e80d393dd8ead8021c8f56af156b',m['archive_sha256']),('2d417346e5c247175dda96392a97434d20a5d2872a96a09ad2b2b23631580be6',package_sha),('7c3c10547700693bd2ae9021c5f8257fbe9fea55e512df4724eb454dbb4dc57b',remote_sha)]:
    assert a in shell;shell=shell.replace(a,b)
(R/'data/siege-live-20261026/publish-live-6f25433-signed.ps1').write_text(shell,encoding='utf8',newline='\n')
print(json.dumps(dict(files=75,package_sha256=package_sha,archive_sha256=m['archive_sha256'],publisher_sha256=remote_sha,preservation='FAIL',accepted=False)))
