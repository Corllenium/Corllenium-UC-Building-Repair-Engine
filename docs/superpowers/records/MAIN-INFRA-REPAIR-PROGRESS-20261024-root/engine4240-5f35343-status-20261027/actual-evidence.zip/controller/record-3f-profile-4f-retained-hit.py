from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,json,subprocess,sys,time

R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
def checked(path,expected):
    b=path.read_bytes();assert hashlib.sha256(b).hexdigest()==expected;return json.loads(b)
guard=checked(R/'.claude/worktrees/v4h/data/iv4h/independent-guard.json','db6d89a33172fc04b989ab88aa80b49897c02831fb5961d60dd986baa2178487')
hit=checked(R/'.claude/worktrees/v4h/data/iv4g-diagnostic/current58169-onepixel-20261026/one-pixel-attribution.json','540053a7992df28e2283ede132146ca8c724318e4cc3854f66e2993ab4eef823')
assert not guard['guard']['passed'] and guard['guard']['totals']['material_changed']==1 and hit['before_original_retained']
t3=json.loads((R/'data/3f-44953-independent-phases-20261026/monitor-3f-44953-readback-20261026T160600/result.json').read_bytes())
assert t3['actual_pid']==49824 and t3['actual_exit_code']==1 and t3['all_owned_exited'] and t3['abort_reason'] is None
later=lambda a,b:max((a or b,b),key=lambda s:datetime.fromisoformat(s.replace('Z','+00:00')))
path=R/'data/main-infra-fresh/current.json'
for attempt in range(6):
    original=load_progress(path);d=copy.deepcopy(original);now=utc_now()
    for floor,pid,birth,end,phase,message in (
        ('3F',49824,t3['actual_creation_utc'],t3['ended_utc'],'new44953_readback_profile_binding_stopped','Saved 44,953 candidate awaits validation. Readback stopped before output because the retained profile copy has different bytes; an explicit authenticated profile path is being fixed. Census and strict checks have not run.'),
        ('4F',30312,'2026-10-26T14:46:03.1300033Z','2026-10-26T14:46:19.6467899Z','new58169_retained_material_hit_reviewed','Saved 58,169 candidate: strict26 FAIL on one material-change pixel; every other gating metric is zero. Both hit faces remain in the model. Exact capture reproduced the mismatch; native and full signed checks have not run.')):
        f=d['floors'][floor];assert f['accepted_preview'] is None and f['output_triangles']==({'3F':44948,'4F':58064}[floor])
        f.update(state='blocked',step=message,blocker=message,worker_pid=pid,worker_start_utc=birth,worker_alive=False,worker_observed_at=end,engine_worker_alive=False)
        f.pop('worker_cpu_seconds',None);f['last_work_event_at']=later(f.get('last_work_event_at'),now)
        if not any(e.get('phase')==phase for e in f.setdefault('worker_events',[])):
            f['worker_events'].append(dict(engine='Validator',run_id='MAIN-INFRA-'+floor+'-INDEPENDENT-20261026',pid=pid,start_utc=birth,observed_at=now,phase=phase,message=message))
    f=d['floors']['4F'];f['pending_saved_candidate']=dict(triangles=58169,source_sha256=guard['candidate_source_sha256'],engine_sha256=guard['candidate_engine_sha256'],protected_originals=19908,
        strict26='FAIL',strict26_sha256='db6d89a33172fc04b989ab88aa80b49897c02831fb5961d60dd986baa2178487',material_changed_pixels=1,other_gating_pixels=0,native='NOT_RUN',full_signed='NOT_RUN',acceptance=False)
    d.update(updated_at=now,last_work_event_at=later(d.get('last_work_event_at'),now))
    draft=R/'data/siege-live-20261026/3f4f-status-draft.json';draft.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
    subprocess.run(['node',str(R/'data/siege-live-20261026/check-status-current.mjs'),str(draft)],check=True,capture_output=True)
    if load_progress(path)['updated_at']!=original['updated_at']:continue
    try:write_progress(path,d);break
    except PermissionError:
        if attempt==5:raise
        time.sleep(.1)
else:raise RuntimeError('Status changed during all bounded attempts; no stale replacement')
actual=load_progress(path)
for floor in actual['floors']:
    for key in ('source_preview','candidate_preview','accepted_preview','output_triangles','latest_saved_candidate'):
        assert actual['floors'][floor].get(key)==original['floors'][floor].get(key)
receipt=dict(at=now,updated_floors=['3F','4F'],all_display_and_acceptance_refs_unchanged=True,other_floor_rows_untouched=True,evidence_payload_uploaded=False,accepted=False)
(R/'data/siege-live-20261026/3f4f-status-readback.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(receipt))
