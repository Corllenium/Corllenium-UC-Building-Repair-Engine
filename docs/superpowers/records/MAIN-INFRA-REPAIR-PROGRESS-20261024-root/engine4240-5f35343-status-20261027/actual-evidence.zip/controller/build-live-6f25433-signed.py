from pathlib import Path
import hashlib,io,json,tarfile

R=Path(__file__).resolve().parents[2];D=R/'data/s6s3';S=D/'s'
REV='7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511'
PREFIX=f'models/main-infra/{REV}/6F/main-infra-clean-20261023/candidate/fs25433/'
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda d:(json.dumps(d,indent=2,allow_nan=False)+'\n').encode()
assert not D.exists();S.mkdir(parents=True)
V=R/'.claude/worktrees/v6h/data';files={}
def add(relative,path):
    path=Path(path);b=path.read_bytes();rel=PREFIX+relative
    assert '..' not in rel and '\\' not in rel and rel not in files
    out=S/rel;assert len(str(out))<=250;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);assert out.read_bytes()==b
    files[rel]=dict(path=rel,bytes=len(b),sha256=sha(b));return '/'+rel
source=V/'iv6h/fullsigned'
paths=[p for p in source.rglob('*')if p.is_file()];assert len(paths)==73
for p in paths:add(p.relative_to(source).as_posix(),p)
for name in ('fullsigned-failure-cohort.json','fullsigned-whole-site-retention-closure.json'):
    add(name,V/'iv6h-preflight'/name)
assert len(files)==75
for name,expected in [('validation.json','f193b86f787d6e03025274359dcbee119217cc9686aa34ee67ad873807a7be8b'),('fullsigned-whole-site-retention-closure.json','26c452474cd90c072681482bd91d5a2873108dbe13806355888efe8a76c7ab8e')]:
    assert files[PREFIX+name]['sha256']==expected
report=json.loads((S/(PREFIX+'validation.json')).read_bytes())
assert report['verdict']=='FAIL' and report['checks']['textures']['samples_failed']==184 and report['checks']['textures']['faces_failed']==31
assert report['checks']['nothing_deleted']['floor']['faces_failed']==44
archive=D/'models.tar.gz'
with tarfile.open(archive,'w:gz')as tf:
    for rel,row in files.items():
        b=(S/rel).read_bytes();assert sha(b)==row['sha256'];info=tarfile.TarInfo(rel);info.size=len(b);info.mode=0o644;tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive)as tf:
    assert len(tf.getmembers())==75
    for member in tf.getmembers():assert member.isfile()and sha(tf.extractfile(member).read())==files[member.name]['sha256']
package=dict(floor='6F',inspection_assets_only=True,accepted=False,source_revision=REV,stage=str(S),archive_sha256=sha(archive.read_bytes()),files=list(files.values()),
    candidate_source_sha256='17773017d245976c66328172900db83608505fb13a811b9c776e18e48350cc8c',triangles=25433,preservation='FAIL',
    validator_ref='/'+PREFIX+'validation.json',evidence_refs=['/'+PREFIX+n for n in ('validation.json','independent-review.json','fullsigned-failure-cohort.json','fullsigned-whole-site-retention-closure.json')])
(D/'package.json').write_bytes(js(package));package_sha=sha(js(package))
old_bytes=(R/'data/siege-live-20261026/publish-live-6f25433.py').read_bytes()
assert sha(old_bytes)=='7c3c10547700693bd2ae9021c5f8257fbe9fea55e512df4724eb454dbb4dc57b'
old=old_bytes.decode('utf8')
remote=old.replace('6f25433','6f25433-signed').replace('2d417346e5c247175dda96392a97434d20a5d2872a96a09ad2b2b23631580be6',package_sha)
assert remote.count('==19')==3 and remote.count('files_per_root=19')==1
remote=remote.replace('==19','==75').replace('files_per_root=19','files_per_root=75')
compile(remote,'publish-live-6f25433-signed.py','exec')
rp=R/'data/siege-live-20261026/publish-live-6f25433-signed.py';rp.write_text(remote,encoding='utf8',newline='\n');remote_sha=sha(rp.read_bytes())
shell=(R/'data/siege-live-20261026/publish-live-6f25433.ps1').read_text().replace('6f25433','6f25433-signed')
shell=shell.replace('/data/live-6f25433-signed/','/data/s6s3/')
for a,b in [('425c5deb4fc77588e5722a08f825391bb883e80d393dd8ead8021c8f56af156b',package['archive_sha256']),('2d417346e5c247175dda96392a97434d20a5d2872a96a09ad2b2b23631580be6',package_sha),('7c3c10547700693bd2ae9021c5f8257fbe9fea55e512df4724eb454dbb4dc57b',remote_sha)]:
    assert a in shell;shell=shell.replace(a,b)
(R/'data/siege-live-20261026/publish-live-6f25433-signed.ps1').write_text(shell,encoding='utf8',newline='\n')
print(json.dumps(dict(files=75,package_sha256=package_sha,archive_sha256=package['archive_sha256'],publisher_sha256=remote_sha,preservation='FAIL',accepted=False)))
