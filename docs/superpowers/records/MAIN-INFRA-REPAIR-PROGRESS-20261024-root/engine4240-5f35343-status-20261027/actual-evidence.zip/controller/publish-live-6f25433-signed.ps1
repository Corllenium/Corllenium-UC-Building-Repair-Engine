$ErrorActionPreference='Stop'
if((Get-FileHash -LiteralPath 'D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023/deploy/known_hosts' -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'a3cf78817285a92b917c345e8d0df1a6cbb6e2263d1d2870806e16f7f74d6630'){throw 'Configured known-host file changed'}
$taskSite='devenvir@sv70.ifastnet.com'
$taskCommon=@('-i','C:/Users/Future26/.ssh/corllenium_siege_ed25519','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=1','-o','LogLevel=ERROR','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023/deploy/known_hosts')
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskRows=@(
 @{Source="$taskRoot/data/s6s3/models.tar.gz";Name='main-infra-6f25433-signed.tar.gz';Sha='52b1c969aea92e68505925882281ee847b9a71c51880e2a58068532027087bf5'},
 @{Source="$taskRoot/data/s6s3/package.json";Name='main-infra-6f25433-signed.json';Sha='88c8290e33c05973852d568ab5959b25c97ac51d467f86067d414e4a9e10bcb6'},
 @{Source="$taskRoot/data/siege-live-20261026/publish-live-6f25433-signed.py";Name='publish-live-6f25433-signed.py';Sha='daadadee2ddf756296634b0fea92ffbfa0797ae80b2a3cf1176bbe8e4fe0cbde'}
)
foreach($taskRow in $taskRows){
 if((Get-FileHash -Algorithm SHA256 -LiteralPath $taskRow.Source).Hash.ToLowerInvariant() -ne $taskRow.Sha){throw 'Publication input changed'}
 & scp -q -P 27015 @taskCommon $taskRow.Source ($taskSite+':/tmp/'+$taskRow.Name)
 if($LASTEXITCODE -ne 0){throw ('Upload failed: '+$taskRow.Name)}
}
$taskRemote='python3 -c "import hashlib,runpy; p=''/tmp/publish-live-6f25433-signed.py''; assert hashlib.sha256(open(p,''rb'').read()).hexdigest()==''daadadee2ddf756296634b0fea92ffbfa0797ae80b2a3cf1176bbe8e4fe0cbde''; runpy.run_path(p,run_name=''__main__'')"'
& ssh -p 27015 @taskCommon $taskSite $taskRemote | Tee-Object -FilePath "$taskRoot/data/s6s3/deployment.log"
if($LASTEXITCODE -ne 0){throw 'Inspection assets not verified; current live model selection stays unchanged'}
