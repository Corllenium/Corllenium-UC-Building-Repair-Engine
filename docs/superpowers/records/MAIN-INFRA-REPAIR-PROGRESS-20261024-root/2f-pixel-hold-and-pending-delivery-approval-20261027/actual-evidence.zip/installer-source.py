from pathlib import Path
import argparse,hashlib,json,os,tarfile,tempfile
from urllib.request import Request,urlopen
from urllib.parse import quote
PACKAGE_SHA='49e318891b9dc4fd4dfffe20840543f7c22e1a28444d2ccf39c6151f2c5c545c'
ARCHIVE_SHA='c83b58990ae239b534cf58eb9a923e6c9e6ef4d82bc496b42f024d5c877ac6ca'
TRANSPORT_SHA='0bf271586722588d641cb693c9be0adf497a6955b9271d97a8d044376eb135d7'
INPUT_SHA='c634bd7cf662f3e31d1bc661b4b73d2918c7a9b27b4e95ab7e0dff8d29441211'
CLIENT_PHASE='046c923961c66ee7ad3edf0aff633c047a8f829b1e095ffe9845a7339c53da0b'
CERTIFICATE_SHA='136065640e84170ff00b38270fb141313d84cfb79c911c22b772537fee09ff2a'
GUARD='1de410dfb2c76a4b6677e5da877f8e31e1e0c658ff90c3ef195ace12c1e0495c'
MODEL='382b37f2e3f4c2955c0b4ab8eb004ef3440f64ec2850805b5d82dc54671a7c2c'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def verify_certificate(q):
    assert q['package_sha256']==PACKAGE_SHA and q['archive_sha256']==ARCHIVE_SHA and q['input_sha256']==INPUT_SHA
    assert q['phase_plan_sha256']==CLIENT_PHASE and q['certificate_sha256']==CERTIFICATE_SHA and q['acceptance'] is False
    assert q['strict']=='FAIL' and q['guard_sha256']==GUARD and q['native']==q['full_signed']=='NOT_RUN' and q['numerical_K1_qualified'] is None
    t=q['terminal'];assert t['state']=='PROCESS_EXITED_ZERO' and t['actual_exit_code']==t['launcher_exit_code']==0 and t['all_owned_exited'] is True and t['abort_reason'] is None and t['phase_plan_sha256']==CLIENT_PHASE
    assert t['actual_pid']==28520 and t['actual_creation_utc']=='2026-10-27T12:57:12.2018183Z' and t['HEAD']=='a61f8d8b5f7f67eaffa2f5de1ef67df79130e536'
    s=q['strong'];assert s['actualTriangles']==s['parsedTriangles']==39334 and s['errorKinds']==7 and s['textureDependencies']==9
    assert s['mapFaceIdsAndCoordinatesExact'] is s['hashValidStaleBindingRejected'] is s['corruptModelRejected'] is True
    assert s['packageSha256']==PACKAGE_SHA and s['archiveSha256']==ARCHIVE_SHA and s['accepted'] is False
    assert s['facadeOverlay']['triangles']==19436 and s['facadeOverlay']['webgl_or_browser_rendered'] is False

def install_payload(A,files,roots,prefix):
    expected={v['path']:v for v in files}
    assert len(expected)==len(files)==14 and all(v.startswith(prefix)and'..'not in v and'\\'not in v for v in expected)
    with tarfile.open(A,'r:gz') as tf:
        members=tf.getmembers()
        assert len(members)==14 and all(v.isfile() and v.name in expected for v in members)
        data={v.name:tf.extractfile(v).read() for v in members}
        assert len(data)==14 and all(len(b)==expected[p]['bytes'] and hashlib.sha256(b).hexdigest()==expected[p]['sha256'] for p,b in data.items())
        for root in roots:
            assert root.resolve()==root
            for rel,b in data.items():
                target=root/rel
                assert root in target.resolve().parents
                if target.exists():
                    assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256'],rel
        for root in roots:
            for rel,b in data.items():
                target=root/rel
                if not target.exists():
                    target.parent.mkdir(parents=True,exist_ok=True)
                    fd,tmp=tempfile.mkstemp(prefix='.codex-inspection-26291-',dir=target.parent)
                    try:
                        with os.fdopen(fd,'wb') as stream:
                            stream.write(b);stream.flush();os.fsync(stream.fileno())
                        os.chmod(tmp,0o644)
                        try:
                            os.link(tmp,target)
                        except FileExistsError:
                            assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256']
                    finally:
                        os.unlink(tmp)
                assert hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256']

def fetch(url):
    with urlopen(Request(url,headers={'Cache-Control':'no-cache'}),timeout=25) as response:
        assert response.status==200
        return response.read()

def main():
    p=argparse.ArgumentParser();p.add_argument('--client-qa-sha256',required=True);a=p.parse_args()
    A=Path('/tmp/main-infra-inspection-2f39334-current-20261027.tar.gz');M=Path('/tmp/main-infra-inspection-2f39334-current-20261027.json');Q=Path('/tmp/main-infra-inspection-2f39334-current-20261027-client-qa.json')
    assert sha(A)==ARCHIVE_SHA and sha(M)==TRANSPORT_SHA and sha(Q)==a.client_qa_sha256
    m=json.loads(M.read_bytes());verify_certificate(json.loads(Q.read_bytes()))
    assert m['source_package_sha256']==PACKAGE_SHA and m['archive_sha256']==ARCHIVE_SHA and m['floor']=='2F' and m['profile']=='2f-39334-current'
    assert m['inspection_assets_only'] is m['not_final'] is True and m['accepted'] is False
    assert m['remaining_target_instances']==26081 and m['results']['candidate']['triangles']==39334
    assert m['results']['candidate']['obj_sha256']==MODEL and m['results']['candidate']['counts']['reversed']==1 and m['facade_layer']['count']==19436
    prefix='models/main-infra/7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511/2F/main-infra-clean-20261023/candidate/'
    receipt_path=Path('/home/devenvir/corllenium/data/codex-inspection-2f39334-current-20261027-receipt.json');assert not receipt_path.exists()
    health_before=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
    assert health_before['sha']=='cedb7c53c35b0599585c17b214f3c29e1dfb7b9f' and health_before['db']['ok']
    roots=[Path('/home/devenvir/corllenium/web'),Path('/home/devenvir/corllenium/app/public')]
    install_payload(A,m['files'],roots,prefix)
    for row in m['files']:
        b=fetch('https://corllenium.ai.dev-environment.site/'+quote(row['path'],safe='/')+'?inspection=2f39334-current-20261027')
        assert hashlib.sha256(b).hexdigest()==row['sha256'],row['path']
    health_after=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
    assert health_after['sha']==health_before['sha'] and health_after['db']['ok']
    receipt=dict(files_per_root=14,http_hashes=14,preview=m['results']['candidate']['preview'],candidate_triangles=39334,
        preservation_passed=False,strict_passed=False,strict_guard_sha256=GUARD,native='NOT_RUN',full_signed='NOT_RUN',numerical_K1_qualified=None,
        signed_targets_passed=False,remaining_target_counts=26081,remaining_reversed_faces=1,accepted=False,archive_sha256=ARCHIVE_SHA,
        package_sha256=PACKAGE_SHA,transport_sha256=TRANSPORT_SHA,client_qa_sha256=a.client_qa_sha256,no_app_restart=True,
        api_sha_before_after=health_after['sha'],status_written=False,installer='exclusive hardlink; different existing bytes refused')
    with receipt_path.open('x') as f:f.write(json.dumps(receipt)+'\n')
    print(json.dumps(receipt))
if __name__=='__main__':main()
