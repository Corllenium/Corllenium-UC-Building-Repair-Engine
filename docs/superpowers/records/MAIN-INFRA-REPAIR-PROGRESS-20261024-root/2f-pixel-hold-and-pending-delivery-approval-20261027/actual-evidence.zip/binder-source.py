from pathlib import Path
import argparse,copy,hashlib,json,subprocess,sys
from publish_inspection_39334_current import PACKAGE_SHA,ARCHIVE_SHA,GUARD,MODEL,CERTIFICATE_SHA,CLIENT_PHASE,verify_certificate
ROOT=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine');OPS=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def bind_document(original,package,now):
    doc=copy.deepcopy(original);floor=doc['floors']['2F'];other=copy.deepcopy({k:v for k,v in doc['floors'].items() if k!='2F'})
    source=copy.deepcopy(floor['source_preview']);accepted=copy.deepcopy(floor['accepted_preview']);decision=copy.deepcopy(floor['owner_decision_ref'])
    assert accepted is decision is None
    pending=copy.deepcopy(floor['pending_saved_candidate']);candidate=package['results']['candidate']
    assert pending['triangles']==candidate['triangles']==39334 and pending['source_sha256']==candidate['obj_sha256']==MODEL
    assert pending['strict26']=='FAIL' and pending['strict26_report_sha256']==GUARD and pending['native']==pending['full_signed']=='NOT_RUN'
    assert pending['numerical_K1_qualified'] is None and package['remaining_target_instances']==26081
    assert candidate['counts']==dict(flicker_diff=9529,flicker_same=8885,reversed=1,hidden=18318,loose=0,open_edges=10067,cracks=7667)
    floor.setdefault('prior_displayed_candidates',[]).append({k:copy.deepcopy(floor.get(k)) for k in ('candidate_preview','output_triangles','latest_saved_candidate','error_census','evidence_refs')})
    pending.update(independent_validation='FAIL_STRICT26_COMPONENT',native='NOT_RUN',full_signed='NOT_RUN',full_signed_preservation='NOT_RUN',preservation_passed=False,
        acceptance=False,source_candidate_sha256=MODEL,candidate_preview=candidate['preview'],inspection_published=True,remaining_problems=candidate['counts'],
        remaining_target_instances=26081,remaining_reversed_faces=1,numerical_K1_qualified=None,repair_complete=False,client_qa_sha256=CERTIFICATE_SHA)
    floor.setdefault('pending_candidate_history',[]).append(copy.deepcopy(floor['pending_saved_candidate']))
    floor.pop('pending_saved_candidate');floor.pop('pending_output_triangles',None);floor['latest_saved_candidate']=pending
    for key in ('validation_proof','signed_validation_sha256','validator_texture_preservation_passed','validator_nothing_deleted_passed','validator_pixel_floor_passed',
                'retained_floor_passed','retained_floor_sha256','native_preservation_passed','native_qualified_changed_pixels','native_qualified_total_views','native_qualified_views',
                'native_readback_sha256','native_diagnostic_changed_pixels','native_qualified_passed','native_validation','native_component_validation','full_signed_validation_sha256'):
        floor.pop(key,None)
    census=copy.deepcopy(floor.get('error_census',{}));census.update(job_id='MAIN-INFRA-2F-NATIVE14-INDEPENDENT-20261027',after_counts=candidate['counts'],
        candidate_obj_sha256=MODEL,after_triangles=39334,after_map_sha256=candidate['errors_sha256'],complete=True,accepted=False);floor['error_census']=census
    floor.update(candidate_preview=candidate['preview'],output_triangles=39334,inspection_published=True,inspection_acceptance=False,publication_eligible=False,accepted=False,
        inspection_receipt_sha256=PACKAGE_SHA,inspection_candidate_sha256=MODEL,inspection_facade_faces=19436,independent_before_triangles=56828,independent_after_triangles=39334,
        inspection_client_qa_sha256=CERTIFICATE_SHA,inspection_client_phase_sha256=CLIENT_PHASE,
        independent_guard_passed=False,independent_guard_sha256=GUARD,independent_readback_sha256=pending.get('independent_readback_sha256'),
        independent_guard_material_change_pixels=1,independent_guard_failed_view_indices=[3],independent_guard_model_pixels=6255399,
        native='NOT_RUN',full_signed='NOT_RUN',preservation_passed=False,signed_targets_passed=False,remaining_target_instances=26081,remaining_reversed_faces=1,
        numerical_K1_qualified=None,validator_passed=False,validator_ref=None,inspection_badge='CURRENT FAILED — UNACCEPTED',
        full_signed_validation=dict(verdict='NOT_RUN',preservation_passed=False,validator_passed=False,candidate_source_sha256=MODEL,acceptance=False),
        state='blocked',step='After displays the current39,334-triangle2F inspection model, nine original textures, seven measured error filters and19,436 facade triangles. Strict26 FAIL:1 material-change pixel in view3;0 holes or movement across6,255,399 model pixels. Native/full signed NOT_RUN; K1 qualification unresolved.26,081 overlap/crack instances plus1 reversed face remain. CURRENT FAILED; unaccepted, not final.',
        blocker='Current39334 strict26 FAIL1 material pixel(view3), native/full signed NOT_RUN;26,081 overlap/crack instances plus1 reversed face remain. No old38110 pass applies.',last_work_event_at=now)
    floor['evidence_refs']=[package['public_summary_url']]
    floor.setdefault('activity_events',[]).append(dict(at=now,phase='current39334_failed_inspection_published',message='14 assets verified in both static roots and byHTTP; actual offline client39334/9textures/7maps/19436facade IDs checked. Current strictFAIL retained; native/full signed NOT_RUN/K1null. Previous38110 archived; no final-clean or acceptance claim.'))
    assert floor['source_preview']==source and floor['accepted_preview']==accepted and floor['owner_decision_ref']==decision
    assert other=={k:v for k,v in doc['floors'].items() if k!='2F'}
    doc['updated_at']=doc['last_work_event_at']=now
    return doc

def write_cas(path,raw,doc,writer,loader):
    assert Path(path).read_bytes()==raw,'Concurrent canonical change; reload required'
    writer(path,doc);fresh=loader(path);assert fresh==doc
    return fresh

def main():
    p=argparse.ArgumentParser();p.add_argument('--client-qa-sha256',required=True);a=p.parse_args()
    package_path=ROOT/'data/i2c/package.json';assert sha(package_path)==PACKAGE_SHA
    package=json.loads(package_path.read_bytes());qpath=OPS/'client-qa-certificate.json';assert sha(qpath)==a.client_qa_sha256;verify_certificate(json.loads(qpath.read_bytes()))
    deployed=json.loads((OPS/'deployment-receipt.json').read_bytes())
    assert deployed['files_per_root']==deployed['http_hashes']==14 and deployed['candidate_triangles']==39334 and deployed['remaining_target_counts']==26081
    assert deployed['archive_sha256']==ARCHIVE_SHA and deployed['package_sha256']==PACKAGE_SHA and deployed['client_qa_sha256']==a.client_qa_sha256
    assert deployed['strict_passed'] is False and deployed['strict_guard_sha256']==GUARD and deployed['native']==deployed['full_signed']=='NOT_RUN'
    assert deployed['numerical_K1_qualified'] is None and deployed['preservation_passed'] is deployed['accepted'] is deployed['status_written'] is False
    for row in package['files']:
        path=ROOT/'data/i2c/s'/row['path'];assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
    writer=ROOT/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023/tools/main_infra_progress.py';assert sha(writer)=='b7aca8d75355af86202be6782d08509efe81668007d596b4ac3e77bd7d872cea'
    sys.path.insert(0,str(writer.parent));from main_infra_progress import load_progress,write_progress,utc_now
    path=ROOT/'data/main-infra-fresh/current.json';raw=path.read_bytes();original=load_progress(path);doc=bind_document(original,package,utc_now())
    draft=OPS/'inspection-39334-current.draft.json';assert not draft.exists();draft.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8')
    subprocess.run(['node',str(ROOT/'data/siege-live-20261026/check-status-current.mjs'),str(draft)],check=True)
    fresh=write_cas(path,raw,doc,write_progress,load_progress)
    assert all(fresh['floors'][k]==v for k,v in original['floors'].items() if k!='2F')
    result=dict(displayed_2F=39334,measured_filters=7,facade_triangles=19436,strict26='FAIL',native='NOT_RUN',full_signed='NOT_RUN',remaining_overlap_crack=26081,remaining_reversed_faces=1,
        numerical_K1_qualified=None,accepted=False,other_floors_unchanged=True,source_and_accepted_refs_unchanged=True,canonical_sha256=sha(path))
    with (OPS/'inspection-39334-selection-readback.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
