import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path

GUARD='39cf94629dfa590c42366b5786d9c7f9b56b6a75c86fd01da4c5c633c6a74a67'
CENSUS='e58ad15f874c15ee712f7c7ee6a0558f1f33299610ea25c147e1d9d8f1f8868b'
PROFILE='2050e60c1d613f1df559b23291262249d754009e47d3848fdb7bb6d9abfdcf4f'
TERMINAL='1d2a2a499156205d17b2a9b9635a0c99f7cb0e4515df9a97cc34ea0e82c60fae'
HEAD='7eed76b2630077b21a7576f9ccc0ed230a36f934'
LEASE_KEYS={'monitor_pid','monitor_creation_utc','nonce','lease_acquired_utc','ended_utc','coordination_sha256','exclusive_operator','original_phase_sha256','profile_sha256','lease_released'}


def need(value,message):
    if not value:raise ValueError(message)


def instant(value):
    result=datetime.fromisoformat(value.replace('Z','+00:00'));need(result.tzinfo is not None,'UTC process/lease timestamps required');return result


def qualify(d):
    success=d['census'];events=d['events'];current=d['current']
    need(d['census_sha256']==TERMINAL and success['state']=='PROCESS_EXITED_ZERO' and type(success['actual_pid']) is int
         and success['actual_pid']==37992 and success['actual_creation_utc']=='2026-10-27T10:41:56.3612855Z'
         and type(success['actual_exit_code']) is type(success['launcher_exit_code']) is int
         and success['actual_exit_code']==success['launcher_exit_code']==0 and success['all_owned_exited'] is True
         and success['abort_reason'] is None and success['phase_plan_sha256']==CENSUS and success['HEAD']==HEAD,'Original successful census chain differs')
    need(len(events)>=2,'Both original no-start HOLDs must remain in the pinned chain')
    previous=None;nonces=set();monitors=set()
    for event in events:
        lease=event['lease'];gate=event['gate'];coord=event['coord'];zero=event['zero'];hold=event['hold']
        need(hold.get('no_phase_started') is True and hold==dict(state='HOLD',no_phase_started=True,reason='Three fresh single-owner launch samples below8GiB')
             and sorted(event['files'])==['launch-gate.json','result.json'],'Only complete no-start memory HOLD artifacts qualify')
        need(set(lease)==LEASE_KEYS and lease==event['identity'] and lease['lease_released'] is True
             and type(lease['monitor_pid']) is int and lease['monitor_pid']>0 and lease['nonce'] and lease['nonce'] not in nonces
             and (lease['monitor_pid'],lease['monitor_creation_utc']) not in monitors
             and lease['original_phase_sha256']==GUARD and lease['profile_sha256']==PROFILE
             and lease['exclusive_operator']=='/root/upper_floor_resume','Exact pinned released HOLD identity differs')
        nonces.add(lease['nonce']);monitors.add((lease['monitor_pid'],lease['monitor_creation_utc']))
        need(instant(lease['monitor_creation_utc'])<=instant(lease['lease_acquired_utc'])<=instant(lease['ended_utc'])
             and (previous is None or instant(previous['ended_utc'])<=instant(lease['monitor_creation_utc'])),'Ordered monitor/lease chronology required')
        need(gate['original_phase_sha256']==GUARD and gate['profile_sha256']==PROFILE and gate['passed'] is False
             and gate['require8GiB'] is True and type(gate['maximum_heavy_phases']) is int and gate['maximum_heavy_phases']==1
             and len(gate['samples'])==3,'Original failed three-sample launch gate differs')
        times=[];headrooms=[]
        for row in gate['samples']:
            need(all(type(row[key]) is int for key in ('commit_bytes','limit_bytes','headroom_bytes'))
                 and row['headroom_bytes']==row['limit_bytes']-row['commit_bytes'] and row['headroom_bytes']>=0,'Launch sample arithmetic differs')
            times.append(instant(row['utc']));headrooms.append(row['headroom_bytes'])
        need(times==sorted(set(times)) and instant(lease['lease_acquired_utc'])<=times[0]<=times[-1]<=instant(lease['ended_utc'])
             and any(value<8*2**30 for value in headrooms),'A genuine failed three-fresh-8GiB gate is required')
        need(event['coord_sha256']==lease['coordination_sha256'] and coord['coordinator']=='/root'
             and coord['exclusive_operator']==lease['exclusive_operator'] and coord['all_model_operators_paused'] is True
             and coord['active_owner_geometry_workers']==[] and coord['phase_sha256']==GUARD and coord['nonce']==lease['nonce'],
             'Pinned HOLD coordination differs')
        need(zero['active_owner_geometry_workers']==[] and all(row['owner_geometry'] is False for row in zero['rows']),'Historical native zero-owner proof differs')
        if previous is None:
            prior=zero.get('prior_released_lease',{})
            need(zero.get('prior_terminal_sha256')==TERMINAL and zero.get('all_other_operators_paused') is True
                 and prior.get('lease_released') is True and prior.get('original_phase_sha256')==CENSUS,'First HOLD must follow original successful census')
        else:
            predecessor=event['predecessor']
            need(zero.get('original_HOLD_monitor_alive') is False and zero.get('predecessor_qualification_sha256')==event['predecessor_sha256']
                 and predecessor['predecessor_qualified'] is True and predecessor['model_started'] is False and predecessor['acceptance'] is False
                 and predecessor['guard_phase_sha256']==GUARD and predecessor['held_nonce']==previous['nonce']
                 and predecessor['current_released_lease']==previous,'No skipped, reordered or started predecessor may enter the HOLD chain')
        previous=lease
    need(current==previous and current['lease_released'] is True and type(current['monitor_pid']) is int,'Current global lease must equal exact last pinned released HOLD')
    return dict(predecessor_qualified=True,model_started=False,acceptance=False,hold_count=len(events),guard_phase_sha256=GUARD,
        held_nonce=previous['nonce'],current_released_lease=current,minimum_new_launch_headroom_bytes=8*2**30,fresh_new_launch_samples=3,
        maximum_owned_private_or_peak_bytes=3*2**30,minimum_running_system_headroom_bytes=int(3.5*2**30),fresh_native_zero_owner_and_Root_slot_still_required=True)


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def read_pin(pin):
    need(sha(pin['path'])==pin['sha256'],'Pinned chain metadata changed: '+pin['path']);return json.loads(Path(pin['path']).read_bytes())


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--spec',type=Path,required=True);parser.add_argument('--spec-sha256',required=True)
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args();need(sha(args.spec)==args.spec_sha256,'Chain spec changed')
    spec=json.loads(args.spec.read_bytes());need(spec['mode']=='2F39334_GUARD_NO_START_HOLD_CHAIN_V1' and spec['HEAD']==HEAD
        and args.out.resolve().parent==args.spec.resolve().parent and Path(spec['current_lease']).resolve()==Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/data/siege-live-20261026/single-owner-8gib.lock').resolve(),'Exact owned guard-only chain scope required')
    for pin in spec['pins']:need(sha(pin['path'])==pin['sha256'],'Chain source/provenance pin changed: '+pin['path'])
    need(sha(spec['current_lease'])==spec['current_lease_sha256'],'Last released global lease bytes changed')
    events=[]
    for row in spec['events']:
        event={key:read_pin(pin) for key,pin in row['documents'].items()};event.update(identity=row['identity'],coord_sha256=row['documents']['coord']['sha256'])
        event['files']=sorted(path.name for path in Path(row['monitor']).iterdir())
        if 'predecessor' in row['documents']:event['predecessor_sha256']=row['documents']['predecessor']['sha256']
        events.append(event)
    result=qualify(dict(census=read_pin(spec['census']),census_sha256=spec['census']['sha256'],events=events,current=json.loads(Path(spec['current_lease']).read_bytes())))
    need(sha(spec['current_lease'])==spec['current_lease_sha256'],'Current lease changed during chain qualification')
    result.update(spec_sha256=args.spec_sha256,current_lease_sha256=spec['current_lease_sha256'])
    with args.out.open('x',encoding='utf8') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(predecessor_qualified=True,hold_count=len(events),model_started=False,proof=str(args.out),proof_sha256=sha(args.out),acceptance=False)))


if __name__=='__main__':main()
