param([Parameter(Mandatory=$true)][string]$Spec,[Parameter(Mandatory=$true)][string]$SpecSha,[Parameter(Mandatory=$true)][string]$ContinuationGO,[Parameter(Mandatory=$true)][string]$ContinuationGOSha)
$ErrorActionPreference='Stop'
function Check-Pin($pin){if((Get-FileHash -Algorithm SHA256 -LiteralPath $pin.path).Hash.ToLower() -cne $pin.sha256){throw ('Changed continuation pin '+$pin.path)}}
Check-Pin @{path=$Spec;sha256=$SpecSha};Check-Pin @{path=$ContinuationGO;sha256=$ContinuationGOSha}
$specDoc=Get-Content -Raw -LiteralPath $Spec|ConvertFrom-Json -DateKind String
$grant=Get-Content -Raw -LiteralPath $ContinuationGO|ConvertFrom-Json -DateKind String
$scriptPath=$PSCommandPath
if($grant.Root_FULL_continuation_source_and_slot_GO -cne $true -or $grant.operator -cne '/root/upper_floor_resume' -or $grant.spec_sha256 -cne $SpecSha -or $grant.guard_phase_sha256 -cne '39cf94629dfa590c42366b5786d9c7f9b56b6a75c86fd01da4c5c633c6a74a67' -or $grant.all_other_model_operators_paused -cne $true -or -not $grant.nonce -or $grant.acceptance -cne $false){throw 'New exact Root continuation source and exclusive-slot GO required'}
Check-Pin $grant.admission_script
if([IO.Path]::GetFullPath($grant.admission_script.path) -ine [IO.Path]::GetFullPath($scriptPath)){throw 'Reviewed continuation script path differs'}
$main='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$root=Join-Path $main '.claude/worktrees/v2n'
$ops=Split-Path $Spec
if([IO.Path]::GetFullPath($ops) -ine [IO.Path]::GetFullPath((Join-Path $root 'data/iv2n-preflight/guard-hold-chain-v1'))){throw 'Owned continuation namespace required'}
if((git -C $root rev-parse HEAD).Trim() -cne '7eed76b2630077b21a7576f9ccc0ed230a36f934' -or (git -C $root status --porcelain --untracked-files=no)){throw 'Original frozen HEAD/tracked source changed'}
foreach($pin in $specDoc.pins){Check-Pin $pin}
Check-Pin $specDoc.original_root_admission
$receipt=Get-Content -Raw -LiteralPath $specDoc.original_root_admission.path|ConvertFrom-Json -DateKind String
if($receipt.source_phase_GO -cne $true -or $receipt.operator -cne '/root/upper_floor_resume' -or $receipt.approval.sha256 -cne '083f880c5356f45955baf70ac11aa79976620be953e0b04058aeb28d152c1e40' -or $receipt.envelopes.guard.sha256 -cne 'f91aeed21eb2733f40f7604ecbfcdf211fc57bf5bb7bd43efe60b3be92b104ac'){throw 'Exact original guard Root admission required'}
Check-Pin $receipt.profile;Check-Pin $receipt.approval;Check-Pin $receipt.envelopes.guard
$envelope=Get-Content -Raw -LiteralPath $receipt.envelopes.guard.path|ConvertFrom-Json -DateKind String
Check-Pin $envelope.original_phase
if($envelope.original_phase.sha256 -cne $grant.guard_phase_sha256){throw 'Original guard phase differs'}
$stamp=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfff')
$attempt=Join-Path $ops ('attempt-'+$grant.nonce+'.json')
$attemptFile=[IO.File]::Open($attempt,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try{$bytes=[Text.Encoding]::UTF8.GetBytes((@{spec_sha256=$SpecSha;Root_GO_sha256=$ContinuationGOSha;attempted_utc=[DateTime]::UtcNow.ToString('o');one_attempt_only=$true}|ConvertTo-Json -Compress));$attemptFile.Write($bytes,0,$bytes.Length);$attemptFile.Flush($true)}finally{$attemptFile.Dispose()}
$qualification=Join-Path $ops ('predecessor-qualification-'+$stamp+'.json')
$env:PYTHONPATH=$root
& (Join-Path $main '.venv/Scripts/python.exe') -B $specDoc.qualifier.path --spec $Spec --spec-sha256 $SpecSha --out $qualification
if($LASTEXITCODE -ne 0){throw 'Original no-start HOLD predecessor qualification refused'}
$qualified=Get-Content -Raw -LiteralPath $qualification|ConvertFrom-Json -DateKind String
if($qualified.predecessor_qualified -cne $true -or $qualified.model_started -cne $false -or $qualified.acceptance -cne $false){throw 'No-start predecessor proof required'}
$observer=$specDoc.observer.path;Check-Pin $specDoc.observer
. $observer -FunctionsOnly
$rows=@();$originalHoldMonitorAlive=$false
$heldMonitors=@($specDoc.events|ForEach-Object {$_.identity})
$heldIds=@($heldMonitors|ForEach-Object {$_.monitor_pid})
foreach($entry in [UcE7ExecNative]::Processes()){
 if($entry.Name -notmatch '^(python|pythonw|blender)\.exe$' -and $entry.Pid -notin $heldIds){continue}
 $proc=Get-Process -Id $entry.Pid -ErrorAction SilentlyContinue
 if(-not $proc){continue}
 try{
  $handle=$proc.Handle;if(-not [UcE7ExecNative]::Alive($handle)){continue}
  $command=[UcE7ExecNative]::Command($handle);$times=[UcE7ExecNative]::Times($handle)
  foreach($held in $heldMonitors){if($entry.Pid -eq $held.monitor_pid -and $times[0].ToString('o') -ceq $held.monitor_creation_utc){$originalHoldMonitorAlive=$true}}
  $owner=($entry.Name -match '^blender\.exe$') -or ($command -match '(?i)-m\s+tools\.(main_infra|repair_fresh_main_infra)') -or ($command -match '(?i)\s[^\s]*main[_-]infra[^\s]*\.py\b')
  $rows += [pscustomobject]@{pid=$entry.Pid;parent=$entry.Parent;name=$entry.Name;birth_utc=$times[0].ToString('o');command=$command;owner_geometry=$owner}
 }catch{if($proc.HasExited){continue};throw}
}
$active=@($rows|Where-Object owner_geometry)
$zeroProof=Join-Path $ops ('native-zero-owner-'+$stamp+'.json')
Write-ExecJson $zeroProof @{observed_utc=[DateTime]::UtcNow.ToString('o');rows=$rows;active_owner_geometry_workers=$active;original_HOLD_monitor_alive=$originalHoldMonitorAlive;predecessor_qualification=$qualification;predecessor_qualification_sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $qualification).Hash.ToLower();Root_continuation_GO_sha256=$ContinuationGOSha}
if($active.Count -ne 0 -or $originalHoldMonitorAlive){throw 'Native owner or original HOLD monitor still active; no launch'}
Check-Pin @{path=$specDoc.current_lease;sha256=$specDoc.current_lease_sha256}
$prewarm=@()
if($specDoc.minimum_stable_prewarm_headroom_bytes -ne 8.5GB){throw 'Reviewed extra8.5GiB readiness margin differs'}
for($i=0;$i -lt 3;$i++){
 $memory=[UcE7ExecNative]::SystemMemory()
 $prewarm += [pscustomobject]@{utc=[DateTime]::UtcNow.ToString('o');commit_bytes=$memory[0];limit_bytes=$memory[1];headroom_bytes=$memory[1]-$memory[0]}
 if($i -lt 2){Start-Sleep -Milliseconds 500}
}
$ready=@($prewarm|Where-Object {$_.headroom_bytes -lt 8.5GB}).Count -eq 0
$prewarmProof=Join-Path $ops ('prewarm-readiness-'+$stamp+'.json')
Write-ExecJson $prewarmProof @{ready=$ready;minimum_headroom_bytes=8.5GB;samples=$prewarm;global_lease_not_opened=$true;original_three_fresh8GiB_launch_gate_unchanged=$true}
if(-not $ready){Write-Output ('READINESS_HOLD_NO_LEASE '+$prewarmProof);exit 3}
$coord=Join-Path $ops ('coordination-guard-'+$stamp+'.json')
Write-ExecJson $coord @{coordinator='/root';exclusive_operator='/root/upper_floor_resume';observed_utc=[DateTime]::UtcNow.ToString('o');nonce=[guid]::NewGuid().ToString();active_owner_geometry_workers=@();all_model_operators_paused=$true;phase_sha256=$envelope.original_phase.sha256;native_zero_owner_proof=$zeroProof;native_zero_owner_proof_sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $zeroProof).Hash.ToLower();delegated_Root_single_slot_grant=$true;Root_continuation_GO_sha256=$ContinuationGOSha}
$profile=Get-Content -Raw -LiteralPath $receipt.profile.path|ConvertFrom-Json -DateKind String
foreach($code in @($profile.launcher,$profile.helper,$profile.original_wrapper,$profile.native_observer)){Check-Pin $code}
Check-Pin @{path=$ContinuationGO;sha256=$ContinuationGOSha};Check-Pin @{path=$Spec;sha256=$SpecSha}
$ps7='C:/Users/Future26/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
& $ps7 -NoProfile -File $profile.launcher.path -Envelope $receipt.envelopes.guard.path -EnvelopeSha $receipt.envelopes.guard.sha256 -ApprovalFile $receipt.approval.path -ApprovalSha $receipt.approval.sha256 -CoordinationFile $coord -CoordinationSha (Get-FileHash -Algorithm SHA256 -LiteralPath $coord).Hash.ToLower()
exit $LASTEXITCODE
