from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
deployment=json.loads((root/'data/siege-live-20261026/inspection-10573-deployment.log').read_text(encoding='utf-8-sig').strip())
assert deployment['files_per_root']==deployment['http_hashes']==26 and deployment['preservation']=='PENDING' and deployment['accepted'] is False
p=root/'data/p573/packet-receipt.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='832f3293d9fae6ae9d86b734d51b322f5a8a02340db28839e68dfb3698098efc'
packet=json.loads(p.read_bytes());candidate=packet['results']['candidate'];assert candidate['n_faces']==10573 and candidate['facade_faces']==6602 and packet['results']['source']['facade_faces']==6506
sys.path.insert(0,str(root/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
path=root/'data/main-infra-fresh/current.json';doc=load_progress(path);f=doc['floors']['1F'];now=utc_now()
other=json.dumps({k:v for k,v in doc['floors'].items() if k!='1F'},sort_keys=True)
assert f['output_triangles']==10571 and f['pending_output_triangles']==10573 and f['accepted_preview'] is None
f.setdefault('prior_displayed_candidates',[]).append(f['latest_saved_candidate'])
f['latest_saved_candidate']=dict(engine='E5',run_id='MAIN-INFRA-1F-10571-E5-PARTIAL-20261026',builder_commit='c8fe287236cc1aefac16c73ea263bf001ab678b2',triangles=10573,base_triangles=10571,original_triangles=15856,planned_edits=4,kept_edits=4,rolled_back_edits=0,protected_original_parents=754,source_candidate_sha256=candidate['obj_sha256'],engine_candidate_sha256='446bd02d5d07a9352bd7aa4e34ba27ff1e7720ecdce38600eaf54d98c99fef74',checkpoint_sha256='c6e2d803c32293afd6865d1e70cd0a597f3242b1a240b5c16015ab67b487622e',independent_validation='exact_binding_and_census_complete_preservation_pending',preservation_passed=None,full_signed='PENDING',full_signed_preservation='PENDING',remaining_problems=candidate['counts'],displayed_candidate_triangles=10573,acceptance=False)
evidence=deployment['preview'].rsplit('/',1)[0]+'/evidence-10573/'
f.update(source_preview=deployment['source_preview'],candidate_preview=deployment['preview'],output_triangles=10573,state='validating',independent_before_triangles=15856,independent_after_triangles=10573,independent_validator_stage='census_complete_10573_preservation_pending',independent_validator_worker_pid=59800,independent_validator_worker_alive=False,
    independent_guard_passed=None,independent_guard_sha256=None,native_preservation_passed=None,native_readback_sha256=None,native_qualified_changed_pixels=None,native_qualified_total_views=None,retained_floor_passed=None,retained_floor_sha256=None,
    validator_passed=None,validator_texture_preservation_passed=None,validator_nothing_deleted_passed=None,validator_pixel_floor_passed=None,signed_validation_sha256=None,validator_ref=None,
    evidence_refs=[evidence+n for n in ('append-boundary.json','census-before.raw.json','census-after.raw.json','census-receipt.json','checkpoint.json','terminal.json')],inspection_published=True,inspection_acceptance=False,inspection_receipt_sha256='832f3293d9fae6ae9d86b734d51b322f5a8a02340db28839e68dfb3698098efc',
    step='After displays newest1F10573 with matching seven error filters and all6602 measured facade IDs.4 exact partial-overlap cuts kept. Fresh census5196 target instances; independent strict/native/full signed preservation pending.',
    blocker='Preservation for10573 is pending. Fresh target counts:1704different-look overlaps,1155same-look overlaps,2337cracks. Four different-look pairs removed but two cracks added; net2 fewer instances. Owner-approved orange-box cleanup follows as a separate version.',last_work_event_at=now)
for key in ('pending_output_triangles','pending_source_candidate_sha256','pending_engine_candidate_sha256','pending_checkpoint_sha256','pending_saved_candidate'):f.pop(key,None)
f.setdefault('activity_events',[]).append(dict(at=now,phase='inspection_10573_published',message='Actual10573 SOURCE model and7originalassets plus matching source/candidate7kind/facade maps and6real evidence files verified in both static roots and26HTTP hashes.26public model files; packet receipt private. Preservation PENDING/targets5196/notaccepted; no10571PASSinherited.'))
assert f['accepted_preview'] is None and f['owner_decision_ref'] is None and other==json.dumps({k:v for k,v in doc['floors'].items() if k!='1F'},sort_keys=True)
doc['updated_at']=now;doc['last_work_event_at']=now
draft=root/'data/siege-live-20261026/inspection-10573-current.draft.json';draft.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8')
code="import fs from 'node:fs';import {parseFreshMainInfraStatus} from './dashboard/lib/buildings/freshMainInfraStatus.ts';import {freshFloorStages} from './dashboard/lib/buildings/freshMainInfraPipeline.ts';const d=parseFreshMainInfraStatus(JSON.parse(fs.readFileSync(process.argv[1],'utf8')));if(!d||d.floors['1F'].output_triangles!==10573||d.floors['1F'].accepted_preview!==null)process.exit(2);const p=d.floors['1F'];const s=freshFloorStages({before:15856,after:10573,sourceErrors:{},afterErrors:p.latest_saved_candidate.remaining_problems,candidateSha:p.latest_saved_candidate.source_candidate_sha256,progress:p});if(s[5].summary.includes('Preservation PASS'))process.exit(3);"
subprocess.run(['node','--input-type=module','-e',code,str(draft)],cwd=root/'.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023',capture_output=True,check=True)
write_progress(path,doc)
print(json.dumps(dict(displayed_1F=10573,measured_error_kinds=7,source_facade_ids=6506,candidate_facade_ids=6602,preservation='PENDING',remaining_targets=5196,other_floors_unchanged=True,accepted=False)))
