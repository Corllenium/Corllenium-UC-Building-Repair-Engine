from pathlib import Path
import hashlib,json,os,tarfile,tempfile
from urllib.request import Request,urlopen
from urllib.parse import quote

A=Path('/tmp/main-infra-inspection-10573.tar');M=Path('/tmp/main-infra-inspection-10573.json')
archive_sha='67e1208bd79746d2d93a40c3644c2e568deb536dba468f1cf2492d2e6c89e366'
assert hashlib.sha256(A.read_bytes()).hexdigest()==archive_sha
m=json.loads(M.read_bytes())
assert m['archive_sha256']==archive_sha and m['candidate_triangles']==10573 and m['source_triangles']==15856
assert m['remaining_target_counts']==5196 and m['preservation']=='PENDING' and m['signed_targets_passed'] is m['acceptance'] is False
expected={r['path']:r for r in m['files']};assert len(expected)==len(m['files'])==27
prefix='models/main-infra/7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511/1F/main-infra-clean-20261023/'
public={p:r for p,r in expected.items() if p.startswith(prefix)}
assert len(public)==26 and set(expected)-set(public)=={'packet-receipt.json'}
assert all('..' not in p and '\\' not in p and not p.startswith('/') for p in expected)
def fetch(url):
    with urlopen(Request(url,headers={'Cache-Control':'no-cache'}),timeout=25) as response:
        assert response.status==200;return response.read()
health_before=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
assert health_before['sha']=='cedb7c53c35b0599585c17b214f3c29e1dfb7b9f' and health_before['db']['ok']
with tarfile.open(A) as tf:
    members=tf.getmembers();assert len(members)==27 and len({v.name for v in members})==27 and all(v.isfile() and v.name in expected for v in members)
    data={v.name:tf.extractfile(v).read() for v in members}
    assert all(len(b)==expected[p]['bytes'] and hashlib.sha256(b).hexdigest()==expected[p]['sha256'] for p,b in data.items())
packet=json.loads(data['packet-receipt.json'])
assert hashlib.sha256(data['packet-receipt.json']).hexdigest()==m['receipt_sha256']=='832f3293d9fae6ae9d86b734d51b322f5a8a02340db28839e68dfb3698098efc'
assert packet['no_model_parse'] is packet['no_detector_call'] is True and packet['preservation']=='PENDING'
assert packet['results']['candidate']['obj_sha256']=='9d8d3718dcd4f41f84483d0e2e1957cd96ac6a7bcc6627bce94c906d81d71008'
assert packet['results']['candidate']['facade_faces']==6602 and packet['results']['source']['facade_faces']==6506
roots=[Path('/home/devenvir/corllenium/web'),Path('/home/devenvir/corllenium/app/public')]
def install_exclusive(target,b,sha):
    if target.exists():
        assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==sha;return
    target.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.codex-inspection-10573-',dir=target.parent)
    try:
        with os.fdopen(fd,'wb') as stream:stream.write(b);stream.flush();os.fsync(stream.fileno())
        os.chmod(tmp,0o644)
        try:os.link(tmp,target)
        except FileExistsError:assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==sha
    finally:os.unlink(tmp)
for root in roots:
    assert root.resolve()==root
    for rel,row in public.items():
        target=root/rel;assert root in target.resolve().parents
        if target.exists():assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256']
for root in roots:
    for rel,row in public.items():
        install_exclusive(root/rel,data[rel],row['sha256']);assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==row['sha256']
for rel,row in public.items():assert hashlib.sha256(fetch('https://corllenium.ai.dev-environment.site/'+quote(rel,safe='/')+'?inspection=10573-20261026')).hexdigest()==row['sha256']
install_exclusive(Path('/home/devenvir/corllenium/data/codex-inspection-10573-packet.json'),data['packet-receipt.json'],m['receipt_sha256'])
health_after=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
assert health_after['sha']==health_before['sha'] and health_after['db']['ok']
receipt=dict(files_per_root=26,http_hashes=26,private_packet_receipt=True,preview=m['results']['candidate']['preview'],source_preview=m['results']['source']['preview'],source_triangles=15856,candidate_triangles=10573,source_facade_faces=6506,candidate_facade_faces=6602,preservation='PENDING',remaining_target_counts=5196,signed_targets_passed=False,accepted=False,archive_sha256=archive_sha,no_app_restart=True,api_sha_before_after=health_after['sha'],status_written=False)
raw=(json.dumps(receipt,sort_keys=True)+'\n').encode()
install_exclusive(Path('/home/devenvir/corllenium/data/codex-inspection-10573-deployment.json'),raw,hashlib.sha256(raw).hexdigest())
print(json.dumps(receipt))
