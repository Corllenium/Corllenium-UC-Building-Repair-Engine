from pathlib import Path
import hashlib,json,os,tarfile,tempfile
from urllib.request import Request,urlopen
from urllib.parse import quote
A=Path('/tmp/main-infra-inspection-26291.tar.gz')
M=Path('/tmp/main-infra-inspection-26291.json')
archive_sha='ec80d704f525949f98adff1df4e614c7e51564d4c878afaa8b05983d9fce71e9'
assert hashlib.sha256(A.read_bytes()).hexdigest()==archive_sha
assert hashlib.sha256(M.read_bytes()).hexdigest()=='e3ec33eda52e526caa38aec69a7ef5656d88860723197141d09e70b2d7df0f2b'
m=json.loads(M.read_bytes())
assert m['archive_sha256']==archive_sha and m['floor']=='6F' and m['profile']=='6f-26291'
assert m['inspection_assets_only']is m['not_final']is True and m['accepted']is False
assert m['remaining_target_instances']==12887 and m['results']['candidate']['triangles']==26291
assert m['results']['candidate']['obj_sha256']=='47feb1846f0f9993690a2f6fa11860f830a712dfd517811ce0f12c20f018f4b4'
assert m['facade_layer']['count']==17855
prefix='models/main-infra/7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511/6F/main-infra-clean-20261023/candidate/'
expected={v['path']:v for v in m['files']}
assert len(expected)==len(m['files'])==16 and all(v.startswith(prefix)and'..'not in v and'\\'not in v for v in expected)
roots=[Path('/home/devenvir/corllenium/web'),Path('/home/devenvir/corllenium/app/public')]
def fetch(url):
    with urlopen(Request(url,headers={'Cache-Control':'no-cache'}),timeout=25) as response:
        assert response.status==200
        return response.read()
health_before=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
assert health_before['sha']=='cedb7c53c35b0599585c17b214f3c29e1dfb7b9f' and health_before['db']['ok']
with tarfile.open(A,'r:gz') as tf:
    members=tf.getmembers()
    assert len(members)==16 and all(v.isfile() and v.name in expected for v in members)
    data={v.name:tf.extractfile(v).read() for v in members}
    assert len(data)==16 and all(len(b)==expected[p]['bytes'] and hashlib.sha256(b).hexdigest()==expected[p]['sha256'] for p,b in data.items())
    for root in roots:
        assert root.resolve()==root
        for rel,b in data.items():
            target=root/rel
            assert root in target.resolve().parents
            if target.exists():
                assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256'],rel
    for root in roots:
        for rel,b in data.items():
            target=root/rel
            if not target.exists():
                target.parent.mkdir(parents=True,exist_ok=True)
                fd,tmp=tempfile.mkstemp(prefix='.codex-inspection-26291-',dir=target.parent)
                try:
                    with os.fdopen(fd,'wb') as stream:
                        stream.write(b);stream.flush();os.fsync(stream.fileno())
                    os.chmod(tmp,0o644)
                    try:
                        os.link(tmp,target)
                    except FileExistsError:
                        assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256']
                finally:
                    os.unlink(tmp)
            assert hashlib.sha256(target.read_bytes()).hexdigest()==expected[rel]['sha256']
for rel,row in expected.items():
    b=fetch('https://corllenium.ai.dev-environment.site/'+quote(rel,safe='/')+'?inspection=26291-20261027')
    assert hashlib.sha256(b).hexdigest()==row['sha256'],rel
health_after=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
assert health_after['sha']==health_before['sha'] and health_after['db']['ok']
receipt=dict(files_per_root=16,http_hashes=16,preview=m['results']['candidate']['preview'],candidate_triangles=26291,preservation_passed=False,strict_passed=True,native_qualified_passed=True,full_signed='FAIL',native_diagnostic_changed_pixels=23,signed_targets_passed=False,remaining_target_counts=12887,accepted=False,archive_sha256=archive_sha,no_app_restart=True,api_sha_before_after=health_after['sha'],status_written=False,installer='exclusive hardlink; different existing bytes refused')
Path('/home/devenvir/corllenium/data/codex-inspection-26291-20261027-receipt.json').write_text(json.dumps(receipt)+'\n')
print(json.dumps(receipt))
