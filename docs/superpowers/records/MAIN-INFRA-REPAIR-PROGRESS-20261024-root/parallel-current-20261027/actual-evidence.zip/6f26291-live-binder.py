from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

root = Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
ops = root/'data/siege-live-20261026'
package_path = root/'data/l6n/package.json'
assert hashlib.sha256(package_path.read_bytes()).hexdigest() == 'e3ec33eda52e526caa38aec69a7ef5656d88860723197141d09e70b2d7df0f2b'
package = json.loads(package_path.read_bytes())
receipt = json.loads((ops/'inspection-26291-deployment.log').read_bytes())
assert receipt['files_per_root'] == receipt['http_hashes'] == 16
assert receipt['candidate_triangles'] == 26291 and receipt['remaining_target_counts'] == 12887
assert receipt['full_signed'] == 'FAIL' and receipt['preservation_passed'] is receipt['accepted'] is receipt['status_written'] is False
assert receipt['archive_sha256'] == package['archive_sha256'] == 'ec80d704f525949f98adff1df4e614c7e51564d4c878afaa8b05983d9fce71e9'
qa = json.loads((root/'data/l6n/client-preview-qa.json').read_bytes())
assert qa['packageSha256'] == hashlib.sha256(package_path.read_bytes()).hexdigest()
assert qa['actualTriangles'] == qa['parsedTriangles'] == 26291
assert qa['mapFaceIdsAndCoordinatesExact'] is True and qa['errorKinds'] == 7 and qa['textureDependencies'] == 11
client_phase = json.loads((root/'.claude/worktrees/v6n/data/26291-inspection-prep/phase-client.json').read_bytes())
assert len(qa['productionClientSourcesUnchanged']) == 3
for source in qa['productionClientSourcesUnchanged']:
    pins = [pin for pin in client_phase['pins'] if Path(pin['path']).name == source['name']]
    assert len(pins) == 1 and pins[0]['sha256'] == source['sha256']
    assert hashlib.sha256(Path(pins[0]['path']).read_bytes()).hexdigest() == source['sha256']
assert qa['facadeOverlay']['triangles'] == 17855 and qa['facadeOverlay']['webgl_or_browser_rendered'] is False
assert qa['accepted'] is False and qa['not_final'] is True
for row in package['files']:
    local = root/'data/l6n/s'/row['path']
    assert hashlib.sha256(local.read_bytes()).hexdigest() == row['sha256']
writer = root/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023/tools/main_infra_progress.py'
assert hashlib.sha256(writer.read_bytes()).hexdigest() == 'b7aca8d75355af86202be6782d08509efe81668007d596b4ac3e77bd7d872cea'
sys.path.insert(0, str(writer.parent))
from main_infra_progress import load_progress, write_progress, utc_now

path = root/'data/main-infra-fresh/current.json'
original_sha = hashlib.sha256(path.read_bytes()).hexdigest()
doc = load_progress(path)
other = copy.deepcopy({key: value for key, value in doc['floors'].items() if key != '6F'})
floor = doc['floors']['6F']
before_preview = floor['source_preview']
component = floor['pending_26291_components']
candidate = package['results']['candidate']
assert component['source_sha256'] == candidate['obj_sha256'] and component['whole_originals'] == 4333
assert component['readback'] == component['strict26'] == component['native'] == 'PASS'
assert component['full_signed'] == component['textures'] == component['visible_coverage'] == component['problems'] == 'FAIL'
assert component['texture_failed_samples'] == 4 and component['texture_failed_faces'] == 2
assert floor['accepted_preview'] is None and floor['owner_decision_ref'] is None
pending = copy.deepcopy(floor['pending_saved_candidate'])
assert pending['triangles'] == 26291 and pending['checkpoint_sha256'] == component['checkpoint_sha256']
floor.setdefault('prior_displayed_candidates', []).append({key: copy.deepcopy(floor.get(key)) for key in
    ('candidate_preview', 'output_triangles', 'latest_saved_candidate', 'error_census', 'full_signed_validation', 'evidence_refs')})
pending.update(independent_validation='PRESERVATION_AND_TARGETS_FAIL', independent_readback='PASS',
    independent_readback_sha256=component['readback_sha256'], default_error_census='MEASURED',
    strict26='PASS', strict26_sha256=component['strict_sha256'], native='PASS', native_sha256=component['native_sha256'],
    native_qualified_changed_pixels=0, native_qualified_views=33, native_diagnostic_changed_pixels=23,
    full_signed='FAIL', full_signed_preservation='FAIL', full_signed_validation_sha256=component['validation_sha256'],
    full_signed_review_sha256=component['independent_review_sha256'], full_signed_texture_samples_failed=4,
    remaining_problems=candidate['counts'], remaining_target_instances=12887, acceptance=False,
    candidate_preview=candidate['preview'], inspection_published=True)
floor.setdefault('pending_candidate_history', []).append(copy.deepcopy(floor['pending_saved_candidate']))
floor.pop('pending_saved_candidate')
floor.pop('pending_output_triangles', None)
floor['latest_saved_candidate'] = pending
old_census = copy.deepcopy(floor['error_census'])
old_census.update(job_id='MAIN-INFRA-6F-26291-INDEPENDENT-20261027',
    after_counts=candidate['counts'], candidate_obj_sha256=candidate['obj_sha256'], after_triangles=26291,
    after_map_sha256=candidate['errors_sha256'], complete=True, accepted=False)
floor['error_census'] = old_census
floor.update(candidate_preview=candidate['preview'], output_triangles=26291, inspection_published=True,
    inspection_acceptance=False, publication_eligible=False, accepted=False,
    inspection_receipt_sha256=hashlib.sha256(package_path.read_bytes()).hexdigest(),
    inspection_candidate_sha256=candidate['obj_sha256'], inspection_facade_faces=17855,
    independent_after_triangles=26291, remaining_target_instances=12887,
    validator_passed=False, validator_texture_preservation_passed=False,
    validator_nothing_deleted_passed=False, validator_pixel_floor_passed=True, validator_ref=None,
    full_signed_validation=dict(summary_ref=package['public_summary_url'], sha256=component['validation_sha256'],
        review_sha256=component['independent_review_sha256'], verdict='FAIL', preservation_passed=False,
        validator_passed=False, candidate_source_sha256=candidate['obj_sha256'], acceptance=False),
    evidence_refs=[package['public_summary_url']], state='blocked',
    step='After displays the new 26,291-triangle 6F model with 11 original textures, seven measured error filters and 17,855 facade triangles. Strict26/native33 passed; signed validation failed four look samples and 12,887 target instances. Unaccepted; not final.',
    blocker='Four texture/look replacement samples on two faces and 12,887 overlap/crack instances remain. This displayed inspection candidate is not a final clean model.')
now = utc_now()
floor['last_work_event_at'] = now
floor.setdefault('activity_events', []).append(dict(at=now, phase='current26291_inspection_published',
    message='16 assets verified in both static roots and by HTTP; actual production client parsed 26,291 triangles, 11 textures, all seven measured maps and 17,855 facade IDs. Signed preservation FAIL is retained; no acceptance or Unity-ready claim.'))
assert floor['source_preview'] == before_preview
assert other == {key: value for key, value in doc['floors'].items() if key != '6F'}
doc['updated_at'] = doc['last_work_event_at'] = now
draft = ops/'inspection-26291-current.draft.json'
draft.write_text(json.dumps(doc, indent=2)+'\n')
subprocess.run(['node', str(ops/'check-status-current.mjs'), str(draft)], check=True)
assert hashlib.sha256(path.read_bytes()).hexdigest() == original_sha, 'Concurrent canonical change; reload required'
write_progress(path, doc)
fresh = load_progress(path)
assert fresh['floors']['6F']['candidate_preview'] == candidate['preview']
assert fresh['floors']['6F']['validator_texture_preservation_passed'] is False
assert other == {key: value for key, value in fresh['floors'].items() if key != '6F'}
result = dict(displayed_6F=26291, measured_filters=7, facade_triangles=17855, strict26='PASS', native33='PASS',
    full_signed='FAIL', preservation='FAIL', failed_look_samples=4, remaining=12887, accepted=False,
    other_floors_unchanged=True, source_preview_unchanged=True,
    canonical_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(ops/'inspection-26291-selection-readback.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
