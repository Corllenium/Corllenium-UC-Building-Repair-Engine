from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

R = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(R / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress, write_progress, utc_now

p = R / 'data/main-infra-fresh/current.json'
original = load_progress(p)
doc = copy.deepcopy(original)
f = doc['floors']['6F']
saved = f['latest_saved_candidate']
assert f['output_triangles'] == saved['triangles'] == 26127 and f['accepted_preview'] is None
assert saved['source_sha256'] == f['inspection_candidate_sha256'] == '5a38f6453f635b9bba64ff25a7a2540a80be1a661dc12a7934a0c8ad659fd548'
report = R / '.claude/worktrees/v6i/data/iv6i/fullsigned/validation.json'
digest = hashlib.sha256(report.read_bytes()).hexdigest()
assert digest == saved['full_signed_validation_sha256'] == 'ca7a9b074594d2b4ab0f4e65f99029d5df3176958f077ab88141a9d24a0aa2ad'
assert json.loads(report.read_bytes())['verdict'] == 'FAIL' and saved['full_signed_preservation'] == 'PASS'
saved.update(source_candidate_sha256=saved['source_sha256'], engine_candidate_sha256=saved['engine_sha256'],
             full_signed_sha256=digest, full_signed='FAIL', full_signed_failure='TARGETS_ONLY')
f['signed_validation_sha256'] = digest
doc['updated_at'] = utc_now()
draft = R / 'data/l6j/pipeline-draft.json'
draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
subprocess.run(['node', str(R / 'data/siege-live-20261026/check-status-current.mjs'), str(draft)], check=True)
assert load_progress(p)['updated_at'] == original['updated_at']
write_progress(p, doc)
actual = load_progress(p)
for floor in original['floors']:
    if floor != '6F':
        assert actual['floors'][floor] == original['floors'][floor]
receipt = dict(candidate_sha256=saved['source_sha256'], validation_sha256=digest,
               displayed=26127, preservation='PASS', overall='FAIL', acceptance=False)
(R / 'data/l6j/pipeline-binding-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
