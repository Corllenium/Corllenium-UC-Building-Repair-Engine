$ErrorActionPreference='Stop'
$taskSite='devenvir@sv70.ifastnet.com'
$taskCommon=@('-i','C:/Users/Future26/.ssh/corllenium_siege_ed25519','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=1','-o','LogLevel=ERROR','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023/deploy/known_hosts')
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskRows=@(
 @{Source="$taskRoot/data/l6j/models.tar.gz";Name='main-infra-6f26127.tar.gz';Sha='01f9d426ff2d5985a892e0a970487adef5fa7f3201f7e80d02dbedf16b91548f'},
 @{Source="$taskRoot/data/l6j/package.json";Name='main-infra-6f26127.json';Sha='bef15b0e5ccbbd3c0143f43bea1e69297992ba9bd43379c2b5cf966bb4766fd4'},
 @{Source="$taskRoot/data/l6j/publish.py";Name='publish-live-6f26127.py';Sha='0964c467552693ce381a9bc1bbfd686de2cbae7ca0208715192932d0cba32298'}
)
foreach($taskRow in $taskRows){
 if((Get-FileHash -Algorithm SHA256 -LiteralPath $taskRow.Source).Hash.ToLowerInvariant() -ne $taskRow.Sha){throw 'Publication input changed'}
 & scp -q -P 27015 @taskCommon $taskRow.Source ($taskSite+':/tmp/'+$taskRow.Name)
 if($LASTEXITCODE -ne 0){throw ('Upload failed: '+$taskRow.Name)}
}
$taskRemote='python3 -c "import hashlib,runpy; p=''/tmp/publish-live-6f26127.py''; assert hashlib.sha256(open(p,''rb'').read()).hexdigest()==''0964c467552693ce381a9bc1bbfd686de2cbae7ca0208715192932d0cba32298''; runpy.run_path(p,run_name=''__main__'')"'
& ssh -p 27015 @taskCommon $taskSite $taskRemote | Tee-Object -FilePath "$taskRoot/data/l6j/deployment.log"
if($LASTEXITCODE -ne 0){throw 'Inspection assets not verified; current live model selection stays unchanged'}
