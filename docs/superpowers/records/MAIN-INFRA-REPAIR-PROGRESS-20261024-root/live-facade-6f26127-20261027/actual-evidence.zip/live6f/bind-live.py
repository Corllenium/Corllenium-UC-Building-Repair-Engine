from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

R = Path(__file__).resolve().parents[2]
D = R / 'data/l6j'
sys.path.insert(0, str(R / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress, write_progress, utc_now

def checked(path, expected):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected, str(path)
    return json.loads(raw)

m = checked(D / 'package.json', 'bef15b0e5ccbbd3c0143f43bea1e69297992ba9bd43379c2b5cf966bb4766fd4')
qa = checked(D / 'client-preview-qa.json', 'fc8cb4c952b1228b944fcd8b69d408a73401b21b29528a59bdcef0ef66c384ff')
deployment = json.loads((D / 'deployment.log').read_text(encoding='utf-8-sig'))
assert deployment['files_per_root'] == deployment['http_hashes'] == 16
assert deployment['archive_sha256'] == m['archive_sha256'] and deployment['accepted'] is False
assert deployment['no_app_restart'] and deployment['api_sha'] == 'cedb7c53c35b0599585c17b214f3c29e1dfb7b9f'
assert qa['parsedTriangles'] == 26127 and qa['errorKinds'] == 7
assert qa['hashValidStaleBindingRejected'] and qa['corruptModelRejected']
assert qa['facadeOverlay']['triangles'] == 17769 and qa['facadeOverlay']['toggle_reuses_mesh']
candidate = m['results']['candidate']
assert candidate['obj_sha256'] == '5a38f6453f635b9bba64ff25a7a2540a80be1a661dc12a7934a0c8ad659fd548'
assert m['remaining_target_instances'] == 12917
W = R / '.claude/worktrees/v6i/data/iv6i'
review = checked(W / 'fullsigned/independent-review.json', '86a2e355300ee8fded44a89b91f9524d605dd7088fec7dded4a9ff6276b69653')
report = checked(W / 'fullsigned/validation.json', 'ca7a9b074594d2b4ab0f4e65f99029d5df3176958f077ab88141a9d24a0aa2ad')
native = checked(W / 'native/native-preservation.json', '4490bc9bc4da2dea128f76bfd810522d89fd88fc514da07b7c683d5c6bd45a63')
guard = checked(W / 'independent-guard.json', '67a42a2c9c947886a1c42ad1633866a707e59abede38bac456f6fcc5c2d95256')
assert report['verdict'] == 'FAIL' and review['preservation_passed'] is True and review['validator_passed'] is False
assert review['candidate_source_sha256'] == candidate['obj_sha256'] and guard['guard']['passed']
checks = report['checks']
assert checks['textures']['status'] == checks['nothing_deleted']['status'] == 'PASS'
counts = {k: checks['problems']['kinds'][k]['after'] for k in ('flicker_diff', 'flicker_same', 'reversed', 'cracks')}
assert sum(counts.values()) == 12917
path = R / 'data/main-infra-fresh/current.json'
original = load_progress(path)
doc = copy.deepcopy(original)
f = doc['floors']['6F']
assert f['output_triangles'] == 25433 and f['pending_saved_candidate']['triangles'] == 26127
assert f['accepted_preview'] is None and f['owner_decision_ref'] is None
now = utc_now()
promoted = copy.deepcopy(f['pending_saved_candidate'])
old_keys = ('candidate_preview', 'output_triangles', 'latest_saved_candidate', 'full_signed_validation',
            'evidence_refs', 'validator_ref', 'remaining_problem_targets', 'remaining_target_instances',
            'independent_guard_sha256', 'native_readback_sha256')
f.setdefault('inspection_manifest_history', []).append(dict(at=now, reason='Published new actual 26127 with matching measured maps',
    scope='Historical 25433 only; no proof transferred', fields={k: copy.deepcopy(f.get(k)) for k in old_keys}))
message = ('After now shows the new orange-free 6F model: 26,127 triangles, seven measured error filters and 17,769 facade faces. '
           'Independent strict26, all 46 native comparisons, and texture/visible-surface preservation PASS under the existing approved backface exception. '
           'Overall validation FAIL: 12,917 overlap/crack target instances remain. Not final or accepted.')
promoted.update(candidate_preview=candidate['preview'], inspection_published=True, acceptance=False)
f.update(candidate_preview=candidate['preview'], output_triangles=26127, pending_output_triangles=None,
    state='blocked', step=message, blocker='12,917 signed target errors remain; not final or accepted.',
    evidence_refs=[m['public_summary_url']], validator_ref=None, latest_saved_candidate=promoted,
    independent_guard_passed=True, independent_guard_sha256=promoted['strict26_sha256'],
    independent_guard_candidate_sha256=candidate['obj_sha256'], independent_guard_model_pixels=4791106,
    independent_guard_error_pixels=0, guard_views_done=26, guard_views_total=26,
    native_preservation_passed=True, native_readback_sha256=promoted['native_sha256'],
    native_qualified_total_views=33, native_qualified_changed_pixels=0,
    native_diagnostic_total_views=13, native_diagnostic_changed_pixels=0,
    validator_passed=False, validator_texture_preservation_passed=True, validator_nothing_deleted_passed=True,
    validator_pixel_floor_passed=True, independent_validator_stage='full_signed_preservation_pass_targets_fail',
    remaining_problem_targets=counts, remaining_target_instances=12917, last_work_event_at=now,
    inspection_published=True, inspection_acceptance=False, publication_eligible=False,
    inspection_receipt_sha256=hashlib.sha256((D / 'deployment.log').read_bytes()).hexdigest(),
    inspection_candidate_sha256=candidate['obj_sha256'], inspection_facade_faces=17769,
    accepted=False, worker_alive=False, engine_worker_alive=False, independent_validator_worker_alive=False,
    full_signed_validation=dict(path=str(W / 'fullsigned/validation.json'),
        sha256=promoted['full_signed_validation_sha256'], review_sha256=promoted['full_signed_review_sha256'],
        verdict='FAIL', preservation_passed=True, validator_passed=False, acceptance=False,
        candidate_source_sha256=candidate['obj_sha256'], existing_approved_backface_exception=promoted['existing_approved_backface_exception']))
f.pop('pending_saved_candidate')
f['worker_events'].append(dict(engine='Validator', run_id='MAIN-INFRA-6F-26127-INSPECTION-PREP-20261027',
    pid=47604, start_utc='2026-10-26T17:57:51.1219121Z',
    phase='new26127_model_maps_facade_published', observed_at=now, message=message +
    ' All16 files rehashed at both live roots and over HTTP; actual committed client parsed26127 and all7 maps. No server restart or acceptance.'))
doc.update(updated_at=now, last_work_event_at=now, step=message, state='blocked')
draft = D / 'current-draft.json'
draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
subprocess.run(['node', str(R / 'data/siege-live-20261026/check-status-current.mjs'), str(draft)], check=True)
assert load_progress(path)['updated_at'] == original['updated_at']
write_progress(path, doc)
actual = load_progress(path)
for floor in original['floors']:
    if floor != '6F':
        assert actual['floors'][floor] == original['floors'][floor]
    for key in ('source_preview', 'accepted_preview', 'owner_decision_ref'):
        assert actual['floors'][floor].get(key) == original['floors'][floor].get(key)
assert actual['floors']['6F']['output_triangles'] == 26127
receipt = dict(at=now, displayed=26127, signed_targets_remaining=12917, facade_faces=17769,
    all16_http_verified=True, other_floors_untouched=True, accepted=False,
    strict26='PASS', native='PASS', preservation='PASS_EXISTING_APPROVED_EXCEPTION', overall='FAIL_TARGETS_ONLY')
(D / 'canonical-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
