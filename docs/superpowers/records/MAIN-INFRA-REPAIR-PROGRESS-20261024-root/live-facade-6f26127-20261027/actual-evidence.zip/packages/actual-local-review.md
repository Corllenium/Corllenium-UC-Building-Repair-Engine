# Actual local packages, ready for controller review

Both approved local builds and saved-candidate client QA completed at frozen062dea8f; no source/runtime/guard/model change was made. Both public tar files were reopened and all member bytes match the saved stages. Full file inventories/SHA256, source-map hash changes, resource identities, counters and actual QA receipts are in actual-local-packages.json.

| Profile | Triangles | Facade IDs/overlay triangles | Members | Max Windows path | Archive SHA256 |
|---|---:|---:|---:|---:|---|
|5F-R2|35343|24593|18|233|55a08032105fbdb51237b2ee0abc7645dc0353d6ee2cde059747b97cd98dd280|
|6F26127|26127|17769|16|232|01f9d426ff2d5985a892e0a970487adef5fa7f3201f7e80d02dbedf16b91548f|

Both actual clients use the exact committeddd90 production loader and exported Three facade renderer. They verify selected saved-model triangles, all seven maps/coordinates, dependencies, stale-binding/corrupt-model negatives, actual facade geometry, toggling and disposal. This is data/Three geometry QA; no browser/WebGL/visibility verdict. SOURCE bytes and14/12qualified assets are unchanged. RAW facade order/count/provenance exact; seven original map fields preserved. Public text localpathleaks0. Old5F52000archive/1a95package and all18stage files remain unchanged. No upload or live switch occurred.

5F strict remains FAIL1material/view16,17096targets. 6F native/strict/preservation PASS with existing granted CBR511samples(53look/458UV),92faces,1910eligible/excusedfloor,grantbbeb; floor0measured/0failed; signed0sites/0newPNGs. Signed overall FAIL12917targets. UNACCEPTED/NOT FINAL for both. Controller owns publication; the old18filepublication must not run.
