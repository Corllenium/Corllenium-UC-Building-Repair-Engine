import { ERROR_KIND_META, type ErrorCounts, type ErrorKindKey } from './types';
import { parseMtlFile, parseWavefrontObj, type ObjWorldTransform } from './meshbuf';

export interface PreviewIdentity { source_revision: string; run_id: string; floor: string }
export type PreviewKind = 'source' | 'candidate' | 'accepted';
interface PreviewManifest extends PreviewIdentity {
  schema_version: 1; building_id: 'MAIN_INFRA'; floor_id: string; kind: PreviewKind;
  display_frame: { up_axis: 'Y'; units: 'metres'; source_local: true };
  bounds: [number[], number[]]; obj_url: string; mtl_url: string; errors_url?: string;
  assets: { url: string; sha256: string }[];
}
export interface LoadedFreshPreview {
  manifest: PreviewManifest; obj: string; materials: ReturnType<typeof parseMtlFile>; errors?: LoadedFreshErrors | null;
}

export function materialInspectionColour(name: string): string {
  let hash = 2166136261;
  for (let i = 0; i < name.length; i++) hash = Math.imul(hash ^ name.charCodeAt(i), 16777619);
  return `hsl(${(hash >>> 0) % 360}, 65%, 62%)`;
}

export async function loadFreshPreview(url: string, identity: PreviewIdentity, kind: PreviewKind): Promise<LoadedFreshPreview> {
  const prefix = `/models/main-infra/${identity.source_revision}/${identity.floor}/${identity.run_id}/${kind}/`;
  const local = (value: string) => value.startsWith(prefix) && !/[\\?#]/.test(value) && !decodeURIComponent(value).includes('..');
  if (!local(url)) throw new Error('Preview identity URL mismatch');
  const response = await fetch(url, { cache: 'no-store' });
  if (!response.ok) throw new Error('Preview manifest is unavailable');
  const manifest = await response.json() as PreviewManifest;
  if (manifest.schema_version !== 1 || manifest.building_id !== 'MAIN_INFRA' || manifest.source_revision !== identity.source_revision ||
      manifest.run_id !== identity.run_id || manifest.floor_id !== `MAIN_INFRA_${identity.floor}` || manifest.kind !== kind)
    throw new Error('Preview identity mismatch');
  if (manifest.display_frame?.up_axis !== 'Y' || manifest.display_frame.units !== 'metres' || !manifest.display_frame.source_local ||
      manifest.bounds?.length !== 2 || manifest.bounds.some(row => row.length !== 3 || row.some(n => !Number.isFinite(n))))
    throw new Error('Preview display frame is missing');
  if (!Array.isArray(manifest.assets) || !local(manifest.obj_url) || !local(manifest.mtl_url)) throw new Error('Invalid preview asset');
  const errorsUrl = typeof manifest.errors_url === 'string' && local(manifest.errors_url) ? manifest.errors_url : null;
  const loaded = new Map<string, ArrayBuffer>();
  for (const asset of manifest.assets) {
    if (!local(asset.url) || !/^[a-f0-9]{64}$/.test(asset.sha256) || loaded.has(asset.url)) throw new Error('Invalid preview asset');
    const result = await fetch(asset.url, { cache: 'no-store' });
    if (!result.ok && asset.url === errorsUrl) continue;
    if (!result.ok) throw new Error(`Missing preview asset: ${asset.url.split('/').pop()}`);
    const bytes = await result.arrayBuffer();
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))).map(n => n.toString(16).padStart(2, '0')).join('');
    if (hash !== asset.sha256 && asset.url === errorsUrl) continue;
    if (hash !== asset.sha256) throw new Error('Preview asset hash mismatch');
    loaded.set(asset.url, bytes);
  }
  if (!loaded.has(manifest.obj_url) || !loaded.has(manifest.mtl_url)) throw new Error('Missing model/material asset');
  const materials = parseMtlFile(new TextDecoder().decode(loaded.get(manifest.mtl_url)), prefix, { localTextures: true });
  if (Object.values(materials).some(material => material.mapKdUrl && !loaded.has(material.mapKdUrl)))
    throw new Error('Texture is missing from preview assets');
  const obj = new TextDecoder().decode(loaded.get(manifest.obj_url));
  const errorBytes = errorsUrl ? loaded.get(errorsUrl) : null;
  return { manifest, obj, materials, errors: errorBytes ? readBoundErrors(errorBytes, manifest, obj) : null };
}

export interface LoadedFreshErrors {
  faces: Partial<Record<ErrorKindKey, Set<number>>>;
  facadeFaces?: Set<number> | null;
  counts: ErrorCounts;
  openEdges: number[][];
  cracks: number[][];
}

function readBoundErrors(bytes: ArrayBuffer, manifest: PreviewManifest, obj: string): LoadedFreshErrors | null {
  try {
    const doc = JSON.parse(new TextDecoder().decode(bytes));
    const binding = doc?.binding;
    const objHash = manifest.assets.find(asset => asset.url === manifest.obj_url)?.sha256;
    const faceRows = obj.split(/\r?\n/).map(row => row.split('#')[0].trim()).filter(row => /^f\s/.test(row));
    if (faceRows.some(row => row.split(/\s+/).length !== 4) || doc.version !== 2 || doc.n_faces !== faceRows.length ||
        binding?.source_revision !== manifest.source_revision || binding.run_id !== manifest.run_id ||
        binding.floor_id !== manifest.floor_id || binding.kind !== manifest.kind || binding.obj_sha256 !== objHash ||
        doc.display_frame?.up_axis !== 'Y' || doc.display_frame.units !== 'metres' || doc.display_frame.source_local !== true)
      return null;
    if (!doc.counts || !doc.faces || typeof doc.faces !== 'object' || Array.isArray(doc.faces)) return null;
    const faces: LoadedFreshErrors['faces'] = {};
    for (const { key } of ERROR_KIND_META) {
      const count = doc.counts[key];
      if (!Number.isSafeInteger(count) || count < 0) return null;
      if (key === 'open_edges' || key === 'cracks') continue;
      const ids: unknown = doc.faces[key];
      if (!Array.isArray(ids) || ids.some(id => !Number.isSafeInteger(id) || id < 0 || id >= doc.n_faces)) return null;
      const set = new Set<number>(ids);
      if (set.size !== ids.length || set.size !== count) return null;
      faces[key] = set;
    }
    const coordinates = (rows: unknown, width: number, count: number): rows is number[][] =>
      Array.isArray(rows) && rows.length === count && rows.every(row => Array.isArray(row) && row.length === width && row.every(value => typeof value === 'number' && Number.isFinite(value)));
    if (!coordinates(doc.open_edges, 6, doc.counts.open_edges) || !coordinates(doc.cracks, 3, doc.counts.cracks)) return null;
    let facadeFaces: Set<number> | null = null;
    const facadeIds: unknown = doc.layers?.facade;
    const facadeCount = doc.layer_counts?.facade;
    if (Array.isArray(facadeIds) && Number.isSafeInteger(facadeCount) && facadeCount >= 0 &&
        facadeIds.every(id => Number.isSafeInteger(id) && id >= 0 && id < doc.n_faces)) {
      const measured = new Set<number>(facadeIds);
      if (measured.size === facadeIds.length && measured.size === facadeCount) facadeFaces = measured;
    }
    return { faces, facadeFaces, counts: doc.counts, openEdges: doc.open_edges, cracks: doc.cracks };
  } catch {
    return null;
  }
}
export function previewMesh(preview: LoadedFreshPreview, reference?: ObjWorldTransform) {
  const [lower, upper] = preview.manifest.bounds;
  const center = lower.map((n, i) => (n + upper[i]) / 2) as [number, number, number];
  const span = Math.max(...upper.map((n, i) => n - lower[i]), 1e-5);
  return parseWavefrontObj(preview.obj, preview.manifest.floor_id,
    reference ?? { center, scale: 18 / span, isAlreadyYUp: true });
}

export function previewCameraDistance(positions: Float32Array, verticalFovDegrees: number, aspect: number) {
  let radius = 0;
  for (let i = 0; i < positions.length; i += 3) radius = Math.max(radius, Math.hypot(positions[i], positions[i + 1], positions[i + 2]));
  const vertical = verticalFovDegrees * Math.PI / 360;
  const horizontal = Math.atan(Math.tan(vertical) * Math.max(aspect, .1));
  return Math.max(1.5, radius * 1.1 / Math.sin(Math.min(vertical, horizontal)));
}
