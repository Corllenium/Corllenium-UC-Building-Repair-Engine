"use client";

import type { LoadedFreshErrors } from '@/lib/buildings/freshMainInfraPreview';
import { useCallback, useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { previewCameraDistance, materialInspectionColour } from '@/lib/buildings/freshMainInfraPreview';
import {
  type MtlMaterialDef,
  type ParsedObjMesh,
  parseMtlFile,
  parseWavefrontObj,
} from "@/lib/buildings/meshbuf";
import {
  ERROR_KIND_META,
  type ErrorCounts,
  type ErrorKindKey,
  type FloorUnitRecord,
} from "@/lib/buildings/types";

export interface DualModelCanvasProps {
  unit: FloorUnitRecord;
  enabledKinds: Record<ErrorKindKey, boolean>;
  isolateErrors: boolean;
  showWireframe: boolean;
  showXray: boolean;
  showTextures: boolean;
  onToggleTextures?: () => void;
  blinkFlicker: boolean;
  syncCameras: boolean;
  importedBeforeObj: ParsedObjMesh | null;
  importedAfterObj: ParsedObjMesh | null;
  flySpotIndex?: number | null;
  freshPreview?: { materials: Record<string, MtlMaterialDef>; afterKind: 'source' | 'candidate' | 'accepted'; materialColours?: boolean; showFacade?: boolean; errorsBefore?: LoadedFreshErrors['faces']; errorsAfter?: LoadedFreshErrors['faces']; errorGeometryBefore?: LoadedFreshErrors | null; errorGeometryAfter?: LoadedFreshErrors | null };
}

interface ErrorsFaceMap {
  faces?: Partial<Record<ErrorKindKey, number[]>>;
}

type ViewportLayoutMode = "split" | "before_only" | "after_only";
type FloorStackMode = "single" | "stack_above" | "stack_tower";
const EMPTY_ERROR_FACES: Partial<Record<ErrorKindKey, Set<number>>> = {};

const CHTM_STACK_NEIGHBORS: Record<string, string[]> = {
  CHTM_1st_floor_zone: ["Chtm_2nd_floor", "CHTM_SIDE_WALK_2nd_floor"],
  Chtm_2nd_floor: ["CHTM_3rd_floor", "CHTM_2nd_to_3rd_building_sidewalk_outside"],
  CHTM_SIDE_WALK_2nd_floor: ["CHTM_1st_floor_zone", "Chtm_2nd_floor", "CHTM_sidewalk_zone"],
  CHTM_2nd_to_3rd_building_sidewalk_outside: ["Chtm_2nd_floor", "CHTM_3rd_floor", "CHTM_sidewalk_zone"],
  CHTM_sidewalk_zone: ["CHTM_1st_floor_zone", "Chtm_2nd_floor", "CHTM_SIDE_WALK_2nd_floor"],
  CHTM_3rd_floor: ["CHTM_4th_floor", "Chtm_2nd_floor"],
  CHTM_4th_floor: ["chtm_5ft_floor", "CHTM_3rd_floor"],
  chtm_5ft_floor: ["CHTM_6th_floor_obj", "CHTM_4th_floor"],
  CHTM_6th_floor_obj: ["CHTM_7th_floor_obj", "chtm_5ft_floor"],
  CHTM_7th_floor_obj: ["CHTM_8th_floor_obj", "CHTM_6th_floor_obj"],
  CHTM_8th_floor_obj: ["CHTM_9th_floor_obj", "CHTM_7th_floor_obj"],
  CHTM_9th_floor_obj: ["CHTM_10th_floor_obj", "CHTM_8th_floor_obj"],
  CHTM_10th_floor_obj: ["CHTM_11th_floor_obj", "CHTM_9th_floor_obj"],
  CHTM_11th_floor_obj: ["CHTM_12th_floor_obj", "CHTM_10th_floor_obj"],
  CHTM_12th_floor_obj: ["CHTM_11th_floor_obj"],
  Architecture_1st_floor: ["Architecture_dep_2nd_Floor_obj"],
  Architecture_dep_2nd_Floor_obj: ["Architecture_1st_floor"],
  BRS_1st_floor_obj: ["BRS_2nd_floor_obj"],
  BRS_2nd_floor_obj: ["BRS_1st_floor_obj"],
  Main_1st_Floor_obj: ["Main_Infrustructure_1st_floor"],
  Main_Infrustructure_1st_floor: ["Main_1st_Floor_obj"],
};

const CHTM_TOWER_STACK: string[] = [
  "CHTM_1st_floor_zone",
  "CHTM_SIDE_WALK_2nd_floor",
  "Chtm_2nd_floor",
  "CHTM_2nd_to_3rd_building_sidewalk_outside",
  "CHTM_3rd_floor",
  "CHTM_4th_floor",
];

function computeStackedSeamConflicts(
  baseMesh: ParsedObjMesh | null,
  stackedMeshes: ParsedObjMesh[],
): { conflictFaceIds: Set<number>; seamOverlayPositions: Float32Array } {
  const conflictFaceIds = new Set<number>();
  if (!baseMesh || stackedMeshes.length === 0) {
    return { conflictFaceIds, seamOverlayPositions: new Float32Array(0) };
  }

  // Collect horizontal triangles from stacked neighbor floors (in Three.js Y-up normalized space)
  const neighborHoriz: { y: number; minX: number; maxX: number; minZ: number; maxZ: number }[] = [];
  for (const sm of stackedMeshes) {
    const pos = sm.positions;
    const nTris = sm.triangleCount;
    for (let t = 0; t < nTris; t++) {
      const b = t * 9;
      const y0 = pos[b + 1];
      const y1 = pos[b + 4];
      const y2 = pos[b + 7];
      if (Math.max(y0, y1, y2) - Math.min(y0, y1, y2) > 0.03) continue;
      const x0 = pos[b], x1 = pos[b + 3], x2 = pos[b + 6];
      const z0 = pos[b + 2], z1 = pos[b + 5], z2 = pos[b + 8];
      neighborHoriz.push({
        y: (y0 + y1 + y2) / 3,
        minX: Math.min(x0, x1, x2),
        maxX: Math.max(x0, x1, x2),
        minZ: Math.min(z0, z1, z2),
        maxZ: Math.max(z0, z1, z2),
      });
    }
  }

  const seamVerts: number[] = [];
  const bPos = baseMesh.positions;
  const bTris = baseMesh.triangleCount;
  for (let t = 0; t < bTris; t++) {
    const b = t * 9;
    const y0 = bPos[b + 1];
    const y1 = bPos[b + 4];
    const y2 = bPos[b + 7];
    if (Math.max(y0, y1, y2) - Math.min(y0, y1, y2) > 0.03) continue;
    const x0 = bPos[b], x1 = bPos[b + 3], x2 = bPos[b + 6];
    const z0 = bPos[b + 2], z1 = bPos[b + 5], z2 = bPos[b + 8];
    const d01 = Math.hypot(x1 - x0, y1 - y0, z1 - z0);
    const d12 = Math.hypot(x2 - x1, y2 - y1, z2 - z1);
    const d20 = Math.hypot(x0 - x2, y0 - y2, z0 - z2);
    if (Math.max(d01, d12, d20) > 5.0) continue;

    const yMean = (y0 + y1 + y2) / 3;
    const minX = Math.min(x0, x1, x2);
    const maxX = Math.max(x0, x1, x2);
    const minZ = Math.min(z0, z1, z2);
    const maxZ = Math.max(z0, z1, z2);

    let collides = false;
    for (let j = 0; j < neighborHoriz.length; j++) {
      const nh = neighborHoriz[j];
      if (Math.abs(nh.y - yMean) <= 0.045) {
        const ovX = Math.min(maxX, nh.maxX) - Math.max(minX, nh.minX);
        const ovZ = Math.min(maxZ, nh.maxZ) - Math.max(minZ, nh.minZ);
        if (ovX > 0.01 && ovZ > 0.01) {
          collides = true;
          break;
        }
      }
    }

    if (collides) {
      const fid = baseMesh.triFaceIds ? baseMesh.triFaceIds[t] : t;
      conflictFaceIds.add(fid);
      seamVerts.push(x0, y0, z0, x1, y1, z1, x2, y2, z2);
    }
  }

  return { conflictFaceIds, seamOverlayPositions: new Float32Array(seamVerts) };
}

const SURFACE_OPTIONS = {
  side: THREE.DoubleSide,
  roughness: 0.88,
  metalness: 0.02,
  polygonOffset: true,
  polygonOffsetFactor: 0.35,
  polygonOffsetUnits: 0.5,
} as const;

interface PanelParts {
  root: THREE.Group;
  texturedMesh?: THREE.Mesh;
  flatMesh?: THREE.Mesh;
  materialMesh?: THREE.Mesh;
  outlineLines?: THREE.LineSegments;
  gridLines?: THREE.LineSegments;
  gridlineCount?: number;
  errorMesh?: THREE.Mesh;
  textures: THREE.Texture[];
  freshErrorSource?: LoadedFreshErrors | null;
  freshErrorLines?: THREE.LineSegments;
  freshErrorPoints?: THREE.Points;
  freshFacadeSource?: Set<number> | null;
  freshFacadeMesh?: THREE.Mesh;
}

function disposePanelParts(scene: THREE.Scene, parts: PanelParts | null) {
  if (!parts) return;
  scene.remove(parts.root);
  const texSet = new Set<THREE.Texture>(parts.textures);
  parts.root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mat = mesh.material;
    if (mat) {
      for (const m of Array.isArray(mat) ? mat : [mat]) {
        const std = m as THREE.MeshStandardMaterial;
        if (std.map) texSet.add(std.map);
        m.dispose();
      }
    }
  });
  texSet.forEach((t) => t.dispose());
}

function buildTrueCreaseEdges(
  meshData: ParsedObjMesh,
  mode: "before" | "after" = "after",
): {
  outlineGeom: THREE.BufferGeometry;
  gridlineGeom: THREE.BufferGeometry;
  gridlineCount: number;
} {
  const pos = meshData.positions;
  const nor = meshData.normals;
  const nTris = meshData.triangleCount;
  const q = 2000; // weld precision in normalized 18-unit space

  const vKey = (x: number, y: number, z: number) =>
    `${Math.round(x * q)},${Math.round(y * q)},${Math.round(z * q)}`;

  interface EdgeEntry {
    ax: number;
    ay: number;
    az: number;
    bx: number;
    by: number;
    bz: number;
    faces: { nx: number; ny: number; nz: number; dir: 1 | -1 }[];
  }

  const edgeMap = new Map<string, EdgeEntry>();

  for (let t = 0; t < nTris; t++) {
    const b = t * 9;
    const nx = nor[b];
    const ny = nor[b + 1];
    const nz = nor[b + 2];

    for (let e = 0; e < 3; e++) {
      const i0 = b + e * 3;
      const i1 = b + ((e + 1) % 3) * 3;
      const x0 = pos[i0], y0 = pos[i0 + 1], z0 = pos[i0 + 2];
      const x1 = pos[i1], y1 = pos[i1 + 1], z1 = pos[i1 + 2];
      const k0 = vKey(x0, y0, z0);
      const k1 = vKey(x1, y1, z1);
      if (k0 === k1) continue;

      const forward = k0 < k1;
      const key = forward ? `${k0}|${k1}` : `${k1}|${k0}`;
      let entry = edgeMap.get(key);
      if (!entry) {
        entry = {
          ax: forward ? x0 : x1,
          ay: forward ? y0 : y1,
          az: forward ? z0 : z1,
          bx: forward ? x1 : x0,
          by: forward ? y1 : y0,
          bz: forward ? z1 : z0,
          faces: [],
        };
        edgeMap.set(key, entry);
      }
      entry.faces.push({ nx, ny, nz, dir: forward ? 1 : -1 });
    }
  }

  const segs: number[] = [];
  const gridSegs: number[] = [];
  interface OpenEdgeItem {
    ax: number;
    ay: number;
    az: number;
    bx: number;
    by: number;
    bz: number;
    mx: number;
    my: number;
    mz: number;
    tx: number;
    ty: number;
    tz: number;
    len: number;
    nx: number;
    ny: number;
    nz: number;
    onlyOpen: boolean;
  }
  const openItems: OpenEdgeItem[] = [];

  edgeMap.forEach((entry) => {
    const fs = entry.faces;
    let continuesFlat = false;
    for (let i = 0; i < fs.length && !continuesFlat; i++) {
      for (let j = i + 1; j < fs.length; j++) {
        const dot = fs[i].nx * fs[j].nx + fs[i].ny * fs[j].ny + fs[i].nz * fs[j].nz;
        if ((fs[i].dir !== fs[j].dir && dot > 0.94) || Math.abs(dot) > 0.985) {
          continuesFlat = true;
          break;
        }
      }
    }
    if (continuesFlat) {
      gridSegs.push(entry.ax, entry.ay, entry.az, entry.bx, entry.by, entry.bz);
    } else if (fs.length === 1) {
      const dx = entry.bx - entry.ax;
      const dy = entry.by - entry.ay;
      const dz = entry.bz - entry.az;
      const len = Math.hypot(dx, dy, dz);
      if (len > 1e-6) {
        openItems.push({
          ax: entry.ax,
          ay: entry.ay,
          az: entry.az,
          bx: entry.bx,
          by: entry.by,
          bz: entry.bz,
          mx: 0.5 * (entry.ax + entry.bx),
          my: 0.5 * (entry.ay + entry.by),
          mz: 0.5 * (entry.az + entry.bz),
          tx: dx / len,
          ty: dy / len,
          tz: dz / len,
          len,
          nx: fs[0].nx,
          ny: fs[0].ny,
          nz: fs[0].nz,
          onlyOpen: true,
        });
      }
    } else {
      segs.push(entry.ax, entry.ay, entry.az, entry.bx, entry.by, entry.bz);
      if (mode === "after") {
        const dx = entry.bx - entry.ax;
        const dy = entry.by - entry.ay;
        const dz = entry.bz - entry.az;
        const len = Math.hypot(dx, dy, dz);
        if (len > 1e-6) {
          for (let k = 0; k < Math.min(fs.length, 2); k++) {
            openItems.push({
              ax: entry.ax,
              ay: entry.ay,
              az: entry.az,
              bx: entry.bx,
              by: entry.by,
              bz: entry.bz,
              mx: 0.5 * (entry.ax + entry.bx),
              my: 0.5 * (entry.ay + entry.by),
              mz: 0.5 * (entry.az + entry.bz),
              tx: dx / len,
              ty: dy / len,
              tz: dz / len,
              len,
              nx: fs[k].nx,
              ny: fs[k].ny,
              nz: fs[k].nz,
              onlyOpen: false,
            });
          }
        }
      }
    }
  });

  // Suppress collinear T-junction & micro-slit sub-edges on coplanar surfaces (after mesh only)
  const isTJun = new Uint8Array(openItems.length);
  if (mode === "after" && openItems.length > 1 && openItems.length <= 45000) {
    const dirBuckets = new Map<number, number[]>();
    for (let i = 0; i < openItems.length; i++) {
      const e = openItems[i];
      // Canonicalize tangent direction so (tx,ty,tz) and (-tx,-ty,-tz) map to the same angle bucket
      let ctx = e.tx, cty = e.ty, ctz = e.tz;
      if (ctx < -1e-4 || (Math.abs(ctx) <= 1e-4 && (cty < -1e-4 || (Math.abs(cty) <= 1e-4 && ctz < 0)))) {
        ctx = -ctx;
        cty = -cty;
        ctz = -ctz;
      }
      const ang = Math.round(((Math.atan2(ctz, Math.hypot(ctx, cty)) + Math.PI) * 8) + ((Math.atan2(cty, ctx) + Math.PI) * 64));
      for (const d of [-1, 0, 1]) {
        const k = ang + d;
        let b = dirBuckets.get(k);
        if (!b) {
          b = [];
          dirBuckets.set(k, b);
        }
        if (d === 0 || b.length < 1500) b.push(i);
      }
    }
    dirBuckets.forEach((idxs) => {
      if (idxs.length > 3500) return;
      for (let a = 0; a < idxs.length; a++) {
        const i = idxs[a];
        const ei = openItems[i];
        for (let b = a + 1; b < idxs.length; b++) {
          const j = idxs[b];
          if (i === j) continue;
          const ej = openItems[j];
          if (!ei.onlyOpen && !ej.onlyOpen) continue;
          const nDot = ei.nx * ej.nx + ei.ny * ej.ny + ei.nz * ej.nz;
          if (Math.abs(nDot) <= 0.94) continue;
          const tDot = ei.tx * ej.tx + ei.ty * ej.ty + ei.tz * ej.tz;
          if (Math.abs(tDot) <= 0.992) continue;
          const shortE = ei.len <= ej.len ? ei : ej;
          const longE = ei.len <= ej.len ? ej : ei;
          const vx = shortE.mx - longE.ax;
          const vy = shortE.my - longE.ay;
          const vz = shortE.mz - longE.az;
          // Must lie on the same plane (normal offset < 0.005)
          if (Math.abs(vx * longE.nx + vy * longE.ny + vz * longE.nz) > 0.005) continue;
          const proj = vx * longE.tx + vy * longE.ty + vz * longE.tz;
          if (proj < -0.015 || proj > longE.len + 0.015) continue;
          const px = vx - proj * longE.tx;
          const py = vy - proj * longE.ty;
          const pz = vz - proj * longE.tz;
          if (px * px + py * py + pz * pz < 0.015 * 0.015) {
            isTJun[i] = 1;
            isTJun[j] = 1;
          }
        }
      }
    });
  }
  for (let i = 0; i < openItems.length; i++) {
    const e = openItems[i];
    if (!e.onlyOpen) continue;
    if (isTJun[i]) {
      gridSegs.push(e.ax, e.ay, e.az, e.bx, e.by, e.bz);
    } else {
      segs.push(e.ax, e.ay, e.az, e.bx, e.by, e.bz);
    }
  }

  const outlineGeom = new THREE.BufferGeometry();
  outlineGeom.setAttribute("position", new THREE.Float32BufferAttribute(segs, 3));
  const gridlineGeom = new THREE.BufferGeometry();
  gridlineGeom.setAttribute("position", new THREE.Float32BufferAttribute(gridSegs, 3));
  return {
    outlineGeom,
    gridlineGeom,
    gridlineCount: gridSegs.length / 6,
  };
}

export function buildModelBaseParts(
  mode: "before" | "after",
  meshData: ParsedObjMesh | null,
  mtlDefs: Record<string, MtlMaterialDef>,
  allowPlaceholder = true,
  freshInspection = false,
): PanelParts {
  const root = new THREE.Group();
  const loadedTextures: THREE.Texture[] = [];

  if (meshData && meshData.positions.length > 0) {
    const geom = new THREE.BufferGeometry();
    geom.setAttribute("position", new THREE.BufferAttribute(meshData.positions, 3));
    geom.setAttribute("normal", new THREE.BufferAttribute(meshData.normals, 3));
    if (meshData.uvs && meshData.uvs.length > 0) {
      geom.setAttribute("uv", new THREE.BufferAttribute(meshData.uvs, 2));
    }

    let texturedMesh: THREE.Mesh | undefined;
    if (meshData.materialGroups && meshData.materialGroups.length > 0) {
      const tGeom = geom.clone();
      tGeom.clearGroups();
      const matArray: THREE.MeshStandardMaterial[] = [];
      const texLoader = new THREE.TextureLoader();
      const texCache = new Map<string, THREE.Texture>();

      meshData.materialGroups.forEach((grp, idx) => {
        tGeom.addGroup(grp.startVertex, grp.vertexCount, idx);
        const def = mtlDefs[grp.materialName];
        const kdColor = def
          ? new THREE.Color(def.kd[0], def.kd[1], def.kd[2])
          : new THREE.Color().setScalar(0.78 + (idx % 5) * 0.04);

        const mat = new THREE.MeshStandardMaterial({
          ...SURFACE_OPTIONS,
          color: kdColor,
        });

        if (def?.mapKdUrl) {
          const applyLoadedTex = (t: THREE.Texture) => {
            mat.map = t;
            mat.color.setHex(0xffffff);
            mat.needsUpdate = true;
          };
          let tex = texCache.get(def.mapKdUrl);
          if (!tex) {
            const pendingMats: THREE.MeshStandardMaterial[] = [mat];
            (texCache as Map<string, THREE.Texture & { __pendingMats?: THREE.MeshStandardMaterial[] }>).set(
              def.mapKdUrl,
              null as unknown as THREE.Texture,
            );
            tex = texLoader.load(
              def.mapKdUrl,
              (loadedTex) => {
                loadedTex.wrapS = THREE.RepeatWrapping;
                loadedTex.wrapT = THREE.RepeatWrapping;
                loadedTex.magFilter = THREE.NearestFilter;
                loadedTex.minFilter = THREE.NearestMipmapLinearFilter;
                loadedTex.colorSpace = THREE.SRGBColorSpace;
                loadedTex.needsUpdate = true;
                for (const m of pendingMats) {
                  m.map = loadedTex;
                  m.color.setHex(0xffffff);
                  m.needsUpdate = true;
                }
              },
              undefined,
              () => {
                for (const m of pendingMats) {
                  m.map = null;
                  m.color.copy(kdColor);
                  m.needsUpdate = true;
                }
              },
            );
            tex.wrapS = THREE.RepeatWrapping;
            tex.wrapT = THREE.RepeatWrapping;
            tex.magFilter = THREE.NearestFilter;
            tex.minFilter = THREE.NearestMipmapLinearFilter;
            tex.colorSpace = THREE.SRGBColorSpace;
            (tex as THREE.Texture & { __pendingMats?: THREE.MeshStandardMaterial[] }).__pendingMats = pendingMats;
            texCache.set(def.mapKdUrl, tex);
            loadedTextures.push(tex);
          } else if (tex.image) {
            applyLoadedTex(tex);
          } else {
            const pending = (tex as THREE.Texture & { __pendingMats?: THREE.MeshStandardMaterial[] }).__pendingMats;
            if (pending) pending.push(mat);
            else applyLoadedTex(tex);
          }
        }
        matArray.push(mat);
      });

      texturedMesh = new THREE.Mesh(tGeom, matArray);
      root.add(texturedMesh);
    }

    const fGeom = geom.clone();
    const flatMat = new THREE.MeshStandardMaterial({
      ...SURFACE_OPTIONS,
      color: 0xd8dee9,
    });
    const flatMesh = new THREE.Mesh(fGeom, flatMat);
    flatMesh.visible = !texturedMesh;
    root.add(flatMesh);

    let materialMesh: THREE.Mesh | undefined;
    if (freshInspection) {
      const colourGeom = geom.clone();
      colourGeom.clearGroups();
      const groups = meshData.materialGroups.length ? meshData.materialGroups
        : [{ materialName: 'default', startVertex: 0, vertexCount: meshData.positions.length / 3 }];
      const colours = groups.map((group, index) => {
        colourGeom.addGroup(group.startVertex, group.vertexCount, index);
        return new THREE.MeshStandardMaterial({ ...SURFACE_OPTIONS, color: materialInspectionColour(group.materialName) });
      });
      materialMesh = new THREE.Mesh(colourGeom, colours);
      materialMesh.visible = false;
      root.add(materialMesh);
    }

    const { outlineGeom, gridlineGeom: creaseGridGeom, gridlineCount: creaseGridCount } = buildTrueCreaseEdges(meshData, mode);
    const gridlineGeom = freshInspection ? new THREE.WireframeGeometry(geom) : creaseGridGeom;
    const gridlineCount = freshInspection ? gridlineGeom.getAttribute('position').count / 2 : creaseGridCount;
    if (freshInspection) creaseGridGeom.dispose();
    const outlineLines = new THREE.LineSegments(
      outlineGeom,
      new THREE.LineBasicMaterial({
        color: mode === "after" ? 0x10b981 : 0x1e293b,
        transparent: true,
        opacity: mode === "after" ? 0.55 : 0.55,
      }),
    );
    root.add(outlineLines);

    // Fresh inspection shows actual triangle edges; legacy flat-line overlays remain Before-only.
    let gridLines: THREE.LineSegments | undefined;
    if ((mode === "before" || freshInspection) && gridlineCount > 0) {
      gridLines = new THREE.LineSegments(
        gridlineGeom,
        new THREE.LineBasicMaterial({
          color: 0x38bdf8, // Bright sky/electric blue for Removable Gridlines (EDGE_REMOVABLE)
          transparent: true,
          opacity: 0.72,
        }),
      );
      root.add(gridLines);
    } else {
      gridlineGeom.dispose();
    }

    return {
      root,
      texturedMesh,
      flatMesh,
      materialMesh,
      outlineLines,
      gridLines,
      gridlineCount,
      textures: loadedTextures,
    };
  }

  if (!allowPlaceholder) return { root, textures: loadedTextures };
  const slabGeom = new THREE.BoxGeometry(14, 0.45, 9);
  const slabMat = new THREE.MeshStandardMaterial({
    ...SURFACE_OPTIONS,
    color: mode === "before" ? 0x334155 : 0x3b4d63,
  });
  const slab = new THREE.Mesh(slabGeom, slabMat);
  slab.position.set(0, -0.22, 0);
  root.add(slab);

  return {
    root,
    flatMesh: slab,
    textures: loadedTextures,
  };
}

export function updateFreshFacadeOverlay(parts: PanelParts | null, mesh: ParsedObjMesh | null, faces: Set<number> | null, shown: boolean): boolean {
  if (!parts || !mesh) return false;
  if (parts.freshFacadeSource !== faces) {
    if (parts.freshFacadeMesh) {
      parts.root.remove(parts.freshFacadeMesh);
      parts.freshFacadeMesh.geometry.dispose();
      const materials = parts.freshFacadeMesh.material;
      for (const material of Array.isArray(materials) ? materials : [materials]) material.dispose();
      parts.freshFacadeMesh = undefined;
    }
    parts.freshFacadeSource = faces;
  }
  if (shown && faces?.size && !parts.freshFacadeMesh) {
    const positions: number[] = [];
    for (let triangle = 0; triangle < mesh.triangleCount; triangle++) {
      if (faces.has(mesh.triFaceIds?.[triangle] ?? triangle)) positions.push(...mesh.positions.slice(triangle * 9, triangle * 9 + 9));
    }
    if (positions.length) {
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      const overlay = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: 0x38bdf8, side: THREE.DoubleSide,
        transparent: true, opacity: .45, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 }));
      overlay.name = 'fresh-facade';
      parts.freshFacadeMesh = overlay;
      parts.root.add(overlay);
    }
  }
  if (parts.freshFacadeMesh) parts.freshFacadeMesh.visible = shown;
  return Boolean(shown && parts.freshFacadeMesh);
}

function applyAppearanceInPlace(
  parts: PanelParts | null,
  opts: {
    showTextures: boolean;
    showWireframe: boolean;
    showXray: boolean;
    isolateErrors: boolean;
    showGridlines?: boolean;
    hasActiveErrorOverlay: boolean;
    showMaterialColours?: boolean;
  },
) {
  if (!parts) return;
  const hasTex = Boolean(parts.texturedMesh);
  const materialColours = Boolean(opts.showMaterialColours && parts.materialMesh);
  if (parts.materialMesh) parts.materialMesh.visible = materialColours;
  if (parts.texturedMesh) {
    parts.texturedMesh.visible = opts.showTextures && !materialColours;
  }
  if (parts.flatMesh) {
    parts.flatMesh.visible = !(opts.showTextures && hasTex) && !materialColours;
  }
  if (parts.gridLines) {
    parts.gridLines.visible = opts.showGridlines ?? true;
  }

  const isolateActive = opts.isolateErrors && opts.hasActiveErrorOverlay;
  const materials: THREE.MeshStandardMaterial[] = [];
  for (const mesh of [parts.texturedMesh, parts.flatMesh, parts.materialMesh]) {
    if (!mesh) continue;
    const m = mesh.material;
    materials.push(...((Array.isArray(m) ? m : [m]) as THREE.MeshStandardMaterial[]));
  }

  for (const m of materials) {
    m.wireframe = opts.showWireframe;
    if (isolateActive) {
      m.transparent = true;
      m.opacity = 0.09;
      m.depthWrite = false;
    } else if (opts.showXray) {
      m.transparent = true;
      m.opacity = 0.25;
      m.depthWrite = false;
    } else {
      m.transparent = false;
      m.opacity = 1.0;
      m.depthWrite = true;
    }
    m.needsUpdate = true;
  }
}

export function updateFreshErrorMarkers(
  parts: PanelParts | null,
  mesh: ParsedObjMesh | null,
  errors: LoadedFreshErrors | null,
  enabled: Record<ErrorKindKey, boolean>,
): boolean {
  if (!parts || !mesh?.transform) return false;
  if (parts.freshErrorSource !== errors) {
    for (const marker of [parts.freshErrorLines, parts.freshErrorPoints]) {
      if (!marker) continue;
      parts.root.remove(marker);
      marker.geometry.dispose();
      for (const material of Array.isArray(marker.material) ? marker.material : [marker.material]) material.dispose();
    }
    parts.freshErrorLines = undefined;
    parts.freshErrorPoints = undefined;
    parts.freshErrorSource = errors;
    const { center, scale } = mesh.transform;
    const positions = (rows: number[][]) => new Float32Array(rows.flat().map((value, index) => (value - center[index % 3]) * scale));
    if (errors?.openEdges.length) {
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(positions(errors.openEdges), 3));
      const marker = new THREE.LineSegments(geometry, new THREE.LineBasicMaterial({ color: 0x16a34a, depthTest: false }));
      marker.name = 'fresh-open-edges';
      marker.renderOrder = 6;
      parts.freshErrorLines = marker;
      parts.root.add(marker);
    }
    if (errors?.cracks.length) {
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(positions(errors.cracks), 3));
      const marker = new THREE.Points(geometry, new THREE.PointsMaterial({ color: 0x00b4d8, size: 4, sizeAttenuation: false, depthTest: false }));
      marker.name = 'fresh-cracks';
      marker.renderOrder = 7;
      parts.freshErrorPoints = marker;
      parts.root.add(marker);
    }
  }
  if (parts.freshErrorLines) parts.freshErrorLines.visible = enabled.open_edges;
  if (parts.freshErrorPoints) parts.freshErrorPoints.visible = enabled.cracks;
  return Boolean(parts.freshErrorLines?.visible || parts.freshErrorPoints?.visible);
}
export function updateErrorOverlayInPlace(
  parts: PanelParts | null,
  mode: "before" | "after",
  meshData: ParsedObjMesh | null,
  counts: ErrorCounts | null,
  errorFaces: Partial<Record<ErrorKindKey, Set<number>>>,
  enabledKinds: Record<ErrorKindKey, boolean>,
  errorGeometry: LoadedFreshErrors | null = null,
): boolean {
  const markerActive = updateFreshErrorMarkers(parts, meshData, errorGeometry, enabledKinds);
  if (!parts) return false;

  if (parts.errorMesh) {
    parts.root.remove(parts.errorMesh);
    parts.errorMesh.geometry.dispose();
    (parts.errorMesh.material as THREE.Material).dispose();
    parts.errorMesh = undefined;
  }

  if (!meshData || !counts) return markerActive;

  const overlayPos: number[] = [];
  const overlayCol: number[] = [];
  const nTris = meshData.triangleCount;

  for (let t = 0; t < nTris; t++) {
    const faceId = meshData.triFaceIds ? meshData.triFaceIds[t] : t;
    let matchedColor: THREE.Color | null = null;

    for (const meta of ERROR_KIND_META) {
      if (!enabledKinds[meta.key]) continue;
      if (counts[meta.key] <= 0) continue;

      const exactSet = mode === "before" || errorGeometry ? errorFaces[meta.key] : undefined;
      if (exactSet && exactSet.size > 0) {
        if (exactSet.has(faceId)) {
          matchedColor = new THREE.Color(meta.colorInt);
          break;
        }
      }
    }

    if (matchedColor) {
      const base = t * 9;
      const ax = meshData.positions[base];
      const ay = meshData.positions[base + 1];
      const az = meshData.positions[base + 2];
      const bx = meshData.positions[base + 3];
      const by = meshData.positions[base + 4];
      const bz = meshData.positions[base + 5];
      const cx = meshData.positions[base + 6];
      const cy = meshData.positions[base + 7];
      const cz = meshData.positions[base + 8];

      const d01 = Math.hypot(bx - ax, by - ay, bz - az);
      const d12 = Math.hypot(cx - bx, cy - by, cz - bz);
      const d20 = Math.hypot(ax - cx, ay - cy, az - cz);
      if (!errorGeometry && Math.max(d01, d12, d20) > 5.0) continue;

      overlayPos.push(ax, ay, az, bx, by, bz, cx, cy, cz);
      for (let vIdx = 0; vIdx < 3; vIdx++) {
        overlayCol.push(matchedColor.r, matchedColor.g, matchedColor.b);
      }
    }
  }

  if (overlayPos.length === 0) return markerActive;

  const ovGeom = new THREE.BufferGeometry();
  ovGeom.setAttribute("position", new THREE.Float32BufferAttribute(overlayPos, 3));
  ovGeom.setAttribute("color", new THREE.Float32BufferAttribute(overlayCol, 3));

  const ovMat = new THREE.MeshBasicMaterial({
    vertexColors: true,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });

  const ovMesh = new THREE.Mesh(ovGeom, ovMat);
  parts.errorMesh = ovMesh;
  parts.root.add(ovMesh);
  return true;
}

export function DualModelCanvas({
  unit,
  enabledKinds,
  isolateErrors,
  showWireframe,
  showXray,
  showTextures,
  onToggleTextures,
  blinkFlicker,
  syncCameras,
  importedBeforeObj,
  importedAfterObj,
  flySpotIndex,
  freshPreview,
}: DualModelCanvasProps) {
  const beforeMountRef = useRef<HTMLDivElement | null>(null);
  const afterMountRef = useRef<HTMLDivElement | null>(null);
  const initialFreshPreview = useRef({ freshPreview, importedBeforeObj });
  const syncCamerasRef = useRef<boolean>(syncCameras);
  useEffect(() => {
    syncCamerasRef.current = syncCameras;
  }, [syncCameras]);

  const engineRef = useRef<{
    rendererLeft: THREE.WebGLRenderer;
    rendererRight: THREE.WebGLRenderer;
    sceneLeft: THREE.Scene;
    sceneRight: THREE.Scene;
    camLeft: THREE.PerspectiveCamera;
    camRight: THREE.PerspectiveCamera;
    controlsLeft: OrbitControls;
    controlsRight: OrbitControls;
    partsLeft: PanelParts | null;
    partsRight: PanelParts | null;
    resizeAll: () => void;
  } | null>(null);

  const [webglAvailable, setWebglAvailable] = useState(true);
  const [zoomPct, setZoomPct] = useState(100);
  const [autoBeforeMesh, setAutoBeforeMesh] = useState<ParsedObjMesh | null>(null);
  const [autoAfterMesh, setAutoAfterMesh] = useState<ParsedObjMesh | null>(null);
  const [mtlDefs, setMtlDefs] = useState<Record<string, MtlMaterialDef>>({});
  const [errorFaces, setErrorFaces] = useState<Partial<Record<ErrorKindKey, Set<number>>>>({});
  const [layoutMode, setLayoutMode] = useState<ViewportLayoutMode>("split");
  const [canvasHeight, setCanvasHeight] = useState<"normal" | "tall" | "max">("tall");
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showGridlines, setShowGridlines] = useState<boolean>(!freshPreview);
  const [gridlineCount, setGridlineCount] = useState<number>(0);
  const [stackMode, setStackMode] = useState<FloorStackMode>("single");
  const [stackedNeighbors, setStackedNeighbors] = useState<
    {
      unitId: string;
      mesh: ParsedObjMesh;
      afterMesh: ParsedObjMesh;
      mtl: Record<string, MtlMaterialDef>;
    }[]
  >([]);
  const [seamConflictCount, setSeamConflictCount] = useState<number>(0);

  // Auto-load real OBJs, materials.mtl (with textures), and errors_before.json per-face error sets
  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (cancelled) return;
      setAutoBeforeMesh(null);
      setAutoAfterMesh(null);
      setMtlDefs(freshPreview?.materials ?? {});
      setErrorFaces(freshPreview?.errorsBefore ?? {});
    });

    if (freshPreview) {
      return () => { cancelled = true; };
    }

    const baseUrl = `/models/${encodeURIComponent(unit.id)}/`;

    fetch(`${baseUrl}materials.mtl`)
      .then((r) => (r.ok ? r.text() : null))
      .then((txt) => {
        if (!cancelled && txt) {
          setMtlDefs(parseMtlFile(txt, baseUrl));
        }
      })
      .catch(() => {});

    const cacheBust = `?v=${unit.trisAfter ?? 1}_smooth4`;
    let latestAfterTxt: string | null = null;
    let latestBeforeTransform: ParsedObjMesh["transform"] | undefined;

    // 1. Fetch AFTER immediately so the repaired model renders in <0.3s
    fetch(`${baseUrl}after.obj${cacheBust}`, { cache: "no-store" })
      .then((r) => (r.ok ? r.text() : null))
      .then((txtAfter) => {
        if (cancelled || !txtAfter || !txtAfter.includes("v ")) return;
        latestAfterTxt = txtAfter;
        setAutoAfterMesh(
          parseWavefrontObj(txtAfter, `${unit.id}.fixed.obj`, latestBeforeTransform),
        );
      })
      .catch(() => {});

    // 2. Fetch BEFORE in parallel, and only fetch errors_before.json after BEFORE is rendered
    // so errors_before.json never competes for HTTP/1.1 sockets with before.obj / after.obj
    fetch(`${baseUrl}before.obj${cacheBust}`)
      .then((r) => (r.ok ? r.text() : null))
      .then((txtBefore) => {
        if (cancelled || !txtBefore || !txtBefore.includes("v ")) return;
        const parsedBefore = parseWavefrontObj(txtBefore, `${unit.id}.obj`);
        latestBeforeTransform = parsedBefore.transform;
        setAutoBeforeMesh(parsedBefore);
        if (latestAfterTxt) {
          setAutoAfterMesh(
            parseWavefrontObj(latestAfterTxt, `${unit.id}.fixed.obj`, parsedBefore.transform),
          );
        }
        return fetch(`${baseUrl}errors_before.json`)
          .then((r) => (r.ok ? r.json() : null))
          .then((doc: ErrorsFaceMap | null) => {
            if (!cancelled && doc?.faces) {
              const map: Partial<Record<ErrorKindKey, Set<number>>> = {};
              for (const meta of ERROR_KIND_META) {
                const arr = doc.faces[meta.key];
                if (Array.isArray(arr)) {
                  map[meta.key] = new Set(arr);
                }
              }
              setErrorFaces(map);
            }
          });
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [unit.id, unit.trisAfter, freshPreview]);

  const activeBeforeMesh = importedBeforeObj ?? autoBeforeMesh;
  const activeAfterMesh = importedAfterObj ?? autoAfterMesh;
  const afterErrorFaces = freshPreview?.errorsAfter ?? EMPTY_ERROR_FACES;

  // Load stacked neighbor floors in the exact same coordinate frame (`activeBeforeMesh.transform`)
  useEffect(() => {
    let cancelled = false;
    if (freshPreview || stackMode === "single" || !activeBeforeMesh?.transform) {
      queueMicrotask(() => {
        if (cancelled) return;
        setStackedNeighbors([]);
        setSeamConflictCount(0);
      });
      return () => {
        cancelled = true;
      };
    }

    const refTx = activeBeforeMesh.transform;
    const neighborIds =
      stackMode === "stack_tower"
        ? CHTM_TOWER_STACK.filter((id) => id !== unit.id)
        : CHTM_STACK_NEIGHBORS[unit.id] ?? ["Chtm_2nd_floor"];

    Promise.all(
      neighborIds.map(async (nid) => {
        const nBase = `/models/${encodeURIComponent(nid)}/`;
        const [objRes, afterRes, mtlRes] = await Promise.all([
          fetch(`${nBase}before.obj`).catch(() => null),
          fetch(`${nBase}after.obj`).catch(() => null),
          fetch(`${nBase}materials.mtl`).catch(() => null),
        ]);
        if (!objRes || !objRes.ok) return null;
        const objTxt = await objRes.text();
        if (!objTxt.includes("v ")) return null;
        const nMesh = parseWavefrontObj(objTxt, `${nid}.obj`, refTx);
        let nAfterMesh = nMesh;
        if (afterRes && afterRes.ok) {
          const afterTxt = await afterRes.text();
          if (afterTxt && afterTxt.includes("v ")) {
            nAfterMesh = parseWavefrontObj(afterTxt, `${nid}.fixed.obj`, refTx);
          }
        }
        let nMtl: Record<string, MtlMaterialDef> = {};
        if (mtlRes && mtlRes.ok) {
          const mtlTxt = await mtlRes.text();
          nMtl = parseMtlFile(mtlTxt, nBase);
        }
        return { unitId: nid, mesh: nMesh, afterMesh: nAfterMesh, mtl: nMtl };
      }),
    ).then((loaded) => {
      if (cancelled) return;
      const valid = loaded.filter(
        (
          x,
        ): x is {
          unitId: string;
          mesh: ParsedObjMesh;
          afterMesh: ParsedObjMesh;
          mtl: Record<string, MtlMaterialDef>;
        } => x !== null,
      );
      setStackedNeighbors(valid);
      const { conflictFaceIds } = computeStackedSeamConflicts(
        activeBeforeMesh,
        valid.map((v) => v.mesh),
      );
      setSeamConflictCount(conflictFaceIds.size);
    });

    return () => {
      cancelled = true;
    };
  }, [stackMode, unit.id, activeBeforeMesh, freshPreview]);

  useEffect(() => {
    const leftEl = beforeMountRef.current;
    const rightEl = afterMountRef.current;
    if (!leftEl || !rightEl) return;
    const initial = initialFreshPreview.current;

    let rendererLeft: THREE.WebGLRenderer;
    let rendererRight: THREE.WebGLRenderer;
    try {
      rendererLeft = new THREE.WebGLRenderer({
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
      });
      rendererRight = new THREE.WebGLRenderer({
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
      });
    } catch {
      queueMicrotask(() => setWebglAvailable(false));
      return;
    }

    rendererLeft.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    rendererRight.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    for (const renderer of [rendererLeft, rendererRight]) {
      renderer.domElement.style.width = "100%";
      renderer.domElement.style.height = "100%";
    }
    rendererLeft.setClearColor(0x0b101b, 1);
    rendererRight.setClearColor(0x0b101b, 1);
    rendererLeft.outputColorSpace = THREE.SRGBColorSpace;
    rendererRight.outputColorSpace = THREE.SRGBColorSpace;

    leftEl.innerHTML = "";
    rightEl.innerHTML = "";
    leftEl.appendChild(rendererLeft.domElement);
    rightEl.appendChild(rendererRight.domElement);

    const sceneLeft = new THREE.Scene();
    const sceneRight = new THREE.Scene();

    const addLightsAndGrid = (scene: THREE.Scene) => {
      const amb = new THREE.AmbientLight(0xffffff, 1.05);
      const hemi = new THREE.HemisphereLight(0xffffff, 0xcbd5e1, 1.45);
      hemi.position.set(0, 25, 0);
      const dir1 = new THREE.DirectionalLight(0xffffff, 1.25);
      dir1.position.set(14, 24, 16);
      const dir2 = new THREE.DirectionalLight(0xe2e8f0, 0.85);
      dir2.position.set(-14, 16, -12);
      const grid = new THREE.GridHelper(32, 32, 0x1e293b, 0x111827);
      grid.position.y = -2.4;
      scene.add(amb, hemi, dir1, dir2, grid);
    };
    addLightsAndGrid(sceneLeft);
    addLightsAndGrid(sceneRight);

    const camLeft = new THREE.PerspectiveCamera(42, 1, 0.05, 1500);
    const camRight = new THREE.PerspectiveCamera(42, 1, 0.05, 1500);
    camLeft.position.set(11, 10, 14);
    camRight.position.set(11, 10, 14);

    const controlsLeft = new OrbitControls(camLeft, rendererLeft.domElement);
    const controlsRight = new OrbitControls(camRight, rendererRight.domElement);

    for (const ctrl of [controlsLeft, controlsRight]) {
      ctrl.enableDamping = true;
      ctrl.dampingFactor = 0.08;
      ctrl.screenSpacePanning = true;
      ctrl.enablePan = true;
      ctrl.panSpeed = 1.15;
      ctrl.rotateSpeed = 0.85;
      ctrl.zoomSpeed = 1.15;
      ctrl.minDistance = 1.2;
      ctrl.maxDistance = 140;
      ctrl.target.set(0, 0, 0);
      ctrl.update();
    }

    let isSyncing = false;
    const syncFrom = (
      srcCam: THREE.PerspectiveCamera,
      srcCtrl: OrbitControls,
      dstCam: THREE.PerspectiveCamera,
      dstCtrl: OrbitControls,
    ) => {
      if (isSyncing || !syncCamerasRef.current) return;
      isSyncing = true;
      dstCam.position.copy(srcCam.position);
      dstCam.quaternion.copy(srcCam.quaternion);
      dstCtrl.target.copy(srcCtrl.target);
      dstCtrl.update();
      isSyncing = false;
    };

    const onLeftChange = () => syncFrom(camLeft, controlsLeft, camRight, controlsRight);
    const onRightChange = () => syncFrom(camRight, controlsRight, camLeft, controlsLeft);
    controlsLeft.addEventListener("change", onLeftChange);
    controlsRight.addEventListener("change", onRightChange);

    const resizeAll = () => {
      for (const [el, renderer, cam] of [
        [leftEl, rendererLeft, camLeft],
        [rightEl, rendererRight, camRight],
      ] as const) {
        const w = Math.max(300, el.clientWidth || 520);
        const h = Math.max(280, el.clientHeight || 560);
        renderer.setSize(w, h, false);
        cam.aspect = w / h;
        if (initial.freshPreview && initial.importedBeforeObj) {
          cam.position.normalize().multiplyScalar(previewCameraDistance(initial.importedBeforeObj.positions, cam.fov, cam.aspect));
        }
        cam.updateProjectionMatrix();
      }
    };

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver(() => resizeAll());
      ro.observe(leftEl);
      ro.observe(rightEl);
    }
    resizeAll();

    engineRef.current = {
      rendererLeft,
      rendererRight,
      sceneLeft,
      sceneRight,
      camLeft,
      camRight,
      controlsLeft,
      controlsRight,
      partsLeft: null,
      partsRight: null,
      resizeAll,
    };

    let animId = 0;
    const animate = () => {
      controlsLeft.update();
      controlsRight.update();
      rendererLeft.render(sceneLeft, camLeft);
      rendererRight.render(sceneRight, camRight);
      animId = requestAnimationFrame(animate);
    };
    animId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animId);
      ro?.disconnect();
      controlsLeft.removeEventListener("change", onLeftChange);
      controlsRight.removeEventListener("change", onRightChange);
      controlsLeft.dispose();
      controlsRight.dispose();
      if (engineRef.current) {
        disposePanelParts(sceneLeft, engineRef.current.partsLeft);
        disposePanelParts(sceneRight, engineRef.current.partsRight);
      }
      rendererLeft.dispose();
      rendererRight.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      engineRef.current?.resizeAll();
    }, 25);
    return () => clearTimeout(timer);
  }, [layoutMode, canvasHeight, isFullscreen]);

  useEffect(() => {
    const eng = engineRef.current;
    if (!eng) return;

    disposePanelParts(eng.sceneLeft, eng.partsLeft);
    disposePanelParts(eng.sceneRight, eng.partsRight);

    const partsLeft = buildModelBaseParts("before", activeBeforeMesh, mtlDefs, !freshPreview, Boolean(freshPreview));
    const partsRight = buildModelBaseParts("after", activeAfterMesh, mtlDefs, !freshPreview, Boolean(freshPreview));
    setGridlineCount(partsLeft.gridlineCount ?? 0);

    // If Floor Stacking is enabled, append stacked neighbor floors in shared world space + highlight seam conflicts
    if (stackedNeighbors.length > 0) {
      for (const sn of stackedNeighbors) {
        const nLeft = buildModelBaseParts("before", sn.mesh, sn.mtl);
        const nRight = buildModelBaseParts("after", sn.afterMesh, sn.mtl);
        partsLeft.root.add(nLeft.root);
        partsRight.root.add(nRight.root);
        partsLeft.textures.push(...nLeft.textures);
        partsRight.textures.push(...nRight.textures);
      }

      const { seamOverlayPositions } = computeStackedSeamConflicts(
        activeBeforeMesh,
        stackedNeighbors.map((s) => s.mesh),
      );
      if (seamOverlayPositions.length > 0) {
        const seamGeom = new THREE.BufferGeometry();
        seamGeom.setAttribute("position", new THREE.BufferAttribute(seamOverlayPositions, 3));
        const seamMat = new THREE.MeshBasicMaterial({
          color: 0x06b6d4, // Bright Cyan for Inter-Floor Stack Seam Z-Fighting
          side: THREE.DoubleSide,
          polygonOffset: true,
          polygonOffsetFactor: -2,
          polygonOffsetUnits: -2,
        });
        partsLeft.root.add(new THREE.Mesh(seamGeom, seamMat));
      }
    }

    eng.sceneLeft.add(partsLeft.root);
    eng.sceneRight.add(partsRight.root);
    eng.partsLeft = partsLeft;
    eng.partsRight = partsRight;
    updateFreshFacadeOverlay(partsLeft, activeBeforeMesh, freshPreview?.errorGeometryBefore?.facadeFaces ?? null, Boolean(freshPreview?.showFacade));
    updateFreshFacadeOverlay(partsRight, activeAfterMesh, freshPreview?.errorGeometryAfter?.facadeFaces ?? null, Boolean(freshPreview?.showFacade));

    const hasErrLeft = updateErrorOverlayInPlace(
      partsLeft,
      "before",
      activeBeforeMesh,
      unit.errorsBefore,
      errorFaces,
      enabledKinds,
      freshPreview?.errorGeometryBefore ?? null,
    );
    const hasErrRight = updateErrorOverlayInPlace(
      partsRight,
      "after",
      activeAfterMesh,
      unit.errorsAfter,
      afterErrorFaces,
      enabledKinds,
      freshPreview?.errorGeometryAfter ?? null,
    );

    applyAppearanceInPlace(partsLeft, {
      showTextures,
      showWireframe,
      showXray,
      isolateErrors,
      showGridlines,
      showMaterialColours: freshPreview?.materialColours,
      hasActiveErrorOverlay: hasErrLeft,
    });
    applyAppearanceInPlace(partsRight, {
      showTextures,
      showWireframe,
      showXray,
      isolateErrors,
      showGridlines: freshPreview ? showGridlines : false,
      showMaterialColours: freshPreview?.materialColours,
      hasActiveErrorOverlay: hasErrRight,
    });
  }, [activeBeforeMesh, activeAfterMesh, mtlDefs, stackedNeighbors]);

  useEffect(() => {
    const eng = engineRef.current;
    if (!eng) return;

    updateFreshFacadeOverlay(eng.partsLeft, activeBeforeMesh, freshPreview?.errorGeometryBefore?.facadeFaces ?? null, Boolean(freshPreview?.showFacade));
    updateFreshFacadeOverlay(eng.partsRight, activeAfterMesh, freshPreview?.errorGeometryAfter?.facadeFaces ?? null, Boolean(freshPreview?.showFacade));
    const hasErrLeft = updateErrorOverlayInPlace(
      eng.partsLeft,
      "before",
      activeBeforeMesh,
      unit.errorsBefore,
      errorFaces,
      enabledKinds,
      freshPreview?.errorGeometryBefore ?? null,
    );
    const hasErrRight = updateErrorOverlayInPlace(
      eng.partsRight,
      "after",
      activeAfterMesh,
      unit.errorsAfter,
      afterErrorFaces,
      enabledKinds,
      freshPreview?.errorGeometryAfter ?? null,
    );

    applyAppearanceInPlace(eng.partsLeft, {
      showTextures,
      showWireframe,
      showXray,
      isolateErrors,
      showGridlines,
      showMaterialColours: freshPreview?.materialColours,
      hasActiveErrorOverlay: hasErrLeft,
    });
    applyAppearanceInPlace(eng.partsRight, {
      showTextures,
      showWireframe,
      showXray,
      isolateErrors,
      showGridlines: freshPreview ? showGridlines : false,
      showMaterialColours: freshPreview?.materialColours,
      hasActiveErrorOverlay: hasErrRight,
    });
  }, [
    unit.errorsBefore,
    unit.errorsAfter,
    errorFaces,
    afterErrorFaces,
    enabledKinds,
    showTextures,
    showWireframe,
    showXray,
    isolateErrors,
    showGridlines,
    activeBeforeMesh,
    activeAfterMesh,
    freshPreview?.materialColours,
    freshPreview?.showFacade,
    freshPreview?.errorGeometryBefore,
    freshPreview?.errorGeometryAfter,
  ]);

  useEffect(() => {
    const eng = engineRef.current;
    if (!eng) return;
    if (!blinkFlicker) {
      if (eng.partsLeft?.errorMesh) eng.partsLeft.errorMesh.visible = true;
      return;
    }
    let vis = true;
    const timer = setInterval(() => {
      vis = !vis;
      if (eng.partsLeft?.errorMesh) {
        eng.partsLeft.errorMesh.visible = vis;
      }
    }, 350);
    return () => {
      clearInterval(timer);
      if (eng.partsLeft?.errorMesh) eng.partsLeft.errorMesh.visible = true;
    };
  }, [blinkFlicker]);

  const setCameraPose = useCallback(
    (pos: [number, number, number], target: [number, number, number], nextZoomPct = 100) => {
      setZoomPct(nextZoomPct);
      const eng = engineRef.current;
      if (!eng) return;
      eng.controlsLeft.target.set(...target);
      eng.camLeft.position.set(...pos);
      eng.controlsLeft.update();
      eng.controlsRight.target.set(...target);
      eng.camRight.position.set(...pos);
      eng.controlsRight.update();
    },
    [],
  );

  const zoomIn = useCallback(() => {
    setZoomPct((prev) => Math.min(450, Math.round(prev * 1.28)));
    const eng = engineRef.current;
    if (!eng) return;
    const offset = eng.camLeft.position.clone().sub(eng.controlsLeft.target);
    const nextLen = Math.max(1.5, Math.min(110, offset.length() * 0.78));
    offset.normalize().multiplyScalar(nextLen);
    eng.camLeft.position.copy(eng.controlsLeft.target).add(offset);
    eng.controlsLeft.update();
    eng.camRight.position.copy(eng.camLeft.position);
    eng.controlsRight.target.copy(eng.controlsLeft.target);
    eng.controlsRight.update();
  }, []);

  const zoomOut = useCallback(() => {
    setZoomPct((prev) => Math.max(25, Math.round(prev * 0.8)));
    const eng = engineRef.current;
    if (!eng) return;
    const offset = eng.camLeft.position.clone().sub(eng.controlsLeft.target);
    const nextLen = Math.max(1.5, Math.min(110, offset.length() * 1.25));
    offset.normalize().multiplyScalar(nextLen);
    eng.camLeft.position.copy(eng.controlsLeft.target).add(offset);
    eng.controlsLeft.update();
    eng.camRight.position.copy(eng.camLeft.position);
    eng.controlsRight.target.copy(eng.controlsLeft.target);
    eng.controlsRight.update();
  }, []);

  const resetCamera = useCallback(() => {
    const eng = engineRef.current;
    const position = new THREE.Vector3(11, 10, 14);
    if (freshPreview && importedBeforeObj && eng) position.normalize().multiplyScalar(previewCameraDistance(importedBeforeObj.positions, 42, eng.camLeft.aspect));
    setCameraPose(position.toArray() as [number, number, number], [0, 0, 0], 100);
  }, [setCameraPose, freshPreview, importedBeforeObj]);

  const handlePanStep = useCallback((dx: number, dy: number) => {
    const eng = engineRef.current;
    if (!eng) return;
    const cam = eng.camLeft;
    const ctrl = eng.controlsLeft;
    const forward = ctrl.target.clone().sub(cam.position).normalize();
    const right = new THREE.Vector3().crossVectors(forward, cam.up).normalize();
    const up = new THREE.Vector3().crossVectors(right, forward).normalize();
    const dist = cam.position.distanceTo(ctrl.target);
    const scale = Math.max(0.45, dist * 0.14);
    const delta = right.multiplyScalar(dx * scale).add(up.multiplyScalar(dy * scale));

    cam.position.add(delta);
    ctrl.target.add(delta);
    ctrl.update();

    eng.camRight.position.copy(cam.position);
    eng.controlsRight.target.copy(ctrl.target);
    eng.controlsRight.update();
  }, []);

  useEffect(() => {
    if (flySpotIndex === null || flySpotIndex === undefined) return;
    const theta = 0.4 + flySpotIndex * 0.55;
    const r = 7.8;
    queueMicrotask(() => {
      setCameraPose(
        [r * Math.sin(theta), 4.2, r * Math.cos(theta)],
        [Math.sin(theta) * 1.6, 0.1, Math.cos(theta) * 1.6],
        160,
      );
    });
  }, [flySpotIndex, setCameraPose]);

  const loadedMatCount = Object.keys(mtlDefs).length;

  const heightClass = isFullscreen
    ? "h-[calc(100vh-165px)] min-h-[560px]"
    : canvasHeight === "max"
      ? "h-[780px]"
      : canvasHeight === "tall"
        ? "h-[580px]"
        : "h-[420px]";

  const wrapperClass = isFullscreen
    ? "fixed inset-3 z-50 flex flex-col rounded-2xl border-2 border-brand-500/60 bg-[#070b14] p-4 shadow-2xl overflow-hidden space-y-3"
    : "space-y-3";

  return (
    <div className={wrapperClass}>
      {/* Zoom / Pan / Enlarge / Layout / Texture Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 rounded-xl border border-white/10 bg-ink-900/95 px-4 py-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 text-ink-300">
          <span className="inline-flex items-center gap-1.5 font-semibold text-white">
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
            {freshPreview ? 'Fresh floor 3D view:' : 'Checkpoint 17 3D OrbitControls:'}
          </span>
          <span className="hidden 2xl:inline text-[11px] text-ink-400">
            (Left-drag: Orbit · Right-drag or Shift+drag: Free Pan/Move · Scroll: Zoom)
          </span>
          <span className="rounded-md bg-emerald-500/15 px-2.5 py-1 font-mono text-[11px] text-emerald-300">
            {loadedMatCount > 0 ? `${loadedMatCount} MTL Textures Loaded` : "Loading MTL..."}
          </span>
          {onToggleTextures && !freshPreview && (
            <button
              type="button"
              onClick={onToggleTextures}
              aria-pressed={showTextures}
              className={`rounded-lg border px-3 py-1.5 font-semibold transition-colors ${
                showTextures
                  ? "border-emerald-500/50 bg-emerald-500/20 text-emerald-200"
                  : "border-white/15 bg-ink-800 text-ink-300 hover:text-white"
              }`}
            >
              {showTextures ? "✓ Textures Shown [U] (Click to Hide)" : "Textures Hidden [U] (Click to Show)"}
            </button>
          )}
          <button
            type="button"
            onClick={() => setShowGridlines((g) => !g)}
            aria-pressed={showGridlines}
            className={`rounded-lg border px-3 py-1.5 font-semibold transition-colors ${
              showGridlines
                ? "border-sky-400/50 bg-sky-500/25 text-sky-200"
                : "border-white/15 bg-ink-800 text-ink-300 hover:text-white"
            }`}
          >
            {freshPreview ? `Triangle edges (both models): ${showGridlines ? 'shown' : 'hidden'}` : showGridlines
              ? `✓ Flat-Surface Gridlines [G]: ${gridlineCount.toLocaleString()} (BEFORE) → 0 (AFTER)`
              : `Flat-Surface Gridlines Hidden [G] (${gridlineCount.toLocaleString()})`}
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2" role="group" aria-label="3D Zoom Controls">
          {/* Multi-Floor Stack Switcher (detects inter-floor seam z-fighting glitches) */}
          {!freshPreview && <div className="inline-flex items-center rounded-lg border border-cyan-500/30 bg-ink-950 p-0.5">
            <button
              type="button"
              onClick={() => setStackMode("single")}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition ${
                stackMode === "single"
                  ? "bg-cyan-500/25 text-cyan-200"
                  : "text-ink-300 hover:text-white"
              }`}
            >
              1 Floor Only
            </button>
            <button
              type="button"
              onClick={() => setStackMode("stack_above")}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition ${
                stackMode === "stack_above"
                  ? "bg-cyan-500/30 text-cyan-100 border border-cyan-400/40"
                  : "text-ink-300 hover:text-white"
              }`}
            >
              + Stack Floor Above (Seam Glitch Check)
            </button>
            <button
              type="button"
              onClick={() => setStackMode("stack_tower")}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition ${
                stackMode === "stack_tower"
                  ? "bg-cyan-500/30 text-cyan-100 border border-cyan-400/40"
                  : "text-ink-300 hover:text-white"
              }`}
            >
              + Stack Floors 1F–4F
            </button>
          </div>}
          {stackMode !== "single" && !freshPreview && (
            <span className="rounded-lg border border-cyan-400/50 bg-cyan-500/20 px-2.5 py-1 font-mono text-[11px] font-semibold text-cyan-200">
              Stack Seam Glitches (Cyan): {seamConflictCount.toLocaleString()} coplanar faces
            </span>
          )}

          {/* Viewport Layout Mode Switcher */}
          <div className="inline-flex rounded-lg border border-white/15 bg-ink-950 p-0.5">
            <button
              type="button"
              onClick={() => setLayoutMode("split")}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition ${
                layoutMode === "split"
                  ? "bg-brand-500/30 text-white"
                  : "text-ink-300 hover:text-white"
              }`}
            >
              Split View
            </button>
            <button
              type="button"
              onClick={() => setLayoutMode("before_only")}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition ${
                layoutMode === "before_only"
                  ? "bg-red-500/30 text-red-100"
                  : "text-ink-300 hover:text-white"
              }`}
            >
              Before (100% Width)
            </button>
            <button
              type="button"
              onClick={() => setLayoutMode("after_only")}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition ${
                layoutMode === "after_only"
                  ? "bg-emerald-500/30 text-emerald-100"
                  : "text-ink-300 hover:text-white"
              }`}
            >
              After (100% Width)
            </button>
          </div>

          <button
            type="button"
            onClick={zoomIn}
            aria-label="Zoom In"
            className="rounded-lg border border-brand-500/40 bg-brand-500/20 px-3 py-1.5 font-semibold text-white hover:bg-brand-500/35"
          >
            + Zoom In
          </button>
          <button
            type="button"
            onClick={zoomOut}
            aria-label="Zoom Out"
            className="rounded-lg border border-white/15 bg-ink-800 px-3 py-1.5 font-semibold text-white hover:bg-white/10"
          >
            − Zoom Out
          </button>

          {/* Free Pan Directional Pad */}
          <div className="inline-flex items-center gap-0.5 rounded-lg border border-white/15 bg-ink-800 px-1.5 py-1">
            <button
              type="button"
              onClick={() => handlePanStep(-1, 0)}
              title="Pan Left"
              className="rounded px-1.5 py-0.5 text-ink-200 hover:bg-white/10 hover:text-white"
            >
              ◀
            </button>
            <button
              type="button"
              onClick={() => handlePanStep(1, 0)}
              title="Pan Right"
              className="rounded px-1.5 py-0.5 text-ink-200 hover:bg-white/10 hover:text-white"
            >
              ▶
            </button>
            <button
              type="button"
              onClick={() => handlePanStep(0, 1)}
              title="Pan Up"
              className="rounded px-1.5 py-0.5 text-ink-200 hover:bg-white/10 hover:text-white"
            >
              ▲
            </button>
            <button
              type="button"
              onClick={() => handlePanStep(0, -1)}
              title="Pan Down"
              className="rounded px-1.5 py-0.5 text-ink-200 hover:bg-white/10 hover:text-white"
            >
              ▼
            </button>
            <button
              type="button"
              onClick={() => setCameraPose([0.01, 22, 0.01], [0, 0, 0], 100)}
              title="Top-Down Plan View"
              className="rounded px-1.5 py-0.5 text-[11px] font-semibold text-ink-200 hover:bg-white/10 hover:text-white"
            >
              Top
            </button>
          </div>

          <button
            type="button"
            onClick={resetCamera}
            aria-label="Reset Zoom"
            className="rounded-lg border border-white/15 bg-ink-800 px-3 py-1.5 text-ink-200 hover:bg-white/10 hover:text-white"
          >
            Reset View ({zoomPct}%)
          </button>

          {!isFullscreen && (
            <button
              type="button"
              onClick={() =>
                setCanvasHeight((h) => (h === "normal" ? "tall" : h === "tall" ? "max" : "normal"))
              }
              className="rounded-lg border border-white/15 bg-ink-800 px-2.5 py-1.5 text-ink-200 hover:bg-white/10 hover:text-white"
            >
              Size: {canvasHeight === "max" ? "780px" : canvasHeight === "tall" ? "580px" : "420px"}
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsFullscreen((f) => !f)}
            className={`rounded-lg border px-3 py-1.5 font-semibold transition ${
              isFullscreen
                ? "border-amber-400/60 bg-amber-500/25 text-amber-200"
                : "border-brand-500/50 bg-brand-500/25 text-white hover:bg-brand-500/40"
            }`}
          >
            {isFullscreen ? "✕ Exit Fullscreen" : "⛶ Enlarge Fullscreen"}
          </button>
        </div>
      </div>

      {/* Synced Dual / Full-Width Viewports */}
      <div
        className={`grid gap-4 ${
          layoutMode === "split" ? "grid-cols-1 lg:grid-cols-2" : "grid-cols-1"
        } flex-1`}
      >
        {/* BEFORE Viewport */}
        <div
          className={`overflow-hidden rounded-xl border border-red-500/25 bg-ink-900 ${
            layoutMode === "after_only" ? "hidden" : ""
          }`}
        >
          <div className="flex items-center justify-between border-b border-white/10 bg-red-950/25 px-4 py-3">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-red-300">
                {freshPreview ? `Fresh source - not cleaned (${unit.id})` : `BEFORE · Checkpoint 17 Export (${unit.id})`}
              </span>
              <p className="mt-0.5 text-xs text-ink-300">
                {activeBeforeMesh
                  ? `${freshPreview ? 'Fresh OBJ' : 'Real CKPT17 OBJ'}: ${activeBeforeMesh.triangleCount.toLocaleString()} tris · ${activeBeforeMesh.materialGroups.length} textured groups`
                  : `${unit.trisBefore.toLocaleString()} triangles · Loading CKPT17 OBJ...`}
              </p>
            </div>
            <span className="rounded bg-red-500/20 px-2.5 py-1 font-mono text-xs text-red-200">
              {freshPreview ? (freshPreview.materialColours ? 'Material colours' : showTextures ? 'Textured source' : 'Plain source') : showTextures ? "Textured + Error Overlay" : "Flat Grey + Error Overlay"}
            </span>
          </div>
          {webglAvailable ? (
            <div
              ref={beforeMountRef}
              data-testid="viewport-before"
              className={`${heightClass} w-full cursor-grab active:cursor-grabbing select-none`}
            />
          ) : (
            <div
              data-testid="viewport-before-fallback"
              className={`flex ${heightClass} flex-col items-center justify-center p-6 text-center text-xs text-ink-300`}
            >
              <p className="font-medium text-white">3D Before Viewport ({unit.label})</p>
              <p className="mt-1">{unit.trisBefore.toLocaleString()} triangles · Zoom {zoomPct}%</p>
            </div>
          )}
        </div>

        {/* AFTER Viewport */}
        <div
          className={`overflow-hidden rounded-xl border border-emerald-500/25 bg-ink-900 ${
            layoutMode === "before_only" ? "hidden" : ""
          }`}
        >
          <div className="flex items-center justify-between border-b border-white/10 bg-emerald-950/25 px-4 py-3">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-emerald-300">
                {freshPreview ? (activeAfterMesh ? `${freshPreview.afterKind === 'accepted' ? 'Accepted cleaned floor' : 'Cleanup candidate - not accepted'} (${unit.id})` : 'After - waiting for a validated repair') : `AFTER · Engine Fixed Version (${unit.id}.fixed.obj)`}
              </span>
              <p className="mt-0.5 text-xs text-ink-300">
                {freshPreview ? (activeAfterMesh ? `${activeAfterMesh.triangleCount.toLocaleString()} triangles; inspect the saved validation evidence` : 'Waiting for a guarded candidate') : activeAfterMesh
                  ? `Real Mesh: ${activeAfterMesh.triangleCount.toLocaleString()} tris · Clean Textured Facade`
                  : unit.trisAfter !== null
                    ? `${unit.trisAfter.toLocaleString()} triangles (-${(((unit.trisBefore - unit.trisAfter) / unit.trisBefore) * 100).toFixed(1)}% fewer)`
                    : "Click 'Run Fix Pipeline' to execute geometry repair"}
              </p>
            </div>
            <span className="rounded bg-emerald-500/20 px-2.5 py-1 font-mono text-xs text-emerald-200">
              {freshPreview ? (activeAfterMesh ? 'Saved model' : 'Pending') : showTextures ? "Textured Clean Slab" : "Flat Grey Clean Slab"}
            </span>
          </div>
          {webglAvailable ? (
            <div
              ref={afterMountRef}
              data-testid="viewport-after"
              className={`${heightClass} w-full cursor-grab active:cursor-grabbing select-none`}
            />
          ) : (
            <div
              data-testid="viewport-after-fallback"
              className={`flex ${heightClass} flex-col items-center justify-center p-6 text-center text-xs text-ink-300`}
            >
              <p className="font-medium text-white">3D After Viewport ({unit.label})</p>
              <p className="mt-1">
                {unit.trisAfter !== null
                  ? `${unit.trisAfter.toLocaleString()} triangles · Zoom ${zoomPct}%`
                  : "Pending Stage 3 Engine Repair"}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
