"use client";
import { useEffect, useMemo, useState } from 'react';
import { loadFreshPreview, previewMesh, materialInspectionColour, type PreviewIdentity, type PreviewKind, type LoadedFreshPreview, type LoadedFreshErrors } from '@/lib/buildings/freshMainInfraPreview';
import type { ParsedObjMesh } from '@/lib/buildings/meshbuf';
import { type ErrorKindKey, type FloorUnitRecord, type ErrorCounts } from '@/lib/buildings/types';
import { DualModelCanvas } from './DualModelCanvas';
import { ErrorFilterTable } from './ErrorFilterTable';
import { FloorPipeline } from './FloorPipeline';
import { InspectionWorkspace } from './InspectionWorkspace';
import { freshFloorStages } from '@/lib/buildings/freshMainInfraPipeline';
import type { FreshFloorProgress } from '@/lib/buildings/freshMainInfraStatus';
const emptyCounts: ErrorCounts = { flicker_diff: 0, flicker_same: 0, reversed: 0, hidden: 0, loose: 0, open_edges: 0, cracks: 0 };
const allKindsOff: Record<ErrorKindKey, boolean> = { flicker_diff: false, flicker_same: false, reversed: false, hidden: false, loose: false, open_edges: false, cracks: false };
interface FreshPreviewProps {
    identity: PreviewIdentity;
    sourceUrl: string;
    afterUrl: string | null;
    afterKind?: PreviewKind;
    progress?: FreshFloorProgress;
}
export function FreshMainInfraPreview(props: FreshPreviewProps) {
    const { identity, sourceUrl, afterUrl, afterKind = 'candidate' } = props;
    return <FreshPreviewContent key={JSON.stringify([identity.source_revision, identity.run_id, identity.floor, sourceUrl, afterUrl, afterKind])} {...props}/>;
}
function FreshPreviewContent({ identity, sourceUrl, afterUrl, afterKind = 'candidate', progress }: FreshPreviewProps) {
    const [loaded, setLoaded] = useState<{
        source: LoadedFreshPreview;
        before: ParsedObjMesh;
        after: ParsedObjMesh | null;
        errorsAfter: LoadedFreshErrors | null;
        candidate: LoadedFreshPreview | null;
    } | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [appearance, setAppearance] = useState<'textures' | 'materials' | 'plain'>('textures');
    const [xray, setXray] = useState(false);
    const [showFacade, setShowFacade] = useState(false);
    const [collapsed, setCollapsed] = useState(false);
    const [activeStageNo, setActiveStageNo] = useState(4);
    const [enabledKinds, setEnabledKinds] = useState<Record<ErrorKindKey, boolean>>(allKindsOff);
    const [isolateErrors, setIsolateErrors] = useState(false);
    const { source_revision, run_id, floor } = identity;
    useEffect(() => {
        let cancelled = false;
        async function load() {
            try {
                const current = { source_revision, run_id, floor };
                const source = await loadFreshPreview(sourceUrl, current, 'source');
                const before = previewMesh(source);
                const candidate = afterUrl ? await loadFreshPreview(afterUrl, current, afterKind) : null;
                if (candidate && JSON.stringify(candidate.manifest.bounds) !== JSON.stringify(source.manifest.bounds))
                    throw new Error('Candidate display frame differs from the source');
                if (!cancelled)
                    setLoaded({ source, before, candidate, after: candidate ? previewMesh(candidate, before.transform) : null, errorsAfter: candidate?.errors ?? null });
            }
            catch (problem) {
                if (!cancelled)
                    setError(problem instanceof Error ? problem.message : 'Preview unavailable');
            }
        }
        void load();
        return () => { cancelled = true; };
    }, [source_revision, run_id, floor, sourceUrl, afterUrl, afterKind]);
    const unit = useMemo<FloorUnitRecord | null>(() => loaded ? { id: `MAIN_INFRA_${floor}`, building: 'MAIN_INFRA', label: floor, sourceFile: sourceUrl, targetRepairRepoPath: '', trisBefore: loaded.before.triangleCount, trisAfter: loaded.after?.triangleCount ?? null, seconds: 0, peakMb: 0, errorsBefore: loaded.source.errors?.counts ?? emptyCounts, errorsAfter: loaded.errorsAfter?.counts ?? null, invariants: null, validator: null, jevDecisions: [], jevRecommendedAction: 'awaiting_engine_run', ownerVerdict: 'pending', checkpointCommit: null, stages: [] } : null, [loaded, floor, sourceUrl]);
    const freshPreview = useMemo(() => loaded ? { materials: loaded.source.materials, afterKind, materialColours: appearance === 'materials', showFacade, errorsBefore: loaded.source.errors?.faces, errorsAfter: loaded.errorsAfter?.faces, errorGeometryBefore: loaded.source.errors ?? null, errorGeometryAfter: loaded.errorsAfter } : null, [loaded, afterKind, appearance, showFacade]);
    if (error)
        return <p role="alert" className="text-amber-100">Model preview unavailable: {error}. The last accepted model has not changed.</p>;
    if (!loaded || !unit || !freshPreview)
        return <p role="status">Loading saved model and checking its texture assets...</p>;
    const beforeErrors = loaded.source.errors;
    const mapsAvailable = Boolean(beforeErrors || loaded.errorsAfter);
    const facadeBefore = beforeErrors?.facadeFaces;
    const facadeAfter = loaded.errorsAfter?.facadeFaces;
    const stages = progress ? freshFloorStages({ before: loaded.before.triangleCount, after: loaded.after?.triangleCount ?? null,
        sourceErrors: beforeErrors?.counts ?? null, afterErrors: loaded.errorsAfter?.counts ?? null,
        candidateSha: loaded.candidate?.manifest.assets.find(asset => asset.url === loaded.candidate?.manifest.obj_url)?.sha256, progress }) : null;
    return <div className="space-y-3">
  {stages && <FloorPipeline label={`Main Infrastructure - ${floor}`} unitId={`MAIN_INFRA_${floor}`} stages={stages} activeStageNo={activeStageNo} onSelectStage={setActiveStageNo} />}
  <fieldset className="rounded-lg border border-white/20 p-3 text-sm text-ink-200">
   <legend className="px-1 font-semibold text-white">Mesh inspection</legend>
   <div className="flex flex-wrap items-center gap-2">{([['textures', 'Original textures'], ['materials', 'Source material colours'], ['plain', 'Plain surfaces']] as const).map(([mode, label]) => <button key={mode} type="button" aria-pressed={appearance === mode} onClick={() => setAppearance(mode)} className={`rounded-md border px-3 py-2 focus-visible:outline-2 focus-visible:outline-accent-300 ${appearance === mode ? 'border-blue-300 bg-blue-950 text-white' : 'border-white/25 hover:border-white/60'}`}>{label}</button>)}
    <label className="flex items-center gap-2 px-2 py-2"><input type="checkbox" checked={xray} onChange={event => setXray(event.target.checked)}/>X-ray inspection</label>
    <label className="flex items-center gap-2 px-2 py-2"><input type="checkbox" disabled={!facadeBefore && !facadeAfter} checked={showFacade} onChange={event => setShowFacade(event.target.checked)}/>Facade mesh: Before {facadeBefore ? facadeBefore.size.toLocaleString() : 'unavailable'} / After {facadeAfter ? facadeAfter.size.toLocaleString() : 'unavailable'}</label>
   </div><p className="mt-2 text-xs">Colours identify materials, not visibility or validation.</p>
   <p className="mt-2 text-xs">Facade highlighting is measured mesh data, not a preservation verdict.</p>
   {appearance === 'materials' && <ul aria-label="Source material colour legend" className="mt-3 flex flex-wrap gap-x-5 gap-y-2 text-xs">{Object.keys(loaded.source.materials).sort().map(name => <li key={name} className="flex min-w-0 items-center gap-2 break-all"><span aria-hidden="true" className="h-3 w-4 shrink-0 rounded-sm" style={{ backgroundColor: materialInspectionColour(name) }}/>{name}</li>)}</ul>}
  </fieldset>
  <InspectionWorkspace collapsed={collapsed} onToggle={() => setCollapsed(value => !value)} filters={<>
  <fieldset className="rounded-lg border border-white/20 p-3 text-sm text-ink-200"><legend className="px-1 font-semibold text-white">Error kinds</legend>
   <ErrorFilterTable before={beforeErrors?.counts ?? null} after={loaded.errorsAfter?.counts ?? null} enabledKinds={enabledKinds}
     onToggle={kind => setEnabledKinds(value => ({ ...value, [kind]: !value[kind] }))} countLabels />
   <div className="mt-3">
    <label className="inline-flex items-start gap-2 py-1"><input type="checkbox" disabled={!mapsAvailable} checked={isolateErrors} onChange={() => setIsolateErrors(value => !value)}/>Isolate errors</label>
   </div>{!beforeErrors && <p className="mt-2 text-xs">Before error map unavailable.</p>}{loaded.after && !loaded.errorsAfter && <p className="mt-2 text-xs">After error map unavailable.</p>}

  </fieldset>   <label className="mt-3 flex items-center gap-2 text-xs"><input type="checkbox" disabled aria-label="Internal surface seams: unmeasured" />Internal surface seams: unmeasured</label>
   <p className="mt-2 text-xs">Gridline and seam KPI counts are unmeasured. Triangle edges remain available in the viewer.</p>
  </>}>

  <DualModelCanvas unit={unit} enabledKinds={enabledKinds} isolateErrors={isolateErrors} showWireframe={false} showXray={xray} showTextures={appearance === 'textures'} onToggleTextures={() => setAppearance(value => value === 'textures' ? 'plain' : 'textures')} blinkFlicker={false} syncCameras importedBeforeObj={loaded.before} importedAfterObj={loaded.after} freshPreview={freshPreview}/>
  </InspectionWorkspace>
 </div>;
}
