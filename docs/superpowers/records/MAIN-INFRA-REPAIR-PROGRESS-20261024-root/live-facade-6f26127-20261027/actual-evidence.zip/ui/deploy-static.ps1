$ErrorActionPreference='Stop'
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskSite='devenvir@sv70.ifastnet.com'
if((Get-FileHash -Algorithm SHA256 -LiteralPath 'D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023/deploy/known_hosts').Hash.ToLowerInvariant() -ne 'a3cf78817285a92b917c345e8d0df1a6cbb6e2263d1d2870806e16f7f74d6630'){throw 'Configured host keys changed'}
$taskCommon=@('-i','C:/Users/Future26/.ssh/corllenium_siege_ed25519','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=1','-o','LogLevel=ERROR','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023/deploy/known_hosts')
$taskRows=@(
 @{Source="$taskRoot/data/facade-ui-build/ui-package/facade-ui.tar.gz";Name='main-infra-facade-ui.tar.gz';Sha='207fff37eec237a6b6d0da6e639e46020a9c89ff3f89a3519636d40c388d60a8'},
 @{Source="$taskRoot/data/facade-ui-build/ui-package/package.json";Name='main-infra-facade-ui.json';Sha='38032e9b8ea62a0fb041575ffea7677e711659a80bc0c3cb68d2a13fd6c6c67e'},
 @{Source="$taskRoot/data/facade-ui-build/deploy-static.py";Name='deploy-main-infra-facade.py';Sha='facb0ab5502d99d2fe067273f8bcfd1431b987c87158c96c6c9b4a2a0134ecd5'}
)
foreach($taskRow in $taskRows){
 if((Get-FileHash -Algorithm SHA256 -LiteralPath $taskRow.Source).Hash.ToLowerInvariant() -ne $taskRow.Sha){throw 'Static deployment input changed'}
 & scp -q -P 27015 @taskCommon $taskRow.Source ($taskSite+':/tmp/'+$taskRow.Name)
 if($LASTEXITCODE -ne 0){throw ('Static upload failed: '+$taskRow.Name)}
}
$taskRemote='python3 -c "import hashlib,runpy; p=''/tmp/deploy-main-infra-facade.py''; assert hashlib.sha256(open(p,''rb'').read()).hexdigest()==''facb0ab5502d99d2fe067273f8bcfd1431b987c87158c96c6c9b4a2a0134ecd5''; m=''/tmp/main-infra-facade-ui.json''; assert hashlib.sha256(open(m,''rb'').read()).hexdigest()==''38032e9b8ea62a0fb041575ffea7677e711659a80bc0c3cb68d2a13fd6c6c67e''; runpy.run_path(p,run_name=''__main__'')"'
& ssh -p 27015 @taskCommon $taskSite $taskRemote
if($LASTEXITCODE -ne 0){throw 'Static canvas deployment failed; inspect rollback receipt'}
