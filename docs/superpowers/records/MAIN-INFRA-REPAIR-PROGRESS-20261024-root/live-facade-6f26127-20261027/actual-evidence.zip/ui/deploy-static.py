from pathlib import Path,PurePosixPath
import hashlib,json,os,shutil,signal,tarfile,tempfile
from urllib.request import Request,urlopen
from urllib.parse import quote

archive=Path('/tmp/main-infra-facade-ui.tar.gz');manifest=Path('/tmp/main-infra-facade-ui.json')
package=json.loads(manifest.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(archive)==package['archive_sha256'] and package['build_sha']=='dd90dd371cb0859e8e3c6c1b5e0451f6269776f2'
assert package['api_restart'] is package['status_write'] is package['model_write'] is False
deploy=package['deploy_id'];assert deploy.startswith('main-infra-facade-dd90dd3-') and '/' not in deploy
rows={r['path']:r for r in package['files']};assert len(rows)==package['file_count']
for rel in rows:
    p=PurePosixPath(rel)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in rel and rel.startswith(('_next/static/','pipelines/jev-repair/'))
site='https://corllenium.ai.dev-environment.site'
roots=[Path('/home/devenvir/corllenium/web'),Path('/home/devenvir/corllenium/app/public')]
backup=Path('/home/devenvir/corllenium/backups')/deploy;backup.mkdir()
stage=backup/'staged';stage.mkdir()
def fetch(url):
    with urlopen(Request(url,headers={'Cache-Control':'no-cache','Accept-Encoding':'identity'}),timeout=25) as response:
        assert response.status==200
        return response.read()
def bindings(root):
    doc=json.loads((root/'building-repair-status.json').read_bytes())
    result={}
    for name in ('freshMainInfra','freshMainInfraUpper'):
        section=doc.get(name)
        if section:
            result[name]=dict(source_revision=section.get('source_revision'),run_id=section.get('run_id'),floors={floor:{k:row.get(k) for k in ('input_triangles','output_triangles','source_preview','candidate_preview','accepted_preview')} for floor,row in section['floors'].items()})
    return result
health=json.loads(fetch(site+'/api/health'));assert health['sha']=='cedb7c53c35b0599585c17b214f3c29e1dfb7b9f' and health['db']['ok']
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(rows) and all(m.isfile() and m.name in rows for m in members)
    for member in members:
        data=tar.extractfile(member).read();row=rows[member.name]
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        path=stage/member.name;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(data)
old_bindings=[];old_health=[]
for i,root in enumerate(roots):
    assert root.resolve()==root
    old_bindings.append(bindings(root));old_health.append(sha(root/'healthz.json'))
    assert (root/'pipelines/jev-repair').is_dir()
    shutil.copytree(root/'pipelines/jev-repair',backup/('before-'+str(i)))
    for rel,row in rows.items():
        target=root/rel;assert root in target.resolve().parents
        if rel.startswith('_next/static/') and target.exists():assert target.is_file() and not target.is_symlink() and sha(target)==row['sha256'],rel
def interrupted(signum,frame):raise RuntimeError('Deployment interrupted: '+str(signum))
for sig in (signal.SIGHUP,signal.SIGINT,signal.SIGTERM):signal.signal(sig,interrupted)
moved=[];complete=False
try:
    for i,root in enumerate(roots):
        for rel,row in rows.items():
            target=root/rel
            if rel.startswith('_next/static/') and not target.exists():
                target.parent.mkdir(parents=True,exist_ok=True)
                fd,tmp=tempfile.mkstemp(prefix='.canvas-static-',dir=target.parent)
                try:
                    with os.fdopen(fd,'wb') as stream:stream.write((stage/rel).read_bytes());stream.flush();os.fsync(stream.fileno())
                    os.chmod(tmp,0o644)
                    try:os.link(tmp,target)
                    except FileExistsError:assert sha(target)==row['sha256']
                finally:os.unlink(tmp)
        incoming=root/'pipelines'/('.jev-repair-'+deploy);assert not incoming.exists()
        shutil.copytree(stage/'pipelines/jev-repair',incoming)
        old=backup/('active-old-'+str(i));(root/'pipelines/jev-repair').rename(old);moved.append((root,old))
        incoming.rename(root/'pipelines/jev-repair')
    for i,root in enumerate(roots):
        assert all(sha(root/rel)==row['sha256'] for rel,row in rows.items())
        assert bindings(root)==old_bindings[i] and sha(root/'healthz.json')==old_health[i]
    for number,(rel,row) in enumerate(rows.items(),1):
        assert hashlib.sha256(fetch(site+'/'+quote(rel,safe='/!()')+'?canvas_build='+deploy)).hexdigest()==row['sha256'],rel
        if number%25==0:print('PUBLIC_HASHES '+str(number)+'/'+str(len(rows)),flush=True)
    assert fetch(site+'/pipelines/jev-repair/?canvas_build='+deploy)==(stage/'pipelines/jev-repair/index.html').read_bytes()
    after=json.loads(fetch(site+'/api/health'));assert after['sha']==health['sha'] and after['db']['ok']
    for i,root in enumerate(roots):assert bindings(root)==old_bindings[i] and sha(root/'healthz.json')==old_health[i]
    receipt=dict(deploy_id=deploy,build_sha=package['build_sha'],filesystem_hashes_per_root=len(rows),public_hashes=len(rows),api_sha_before_after=after['sha'],backup=str(backup),status_binding_preserved=True,status_files_written=False,app_restart=False,model_write=False,live_producer_action='none')
    (backup/'receipt.json').write_text(json.dumps(receipt)+'\n')
    complete=True;print(json.dumps(receipt),flush=True)
finally:
    if not complete:
        for root,old in reversed(moved):
            target=root/'pipelines/jev-repair'
            if target.exists():target.rename(backup/('failed-'+str(roots.index(root))))
            old.rename(target)
        print('DEPLOY_ROLLED_BACK '+deploy,flush=True)
