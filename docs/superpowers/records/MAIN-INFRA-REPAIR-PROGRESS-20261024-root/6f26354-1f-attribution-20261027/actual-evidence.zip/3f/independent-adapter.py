"""Independent new3F44958 roles; unchanged paid structural/census/strict functions."""
import argparse
from dataclasses import asdict,replace
import hashlib
import json
import math
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT.parents[2]
JOB='MAIN-INFRA-3F-44958-INDEPENDENT-20261027'
SOURCE='e5a300ef12918aaeb4cb48128d9eab4c2a6f37478a09ddf0c3b627a49cbbee65'
ENGINE='a986bc912f6c847a26edd4d2ce922636905b0286cd100c1546b489aaa36f1cd3'
CP='b5ec759bac23a43b3ce6f9042839d295a310168e479d55b1c7b2e4372a808a69'
E3='84880ec064312a6a8b8c16a2af7eff0b068b7951a0bd7b4c143a512b4ef46d2b'
BEFORE_SOURCE='eac7d813adb398adb4b8d94eba54a17020e6552148a892069932804e353eba6d'
BEFORE_ENGINE='deb717d51db9c55ee839f148c0705876c028fceb3e8e25955d254f01eb6f65ab'
AUTHORITY='81c02db5fca5eda121549533cca06a23e14c160860246af9613deedc652b6dfb'
BUILDER='3b600f82331572e486c5d419ea3b2ca7634d7e88'
WRITER='8cecdd73e86ea7bba61090451fc69473e329cdd0'
PROPOSAL='eb719c1fce75bc7b4b2a7d83c279ada0b986c9931693b4fb1ad6099d6d00b813'
PLAN='c84a6045503341a2d8f8f0540fca8eb6f76a2fce31942708046585af436f73d3'
MARKERS=list(range(53318,53342))


def need(ok,message):
    if not ok:raise ValueError(message)


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()


def marker_ancestry(marker):
    selected=marker['selected_current'];kept=marker['original_source_faces']
    need(selected==list(range(44705,44729)) and marker['removed_originals']==MARKERS
        and len(kept)==44953 and kept==sorted(set(kept)) and not set(kept)&set(MARKERS), 'Exact new marker SOURCE/current mapping required')
    selected_map=dict(zip(selected,MARKERS));values=iter(kept)
    result=[selected_map[i]if i in selected_map else next(values)for i in range(44977)]
    need(result==sorted(set(result)) and all(type(i)is int and 0<=i<53602 for i in result), 'Complete new E3 marker ancestry required')
    return result


def marker_context(actual,captured):
    a,b=actual['original_axis_quanta'],captured['original_axis_quanta']
    need(type(a)is tuple and type(b)is list and len(a)==len(b)==3
        and all(type(x)is float and math.isfinite(x)and x>0 for x in (*a,*b)) and a==tuple(b), 'Only exact original-quanta receipt tuple/list difference allowed')
    normalized=dict(actual,original_axis_quanta=list(a))
    def same(a,b):
        if type(a)is not type(b):return False
        if isinstance(a,dict):return set(a)==set(b)and all(same(a[k],b[k])for k in a)
        if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
        return a==b
    need(same(normalized,captured), 'Another marker receipt field/value/type differs')
    return dict(field='original_axis_quanta',values_exact=True,tuple_to_JSON_list_only=True,mesh_changed=False)


def records_contract(records,result):
    need(len(records)==len(result['edits'])==len(result['source_edits'])==14 and len(result['records'])==15
        and result['kept']==list(range(14)) and result['rolled_back']==[], 'Actual complete fourteen/zero typed partition required')
    need(all('rolled_back'not in row and 'flat_fill'not in row and 'after_faces'not in row for row in records)
        and records+[{'check':result['checks'][0]}]==result['records'], 'Exact current fourteen records and check required')
    return dict(exact_records=15,kept=14,rolled_back=0,all_values_and_keys_exact=True)


def asset_inventory(provenance,reported,root):
    from tools.main_infra_3f_44953_geometry import qualified_asset_rows
    original=provenance['assets'];root=Path(root).resolve();seen=set()
    need(len(original)==len(reported)==8 and all(type(row)is dict and set(row)=={'path','sha256','bytes'}
        and type(row['bytes'])is int and row['bytes']>=0 for row in reported), 'Exact eight byte-bearing writer asset rows required')
    for qualified,row in zip(original,reported):
        need(type(qualified)is dict and set(qualified)=={'path','sha256'} and type(qualified['path'])is type(row['path'])is str, 'Qualified asset identity required')
        a,b=(x.replace(chr(92),'/')for x in (qualified['path'],row['path']))
        need(a==b and ':'not in a and all(x not in ('','.','..')for x in a.split('/')) and qualified['sha256']==row['sha256'], 'Exact qualified asset path/hash required before identity view')
        path=(root/qualified['path']).resolve()
        need(path.is_relative_to(root) and path not in seen and path.stat().st_size==row['bytes']
            and digest(path)==qualified['sha256'], 'Reported size/hash differs from pinned qualified file before identity view')
        seen.add(path)
    identities=[{key:row[key]for key in ('path','sha256')}for row in reported]
    rows,view=qualified_asset_rows(provenance,identities,root)
    need(all(row['bytes']==saved['bytes'] for row,saved in zip(rows,reported)), 'Paid sized rows must retain the verified declared counts')
    return rows,dict(view,reported_byte_counts_exact=True,identity_only_view_for_paid_helper=True)


def builder_runtime_pins(binding):
    root=Path(binding['worktree_root']).resolve();runtime=binding['runtime_files'];rows=[];seen=set()
    need(type(runtime)is dict and runtime,'Explicit builder relative runtime dictionary required')
    for name,sha in runtime.items():
        need(type(name)is str and ':'not in name and all(x not in ('','.','..')for x in name.replace(chr(92),'/').split('/'))
            and type(sha)is str and len(sha)==64 and all(x in '0123456789abcdef'for x in sha),'Bounded relative runtime path and exact SHA required')
        path=(root/name).resolve();need(path.is_relative_to(root) and path not in seen,'Runtime path escapes or aliases builder root')
        seen.add(path);rows.append(dict(path=str(path),sha256=sha))
    return rows


def metadata_contract(d):
    cp,run,result,proposal,selection,marker=(d[k]for k in ('checkpoint','run','result','proposal','selection','marker'));pair=run['pair']
    need(d['candidate_source_sha256']==SOURCE and d['candidate_engine_sha256']==ENGINE, 'New44958 candidate roles required')
    need(cp['mode']=='actual_checked_E5_exact_SOURCE_partial' and cp['capture_only']is True
        and run['checkpoint_sha256']==pair['checkpoint_sha256']==CP
        and run['original_builder_commit']==cp['binding']['builder_commit']==BUILDER and run['resume_code_commit']==WRITER, 'Actual captured E5 and writer-only roles required')
    need(all((x['planned'],x['kept'],x['rolled_back'],x['output_triangles'])==(14,14,0,44958)for x in (cp,run,pair))
        and pair['input_triangles']==44953 and pair['files']['candidate.source.obj']==SOURCE and pair['files']['candidate.engine.obj']==ENGINE
        and pair['exact_saved_readback']is True, 'Exact new14/14/0 paired output required')
    need(run['mode']=='serialization_only_from_actual_checked_E5' and run['state']=='candidate_saved'
        and run['kernel_called']is run['checkpoint_recaptured']is run['repair_complete']is run['acceptance']is False
        and run['canonical_JSON_binding_exact']is run['checkpoint_unchanged']is run['exact_one_field_receipt_comparison']is True, 'No recapture, kernel rerun or acceptance permitted')
    e3=d['e3'];need(e3['mode']=='actual_checked_e3_checkpoint' and e3['capture_only']is True
        and (e3['planned'],e3['kept'],e3['rolled_back'],e3['output_triangles'])==(1410,1410,0,44977)
        and cp['binding']['actual_new_e3_checkpoint_sha256']==proposal['actual_new_e3_checkpoint_sha256']==marker['checkpoint_sha256']==E3, 'New1410-kept E3 ancestry required')
    need(cp['binding']['input_source_sha256']==proposal['source_model_sha256']==BEFORE_SOURCE
        and cp['binding']['input_engine_sha256']==proposal['engine_model_sha256']==BEFORE_ENGINE
        and cp['binding']['proposal_sha256']==PROPOSAL and cp['binding']['typed_plan_digest']==proposal['partial_plan_digest']==PLAN
        and cp['before_digest']==proposal['before_engine_digest']==marker['engine_digest'], 'New eac7/deb7 predecessor and plan roles required')
    need(marker['authority_sha256']==AUTHORITY and marker['input_triangles']==44977 and marker['output_triangles']==44953
        and cp['binding']['context_transition']=={k:marker[k]for k in cp['binding']['context_transition']}, 'Exact captured marker transition required')
    ancestry=marker_ancestry(marker)
    need(proposal['input_triangles']==44953 and proposal['partial_sites']==len(proposal['partial_engine_edits'])==len(proposal['partial_source_edits'])==14
        and proposal['remove_sites']==0 and proposal['remove_edits']==[] and len(proposal['anchor_faces'])==276, 'Complete SOURCE14-partial/0-remove proposal required')
    required=selection['required_originals'];required_set=set(required);parents=marker['original_source_faces']
    need(required==sorted(set(required))==run['whole_required_originals']==proposal['whole_required_originals'] and len(required)==6494
        and {3221,9138,9139,38508,38509}<=set(required)<=set(ancestry)
        and set(parents[i]for i in proposal['anchor_faces'])<=set(required)
        and proposal['protected_current_faces']==[i for i,p in enumerate(parents)if p in required_set], 'All6494 whole originals and276 source anchors required')
    need(selection['old_verdict_is_not_reused']is True and len(selection['selected_sites'])==1410
        and run['fresh_rollback_originals']==[] and result['kept']==list(range(14)) and result['rolled_back']==[], 'Current full kept partition required')
    for e,s,q in zip(result['edits'],result['source_edits'],proposal['partial_engine_edits']):
        need(e['engine']==s['engine']=='E5' and e['kind']==s['kind']=='cut' and e['legacy']is s['legacy']is False
            and e['faces']==s['faces']==q['faces']==[e['site']] and e['evidence']==s['evidence']==q['evidence']
            and parents[e['site']]not in required and e['site']not in proposal['anchor_faces'], 'Current cut touches a whole/priority original or differs from paired plan')
    need(result['checks']==run['unchanged_default_checks'] and len(result['checks'])==1, 'Actual default E5 check required')
    check=result['checks'][0];need(check['stage']==check['engine']=='E5' and check['legacy']is False and check['rollback']is True
        and check['final']=='PASS' and check['stage_rolled_back']is None and check['rounds_exhausted']is False
        and check['rolled_back']==[] and check['runs'][-1]['failing']==check['runs'][-1]['unknown']==0, 'Actual unchanged14-kept default check required')
    records_contract(result['records'][:-1],result)
    for key,pid,exit_code,head in [('e3_terminal',61836,0,'2c997b1fa1b9bf386dd1d581e084febb7cea804f'),('kernel_terminal',63248,1,BUILDER),('writer_terminal',51956,0,WRITER)]:
        t=d[key];need(t['actual_pid']==pid and t['actual_exit_code']==t['launcher_exit_code']==exit_code
            and t['HEAD']==head and t['abort_reason']is None and t['all_owned_exited']is True, 'Exact actual earned phase terminal required: '+key)
    return dict(original_triangles=53602,reference_triangles=53578,input_triangles=44953,output_triangles=44958,
        E3_kept=1410,planned=14,kept=14,rolled_back=0,whole_required_originals=6494,anchors=276,assets=8,
        previous_verdict_transferred=False,owner_exception=None,acceptance=False)


def documents(path,expected):
    from tools import jobs
    need(digest(path)==expected,'New independent binding hash differs');plan=read(path)
    need(plan['job_id']==JOB and Path(plan['out']).resolve()==ROOT/'data/iv3q/attempt1'
        and plan['acceptance']is False and plan['owner_exception']is None, 'Owned exclusive independent3F scope required')
    job=jobs.get(MAIN,JOB);need(job['status']=='claimed' and job['holder']=='Codex-3F-44958-Independent'
        and job['branch']=='codex/main-infra-3f-44958-independent-20261027', 'Owned new independent3F job required')
    git=lambda *args:subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()
    need(git('branch','--show-current')==job['branch'] and (Path(git('rev-parse','--path-format=absolute','--git-dir'))/'locked').is_file(), 'Own locked independent worktree required')
    for row in plan['pins']:need(digest(row['path'])==row['sha256'],'Runtime/input pin differs: '+row['path'])
    pinned={Path(row['path']).resolve():row['sha256']for row in plan['pins']};need(pinned.get(Path(__file__).resolve())==digest(__file__),'Executing adapter must be pinned')
    for key in ('writer_binding','delivery','run','source','reference_source','reference_engine','strict_helper'):
        need(pinned.get(Path(plan[key]['path']).resolve())==plan[key]['sha256'],'Complete primary role pin required: '+key)
    need(plan['source']['sha256']==SOURCE,'Fresh candidate map SOURCE binding required')
    need(digest(ROOT/'engine/guard/compare.py')=='8aca5a91a3d33af2bf0387a2fc6e5e13490ca337c2b3e24ea53b94cbe8722412'
        and not(ROOT/'engine/guard/exact_hits.py').exists(), 'Paid i3p guard runtime must remain unchanged')
    binding=read(plan['writer_binding']['path']);manifest=read(plan['delivery']['path'])
    need(plan['writer_binding']['sha256']=='7996110e0f7f1f1d2bbd8eecf01f7aa60853987d7b570c30913a80b1205749c2', 'Exact new writer85-role binding required')
    runtime=builder_runtime_pins(binding);need(len(runtime)==289,'Complete new writer runtime289 required')
    for row in [*binding['refs'].values(),*runtime,*manifest['entries'].values()]:need(digest(row['path'])==row['sha256'],'Builder role/runtime differs: '+row['path'])
    r=binding['refs'];entry=manifest['entries'];proposal=read(r['fresh_source_proposal']['path']);selection=read(r['fresh_e3_selection']['path'])
    keys=['job_id','input_triangles','partial_sites','remove_sites','remove_edits','partial_plan_digest','before_source_digest','before_engine_digest','source_model_sha256','engine_model_sha256','anchor_faces','protected_current_faces','partial_source_edits','partial_engine_edits','whole_required_originals','actual_new_e3_checkpoint_sha256','input_binding_sha256']
    d=dict(e3=read(r['fresh_e3_checkpoint']['path']),checkpoint=read(r['earned_e5_checkpoint']['path']),result=read(r['earned_e5_result']['path']),
        proposal={k:proposal[k]for k in keys},selection={k:selection[k]for k in ['required_originals','new_whole_originals','selected_sites','old_verdict_is_not_reused']},marker=read(r['corrected_marker_receipt']['path']),
        run=read(plan['run']['path']),e3_terminal=read(r['fresh_e3_terminal']['path']),kernel_terminal=read(r['earned_e5_terminal']['path']),writer_terminal=read(entry['evidence/writer-terminal.json']['path']),
        candidate_source_sha256=entry['candidate/candidate.source.obj']['sha256'],candidate_engine_sha256=entry['candidate/candidate.engine.obj']['sha256'])
    metadata_contract(d)
    need(d['run']['pair']==read(entry['candidate/pair-receipt.json']['path'])
        and Path(plan['source']['path']).resolve()==Path(entry['candidate/candidate.source.obj']['path']).resolve(), 'Exact saved candidate pair/source roles required')
    return plan,binding,manifest,d


def load_pair(path,expected):
    import numpy as np
    from engine.io.minecraft_floor import Frame,parse_floor
    from engine.io.obj_reader import read_obj
    from engine.io.mtl import parse_mtl
    from engine.validate.checks import load_looks
    from engine.repair.types import Edit,apply_edits
    from engine.repair.kernel import stage_records
    from tools.main_infra_3f_e5_continue import bind_captured_before
    from tools.main_infra_e3_checkpoint import restore_e3_checkpoint
    from tools.main_infra_e3 import source_survivors,_source_digest
    from tools.main_infra_1f_e5_validation import typed_after,verify_qualified_assets
    from tools.main_infra_e7_serialization import _tables
    from tools.main_infra_physical_validation import _same_mesh
    from tools.main_infra_1f_e5_append_boundary import guard_reference
    from tools import main_infra_3f_44953_geometry as paid
    plan,binding,manifest,d=documents(path,expected);r=binding['refs'];native=read(r['reference']['path']);q=read(r['qualification']['path']);provenance=read(r['provenance']['path'])
    need(q['qualified']is True and q['floor_id']=='3F' and q['source_obj_sha256']==native['source_sha256']==r['raw']['sha256']
        and q['native_reference_sha256']==r['reference']['sha256'] and native['unmatched_polygons']==0, 'Qualified original RAW/native reference required')
    source=parse_floor(Path(r['raw']['path']).read_text(encoding='utf8'),triangulations={int(k):v for k,v in native['polygons'].items()});frame=Frame(1000/25.4,provenance['frame_evidence'])
    need(source.mesh.n_faces==53602 and np.array_equal(frame.matrix,provenance['source_to_engine']),'Exact original53602 Frame required')
    raw_before,physical=paid.original_guard_context(source,frame,q)
    _same_mesh(read_obj(r['baseline_source']['path']),source.mesh);_same_mesh(read_obj(r['baseline_engine']['path']),raw_before)
    engine,context=bind_captured_before(source.in_frame(frame),read_obj(r['baseline_engine']['path']),expected_digest=d['e3']['before_digest'])
    raw_parent=Path(r['raw']['path']).parent;candidate=Path(manifest['entries']['candidate/candidate.source.obj']['path']).parent;baseline=Path(r['baseline_engine']['path']).parent
    looks=load_looks(r['materials']['path'],[(parse_mtl(raw_parent/source.mesh.mtllib),raw_parent),(parse_mtl(candidate/source.mesh.mtllib),candidate)])
    need(not looks.unknown(engine.mesh),'All original material looks required')
    e3=restore_e3_checkpoint(engine.mesh,looks,Path(r['fresh_e3_checkpoint']['path']).parent,binding=d['e3']['binding'],expected_receipt_sha256=E3)
    parents=source_survivors(engine.mesh,e3);need(parents.tolist()==marker_ancestry(d['marker']),'Fresh actual E3 original ancestry differs')
    e3_source,source_ids=apply_edits(source.mesh,e3.kept);need(np.array_equal(parents,source_ids),'Paired E3 SOURCE survivor vector differs')
    selected=d['marker']['selected_current'];marker_edit=Edit('E3','remove',tuple(selected),None,None,min(selected),
        'Explicit owner marker exception on new checked E3 ancestry',dict(authority_sha256=AUTHORITY,original_faces=MARKERS))
    before,kept=apply_edits(e3.mesh,[marker_edit]);current_mesh,source_kept=apply_edits(e3_source,[marker_edit]);need(np.array_equal(kept,source_kept),'Paired new marker survivor vector differs')
    ancestry=parents[kept];need(ancestry.tolist()==d['marker']['original_source_faces'],'New corrected marker-free original mapping differs')
    current=replace(source,mesh=current_mesh,triangle_polygon=source.triangle_polygon[ancestry],triangle_corners=source.triangle_corners[ancestry])
    marker=dict(authority_sha256=AUTHORITY,input_triangles=44977,output_triangles=44953,selected_current=selected,removed_originals=MARKERS,
        all_required_whole_survive=True,original_axis_quanta=before.physical_quanta,source_digest=_source_digest(current_mesh).hex(),engine_digest=_source_digest(before).hex(),independent_validation='PENDING',acceptance=False)
    transition=marker_context(marker,d['checkpoint']['binding']['context_transition'])
    _tables(read_obj(r['corrected_source_model']['path']),current.mesh);_tables(read_obj(r['corrected_engine_model']['path']),before)
    whole=paid.whole_original_contract(source,current,ancestry)
    after,result,cp=typed_after(r['earned_e5_checkpoint']['path'],CP,'actual_checked_E5_exact_SOURCE_partial');need(_source_digest(before).hex()==cp['before_digest'],'Exact E5 predecessor digest required')
    with np.load(Path(r['earned_e5_checkpoint']['path']).parent/'arrays.npz',allow_pickle=False)as z:
        def decode(rows):return [Edit(**dict(row,faces=tuple(row['faces']),**{k:None if row[k]is None else z[row[k]]for k in ('new_points','new_faces','new_face_uv','new_face_normal')}))for row in rows]
        edits,sources=decode(result['edits']),decode(result['source_edits'])
    replay,_=apply_edits(before,edits);need(_source_digest(replay)==_source_digest(after),'All fourteen actual kept E5 cuts must replay exactly')
    saved=parse_floor(Path(manifest['entries']['candidate/candidate.source.obj']['path']).read_text(encoding='utf8'));_tables(read_obj(manifest['entries']['candidate/candidate.engine.obj']['path']),after)
    source_view,material_view=paid.saved_source_material_view(saved,after,frame)
    assets,asset_view=asset_inventory(provenance,d['run']['assets'],raw_parent);asset_proof=verify_qualified_assets(source.mesh,provenance,assets,[raw_parent,baseline,candidate])
    records=stage_records(before,edits,{i:looks.key_of(n)for i,n in enumerate(before.materials)},'E5');capture=records_contract(records,result)
    reference,marker_proof=paid.marker_reference(raw_before,MARKERS,r['root_selection']['sha256'],read(r['marker_proof']['path']))
    source_reference,_=paid.marker_reference(source.mesh,MARKERS,r['root_selection']['sha256'],read(r['marker_proof']['path']))
    gb,ga,boundary=guard_reference(reference,current.mesh,before,source_view,after,sources,edits,frame)
    lineage=read(manifest['entries']['candidate/source-faces.json']['path']);need(lineage['mode']=='exact_SOURCE_partial_composed_lineage' and lineage['checkpoint_sha256']==CP,'Exact new partial SOURCE lineage required')
    lineage_proof=paid.lineage_contract(source,current,saved,before,after,ancestry,edits,lineage['faces'],set(d['run']['whole_required_originals']))
    _tables(read_obj(plan['reference_source']['path']),source_reference);_tables(read_obj(plan['reference_engine']['path']),reference)
    documents(path,expected)
    proof=dict(metadata_contract(d),physical=physical,original_input_context=context,marker_transition_receipt=transition,marker_reference=marker_proof,
        whole_originals=whole,lineage=lineage_proof,append_boundary=boundary,source_material_view=material_view,assets=dict(asset_proof,representation=asset_view),capture_records=capture,
        source_sha256=SOURCE,engine_sha256=ENGINE,checkpoint_sha256=CP,E3_checkpoint_sha256=E3,E3_kernel_rerun=False)
    return dict(plan=plan,binding=binding,source=source,source_reference=source_reference,before=reference,after=after,saved=saved,guard_before=gb,guard_after=ga,
        frame=frame,provenance=provenance,proof=proof,original_guard=read(r['base_guard']['path']))


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('phase',choices=['metadata','readback','census','strict']);parser.add_argument('--binding',required=True,type=Path);parser.add_argument('--binding-sha256',required=True);a=parser.parse_args(argv)
    plan,_,_,docs=documents(a.binding,a.binding_sha256)
    if a.phase=='metadata':print(json.dumps(dict(metadata_contract(docs),geometry_loaded=False,pins=len(plan['pins']))));return 0
    from tools.main_infra_3f_44953_census import save_default_pair,bind_display,write_new
    c=load_pair(a.binding,a.binding_sha256);out=Path(plan['out'])/a.phase
    if a.phase=='readback':out.mkdir(parents=True,exist_ok=False);proof=c['proof']
    elif a.phase=='census':
        need(read(Path(plan['out'])/'readback/independent-proof.json')['binding_sha256']==a.binding_sha256,'Fresh readback required before census')
        raw=save_default_pair(c['before'],c['after'],out)
        for kind,label,mesh,source,doc,ref in [('source','before',c['before'],c['source_reference'],raw[0],plan['reference_source']),('candidate','after',c['after'],c['saved'].mesh,raw[1],plan['source'])]:
            identity=dict(source_revision=plan['source_revision'],run_id='main-infra-clean-20261023',floor_id='MAIN_INFRA_3F',kind=kind,obj_sha256=ref['sha256'])
            provenance=dict(raw_census_sha256=digest(out/('census-'+label+'.raw.json')),binding_sha256=a.binding_sha256,source_obj_sha256=ref['sha256'],physical_context=c['proof']['physical'],marker_authority_sha256=AUTHORITY,acceptance=False)
            write_new(out/('errors-'+kind+'.json'),bind_display(doc,mesh,source,c['frame'],identity,provenance))
        proof=dict(c['proof'],counts_before=raw[0]['counts'],counts_after=raw[1]['counts'],default_find_errors_calls=2)
    else:
        need(read(Path(plan['out'])/'census/independent-proof.json')['binding_sha256']==a.binding_sha256,'Fresh census required before strict')
        from tools.main_infra_3f_44953_phases import strict_helper
        guard_context=dict(c,plan=dict(refs={'strict_helper':plan['strict_helper']}))
        guard=strict_helper(guard_context);out.mkdir(parents=True,exist_ok=False);views=[]
        def progress(label,index):views.append((label,index));(out/'progress.json').write_text(json.dumps(dict(pair=label,completed_views=index))+'\n')
        report,tol=guard(c['guard_before'],c['guard_after'],c['source'].mesh,c['provenance'],on_view=progress)
        need(views==[(label,index)for label in ('Before','After')for index in range(1,27)] and tol==c['proof']['physical']['guard_depth_tol_inches'],'All paid26 strict views and original RAW tolerance required')
        proof=dict(c['proof'],guard=asdict(report),guard_depth_tol_inches=tol,views_per_model=26,resolution=[900,600])
    documents(a.binding,a.binding_sha256);write_new(out/'independent-proof.json',dict(proof,binding_sha256=a.binding_sha256))
    print(json.dumps(dict(phase=a.phase,path=str(out/'independent-proof.json'),sha256=digest(out/'independent-proof.json'),strict_passed=proof.get('guard',{}).get('passed'),acceptance=False)))
    return 2 if a.phase=='strict'and not proof['guard']['passed']else 0


if __name__=='__main__':raise SystemExit(main())
