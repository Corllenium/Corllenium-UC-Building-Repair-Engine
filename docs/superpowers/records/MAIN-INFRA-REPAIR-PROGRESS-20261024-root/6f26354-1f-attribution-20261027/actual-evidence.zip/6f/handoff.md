# Actual 6F26354 builder handoff

This saved candidate remains UNACCEPTED. Fresh census and independent strict/native/fullsigned checks are NOT_RUN. Historical26127 or25433 proofs do not transfer.

- Job: MAIN-INFRA-6F-26127-E7-PLAN-20261027; now awaiting-review.
- Executed builder HEAD: 8ee243a5dbdb1c0eaec598ace788b8cc8d151bbc. Later commits carry records only.
- Actual226 planned,182 kept,44 rolled;26354 triangles. Whole-original protection4284=4240base+44fresh rollback.
- Local default checks: FAIL75 → FAIL1 → PASS0 after two rollback rounds. This is not the independent Validator.
- Terminal: 52892/birth2026-10-26T20:10:13.2784061Z; exit0/launcher0/no abort/all-owned-gone20:27:42.8753954Z. TerminalSHA dc816e93823c31d8986023ea0f3aa150c8801fd596106f64218ad34b74c350c7.

All relative paths below are under this locked e6n checkout.

| Artifact | Path | SHA256 |
|---|---|---|
| SOURCE | data/26127-e7-checked/run-20261027/candidate/candidate.source.obj | f385f9f8ed363de03c7c14b94e96735ca3f9966bd2d5b116b391409c840db885 |
| ENGINE | data/26127-e7-checked/run-20261027/candidate/candidate.engine.obj | 4f82b5529940c2cfca207b2352e52e004b1a06e83b1c55fbe4b53e0d691a0feb |
| True checked checkpoint | data/26127-e7-checked/run-20261027/checked-outcome/checkpoint-receipt.json | 6e321319803b80e67d4d41633bb1f3c049fc882ab4a5dcf4fca53cd731c6a376 |
| Pair proof | data/26127-e7-checked/run-20261027/candidate/cut-receipt.json | 88795b4bc5dbbfe651c37f7cf29a719831f823219d5b79278bd894cdf65ce432 |
| Composed ancestry | data/26127-e7-checked/run-20261027/candidate/cut-lineage.json | 11a442658f3d7aed3dede8ea90f86a2cb58912b97f17e10ffb2bf1d08e8fcf81 |
| Run receipt | data/26127-e7-checked/run-20261027/run-receipt.json | 3c00a589073750e7d74844c501aa58944ad740c378dcd26fdd753541b2d56a1c |
| Builder lexical readback | data/26127-e7-preflight/saved-26354-readback.json | 2ed19b6b3b9c39ca65b5be1d6526f552f3f0ea29d255db3627f5f3dfba814c78 |

The independent-26354-role-inputs.json in this record folder (ae480116462c4b197c3a97074b346c19d771e7ada9a36c9a54c2c7ff9599a8f8) contains full absolute input paths/hashes, original34862 RAW/Frame authority,34838marker-filtered reference, CP3→identityCP5→24mask→current26127→E7 lineage, all4284 literal originals/current output indices,12assets and exact native execution. CBR winners remain UNENUMERATED; no empty-vector assumption or new exception.

The lossless actual-6f-26354-checked-E7.zip (bfc78da6024f8fb71be9c2a0b108ca22d2e5052aa1d67a9d030a4c829cac996f;12,918,165B) contains all24 output files, every243 frozen phase input,12assets, full checkpoint arrays/result/log, monitor records and earned tests. All291 regular unique members were reopened and hashed; actual-26354-archive-readback.json SHA a0099104d5944bc2ca520bf13a6cb638a8598dd93a80f641e113e88c09d20716. Frozen brief bytes remain inside the archive; the current brief explicitly records the later Root-authorized actual execution.

The separate SOURCEUV diagnostic proposal remains unexecuted/HOLD. No new geometry, model parse, settings/guard changes, uploads, publication or GUI actions are authorized by this handoff.
