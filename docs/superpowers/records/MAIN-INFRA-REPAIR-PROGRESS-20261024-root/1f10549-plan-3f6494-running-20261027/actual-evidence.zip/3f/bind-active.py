from pathlib import Path
import copy
import json
import subprocess
import sys

R = Path(__file__).resolve().parents[3]
OPS = Path(__file__).resolve().parent
sys.path.insert(0, str(R / '.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress, write_progress, utc_now

observation = json.loads((OPS / 'actual-engine-observation.json').read_bytes())
assert observation['pid'] == 61836 and observation['start_utc'] == '2026-10-26T18:57:56.4653171Z'
assert observation['alive'] is True and observation['cpu_seconds'] > 0
assert observation['phase_sha256'] == '9db078e939e92c174dcb4493fcaef0a56add5a0c935cde68a463fc766ed95f5b'
path = R / 'data/main-infra-fresh/current.json'
original = load_progress(path)
doc = copy.deepcopy(original)
f = doc['floors']['3F']
assert f['output_triangles'] == 44948 and f['pending_saved_candidate']['triangles'] == 44953
assert f['accepted_preview'] is None and f['owner_decision_ref'] is None
now = utc_now()
message = ('3F repair engine is checking a fresh E3 pass with 6,494 whole original faces protected. '
           'The two whole E3 sites implicated by the actual failed pixels are retained; 1,410 other proposed sites undergo unchanged checks. '
           'Worker 61836 is authenticated by native lifetime, command and CPU. No new output is saved yet; After still displays older 44,948.')
f.update(state='cleaning', step=message, blocker='Previous 44,953 candidate failed strict preservation; fresh guarded correction is running.',
    worker_pid=observation['pid'], worker_start_utc=observation['start_utc'], worker_alive=True,
    worker_cpu_seconds=observation['cpu_seconds'], worker_observed_at=observation['observed_at'],
    engine_stage='E3', engine_worker_pid=observation['pid'], engine_worker_start_utc=observation['start_utc'],
    engine_worker_alive=True, active_engine_run_id='MAIN-INFRA-3F-E3-TWO-WITNESS-20261027',
    active_engine_component_commit='2c997b1fa1b9bf386dd1d581e084febb7cea804f', last_work_event_at=now)
f['worker_events'].append(dict(engine='E3', run_id='MAIN-INFRA-3F-E3-TWO-WITNESS-20261027',
    phase='fresh_e3_6494_actual_running', pid=observation['pid'], start_utc=observation['start_utc'],
    observed_at=observation['observed_at'], message=message))
f.setdefault('worker_cpu_samples', []).append(dict(pid=observation['pid'], start_utc=observation['start_utc'],
    observed_at=observation['observed_at'], cpu_seconds=observation['cpu_seconds']))
f['worker_cpu_samples'] = f['worker_cpu_samples'][-100:]
doc.update(updated_at=now, last_work_event_at=now, state='cleaning', step=message)
draft = OPS / 'active-status-draft.json'
draft.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf8')
subprocess.run(['node', str(R / 'data/siege-live-20261026/check-status-current.mjs'), str(draft)], check=True)
assert load_progress(path)['updated_at'] == original['updated_at']
write_progress(path, doc)
actual = load_progress(path)
for floor in original['floors']:
    if floor != '3F':
        assert actual['floors'][floor] == original['floors'][floor]
    for key in ('source_preview', 'candidate_preview', 'accepted_preview', 'owner_decision_ref', 'output_triangles'):
        assert actual['floors'][floor].get(key) == original['floors'][floor].get(key)
receipt = dict(at=now, actual_worker=observation, all_display_refs_unchanged=True, other_floor_rows_unchanged=True,
    protected_originals=6494, planned_sites=1410, new_output_saved=False, accepted=False)
(OPS / 'active-status-readback.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
