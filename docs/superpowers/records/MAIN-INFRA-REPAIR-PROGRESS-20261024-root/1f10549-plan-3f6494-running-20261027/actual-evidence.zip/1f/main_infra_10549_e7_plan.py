"""Measure unchanged existing-vertex E7 proposals on the authenticated saved10549 state."""
import argparse
from dataclasses import replace
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
JOB='MAIN-INFRA-1F-10549-E7-PLAN-20261027'
SOURCE='7a9513f7b4e03fa1f72b76c843f2ed2fc4bc843b4d33ddd1ebfdbe8f84b0de21'
ENGINE='7318bde957738a525403395cc0001ba7b65bab1ba324c934644eda8ab2666594'
PARTIAL_SOURCE='9d8d3718dcd4f41f84483d0e2e1957cd96ac6a7bcc6627bce94c906d81d71008'
PARTIAL_ENGINE='446bd02d5d07a9352bd7aa4e34ba27ff1e7720ecdce38600eaf54d98c99fef74'
PARTIAL_CP='c6e2d803c32293afd6865d1e70cd0a597f3242b1a240b5c16015ab67b487622e'
MARKER_CP='f1fc2c8112c576a1780df5373f219c99f5400df4ecd9ca021f9bb4737b3c368d'
AUTH='81c02db5fca5eda121549533cca06a23e14c160860246af9613deedc652b6dfb'
UNCHANGED=('original_source_triangle','kind','vertex_ids','source_uv','source_normal','engine_uv','engine_normal','material','group','object_name')


def need(value,message):
    if not value:raise ValueError(message)


def compose_context(old,partial,kept,mandatory,locked,anchors):
    need(kept==sorted(set(kept)) and all(type(i) is int and 0<=i<len(partial) for i in kept),'Complete ordered marker survivor vector required')
    need(all(r['output_face']==i for i,r in enumerate(old)) and all(r['output_face']==i for i,r in enumerate(partial)),'Ordered predecessor lineage required')
    for r in partial:
        parent=r['e5_partial_input_face']
        need(type(parent) is int and 0<=parent<len(old) and type(r['original_source_triangle']) is int
             and r['original_source_triangle']==old[parent]['original_source_triangle'],'Composed original parent differs')
    rows=[dict(partial[k],output_face=i) for i,k in enumerate(kept)];by_parent={}
    for i,r in enumerate(rows):by_parent.setdefault(r['e5_partial_input_face'],[]).append(i)
    need(set(anchors)<=set(locked),'Every source-priority anchor must remain locked')
    def remap(ids):
        result=[]
        for parent in ids:
            found=by_parent.get(parent,[])
            need(len(found)==1,'Protected stage face was removed or split')
            i=found[0];need(all(rows[i][k]==old[parent][k] for k in UNCHANGED),'Protected corner/UV/material/group changed')
            result.append(i)
        return sorted(result)
    for original in mandatory:
        found=[r for r in rows if r['original_source_triangle']==original]
        need(len(found)==1 and found[0]['kind']=='unchanged','Mandatory original no longer whole')
    return dict(rows=rows,mandatory=sorted(mandatory),locked=remap(locked),anchors=remap(anchors))


def bind_documents(d):
    r,p,cp,run=d['old_reference'],d['old_prepared'],d['partial_checkpoint'],d['partial_run']
    need(r['current_count']==10571 and len(r['mandatory_originals'])==754 and len(r['current_locked_faces'])==829
         and len(r['current_anchor_faces'])==100 and p['mandatory_unchanged_original_parents']==r['mandatory_originals'],'Paid protection context differs')
    need(cp['mode']=='actual_checked_E5_exact_SOURCE_partial' and cp['capture_only'] is True
         and (cp['planned'],cp['kept'],cp['rolled_back'],cp['output_triangles'])==(4,4,0,10573)
         and (run['planned'],run['kept'],run['rolled_back'],run['output_triangles'])==(4,4,0,10573)
         and run['checkpoint_sha256']==d['partial_rows']['checkpoint_sha256']==PARTIAL_CP,'Actual four-kept partial checkpoint required')
    need(cp['before_digest']==p['checkpoint_after_digest']==d['old_checkpoint']['after_digest']
         and run['source_sha256']==p['source_after_sha256'] and run['engine_sha256']==p['after_sha256']
         and run['pair']['files']['candidate.source.obj']==PARTIAL_SOURCE and run['pair']['files']['candidate.engine.obj']==PARTIAL_ENGINE,'10571 to10573 pair chain differs')
    data=d['partial_result'];need(data['kept']==[0,1,2,3] and data['rolled_back']==[] and len(data['edits'])==4
         and data['checks']==run['unchanged_default_checks'] and data['checks'][0]['final']=='PASS','Actual default checked partition differs')
    signed,review=d['validation'],d['review']
    need(signed['independent10573']==review['binding'] and signed['independent10573']['engine_sha256']==PARTIAL_ENGINE
         and signed['after']['faces']==10573 and signed['checks']['textures']['status']==signed['checks']['nothing_deleted']['status']=='PASS'
         and review['binding']['source_sha256']==PARTIAL_SOURCE and review['binding']['checkpoint_sha256']==PARTIAL_CP
         and review['binding']['owner_exception'] is None,'Actual10573 independent preservation basis required')
    marker,drop=d['marker_lineage'],d['marker_drop'];partial=d['partial_rows']['faces']
    need(marker['mode']=='owner_approved_marker_survivors' and (marker['input_triangles'],marker['output_triangles'])==(10573,10549)
         and len(partial)==10573 and len(marker['source_faces'])==10549 and marker['source_faces']==drop['kept_current']
         and drop['root_selection_sha256']==AUTH and drop['selected_original']==list(range(15832,15856))
         and len(drop['selected_current'])==24 and sorted(drop['selected_current']+drop['kept_current'])==list(range(10573)), 'Exact Root-approved24 marker-only subset required')
    need([[partial[i]['original_source_triangle']] for i in drop['kept_current']]==marker['original_source_faces']
         and sorted(partial[i]['original_source_triangle'] for i in drop['selected_current'])==drop['selected_original'],'Marker original-parent composition differs')
    root=d['root_marker_proof'];proof=next(row for row in root['floors'] if row['floor']=='1F');saved=next(row for row in d['marker_receipt']['floors'] if row['floor']=='1F')
    need(root['authority_sha256']==AUTH and root['removal_only_preservation_passed'] is True and proof['passed'] is True
         and proof['approved_input_faces']==drop['selected_current'] and proof['approved_original_faces']==drop['selected_original'],'Independent marker proof differs')
    for key,before,after in [('candidate_source',PARTIAL_SOURCE,SOURCE),('candidate_engine',PARTIAL_ENGINE,ENGINE)]:
        q=proof['proofs'][key];need(q['before_sha256']==before and q['after_sha256']==after and q['tables_exact'] is True
            and q['nonselected_faces_exact'] is True,'Current SOURCE/ENGINE marker proof differs')
    need(saved['candidate_source_sha256']==SOURCE and saved['candidate_engine_sha256']==ENGINE
         and saved['checkpoint_sha256']==MARKER_CP and d['marker_checkpoint']['binding']['root_selection_sha256']==AUTH,'Current saved10549 role differs')
    ctx=compose_context(d['old_rows']['faces'],partial,drop['kept_current'],r['mandatory_originals'],r['current_locked_faces'],r['current_anchor_faces'])
    need((len(ctx['mandatory']),len(ctx['locked']),len(ctx['anchors']))==(754,829,100),'Complete current protection mapping differs')
    ctx.update(marker_intersection=sorted(set(r['mandatory_originals'])&set(drop['selected_original'])),independent10549_validation='NOT_RUN')
    need(ctx['marker_intersection']==[],'Marker/protection exception requires explicit remapping')
    return ctx


def subset_typed(mesh,kept):
    need(kept==sorted(set(kept)) and all(type(i) is int and 0<=i<mesh.n_faces for i in kept),'Bounded ordered saved-state indices required')
    return replace(mesh,**{k:getattr(mesh,k)[kept].copy() for k in ('face_v','face_vt','face_vn','face_material','face_line')})


def read_bound(ref):
    b=Path(ref['path']).read_bytes();need(hashlib.sha256(b).hexdigest()==ref['sha256'],'Bound input differs: '+ref['path']);return b


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',type=Path,required=True);parser.add_argument('--input-sha256',required=True);args=parser.parse_args()
    plan=json.loads(read_bound(dict(path=str(args.input),sha256=args.input_sha256)))
    need(plan['job_id']==JOB and plan['mode']=='1F10549_fresh_E7_plan_only' and plan['acceptance'] is False,'Owned plan-only scope required')
    out=Path(plan['output']);need(out.resolve().is_relative_to(ROOT/'data') and not out.exists(),'Exclusive owned output required')
    raw={k:read_bound(v) for k,v in plan['refs'].items()};docs={k:json.loads(raw[k]) for k in plan['documents']}
    need(plan['refs']['marker_checkpoint']['sha256']==MARKER_CP,'Recorded marker checkpoint differs');ctx=bind_documents(docs)
    need(plan['refs']['source']['sha256']==SOURCE and plan['refs']['engine']['sha256']==ENGINE,'Actual saved10549 pair required')
    from tools.jobs import get
    claim=get(ROOT.parents[2],JOB);need(claim['status']=='claimed' and claim['holder']=='Codex-1F-10549-E7-Plan','Current planning job claim differs')
    from tools.main_infra_1f_e5_validation import typed_after
    from tools.main_infra_e3 import _source_digest
    from tools.main_infra_e7_serialization import _tables,_encode
    from tools.main_infra_10571_e7_plan import qualify_proposals
    from engine.io.minecraft_floor import Frame,parse_floor
    from engine.io.obj_reader import read_obj
    from engine.fixes.pipeline import FixProfile
    from engine.repair.engines.e7_thread import E7Thread
    from engine.repair.types import RepairContext,UnitState
    partial,_,cp=typed_after(plan['refs']['partial_checkpoint']['path'],PARTIAL_CP,'actual_checked_E5_exact_SOURCE_partial')
    before=subset_typed(partial,docs['marker_drop']['kept_current']);need(before.n_faces==10549,'Current typed10549 required')
    _tables(read_obj(plan['refs']['engine']['path']),before)
    source=parse_floor(raw['source'].decode('utf-8'));provenance=json.loads(raw['provenance']);frame=Frame(1000/25.4,provenance['frame_evidence'])
    _tables(source.in_frame(frame).mesh,before)
    need(all(row['vertex_ids']==source.mesh.face_v[i].tolist() and row['source_uv']==source.mesh.face_vt[i].tolist()
         and row['source_normal']==source.mesh.face_vn[i].tolist() and row['material']==source.mesh.materials[int(source.mesh.face_material[i])] for i,row in enumerate(ctx['rows'])),'Current exact SOURCE corner lineage differs')
    original=(_source_digest(source.mesh),_source_digest(before),_source_digest(partial));planner=E7Thread()
    edits=planner.plan(UnitState(before,None,{},None),RepairContext(FixProfile(),None,None))
    report=qualify_proposals(source.mesh,before,ctx['rows'],edits,ctx['mandatory'],ctx['locked'])
    need(original==(_source_digest(source.mesh),_source_digest(before),_source_digest(partial)),'Plan-only work mutated input state')
    report.update(mode=plan['mode'],input_refs=plan['refs'],output_triangles=10549,source_digest=original[0].hex(),engine_digest=original[1].hex(),partial_checkpoint_after_digest=cp['after_digest'],mandatory_originals=ctx['mandatory'],locked_current_faces=ctx['locked'],anchor_current_faces=ctx['anchors'],planner_report=planner.report,edits=[dict(_encode(e),decision=e.decision) for e in edits],preservation_basis='authenticated10573 independent preservation plus Root-approved literal24 marker proof',independent10549_validation='NOT_RUN',new_output_saved=False)
    for ref in plan['refs'].values():read_bound(ref)
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('x',encoding='utf-8') as f:json.dump(report,f,indent=2,sort_keys=True,allow_nan=False)
    print(json.dumps(dict(planned=len(edits),admitted=len(report['admitted_indices']),report=str(out),report_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),kernel_called=False,new_output_saved=False,acceptance=False)))
    return 0


if __name__=='__main__':raise SystemExit(main())
