"""Current1F ancestry/protection mapping cannot reuse10571 indices after partial cuts and marker removal."""
import copy,json,zipfile
from pathlib import Path
import numpy as np
import pytest
REC=Path(__file__).parents[2]/'docs/superpowers/records/MAIN-INFRA-1F-10549-E7-PLAN-20261027'
def fixture():
    with zipfile.ZipFile(REC/'actual10549-chain-schema.zip') as z:return {Path(n).stem:json.loads(z.read(n)) for n in z.namelist()}
def api():
    from tools import main_infra_10549_e7_plan as m
    return m

def test_actual_metadata_remaps_all754_whole_829_locked_100_anchors():
    d=fixture();r=api().bind_documents(d)
    assert len(r['rows'])==10549 and len(r['mandatory'])==754 and len(r['locked'])==829 and len(r['anchors'])==100
    assert r['marker_intersection']==[] and r['independent10549_validation']=='NOT_RUN'
    assert set(r['anchors'])<=set(r['locked'])

@pytest.mark.parametrize('key',['old_output','partial_failed','partial_cp','wrong_source','wrong_engine','marker_extra','marker_proof_fail','lost_required','lost_lock','wrong_parent','old_validation_fail','owner_exception'])
def test_actual_chain_rejects_stale_proof_or_incomplete_protection(key):
    d=fixture()
    if key=='old_output':d['marker_lineage']['output_triangles']=10571
    elif key=='partial_failed':d['partial_run']['rolled_back']=1
    elif key=='partial_cp':d['partial_rows']['checkpoint_sha256']='0'*64
    elif key=='wrong_source':d['marker_receipt']['floors'][0]['candidate_source_sha256']='0'*64
    elif key=='wrong_engine':d['marker_receipt']['floors'][0]['candidate_engine_sha256']='0'*64
    elif key=='marker_extra':d['marker_drop']['selected_original'].append(0)
    elif key=='marker_proof_fail':d['root_marker_proof']['floors'][0]['passed']=False
    elif key=='lost_required':
        old=d['old_reference']['mandatory_originals'][0]
        next(r for r in d['partial_rows']['faces'] if r['original_source_triangle']==old)['kind']='cut_child'
    elif key=='lost_lock':
        old=d['old_reference']['current_locked_faces'][0]
        next(r for r in d['partial_rows']['faces'] if r['e5_partial_input_face']==old)['e5_partial_input_face']=10570
    elif key=='wrong_parent':d['partial_rows']['faces'][0]['original_source_triangle']=15855
    elif key=='old_validation_fail':d['validation']['checks']['textures']['status']='FAIL'
    else:d['review']['binding']['owner_exception']='new-unapproved-exception'
    with pytest.raises(ValueError):api().bind_documents(d)

def row(i,parent=None):
    return dict(output_face=i,original_source_triangle=10+i,kind='unchanged',vertex_ids=[i,i,i],source_uv=[0,0,0],source_normal=[-1,-1,-1],engine_uv=[0,0,0],engine_normal=[-1,-1,-1],material='wall',group='g',object_name='',e5_partial_input_face=i if parent is None else parent)
def synthetic():
    old=[row(i) for i in range(5)];parents=[0,1,3,4,2,2];partial=[]
    for i,p in enumerate(parents):
        r=dict(old[p],output_face=i,e5_partial_input_face=p)
        if p==2:r['kind']='cut_child'
        partial.append(r)
    return old,partial,[0,1,2,4,5]
def test_synthetic_mapping_uses_current_indices_not_original_ids():
    old,partial,kept=synthetic();r=api().compose_context(old,partial,kept,[10],[0,1,3],[3])
    assert r['locked']==[0,1,2] and r['anchors']==[2]
    assert [x['original_source_triangle'] for x in r['rows']]==[10,11,13,12,12]
    assert [x['output_face'] for x in r['rows']]==[0,1,2,3,4]
def test_locked_partial_parent_cannot_be_downgraded_to_children():
    old,partial,kept=synthetic()
    with pytest.raises(ValueError):api().compose_context(old,partial,kept,[10],[2],[2])

@pytest.mark.parametrize('bad',[[0,0],[1,0],[True,2],[-1,2],[0,5]])
def test_typed_subset_rejects_bad_kept_index_vector(bad):
    with pytest.raises(ValueError):api().subset_typed(tiny(),bad)
def tiny():
    from engine.model import MeshData
    return MeshData(name='tiny',positions=np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]]),face_v=np.array([[0,1,2]]*4,dtype=np.int64),uvs=np.array([[0.,0.],[1.,0.],[0.,1.]]),face_vt=np.array([[0,1,2]]*4,dtype=np.int64),normals=np.empty((0,3)),face_vn=np.full((4,3),-1,dtype=np.int64),face_material=np.zeros(4,dtype=np.int64),materials=['wall'],face_line=np.array([10,11,12,13],dtype=np.int64),mtllib='x.mtl',physical_quanta=(0.1,0.2,0.3),sig_digits=9,coord_decimals=7,units='inches')
def test_typed_subset_preserves_all_tables_metadata_and_literal_face_order():
    m=tiny();a=api().subset_typed(m,[0,2,3]);assert a.n_faces==3 and m.n_faces==4
    for k in ['positions','uvs','normals','materials']:assert getattr(a,k) is getattr(m,k)
    for k in ['sig_digits','coord_decimals','units','physical_quanta','mtllib']:assert getattr(a,k)==getattr(m,k)
    assert a.face_line.tolist()==[10,12,13] and np.array_equal(a.face_v,m.face_v[[0,2,3]])
