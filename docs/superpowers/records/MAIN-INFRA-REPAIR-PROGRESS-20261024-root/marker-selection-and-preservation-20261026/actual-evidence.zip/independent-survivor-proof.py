"""Independent exact-byte proof for an explicitly selected marker-only dropout."""


MARKER = 'minecraft_wool_colored_orange_-1'


def _need(value, message):
    if not value:
        raise ValueError(message)


def verify_survivors(before, after, removed_faces):
    _need(type(before) is bytes and type(after) is bytes, 'Exact OBJ bytes required')
    _need(isinstance(removed_faces, list) and removed_faces
          and all(type(i) is int and i >= 0 for i in removed_faces)
          and len(set(removed_faces)) == len(removed_faces), 'Unique exact selected face IDs required')
    before.decode('utf-8', errors='strict')
    after.decode('utf-8', errors='strict')
    selected = set(removed_faces)
    current_material = None
    expected, kept = [], []
    face_count = 0
    for raw in before.splitlines(keepends=True):
        tokens = raw.strip().split()
        if tokens and tokens[0] == b'usemtl':
            current_material = b' '.join(tokens[1:]).decode('utf-8')
        if not tokens or tokens[0] != b'f':
            expected.append(raw)
            continue
        _need(len(tokens) == 4, 'Triangular input required')
        for corner in tokens[1:]:
            parts = corner.split(b'/')
            _need(1 <= len(parts) <= 3 and parts[0] and all(not x or int(x) > 0 for x in parts),
                  'Absolute positive OBJ corner indices required')
        if face_count in selected:
            _need(current_material == MARKER, 'Selection includes a nonmarker material')
        else:
            expected.append(raw)
            kept.append(face_count)
        face_count += 1
    _need(max(selected) < face_count, 'Selected face outside authenticated input')
    _need(after == b''.join(expected), 'Unapproved OBJ change outside selected marker face lines')
    return dict(before_faces=face_count, after_faces=len(kept), removed_faces=sorted(selected),
                kept_faces=kept, nonselected_faces_exact=True, tables_exact=True,
                full_floor_acceptance=False)
