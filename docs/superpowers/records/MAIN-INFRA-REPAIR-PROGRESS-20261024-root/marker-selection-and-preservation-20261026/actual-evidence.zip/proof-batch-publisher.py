from pathlib import Path
import hashlib,json,os,tarfile,tempfile
from urllib.request import Request,urlopen
from urllib.parse import quote
M=Path('/tmp/infra-proof-batch.json');A=Path('/tmp/infra-proof-batch.tar')
assert hashlib.sha256(M.read_bytes()).hexdigest()=='88b1770ed0ec33964fcfd55ba10bc579ae675487bef50072ddf42f74ffdaea57'
m=json.loads(M.read_bytes());assert hashlib.sha256(A.read_bytes()).hexdigest()==m['archive_sha256']
assert m['model_publication'] is m['accepted'] is m['api_restart'] is False
rows={r['path']:r for r in m['files']};assert len(rows)==8
assert all(p.startswith('models/main-infra/7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511/') and '..' not in p and '\\' not in p for p in rows)
with tarfile.open(A) as tf:
    members=tf.getmembers();assert len(members)==8 and len({x.name for x in members})==8 and all(x.isfile() and x.name in rows for x in members)
    data={x.name:tf.extractfile(x).read() for x in members}
assert all(len(b)==rows[p]['bytes'] and hashlib.sha256(b).hexdigest()==rows[p]['sha256'] for p,b in data.items())
def fetch(url):
    with urlopen(Request(url,headers={'Cache-Control':'no-cache'}),timeout=25) as response:
        assert response.status==200;return response.read()
health=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'))
assert health['sha']=='cedb7c53c35b0599585c17b214f3c29e1dfb7b9f' and health['db']['ok']
def install(target,b,sha):
    if target.exists():
        assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==sha;return
    target.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.codex-strict10573-',dir=target.parent)
    try:
        with os.fdopen(fd,'wb') as stream:stream.write(b);stream.flush();os.fsync(stream.fileno())
        os.chmod(tmp,0o644)
        try:os.link(tmp,target)
        except FileExistsError:assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==sha
    finally:os.unlink(tmp)
roots=[Path('/home/devenvir/corllenium/web'),Path('/home/devenvir/corllenium/app/public')]
for root in roots:
    assert root.resolve()==root
    for rel,row in rows.items():
        target=root/rel;assert root in target.resolve().parents
        if target.exists():assert target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256']
for root in roots:
    for rel,row in rows.items():install(root/rel,data[rel],row['sha256'])
for root in roots:
    for rel,row in rows.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==row['sha256']
for rel,row in rows.items():assert hashlib.sha256(fetch('https://corllenium.ai.dev-environment.site/'+quote(rel,safe='/')+'?proof=10573-strict26')).hexdigest()==row['sha256']
after=json.loads(fetch('https://corllenium.ai.dev-environment.site/api/health'));assert after['sha']==health['sha'] and after['db']['ok']
receipt=dict(files_per_root=8,http_hashes=8,model_publication=False,accepted=False,no_app_restart=True,api_sha=after['sha'],archive_sha256=m['archive_sha256'])
raw=(json.dumps(receipt,sort_keys=True)+'\n').encode();install(Path('/home/devenvir/corllenium/data/codex-infra-proof-batch-20261026.json'),raw,hashlib.sha256(raw).hexdigest())
print(json.dumps(receipt))
