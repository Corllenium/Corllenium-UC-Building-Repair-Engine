import importlib

import pytest


def proof():
    try:
        return importlib.import_module('tools.main_infra_orange_survivor_proof')
    except ModuleNotFoundError:
        pytest.fail('Independent orange survivor proof is missing')


def obj(faces=None, material='minecraft_wool_colored_orange_-1'):
    rows = faces or [
        ('1/1/1 2/2/1 3/3/1', material, 'marker'),
        ('1/1/1 3/3/1 4/4/1', 'facade', 'wall'),
        ('1/1/1 4/4/1 2/2/1', material, 'orange_facade'),
    ]
    text = 'mtllib original.mtl\no floor\nv 0 0 0\nv 1 0 0\nv 1 1 0\nv 0 1 0\n'
    text += 'vt 0 0\nvt 1 0\nvt 1 1\nvt 0 1\nvn 0 0 1\ns off\n'
    for face, look, group in rows:
        text += f'g {group}\nusemtl {look}\nf {face}\n'
    return text.encode()


def after():
    return obj().replace(b'f 1/1/1 2/2/1 3/3/1\n', b'')


def test_only_selected_marker_is_removed_other_orange_face_and_all_tables_survive():
    result = proof().verify_survivors(obj(), after(), [0])
    assert result == dict(before_faces=3, after_faces=2, removed_faces=[0],
                          kept_faces=[1, 2], nonselected_faces_exact=True,
                          tables_exact=True, full_floor_acceptance=False)


@pytest.mark.parametrize('kind', ['position', 'uv', 'normal', 'material', 'group', 'object', 'smooth', 'mtllib', 'extra_loss', 'winding'])
def test_any_unapproved_change_fails(kind):
    data = after()
    changes = {
        'position': (b'v 1 1 0', b'v 1 1 0.000000000000001'),
        'uv': (b'vt 1 1', b'vt 1 0.99'),
        'normal': (b'vn 0 0 1', b'vn 0 1 0'),
        'material': (b'usemtl facade', b'usemtl wrong'),
        'group': (b'g wall', b'g wrong'),
        'object': (b'o floor', b'o wrong'),
        'smooth': (b's off', b's 1'),
        'mtllib': (b'original.mtl', b'wrong.mtl'),
        'extra_loss': (b'f 1/1/1 3/3/1 4/4/1\n', b''),
        'winding': (b'f 1/1/1 3/3/1 4/4/1', b'f 1/1/1 4/4/1 3/3/1'),
    }
    old, new = changes[kind]
    with pytest.raises(ValueError):
        proof().verify_survivors(obj(), data.replace(old, new), [0])


@pytest.mark.parametrize('selection', [[], [0, 0], [-1], [3], [1], [0.0], [True]])
def test_wrong_or_nonmarker_selection_fails(selection):
    with pytest.raises(ValueError):
        proof().verify_survivors(obj(), after(), selection)


def test_invalid_utf8_and_nontriangular_or_relative_face_input_fail_closed():
    for data in [obj()+b'\xff', obj().replace(b'1/1/1 2/2/1 3/3/1', b'1/1/1 2/2/1 3/3/1 4/4/1'), obj().replace(b'1/1/1', b'-1/1/1')]:
        with pytest.raises(ValueError):
            proof().verify_survivors(data, after(), [0])
