from dataclasses import replace
import hashlib
import struct
import warnings
import numpy as np
import pytest
from engine.model import MeshData
from engine.repair.types import face_keys,print_step


def mesh_at(first=1000.,second=1100.,decimals=16):
    positions=np.array([[first,0,0],[first,-1,0],[first,0,1],[second,0,0],[second,-1,0],[second,0,1]],dtype=np.float64)
    faces=np.array([[0,1,2],[3,4,5]],dtype=np.int64)
    return MeshData('literal',positions,np.empty((0,2)),np.empty((0,3)),faces,np.full((2,3),-1),np.full((2,3),-1),
        np.zeros(2,dtype=np.int64),np.arange(2),['wall'],None,decimals,17,physical_quanta=(1e-6,1e-6,1e-7))


def quiet_keys(mesh,looks=None):
    with warnings.catch_warnings(record=True)as seen:
        warnings.simplefilter('always');keys=face_keys(mesh,{0:'wall-look'}if looks is None else looks)
    assert seen==[]
    return keys


def legacy_oracle(mesh,looks):
    points=np.rint(mesh.positions/print_step(mesh))
    assert np.isfinite(points).all()and ((points>=-(2**63))&(points<2**63)).all()
    result=[]
    for face,material in zip(mesh.face_v,mesh.face_material):
        corners=[tuple(int(x)for x in points[i])for i in face]
        rotations=[tuple(x for row in corners[k:]+corners[:k]for x in row)for k in range(3)]
        look='material:<none>'if material<0 else looks.get(int(material),'material:'+mesh.materials[int(material)])
        result.append(hashlib.sha256(struct.pack('<9q',*min(rotations))+b'|'+look.encode()).hexdigest())
    return result


def test_literal_positive_wide_faces_have_distinct_keys_without_cast_warning():
    keys=quiet_keys(mesh_at());assert keys[0]!=keys[1]


@pytest.mark.parametrize('first,second',[(-1000.,-1100.),(1e100,2e100),(-1e100,-2e100)])
def test_finite_negative_and_large_rounded_integers_remain_distinct(first,second):
    keys=quiet_keys(mesh_at(first,second));assert keys[0]!=keys[1]


def test_recorded_representable_literal_control_keys_stay_byte_identical():
    assert quiet_keys(mesh_at(100.,200.))==['15735d59278e3f93f846e9738021d63529d70894739e46758db6e69c1f054781','1a987cad57c9e120b41f6a3868e160945310bcb0bb97c2a5061ed35449a01555']


@pytest.mark.parametrize('seed',[0,1,2])
def test_representable_payload_matches_independent_legacy_oracle(seed):
    rng=np.random.default_rng(seed);mesh=mesh_at(100.,200.)
    mesh=replace(mesh,positions=rng.uniform(-500,500,(6,3)))
    assert quiet_keys(mesh)==legacy_oracle(mesh,{0:'wall-look'})


def test_mixed_mesh_preserves_ordinary_face_key_independently_of_wide_neighbors():
    ordinary=mesh_at(100.,200.);wide=mesh_at()
    mixed=replace(ordinary,positions=np.vstack([ordinary.positions,wide.positions]),face_v=np.vstack([ordinary.face_v,wide.face_v+6]),
        face_vt=np.full((4,3),-1),face_vn=np.full((4,3),-1),face_material=np.zeros(4,dtype=np.int64),face_line=np.arange(4))
    assert quiet_keys(mixed)[:2]==quiet_keys(ordinary)
    assert quiet_keys(mixed)[2:]==quiet_keys(wide)


def test_wide_corner_start_reordering_duplication_and_winding_contracts():
    mesh=mesh_at();keys=quiet_keys(mesh)
    assert quiet_keys(replace(mesh,face_v=np.roll(mesh.face_v,1,axis=1)))==keys
    assert quiet_keys(replace(mesh,face_v=mesh.face_v[::-1]))==keys[::-1]
    order=np.array([4,1,5,0,3,2]);inverse=np.argsort(order)
    assert quiet_keys(replace(mesh,positions=mesh.positions[order],face_v=inverse[mesh.face_v]))==keys
    assert quiet_keys(replace(mesh,positions=np.vstack([mesh.positions,mesh.positions]),face_v=mesh.face_v+6))==keys
    assert quiet_keys(replace(mesh,face_v=mesh.face_v[:,::-1]))!=keys


def test_material_look_and_uv_normal_compatibility():
    mesh=mesh_at();keys=quiet_keys(mesh)
    assert quiet_keys(mesh,{0:'different-look'})!=keys
    assert quiet_keys(replace(mesh,materials=['renamed']),{0:'wall-look'})==keys
    assert quiet_keys(mesh,{})!=quiet_keys(replace(mesh,materials=['renamed']),{})
    changed=replace(mesh,uvs=np.array([[0.,0.],[1.,0.],[0.,1.]]),face_vt=np.tile([0,1,2],(2,1)),normals=np.array([[1.,0.,0.]]),face_vn=np.zeros((2,3),dtype=np.int64))
    assert quiet_keys(changed)==keys


def test_encoding_does_not_change_arrays_or_precision_metadata():
    mesh=mesh_at();saved={k:getattr(mesh,k).copy()for k in('positions','uvs','normals','face_v','face_vt','face_vn','face_material','face_line')}
    quiet_keys(mesh)
    assert all(np.array_equal(getattr(mesh,k),value)for k,value in saved.items())
    assert mesh.coord_decimals==16 and mesh.sig_digits==17 and mesh.physical_quanta==(1e-6,1e-6,1e-7)
    assert print_step(mesh)==1e-16


@pytest.mark.parametrize('value',[np.nan,np.inf,-np.inf])
def test_nonfinite_position_is_rejected_without_a_cast_warning(value):
    mesh=mesh_at();mesh.positions[0,0]=value
    with warnings.catch_warnings(record=True)as seen:
        warnings.simplefilter('always')
        with pytest.raises(ValueError):face_keys(mesh,{0:'wall-look'})
    assert seen==[]


@pytest.mark.parametrize('decimals',[400,-400])
def test_invalid_underflowed_or_overflowed_step_fails_closed(decimals):
    with pytest.raises(ValueError):face_keys(mesh_at(decimals=decimals),{0:'wall-look'})


def test_finite_positions_with_nonfinite_scaled_grid_fail_closed():
    with pytest.raises(ValueError):face_keys(mesh_at(1e308,1.7e308),{0:'wall-look'})


def test_signed_int64_boundary_and_just_outside_have_distinct_keys():
    step=1e-16;limit=float(2**63)
    inside=np.nextafter(limit,0)*step;outside=np.nextafter(limit,np.inf)*step
    keys=quiet_keys(mesh_at(inside,outside));assert keys[0]!=keys[1]
    keys=quiet_keys(mesh_at(-inside,-outside));assert keys[0]!=keys[1]
