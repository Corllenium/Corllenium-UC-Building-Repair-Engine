import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path


GUARD='39cf94629dfa590c42366b5786d9c7f9b56b6a75c86fd01da4c5c633c6a74a67'
CENSUS='e58ad15f874c15ee712f7c7ee6a0558f1f33299610ea25c147e1d9d8f1f8868b'
CENSUS_TERMINAL='1d2a2a499156205d17b2a9b9635a0c99f7cb0e4515df9a97cc34ea0e82c60fae'
HEAD='7eed76b2630077b21a7576f9ccc0ed230a36f934'
HELD=dict(monitor_pid=45640,lease_released=True,profile_sha256='2050e60c1d613f1df559b23291262249d754009e47d3848fdb7bb6d9abfdcf4f',
    lease_acquired_utc='2026-10-27T10:45:48.6850277Z',nonce='ab1bb939-94ce-4972-a88a-5096ea852465',
    monitor_creation_utc='2026-10-27T10:45:47.7533940Z',coordination_sha256='4ebc38abc9340f8139c396f930f926635921e7428f0b18549e7db263e3f0fa9f',
    exclusive_operator='/root/upper_floor_resume',original_phase_sha256=GUARD,ended_utc='2026-10-27T10:45:50.7035563Z')


def need(value,message):
    if not value:raise ValueError(message)


def instant(value):return datetime.fromisoformat(value.replace('Z','+00:00'))


def qualify(d):
    need(set(d)=={'census','held','current','gate','coord','zero','hold','files'},'Exact continuation document inventory required')
    success=d['census'];held=d['held'];gate=d['gate'];coord=d['coord'];zero=d['zero']
    need(type(success['actual_exit_code']) is type(success['launcher_exit_code']) is int
         and d['current']['lease_released'] is True and type(d['current']['monitor_pid']) is int
         and held['lease_released'] is True and type(held['monitor_pid']) is type(success['actual_pid']) is int
         and d['hold']['no_phase_started'] is True
         and type(gate['maximum_heavy_phases']) is int,'Original JSON boolean/integer types required')
    need(success['state']=='PROCESS_EXITED_ZERO' and success['actual_pid']==37992
         and success['actual_creation_utc']=='2026-10-27T10:41:56.3612855Z' and success['HEAD']==HEAD
         and success['actual_exit_code']==success['launcher_exit_code']==0 and success['all_owned_exited'] is True
         and success['abort_reason'] is None and success['phase_plan_sha256']==CENSUS,'Original successful census identity differs')
    need(d['hold']==dict(state='HOLD',no_phase_started=True,reason='Three fresh single-owner launch samples below8GiB')
         and sorted(d['files'])==['launch-gate.json','result.json'],'Only original no-start memory HOLD may continue')
    need(held==HELD and d['current']==held,'Exact original released guard lease/nonce/birth required; never reset lease')
    need(gate['original_phase_sha256']==GUARD and gate['profile_sha256']==HELD['profile_sha256']
         and gate['passed'] is False and gate['require8GiB'] is True and gate['maximum_heavy_phases']==1
         and len(gate['samples'])==3,'Original failed guard launch gate differs')
    times=[]
    for row in gate['samples']:
        need(all(type(row[key]) is int for key in ('commit_bytes','limit_bytes','headroom_bytes'))
             and row['headroom_bytes']==row['limit_bytes']-row['commit_bytes']
             and 0<=row['headroom_bytes']<8*2**30,'Original below-8GiB HOLD samples differ')
        times.append(instant(row['utc']))
    need(times==sorted(set(times)) and instant(held['lease_acquired_utc'])<=times[0]<=times[-1]<=instant(held['ended_utc']),
         'Original held lease/gate chronology differs')
    need(coord['coordinator']=='/root' and coord['exclusive_operator']==HELD['exclusive_operator']
         and coord['all_model_operators_paused'] is True and coord['active_owner_geometry_workers']==[]
         and coord['phase_sha256']==GUARD and coord['nonce']==held['nonce'],'Original HOLD coordination differs')
    need(zero['active_owner_geometry_workers']==[] and zero['all_other_operators_paused'] is True
         and all(row['owner_geometry'] is False for row in zero['rows'])
         and zero['prior_terminal_sha256']==CENSUS_TERMINAL and zero['prior_released_lease']['lease_released'] is True
         and zero['prior_released_lease']['original_phase_sha256']==CENSUS,'Original pre-HOLD native zero-owner/census chain differs')
    return dict(predecessor_qualified=True,model_started=False,acceptance=False,guard_phase_sha256=GUARD,
        held_nonce=held['nonce'],minimum_new_launch_headroom_bytes=8*2**30,fresh_new_launch_samples=3,
        maximum_owned_private_or_peak_bytes=3*2**30,minimum_running_system_headroom_bytes=int(3.5*2**30),
        fresh_native_zero_owner_and_Root_slot_still_required=True)


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def read_pin(pin):
    path=Path(pin['path']);need(sha(path)==pin['sha256'],'Continuation input pin changed: '+str(path))
    return json.loads(path.read_bytes())


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--spec',type=Path,required=True)
    parser.add_argument('--spec-sha256',required=True);parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    need(sha(args.spec)==args.spec_sha256,'Continuation spec changed');spec=json.loads(args.spec.read_bytes())
    need(spec['mode']=='2F39334_GUARD_NO_START_HOLD_CONTINUATION_V1' and spec['HEAD']==HEAD
         and Path(spec['current_lease']).resolve()==Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/data/siege-live-20261026/single-owner-8gib.lock').resolve()
         and args.out.resolve().parent==args.spec.resolve().parent,'Exact owned guard-only metadata qualification required')
    for pin in spec['pins']:need(sha(pin['path'])==pin['sha256'],'Continuation runtime/provenance pin changed: '+pin['path'])
    need(sha(spec['current_lease'])==spec['current_lease_sha256'],'Original released lease bytes changed')
    documents={key:read_pin(pin) for key,pin in spec['documents'].items()}
    documents['current']=json.loads(Path(spec['current_lease']).read_bytes())
    documents['files']=sorted(path.name for path in Path(spec['hold_monitor']).iterdir())
    result=qualify(documents)
    need(sha(spec['current_lease'])==spec['current_lease_sha256'],'Released lease changed during qualification')
    result.update(spec_sha256=args.spec_sha256,current_released_lease=documents['current'],current_lease_sha256=spec['current_lease_sha256'])
    with args.out.open('x',encoding='utf8') as out:json.dump(result,out,indent=2);out.write('\n')
    print(json.dumps(dict(predecessor_qualified=True,model_started=False,acceptance=False,proof=str(args.out),proof_sha256=sha(args.out))))


if __name__=='__main__':main()
