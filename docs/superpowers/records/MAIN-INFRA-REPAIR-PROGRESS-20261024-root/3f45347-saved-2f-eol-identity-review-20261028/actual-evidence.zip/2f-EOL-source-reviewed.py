"""Independent saved 2F site100 readback, strict guard and default census."""
import argparse
from dataclasses import asdict, replace
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT.parents[2]
JOB="MAIN-INFRA-2F-SITE100-INDEPENDENT-20261028"
BRANCH="codex/main-infra-2f-site100-independent-20261028"
SAFE="2c6a47c8ef5a5a20183c06db916262525b44f40daca7b5fad3d761e52707b73c"
HANDOFF="e7436ab3d28d97ac32ec506644c1cd4e1404354996ca0411a76f79f296442e9b"
GUARDS={"engine/guard/compare.py":"95cd6b9094025bd2776635cd65e7ad01d32577f7785199e825f4d090703d4e56","engine/guard/exact_hits.py":"905a22cb0eb312eb5d81410c585a8ac6826524617e35d559e76fc9a7ac24c419"}

def need(value,message):
    if not value:raise ValueError(message)
def sha(p):
    with Path(p).open("rb")as s:return hashlib.file_digest(s,"sha256").hexdigest()
def source_identity(path,expected):
    raw=Path(path).read_bytes();canonical=raw.replace(b"\r\n",b"\n");actual=hashlib.sha256(canonical).hexdigest()
    need(actual==expected,"Paid strict guard changed")
    return dict(raw_sha256=hashlib.sha256(raw).hexdigest(),canonical_LF_sha256=actual,CRLF_count=raw.count(b"\r\n"),canonicalization="CRLF_to_LF_only")
def read(p):return json.loads(Path(p).read_bytes())
def save(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("x",encoding="utf8")as s:json.dump(value,s,indent=2,allow_nan=False);s.write("\n")
def module(pin,name):
    need(sha(pin["path"])==pin["sha256"],"Paid helper changed")
    spec=importlib.util.spec_from_file_location(name,pin["path"]);value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value);return value

def derive(scope,site,run,lineage):
    n=scope["original_triangles"]
    need(type(n)is int and n>0,"Original count required")
    for values in (scope["current_originals"],scope["mandatory_originals"],scope["contact_originals"],scope["marker_originals"],site):
        need(values==sorted(set(values))and all(type(i)is int and 0<=i<n for i in values),"Ordered bounded distinct originals required")
    current=set(scope["current_originals"]);markers=set(scope["marker_originals"])
    need(site and not set(site)&current and not markers&(current|set(site)),"Entire absent site and exact marker exclusion required")
    need(set(scope["mandatory_originals"])<=current and set(scope["contact_originals"])<=set(scope["mandatory_originals"]),"Current mandatory/contact scope differs")
    parents=sorted(current|set(site));mandatory=sorted(set(scope["mandatory_originals"])|set(site))
    need(run["original_source_survivors"]==parents and run["restored_originals"]==site and run["whole_required_originals"]==mandatory,"Whole prior/site/mandatory ancestry differs")
    need(run["source_priority_contacts"]==scope["contact_originals"]and run["approved_absent_markers"]==scope["marker_originals"]and run["assets"]==scope["assets"],"Contact/marker/asset inventory differs")
    need([r["original_source_triangle"]for r in lineage["faces"]]==parents and run["output_triangles"]==len(parents),"Saved count or ordered lineage differs")
    need(run["kernel_called"]is False and run["engine_survivor_writer_called"]is True and run["model_written"]is True and run["repair_complete"]is False and run["acceptance"]is False,"Actual survivor-only candidate required")
    need(run["independent_validation"]=="PENDING"and all(run[k]=="NOT_RUN"for k in ("strict26","native","fullsigned","census")),"Historical validation cannot transfer")
    return dict(parents=parents,mandatory=mandatory,restored=site,contacts=scope["contact_originals"],markers=scope["marker_originals"],acceptance=False)

def context(path,expected):
    need(sha(path)==expected,"Independent role changed");role=read(path)
    need(role["job_id"]==JOB and role["acceptance"]is False and Path(role["out"]).resolve()==ROOT/"data/site100-iv/attempt0001","Exact independent job/output required")
    git=lambda *a:subprocess.check_output(["git","-C",str(ROOT),*a],text=True).strip()
    need(git("rev-parse","HEAD")==role["executing_HEAD"]and git("branch","--show-current")==BRANCH and not git("status","--porcelain","--untracked-files=no"),"Clean frozen independent source required")
    from tools.jobs import get
    claim=get(MAIN,JOB);need((claim["status"],claim["holder"],claim["branch"])==("claimed","Codex-2F-Site100-IV",BRANCH),"Independent claim required")
    pins={}
    for p in role["pins"]:
        key=str(Path(p["path"]).resolve());need(key not in pins and Path(p["path"]).stat().st_size==p["bytes"]and sha(p["path"])==p["sha256"],"Frozen input changed or duplicated");pins[key]=p
    for p in [role["handoff"],*role["helpers"].values(),*role["refs"].values()]:need(pins.get(str(Path(p["path"]).resolve()))==p,"Consumed role input omitted from closure")
    need(role["handoff"]["sha256"]==HANDOFF and sha(ROOT/"engine/repair/types.py")==SAFE,"Exact producer handoff and safe runtime required")
    for rel,s in GUARDS.items():source_identity(ROOT/rel,s)
    h=read(role["handoff"]["path"]);r=role["refs"];run=read(r["run"]["path"]);terminal=read(r["terminal"]["path"]);b=read(r["producer_binding"]["path"]);scope=read(r["scope"]["path"])
    need(h["acceptance"]is False and h["historical_verdict_transferred"]is False and h["old_checkpoint_replayed"]is False,"Unaccepted checkpoint-free handoff required")
    need(run["job_id"]==h["builder_job_id"]and run["executing_HEAD"]==h["builder_HEAD"]==terminal["HEAD"]and run["binding_sha256"]==h["builder_binding"]["sha256"],"Actual producer binding differs")
    need(terminal["state"]=="PROCESS_EXITED_ZERO"and terminal["actual_exit_code"]==terminal["launcher_exit_code"]==0 and terminal["all_owned_exited"]is True and terminal["abort_reason"]is None and terminal["actual_pid"]==66024 and terminal["actual_creation_utc"]=="2026-10-28T06:57:54.7102695Z","Completed builder lifetime required")
    records=[json.loads(x)for x in Path(r["original_log"]["path"]).read_text().splitlines()];sites=[x for x in records[:-1]if x["site"]==100 and x["engine"]=="E3"and x["kind"]=="remove"and not x.get("rolled_back",False)]
    need(len(sites)==1,"Exact original E3 site100 required");site=sorted(sites[0]["faces"]);a=read(r["attribution"]["path"])
    need(a["pixel"]==dict(y=570,x=206,before_original=9257,after_original=3966,stage="E3",sites=[100],code=2)and a["before"]["membership"]["whole_originals"]==site,"Actual failed-pixel whole-site evidence differs")
    facts=derive(scope,site,run,read(r["lineage"]["path"]))
    need(scope["original_triangles"]==56828 and len(facts["parents"])==39614 and len(facts["mandatory"])==8997 and len(site)==280 and 9257 in site and len(facts["contacts"])==7 and facts["markers"]==list(range(56804,56828))and len(scope["assets"])==10,"Exact measured restored2F scope required")
    need(run["source_sha256"]==r["source"]["sha256"]==h["source"]["sha256"]and run["engine_sha256"]==r["engine"]["sha256"]==h["engine"]["sha256"],"Saved model role differs")
    return role,scope,facts

def geometry(role,scope,facts):
    import numpy as np
    from engine.io.minecraft_floor import parse_floor
    from engine.io.obj_reader import read_obj
    from tools.main_infra_e3 import load_qualified_floor
    paid=module(role["helpers"]["direct"],"paid_site100_direct");r=role["refs"]
    source,normalized,original,receipt=load_qualified_floor(raw=r["raw"]["path"],reference=r["reference"]["path"],baseline=Path(r["before_engine"]["path"]).parent,qualification=r["qualification"]["path"])
    need(original.n_faces==56828 and receipt["assets"]==scope["assets"]and receipt["source_to_engine"]==scope["source_to_engine"]and receipt["physical_axis_quanta_inches"]==scope["physical_axis_quanta_inches"],"Original RAW/Frame/quanta/assets differ")
    proofs={}
    for label,ids,sk,ek in [("candidate",facts["parents"],"source","engine"),("reference",list(range(56804)),"reference_source","reference_engine")]:
        sf=parse_floor(Path(r[sk]["path"]).read_text(encoding="utf8"));ef=parse_floor(Path(r[ek]["path"]).read_text(encoding="utf8"))
        proof=paid.verify_floor_fields(source,sf,ids);proof["engine_direct"]=paid.verify_finite_whole_mesh(original,ef.mesh,ids)
        for out,parent in enumerate(ids):
            a=source.polygons[source.triangle_polygon[parent]];b=ef.polygons[ef.triangle_polygon[out]];need((a.group,a.object_name)==(b.group,b.object_name),"ENGINE group/object ancestry differs")
        for asset in receipt["assets"]:need(sha(Path(r[sk]["path"]).parent/asset["path"])==sha(Path(r[ek]["path"]).parent/asset["path"])==asset["sha256"],"Saved original asset differs")
        proofs[label]=proof
    before=paid.bind_raw_quanta(original,read_obj(r["reference_engine"]["path"]));after=paid.bind_raw_quanta(original,read_obj(r["engine"]["path"]))
    need(before.n_faces==56804 and after.n_faces==39614,"Saved guard pair counts differ")
    proof=dict(job_id=JOB,actual_triangles=39614,mandatory_originals=len(facts["mandatory"]),restored_originals=len(facts["restored"]),contacts=7,assets=10,approved_markers_absent=24,saved_pairs=proofs,RAW_context=receipt,runtime_types_sha256=SAFE,guard_source_identities={rel:source_identity(ROOT/rel,value)for rel,value in GUARDS.items()},guard_runtime_raw_bytes_frozen=True,old_checkpoint_replayed=False,before_sha256=r["reference_engine"]["sha256"],source_sha256=r["source"]["sha256"],after_sha256=r["engine"]["sha256"],native="NOT_RUN",fullsigned="NOT_RUN",historical_verdict_transferred=False,acceptance=False)
    return source,normalized.frame,original,before,after,proof

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("phase",choices=("metadata","readback","guard","census"));p.add_argument("--binding",type=Path,required=True);p.add_argument("--binding-sha256",required=True);a=p.parse_args(argv)
    role,scope,facts=context(a.binding,a.binding_sha256);out=Path(role["out"])
    if a.phase=="metadata":print(json.dumps(dict(owner_geometry_loaded=False,actual_triangles=39614,whole_required=8997,restored=280,contacts=7,acceptance=False)));return 0
    source,frame,original,before,after,proof=geometry(role,scope,facts);context(a.binding,a.binding_sha256)
    if a.phase=="readback":save(out/"independent-readback.json",proof);print(json.dumps(dict(readback_sha256=sha(out/"independent-readback.json"),acceptance=False)));return 0
    if a.phase=="guard":
        import numpy as np
        helper=module(role["helpers"]["strict"],"paid_site100_strict");names={name:i for i,name in enumerate(before.materials)};need(set(after.materials)<=set(names),"Guard material namespace differs")
        guarded=replace(after,materials=before.materials.copy(),face_material=np.array([-1 if i<0 else names[after.materials[int(i)]]for i in after.face_material],np.int64))
        report,tol=helper.strict_guard(before,guarded,source.mesh,read(role["refs"]["provenance"]["path"]));context(a.binding,a.binding_sha256)
        save(out/"independent-guard.json",dict(proof,guard=asdict(report),tolerance_inches=tol,corrected_numerical_components=GUARDS,views=26,resolution=[900,600],reference_triangles=56804))
        print(json.dumps(dict(passed=report.passed,guard_sha256=sha(out/"independent-guard.json"),totals=asdict(report)["totals"],acceptance=False)));return 0 if report.passed else 2
    shared=module(role["helpers"]["census"],"paid_site100_census");raw=shared.save_raw_pair(original,after,out/"census");results={}
    from engine.io.obj_reader import read_obj
    r=role["refs"]
    for kind,label,mesh,display,pin,ep,doc in [("source","before",original,source.mesh,r["before_source"],r["before_engine"],raw[0]),("candidate","after",after,read_obj(r["source"]["path"]),r["source"],r["engine"],raw[1])]:
        rawpath=out/"census"/("census-"+label+".raw.json");binding=dict(source_revision=shared.REV,run_id=shared.RUN,floor_id="MAIN_INFRA_2F",kind=kind,obj_sha256=pin["sha256"]);provenance=dict(raw_census_sha256=sha(rawpath),engine_obj_sha256=ep["sha256"],source_obj_sha256=pin["sha256"],role_sha256=a.binding_sha256)
        mapped=shared.bind_display(doc,mesh,display,frame,binding,provenance,floor_id="MAIN_INFRA_2F");target=out/"census"/("errors-"+kind+".json");save(target,mapped);results[kind]=dict(path=str(target),sha256=sha(target),counts=doc["counts"],n_faces=mesh.n_faces)
    context(a.binding,a.binding_sha256);save(out/"census/census-receipt.json",dict(job_id=JOB,actual_triangles=39614,results=results,profile="unchanged default find_errors/FixProfile",native="NOT_RUN",fullsigned="NOT_RUN",acceptance=False));print(json.dumps(dict(results=results,acceptance=False)));return 0

if __name__=="__main__":raise SystemExit(main())
