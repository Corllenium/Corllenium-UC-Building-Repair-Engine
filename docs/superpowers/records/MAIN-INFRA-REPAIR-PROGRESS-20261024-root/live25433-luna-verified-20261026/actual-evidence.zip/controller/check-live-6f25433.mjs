import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=fileURLToPath(new URL('../../',import.meta.url));
const dashboard=path.join(root,'.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023/dashboard');
const require=createRequire(path.join(dashboard,'package.json'));
const bundle=path.join(root,'data/siege-live-20261026/fresh-preview-client.mjs');
require('esbuild').buildSync({entryPoints:[path.join(dashboard,'lib/buildings/freshMainInfraPreview.ts')],bundle:true,format:'esm',platform:'node',outfile:bundle});
const {loadFreshPreview}=await import(pathToFileURL(bundle));
const p=JSON.parse(fs.readFileSync(path.join(root,'data/live-6f25433/package.json'),'utf8'));
const rows=new Map(p.files.map(row=>['/'+row.path,row]));
let stale=false,corrupt=false;
globalThis.fetch=async url=>{
  const rel=decodeURIComponent(url);if(!rows.has(rel))throw new Error('Unexpected client request');
  let bytes=fs.readFileSync(path.join(p.stage,rel.slice(1)));
  if(stale&&url===p.results.candidate.errors_url){const doc=JSON.parse(bytes);doc.binding.obj_sha256='0'.repeat(64);bytes=Buffer.from(JSON.stringify(doc));}
  if(corrupt&&url===p.results.candidate.obj_url)bytes=Buffer.from('broken model');
  return new Response(bytes,{status:200});
};
const identity={source_revision:p.source_revision,run_id:'main-infra-clean-20261023',floor:'6F'};
const actual=await loadFreshPreview(p.results.candidate.preview,identity,'candidate');
if((actual.obj.match(/^f /gm)??[]).length!==25433||!actual.errors||Object.keys(actual.errors.counts).length!==7||actual.errors.counts.flicker_diff!==1911||actual.errors.counts.flicker_same!==3690||actual.errors.counts.cracks!==6448)throw new Error('Actual new 6F model/maps did not load');
stale=true;const rejected=await loadFreshPreview(p.results.candidate.preview,identity,'candidate');
if(rejected.errors!==null)throw new Error('Stale error map was accepted');
stale=false;corrupt=true;let modelRejected=false;
try{await loadFreshPreview(p.results.candidate.preview,identity,'candidate');}catch{modelRejected=true;}
if(!modelRejected)throw new Error('Corrupt model was accepted');
const receipt={actualTriangles:25433,errorKinds:7,counts:actual.errors.counts,materials:Object.keys(actual.materials).length,staleMapRejected:true,corruptModelRejected:true,accepted:false};
fs.writeFileSync(path.join(root,'data/live-6f25433/client-preview-qa.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
