from pathlib import Path
import hashlib,json,subprocess,sys,time

R=Path(__file__).resolve().parents[2]
D=R/'data/live-6f25433'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

assert sha(D/'package.json')=='2d417346e5c247175dda96392a97434d20a5d2872a96a09ad2b2b23631580be6'
m=read(D/'package.json');candidate=m['results']['candidate']
deployed=json.loads((D/'deployment.log').read_text(encoding='utf-8-sig').strip())
assert deployed['files_per_root']==deployed['http_hashes']==19 and not deployed['accepted']
assert deployed['archive_sha256']==m['archive_sha256']
qa=read(D/'client-preview-qa.json')
assert qa['actualTriangles']==25433 and qa['errorKinds']==7 and qa['staleMapRejected'] and qa['corruptModelRejected']
assert m['remaining_target_instances']==12049
v=R/'.claude/worktrees/v6h/data'
cp=v/'iv6h-preflight/monitor-6F25433-independent-census-20261026T121618/result.json'
gp=v/'iv6h-preflight/monitor-6F25433-independent-guard-20261026T121836/result.json'
t,g=read(cp),read(gp)
for terminal,pid in ((t,41364),(g,46988)):
    assert terminal['actual_pid']==pid and terminal['actual_exit_code']==0 and terminal['all_owned_exited'] and terminal['abort_reason'] is None
report=v/'iv6h/independent-guard.json'
assert sha(report)=='4178699a457e1af4cfc1d15ab45d81273ceef5f5942f096a8d301a6fd5e51dd7'
guard=read(report)
assert guard['guard']['passed'] and guard['candidate_source_sha256']==candidate['obj_sha256']
assert len(guard['guard']['views'])==26 and guard['guard']['totals']['model_px']==4791106
assert all(value==0 for key,value in guard['guard']['totals'].items() if key not in ('model_px','zfight_tie'))
sys.path.insert(0,str(R/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
path=R/'data/main-infra-fresh/current.json'
for attempt in range(6):
    d=load_progress(path);f=d['floors']['6F'];now=utc_now()
    assert f['output_triangles'] in (25210,25433) and f['accepted_preview'] is None and f['owner_decision_ref'] is None
    if f['candidate_preview']!=candidate['preview']:
        f.setdefault('inspection_manifest_history',[]).append(dict(at=now,source=f['source_preview'],candidate=f['candidate_preview'],
            strict26_passed=f.get('independent_guard_passed'),guard_sha256=f.get('independent_guard_sha256'),reason='New actual25433 with fresh detector maps'))
    f.update(candidate_preview=candidate['preview'],output_triangles=25433,pending_output_triangles=None,evidence_refs=m['evidence_refs'],validator_ref=None,
        state='validating',step='After shows the new 6F candidate: 25,433 triangles, approved orange boxes removed and seven matching error filters. Independent strict26 passed; native and full signed checks are pending.',
        blocker='12,049 measured target instances remain: 1,911 different-look overlaps, 3,690 same-look overlaps and 6,448 cracks. All 3,546 protected originals and 12 assets passed independent saved-file readback. Not accepted.',
        worker_pid=46988,worker_start_utc=g['actual_creation_utc'],worker_alive=False,worker_observed_at=g['ended_utc'],last_work_event_at=now,
        independent_guard_passed=True,independent_guard_sha256=sha(report),independent_guard_candidate_sha256=candidate['obj_sha256'],
        independent_guard_model_pixels=4791106,independent_guard_error_pixels=0,native_preservation_passed=None,guard_views_done=26,guard_views_total=26)
    f.pop('worker_cpu_seconds',None);f.pop('validation_proof',None);f.pop('acceptance_proof',None)
    f.pop('pending_saved_candidate',None)
    f['latest_saved_candidate']=dict(triangles=25433,source_candidate_sha256=candidate['obj_sha256'],
        engine_candidate_sha256='3ff8f6c396c35e1cb488d84f963e6e03d3e8697ef305d21e20bb25982be0fb54',candidate_preview=candidate['preview'],
        strict26='PASS',strict26_sha256=sha(report),native='PENDING',full_signed='PENDING',marker_dropout='EXACT_24_ONLY_PASS',protected_originals=3546,acceptance=False)
    phase='new25433_model_maps_strict26_published'
    if not any(e.get('phase')==phase for e in f.setdefault('worker_events',[])):
        f['worker_events'].append(dict(engine='Validator',run_id='MAIN-INFRA-6F-25433-INDEPENDENT-20261026',pid=46988,
            start_utc=g['actual_creation_utc'],observed_at=now,phase=phase,
            message='New25,433 model,12 unchanged assets,seven measured filters and strict26 report published to both live roots; all19 HTTP hashes and real client loader passed. Strict26 PASS/4,791,106 model pixels/zero gating violations; report-only tie1. Native/full signed pending;12,049 target instances remain; no acceptance.'))
    d.update(updated_at=now,last_work_event_at=now)
    draft=D/'current-draft.json';draft.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
    subprocess.run(['node',str(R/'data/siege-live-20261026/check-status-current.mjs'),str(draft)],capture_output=True,check=True)
    try:write_progress(path,d);break
    except PermissionError:
        if attempt==5:raise
        time.sleep(.1)
f=load_progress(path)['floors']['6F']
assert f['candidate_preview']==candidate['preview'] and f['output_triangles']==25433 and f['independent_guard_passed'] is True and f['accepted_preview'] is None
result=dict(at=now,floor='6F',output_triangles=25433,candidate_preview=candidate['preview'],remaining_target_instances=12049,
    strict26_passed=True,all19_HTTP_verified=True,actual_client_loader_passed=True,native='PENDING',full_signed='PENDING',accepted=False)
(D/'canonical-readback.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
