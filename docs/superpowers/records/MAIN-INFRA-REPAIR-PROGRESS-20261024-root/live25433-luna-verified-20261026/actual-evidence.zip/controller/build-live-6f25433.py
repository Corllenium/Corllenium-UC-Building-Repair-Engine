from pathlib import Path
import hashlib,io,json,tarfile
from urllib.parse import quote
R=Path(__file__).resolve().parents[2];D=R/'data/live-6f25433';S=D/'stage'
REV='7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511'
PREFIX=f'models/main-infra/{REV}/6F/main-infra-clean-20261023/candidate/'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(doc):return (json.dumps(doc,indent=2,allow_nan=False)+'\n').encode()
def checked(p,digest):
    b=Path(p).read_bytes();assert sha(b)==digest,str(p);return b
row=json.loads(checked(R/'.claude/worktrees/v6h/data/iv6h-preflight/live-inspection-row-25433.json','248eb2bbc585cd06dd974dc5397417b72a433c25f21ca3444ec8275ba386e0c6'))
census=R/'.claude/worktrees/v6h/data/iv6h/census'
receipt=checked(census/'census-receipt.json','bbad032669fa48437aa6a6079b6bc191ac39d38dd2ad476196950373b2f0aea2');measured=json.loads(receipt)
assert measured['no_model_mutation'] and not measured['acceptance'] and measured['floor']=='6F'
terminal=json.loads((R/'.claude/worktrees/v6h/data/iv6h-preflight/monitor-6F25433-independent-census-20261026T121618/result.json').read_bytes())
assert terminal['actual_exit_code']==0 and terminal['all_owned_exited'] and terminal['abort_reason'] is None
candidate=measured['results']['candidate'];raw=json.loads(checked(candidate['raw_path'],candidate['raw_sha256']));mapped=json.loads(checked(candidate['path'],candidate['sha256']))
assert candidate['n_faces']==raw['n_faces']==mapped['n_faces']==25433
assert raw['counts']==mapped['counts']==candidate['counts'] and mapped['binding']['obj_sha256']==row['candidate']['sha256']
assert mapped['binding']==dict(source_revision=REV,run_id='main-infra-clean-20261023',floor_id='MAIN_INFRA_6F',kind='candidate',obj_sha256=row['candidate']['sha256'])
for name,ids in raw['layers'].items():assert len(ids)==len(set(ids)) and all(type(i)is int and 0<=i<25433 for i in ids)
mapped.update(layers=raw['layers'],layer_counts=raw['layer_counts'],layer_provenance=dict(facade='Existing default detector diagnostic; not a preservation verdict.'))
remaining=sum(candidate['counts'][k] for k in ('flicker_diff','flicker_same','reversed','cracks'));assert remaining==12049
S.mkdir(parents=True,exist_ok=False);files={}
def add(relative,b):
    p=PREFIX+relative;assert '..' not in p and '\\' not in p and p not in files
    target=S/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);assert target.read_bytes()==b
    files[p]=dict(path=p,sha256=sha(b),bytes=len(b));return '/'+quote(p,safe='/')
assets=[]
for asset in row['assets']:
    b=checked(asset['path'],asset['sha256']);url=add(asset['relative'].replace('\\','/'),b);assets.append(dict(url=url,sha256=sha(b)))
model=checked(row['candidate']['path'],row['candidate']['sha256']);assert sum(line.startswith(b'f ') for line in model.splitlines())==25433
obj_url=add('model-25433-20261026.obj',model);assets.append(dict(url=obj_url,sha256=sha(model)))
errors=js(mapped);errors_url=add('errors-25433-20261026.json',errors);assets.append(dict(url=errors_url,sha256=sha(errors)))
evidence='evidence-25433-20261026/'
census_url=add(evidence+'census-receipt.json',receipt)
marker=checked(row['marker_dropout']['proof']['path'],row['marker_dropout']['proof']['sha256']);marker_url=add(evidence+'marker-proof.json',marker)
saved=checked(R/'.claude/worktrees/v6h/data/iv6h/independent-saved-readback.json','90ced9fa545309170b5005b73cadf7255a1b629ab489ea8abecb0af6126e51f5');saved_url=add(evidence+'saved-readback.json',saved)
strict=checked(R/'.claude/worktrees/v6h/data/iv6h/independent-guard.json','4178699a457e1af4cfc1d15ab45d81273ceef5f5942f096a8d301a6fd5e51dd7');strict_doc=json.loads(strict);assert strict_doc['guard']['passed'];strict_url=add(evidence+'strict26.json',strict)
mtl=[a for a in row['assets'] if a['relative'].lower().endswith('.mtl')];assert len(mtl)==1
inspection=dict(row['inspection'],census=dict(url=census_url,sha256=sha(receipt),errors_available=True,status='MEASURED'),remaining_target_counts=remaining,
    problem_targets=dict(status='FAIL',remaining=remaining,basis='Fresh default detector; full signed validation still pending'),
    marker_dropout=dict(url=marker_url,sha256=sha(marker),passed=True,scope='Exact approved 24 box triangles only'),
    label='6F saved repair candidate: 25,433 triangles; orange boxes removed; 12,049 target instances remain; not accepted')
manifest=dict(schema_version=1,building_id='MAIN_INFRA',source_revision=REV,run_id='main-infra-clean-20261023',floor='6F',floor_id='MAIN_INFRA_6F',kind='candidate',
    display_frame=dict(up_axis='Y',units='metres',source_local=True),bounds=row['source_bounds'],obj_url=obj_url,
    mtl_url='/'+quote(PREFIX+mtl[0]['relative'].replace('\\','/'),safe='/'),assets=assets,errors_url=errors_url,inspection=inspection)
manifest_bytes=js(manifest);preview=add('preview-25433-20261026.json',manifest_bytes)
A=D/'models.tar.gz'
with tarfile.open(A,'w:gz') as tf:
    for rel,entry in files.items():
        b=(S/rel).read_bytes();assert sha(b)==entry['sha256'];info=tarfile.TarInfo(rel);info.size=len(b);info.mode=0o644;tf.addfile(info,io.BytesIO(b))
with tarfile.open(A) as tf:
    assert len(tf.getmembers())==len(files)
    for member in tf.getmembers():assert member.isfile() and sha(tf.extractfile(member).read())==files[member.name]['sha256']
result=dict(floor='6F',inspection_assets_only=True,accepted=False,stage=str(S),archive=str(A),archive_sha256=sha(A.read_bytes()),source_revision=REV,files=list(files.values()),
    evidence_refs=[marker_url,census_url,saved_url,strict_url],remaining_target_instances=remaining,
    results=dict(candidate=dict(preview=preview,preview_sha256=sha(manifest_bytes),obj_url=obj_url,obj_sha256=sha(model),triangles=25433,errors_url=errors_url,errors_sha256=sha(errors),facade_faces=raw['layer_counts']['facade'],counts=candidate['counts'])))
(D/'package.json').write_bytes(js(result));print(json.dumps(dict(package_sha256=sha(js(result)),archive_sha256=result['archive_sha256'],files=len(files),triangles=25433,remaining=remaining,accepted=False)))
