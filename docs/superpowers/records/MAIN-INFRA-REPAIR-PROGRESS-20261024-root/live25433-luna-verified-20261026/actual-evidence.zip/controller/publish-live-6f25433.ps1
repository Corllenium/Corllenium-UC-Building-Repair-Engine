$ErrorActionPreference='Stop'
$taskSite='devenvir@sv70.ifastnet.com'
$taskCommon=@('-i','C:/Users/Future26/.ssh/corllenium_siege_ed25519','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=1','-o','LogLevel=ERROR','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=deploy/known_hosts')
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskRows=@(
 @{Source="$taskRoot/data/live-6f25433/models.tar.gz";Name='main-infra-6f25433.tar.gz';Sha='425c5deb4fc77588e5722a08f825391bb883e80d393dd8ead8021c8f56af156b'},
 @{Source="$taskRoot/data/live-6f25433/package.json";Name='main-infra-6f25433.json';Sha='2d417346e5c247175dda96392a97434d20a5d2872a96a09ad2b2b23631580be6'},
 @{Source="$taskRoot/data/siege-live-20261026/publish-live-6f25433.py";Name='publish-live-6f25433.py';Sha='7c3c10547700693bd2ae9021c5f8257fbe9fea55e512df4724eb454dbb4dc57b'}
)
foreach($taskRow in $taskRows){
 if((Get-FileHash -Algorithm SHA256 -LiteralPath $taskRow.Source).Hash.ToLowerInvariant() -ne $taskRow.Sha){throw 'Publication input changed'}
 & scp -q -P 27015 @taskCommon $taskRow.Source ($taskSite+':/tmp/'+$taskRow.Name)
 if($LASTEXITCODE -ne 0){throw ('Upload failed: '+$taskRow.Name)}
}
$taskRemote='python3 -c "import hashlib,runpy; p=''/tmp/publish-live-6f25433.py''; assert hashlib.sha256(open(p,''rb'').read()).hexdigest()==''7c3c10547700693bd2ae9021c5f8257fbe9fea55e512df4724eb454dbb4dc57b''; runpy.run_path(p,run_name=''__main__'')"'
& ssh -p 27015 @taskCommon $taskSite $taskRemote | Tee-Object -FilePath "$taskRoot/data/live-6f25433/deployment.log"
if($LASTEXITCODE -ne 0){throw 'Inspection assets not verified; current live model selection stays unchanged'}
