
param([switch]$Once)
function Invoke-UcStatusPublication {
    $stage='upload'
    try {
        $output=@(& scp -q -P 27015 -i 'C:/Users/Future26/.ssh/corllenium_siege_ed25519' -o IdentitiesOnly=yes -o BatchMode=yes -o ConnectTimeout=10 -o ServerAliveInterval=5 -o ServerAliveCountMax=1 -o LogLevel=ERROR -o StrictHostKeyChecking=yes -o UserKnownHostsFile=deploy/known_hosts $taskSnapshot 'devenvir@sv70.ifastnet.com:/home/devenvir/corllenium/data/main-infra-current-codex-20261023.json' 2>&1)
        $code=$LASTEXITCODE
        if($code -ne 0){return [pscustomobject]@{Succeeded=$false;Stage=$stage;ExitCode=$code;Output=($output -join "`n")}}
        $stage='publish'
        $output=@(& ssh -p 27015 -i 'C:/Users/Future26/.ssh/corllenium_siege_ed25519' -o IdentitiesOnly=yes -o BatchMode=yes -o ConnectTimeout=10 -o ServerAliveInterval=5 -o ServerAliveCountMax=1 -o LogLevel=ERROR -o StrictHostKeyChecking=yes -o UserKnownHostsFile=deploy/known_hosts devenvir@sv70.ifastnet.com 'python3 /home/devenvir/corllenium/data/publish-workers-remote-takeover-v2.py' 2>&1)
        $code=$LASTEXITCODE
        return [pscustomobject]@{Succeeded=($code -eq 0);Stage=$stage;ExitCode=$code;Output=($output -join "`n")}
    } catch {
        return [pscustomobject]@{Succeeded=$false;Stage=$stage;ExitCode=$null;Output=$_.Exception.Message}
    }
}

$ErrorActionPreference='Stop'
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskDirectory="$taskRoot/data/siege-live-20261026/status-publisher-readonly"
$taskSnapshot="$taskDirectory/current-upload.json"
$taskMutex=[Threading.Mutex]::new($false,'Local\MAIN-INFRA-READONLY-STATUS-PUBLISHER')
if(-not $taskMutex.WaitOne(0)){throw 'Owned status publisher already running'}
try {
 do {
  $taskDocument=Get-Content -Raw -LiteralPath "$taskRoot/data/main-infra-fresh/current.json"|ConvertFrom-Json
  if($taskDocument.source_revision -ne '7b2f7451b5723f724a1e074fdedc07dbcf7291d330ae550066f4926886136511' -or $taskDocument.run_id -ne 'main-infra-clean-20261023' -or @($taskDocument.floors.PSObject.Properties.Name).Count -ne 7){throw 'Source status identity changed'}
  $taskNow=[DateTime]::UtcNow.ToString('o');$taskDocument.heartbeat_at=$taskNow;$taskDocument.updated_at=$taskNow
  [IO.File]::WriteAllText($taskSnapshot,($taskDocument|ConvertTo-Json -Depth 100),[Text.UTF8Encoding]::new($false))
  $taskPublication=Invoke-UcStatusPublication
  $taskHealth=@{at=$taskNow;pid=$PID;read_only_canonical=$true;succeeded=$taskPublication.Succeeded;stage=$taskPublication.Stage;output=$taskPublication.Output}
  [IO.File]::WriteAllText("$taskDirectory/health.json",($taskHealth|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
  Write-Output ($taskHealth|ConvertTo-Json -Depth 8 -Compress)
  if($Once){if(-not $taskPublication.Succeeded){throw 'Status upload not verified'};break}
  if((Get-Process -Id $PID).PrivateMemorySize64 -ge 250MB){throw 'Status publisher private memory cap'}
  Start-Sleep -Seconds 10
 }while($true)
}finally{$taskMutex.ReleaseMutex();$taskMutex.Dispose()}
