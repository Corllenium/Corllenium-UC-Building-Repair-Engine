param([switch]$PreviewOnly)
$ErrorActionPreference='Stop'
$taskRoot='D:/SOFTWARE/CODEX DATA/claude-mem-codex-bridge'
$taskSource=Join-Path $PSScriptRoot 'codex_memory_bridge.py'
$taskInstalled=Join-Path $taskRoot 'codex_memory_bridge.py'
$taskLauncher=Join-Path $taskRoot 'startup_bridge.ps1'
$taskLauncherSource=Join-Path $PSScriptRoot 'startup_bridge.ps1'
$taskConfigPath=Join-Path $taskRoot 'config.json'
$taskSettingsPath='C:/Users/Future26/.claude-mem/settings.json'
$taskName='Corllenium-CodexMemoryBridge-Logon'
$taskOldHash='f23210eaca467f1e45946263ab0e42be5593f63b98ca8c4e0342817cc9a5b9fb'
$taskNewHash='d68873420f064a17a7d3efc92472e33fec6905148e0e1b9fcd42f30574201616'
$taskOldLauncherHash='be797dffad28e7ceb05358e2aaa0040076970ffd5fc06232dadd41f281eb28a1'
$taskNewLauncherHash='db6e003fd572d31f69d9205fd3b4f80f07cef0a6bb1f4fffa56a50430e9cc6b9'
$taskOldConfigHash='cbcbbd712a9002402b557b64f54288bb08f11221951a75048eb6bb9fdbd3689f'
$taskPython='C:/Users/Future26/AppData/Local/Programs/Python/Python312/pythonw.exe'
$taskPowerShell='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
$taskOldPid=30928
. $taskLauncher
function Hash([string]$Path) {return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower()}
function Assert-CurrentPins {
    if ((Hash $taskInstalled) -ne $taskOldHash -or (Hash $taskLauncher) -ne $taskOldLauncherHash -or (Hash $taskConfigPath) -ne $taskOldConfigHash) {throw 'Shared_runtime_changed_hold_no_overwrite'}
}
. (Join-Path $PSScriptRoot 'native_idle_sampler.ps1')

Assert-CurrentPins
if ((Hash $taskSource) -ne $taskNewHash -or (Hash $taskLauncherSource) -ne $taskNewLauncherHash) {throw 'Tested_Luna_source_pin_mismatch'}
$taskOld=Get-BridgeStartupListener 37779 $taskInstalled
if ($taskOld.ProcessId -ne $taskOldPid -or [IO.Path]::GetFullPath($taskOld.ExecutablePath) -ne [IO.Path]::GetFullPath($taskPython)) {throw 'Expected_owned_bridge_identity_changed'}
$taskHeld=[Diagnostics.Process]::GetProcessById($taskOldPid);$taskHeldHandle=$taskHeld.Handle;$taskHeldBirth=[UcE7ExecNative]::Times($taskHeldHandle)[0]
$taskConfigText=[IO.File]::ReadAllText($taskConfigPath);$taskConfig=$taskConfigText|ConvertFrom-Json
$taskSettingsText=[IO.File]::ReadAllText($taskSettingsPath);$taskSettings=$taskSettingsText|ConvertFrom-Json
$taskSettingsHash=Hash $taskSettingsPath
if ($taskConfig.model -ne 'gpt-6.1-sol' -or $taskConfig.queue_wait_seconds -ne 90 -or $taskConfig.timeout_seconds -ne 180 -or $taskConfig.job_memory_bytes -ne 1073741824) {throw 'Foreign_runtime_contract_changed'}
if ($taskSettings.CLAUDE_MEM_PROVIDER -ne 'openrouter' -or $taskSettings.CLAUDE_MEM_OPENROUTER_MODEL -ne 'gpt-6.1-sol' -or $taskSettings.CLAUDE_MEM_OPENROUTER_BASE_URL -ne 'http://127.0.0.1:37779/v1' -or $taskSettings.CLAUDE_MEM_TIER_ROUTING_ENABLED -ne 'false') {throw 'Expected_local_fixed_route_changed'}
$taskDefinition=Get-ScheduledTask -TaskName $taskName
if ($taskDefinition.Principal.RunLevel -ne 'Limited' -or $taskDefinition.Actions[0].Arguments -notmatch $taskOldHash -or $taskDefinition.Actions[0].Arguments -notmatch $taskOldLauncherHash) {throw 'Startup_pins_or_principal_changed'}
if ($PreviewOnly) {[ordered]@{state='PREVIEW';old_pid=$taskOldPid;base=$taskOldHash;new=$taskNewHash;new_launcher=$taskNewLauncherHash;queue90_preserved=$true;handshake_preserved=$true;worker_restart=$false;model_calls=0}|ConvertTo-Json -Compress;exit 0}
$taskMarker=Join-Path $taskRoot 'LUNA-MIGRATION-IN-PROGRESS.md'
$taskMarkerText="# Luna memory migration`n`nOwner selected fixed gpt-6-luna. PREPARING: base $taskOldHash, planned $taskNewHash; launcher $taskNewLauncherHash. Existing queue90 and MEMORY_READY handshake are preserved. Only config/settings model and hash-pinned startup action change; no key/DB/plugin/MCP/worker37777 restart. Legacy6.1 request labels receive actual Luna model plus explicit migration metadata. Wait for ACTIVE readback below; do not overwrite this shared runtime during the bounded idle switch.`n"
[IO.File]::WriteAllText($taskMarker,$taskMarkerText,[Text.UTF8Encoding]::new($false))
$taskStamp=[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss');$taskBackup=Join-Path $taskRoot ('pre-luna-switch-'+$taskStamp)
New-Item -ItemType Directory -Path $taskBackup|Out-Null
foreach($taskPair in @(@($taskInstalled,'codex_memory_bridge.py'),@($taskLauncher,'startup_bridge.ps1'),@($taskConfigPath,'config.json'),@($taskSettingsPath,'settings.json'))) {Copy-Item -LiteralPath $taskPair[0] -Destination (Join-Path $taskBackup $taskPair[1])}
[IO.File]::WriteAllText((Join-Path $taskBackup 'startup-task.xml'),(Export-ScheduledTask -TaskName $taskName),[Text.UTF8Encoding]::new($false))
$taskStageSource=Join-Path $taskRoot 'codex_memory_bridge.luna-pending.py';$taskStageLauncher=Join-Path $taskRoot 'startup_bridge.luna-pending.ps1';$taskStageConfig=Join-Path $taskRoot 'config.luna-pending.json'
Copy-Item -LiteralPath $taskSource -Destination $taskStageSource;Copy-Item -LiteralPath $taskLauncherSource -Destination $taskStageLauncher
$taskConfig.model='gpt-6-luna';$taskSettings.CLAUDE_MEM_OPENROUTER_MODEL='gpt-6-luna'
[IO.File]::WriteAllText($taskStageConfig,($taskConfig|ConvertTo-Json -Depth 64),[Text.UTF8Encoding]::new($false))
$taskIdleProof=Wait-NativeBridgeIdle -RootProcessId $taskOldPid -Port 37779 -TimeoutMilliseconds 60000
$taskIdleSamples=$taskIdleProof.samples
Assert-CurrentPins
if ((Hash $taskSettingsPath) -ne $taskSettingsHash) {throw 'Shared_settings_changed_hold_no_overwrite'}
$taskSettingsStage=Join-Path (Split-Path -Parent $taskSettingsPath) ('settings.luna-pending-'+[Guid]::NewGuid().ToString('N')+'.json')
[IO.File]::WriteAllText($taskSettingsStage,($taskSettings|ConvertTo-Json -Depth 64),[Text.UTF8Encoding]::new($false))
$taskFinal=Assert-NativeBridgeIdleReady -Process $taskHeld -ExpectedBirth $taskHeldBirth -ExpectedImage $taskPython -Port 37779 -Pins @(
 @{path=$taskInstalled;sha256=$taskOldHash},@{path=$taskLauncher;sha256=$taskOldLauncherHash},@{path=$taskConfigPath;sha256=$taskOldConfigHash},@{path=$taskSettingsPath;sha256=$taskSettingsHash})
$taskHeld.Kill();if(-not $taskHeld.WaitForExit(5000)){throw 'Owned_idle_bridge_exit_unconfirmed'}
[IO.File]::Replace($taskStageSource,$taskInstalled,[NullString]::Value);[IO.File]::Replace($taskStageLauncher,$taskLauncher,[NullString]::Value)
[IO.File]::Replace($taskStageConfig,$taskConfigPath,[NullString]::Value);[IO.File]::Replace($taskSettingsStage,$taskSettingsPath,[NullString]::Value)
$taskSwitchedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
$taskArgs=($taskDefinition.Actions[0].Arguments -replace $taskOldHash,$taskNewHash) -replace $taskOldLauncherHash,$taskNewLauncherHash
$taskAction=New-ScheduledTaskAction -Execute $taskDefinition.Actions[0].Execute -Argument $taskArgs -WorkingDirectory $taskDefinition.Actions[0].WorkingDirectory
Set-ScheduledTask -TaskName $taskName -Action $taskAction|Out-Null
. $taskLauncher
$taskNew=Start-Process -FilePath $taskPython -ArgumentList @('-B',('"'+$taskInstalled+'"'),'--config',('"'+$taskConfigPath+'"')) -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskRoot 'bridge-luna.stdout.log') -RedirectStandardError (Join-Path $taskRoot 'bridge-luna.stderr.log')
$taskToken=[IO.File]::ReadAllText($taskConfig.token_file).Trim();$taskReady=$false
for($taskAttempt=0;$taskAttempt -lt 40;$taskAttempt++) {if (Test-BridgeStartupHealth 37779 $taskToken) {$taskReady=$true;break};if($taskNew.HasExited){break};Start-Sleep -Milliseconds 250}
if (-not $taskReady) {throw 'Luna_bridge_health_unconfirmed'}
$taskServer=Get-BridgeStartupListener 37779 $taskInstalled
if ($taskServer.ProcessId -ne $taskNew.Id) {throw 'Luna_listener_identity_mismatch'}
$taskHealth=Invoke-RestMethod -Uri 'http://127.0.0.1:37779/health' -Headers @{Authorization=('Bearer '+$taskToken)} -TimeoutSec 3
$taskReadSettings=Get-Content -Raw -LiteralPath $taskSettingsPath|ConvertFrom-Json
if ($taskReadSettings.CLAUDE_MEM_OPENROUTER_MODEL -ne 'gpt-6-luna' -or $taskReadSettings.CLAUDE_MEM_OPENROUTER_API_KEY -ne $taskSettings.CLAUDE_MEM_OPENROUTER_API_KEY -or (Hash $taskInstalled) -ne $taskNewHash -or (Hash $taskLauncher) -ne $taskNewLauncherHash) {throw 'Luna_readback_mismatch'}
$taskRecord=[ordered]@{pid=$taskServer.ProcessId;launcher_pid=$taskNew.Id;started_utc=$taskServer.CreationDate.ToUniversalTime().ToString('o');script=$taskInstalled;script_sha256=$taskNewHash;config=$taskConfigPath;startup='current-user-logon-limited'}
[IO.File]::WriteAllText((Join-Path $taskRoot 'bridge.pid.json'),($taskRecord|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
& $taskPowerShell -NoLogo -NoProfile -NonInteractive -File $taskLauncher -ConfigPath $taskConfigPath -PythonExe $taskPython -ExpectedBridgeHash $taskNewHash -ExpectedLauncherHash $taskNewLauncherHash -CheckOnly
if ($LASTEXITCODE -ne 0) {throw 'Luna_startup_check_failed'}
$taskReceipt=[ordered]@{state='ACTIVE';at_utc=[DateTime]::UtcNow.ToString('o');switch_epoch_ms=$taskSwitchedAt;old_pid=$taskOldPid;new_pid=$taskServer.ProcessId;base_hash=$taskOldHash;source_sha256=$taskNewHash;launcher_sha256=$taskNewLauncherHash;private_backup=$taskBackup;idle_samples=$taskIdleSamples;descendants_before_stop=$taskFinal.descendants;established_before_stop=$taskFinal.connections;settings_changed_names=@('CLAUDE_MEM_OPENROUTER_MODEL');config_changed_names=@('model');key_unchanged=$true;health=$taskHealth;queue90_preserved=$true;startup_handshake_preserved=$true;worker_restarted=$false;database_written_directly=$false;model_probe_calls=0;inherited_queue90_plus180_can_exceed_client200=$true;reboot_not_tested=$true}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'luna-switch-receipt.json'),($taskReceipt|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
[IO.File]::AppendAllText($taskMarker,("`nACTIVE "+$taskReceipt.at_utc+"; PID"+$taskServer.ProcessId+"; source"+$taskNewHash+"; startup pins"+$taskNewHash+"/"+$taskNewLauncherHash+". Settings/configmodelgpt-6-luna, private token unchanged. No worker37777 restart; real completion/persistence proof pending.`n"),[Text.UTF8Encoding]::new($false))
$taskReceipt|ConvertTo-Json -Depth 8 -Compress
