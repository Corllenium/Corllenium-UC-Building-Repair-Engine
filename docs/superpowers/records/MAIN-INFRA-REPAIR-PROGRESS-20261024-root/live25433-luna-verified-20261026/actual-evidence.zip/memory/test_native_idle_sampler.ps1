$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'native_idle_sampler.ps1')
$taskAssertions=0
function Assert-True($Value) {if(-not $Value){throw 'Native idle assertion failed'};$script:taskAssertions++}
function Assert-Throws([scriptblock]$Action) {$taskFailed=$false;try {& $Action|Out-Null}catch{$taskFailed=$true};Assert-True $taskFailed}
$taskCurrent=Get-Process -Id $PID;$taskHandle=$taskCurrent.Handle
$taskBirth=[UcE7ExecNative]::Times($taskHandle)[0];$taskImage=[UcE7ExecNative]::Image($taskHandle)
$taskStart=[Diagnostics.ProcessStartInfo]::new('C:/Users/Future26/AppData/Local/Programs/Python/Python312/python.exe','-B -c "import time; time.sleep(0.7)"')
$taskStart.UseShellExecute=$false;$taskStart.CreateNoWindow=$true
$taskChild=[Diagnostics.Process]::Start($taskStart)
try {
    $taskState=Get-NativeBridgeIdleState $PID 1
    Assert-True ($taskState.descendants -contains $taskChild.Id)
    Assert-Throws {Wait-NativeBridgeIdle $PID 1 -TimeoutMilliseconds 100}
    Assert-True (-not $taskChild.HasExited)
    Assert-True ($taskChild.WaitForExit(2000))
    $taskIdle=Wait-NativeBridgeIdle $PID 1 -TimeoutMilliseconds 2000
    Assert-True ($taskIdle.quiet_samples -ge 3 -and $taskIdle.quiet_elapsed_ms -ge 150)
    Assert-Throws {Assert-NativeBridgeIdleReady $taskCurrent ($taskBirth.AddTicks(1)) $taskImage 1 @()}
    $taskFolder=Join-Path $PSScriptRoot ('test-temp/native-idle-'+[Guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $taskFolder|Out-Null
    $taskPinFile=Join-Path $taskFolder 'config.json';[IO.File]::WriteAllText($taskPinFile,'synthetic-a')
    $taskPins=@([pscustomobject]@{path=$taskPinFile;sha256=(Get-FileHash -LiteralPath $taskPinFile -Algorithm SHA256).Hash})
    Assert-NativeBridgeIdleReady $taskCurrent $taskBirth $taskImage 1 $taskPins|Out-Null
    $taskAssertions++
    [IO.File]::WriteAllText($taskPinFile,'synthetic-b')
    Assert-Throws {Assert-NativeBridgeIdleReady $taskCurrent $taskBirth $taskImage 1 $taskPins}
    $taskListener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$taskListener.Start();$taskPort=$taskListener.LocalEndpoint.Port
    $taskClient=[Net.Sockets.TcpClient]::new();$taskClient.Connect('127.0.0.1',$taskPort);$taskAccepted=$taskListener.AcceptTcpClient()
    try {
        Assert-True ((Get-NativeBridgeIdleState $PID $taskPort).connections -gt 0)
        Assert-Throws {Assert-NativeBridgeIdleReady $taskCurrent $taskBirth $taskImage $taskPort @()}
    } finally {$taskClient.Close();$taskAccepted.Close();$taskListener.Stop()}
    $taskIdle=Wait-NativeBridgeIdle $PID $taskPort -TimeoutMilliseconds 3000
    Assert-True ($taskIdle.quiet_elapsed_ms -ge 150 -and $taskIdle.final_state.connections -eq 0)
    [ordered]@{status='PASS';assertions=$taskAssertions;qualified_v5='f158802651c955b6b322140ff9567496c527cd1bac0e63598171c45eeea60e12';native_child_exited_naturally=$true;live_tcp_blocked=$true;closed_tcp_idle=$true;identity_and_foreign_config_change_refused=$true;inference_calls=0;live_bridge_or_worker_stopped=$false}|ConvertTo-Json -Compress
} finally {
    if(-not $taskChild.HasExited){$taskChild.Kill();$taskChild.WaitForExit()}
    $taskChild.Dispose();$taskCurrent.Dispose()
}
