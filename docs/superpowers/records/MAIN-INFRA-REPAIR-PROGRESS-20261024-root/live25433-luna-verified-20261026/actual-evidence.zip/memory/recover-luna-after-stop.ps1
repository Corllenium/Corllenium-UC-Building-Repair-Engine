$ErrorActionPreference='Stop'
$taskRoot='D:/SOFTWARE/CODEX DATA/claude-mem-codex-bridge'
$taskSource=Join-Path $PSScriptRoot 'codex_memory_bridge.py'
$taskInstalled=Join-Path $taskRoot 'codex_memory_bridge.py'
$taskLauncher=Join-Path $taskRoot 'startup_bridge.ps1'
$taskLauncherSource=Join-Path $PSScriptRoot 'startup_bridge.ps1'
$taskConfigPath=Join-Path $taskRoot 'config.json'
$taskSettingsPath='C:/Users/Future26/.claude-mem/settings.json'
$taskName='Corllenium-CodexMemoryBridge-Logon'
$taskOldHash='f23210eaca467f1e45946263ab0e42be5593f63b98ca8c4e0342817cc9a5b9fb'
$taskNewHash='d68873420f064a17a7d3efc92472e33fec6905148e0e1b9fcd42f30574201616'
$taskOldLauncherHash='be797dffad28e7ceb05358e2aaa0040076970ffd5fc06232dadd41f281eb28a1'
$taskNewLauncherHash='db6e003fd572d31f69d9205fd3b4f80f07cef0a6bb1f4fffa56a50430e9cc6b9'
$taskOldConfigHash='cbcbbd712a9002402b557b64f54288bb08f11221951a75048eb6bb9fdbd3689f'
$taskPython='C:/Users/Future26/AppData/Local/Programs/Python/Python312/pythonw.exe'
$taskPowerShell='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
$taskOldPid=30928

if(Get-Process -Id $taskOldPid -ErrorAction SilentlyContinue){throw 'Old bridge unexpectedly alive; recovery held'}
if(Get-NetTCPConnection -State Listen -LocalPort 37779 -ErrorAction SilentlyContinue){throw 'Another bridge owns the port; recovery held'}
$taskDefinition=Get-ScheduledTask -TaskName $taskName
if($taskDefinition.Principal.RunLevel -ne 'Limited' -or $taskDefinition.Actions[0].Arguments -notmatch $taskOldHash -or $taskDefinition.Actions[0].Arguments -notmatch $taskOldLauncherHash){throw 'Startup ownership changed'}
& 'D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine/.venv/Scripts/python.exe' -B (Join-Path $PSScriptRoot 'recover-luna-staged-files.py')
if($LASTEXITCODE -ne 0){throw 'Staged recovery verification failed'}
$taskConfig=Get-Content -LiteralPath $taskConfigPath -Raw|ConvertFrom-Json
$taskSettings=Get-Content -LiteralPath $taskSettingsPath -Raw|ConvertFrom-Json
$taskMarker=Join-Path $taskRoot 'LUNA-MIGRATION-IN-PROGRESS.md'
$taskBackup=(Get-ChildItem -LiteralPath $taskRoot -Directory -Filter 'pre-luna-switch-*'|Sort-Object LastWriteTimeUtc -Descending|Select-Object -First 1).FullName
$taskIdleSamples='Native final150ms quiet assertion passed before replacement-error stop'
$taskFinal=[pscustomobject]@{descendants=@();connections=0}
function Hash([string]$Path){return(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
$taskSwitchedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
$taskArgs=($taskDefinition.Actions[0].Arguments -replace $taskOldHash,$taskNewHash) -replace $taskOldLauncherHash,$taskNewLauncherHash
$taskAction=New-ScheduledTaskAction -Execute $taskDefinition.Actions[0].Execute -Argument $taskArgs -WorkingDirectory $taskDefinition.Actions[0].WorkingDirectory
Set-ScheduledTask -TaskName $taskName -Action $taskAction|Out-Null
. $taskLauncher
$taskNew=Start-Process -FilePath $taskPython -ArgumentList @('-B',('"'+$taskInstalled+'"'),'--config',('"'+$taskConfigPath+'"')) -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskRoot 'bridge-luna.stdout.log') -RedirectStandardError (Join-Path $taskRoot 'bridge-luna.stderr.log')
$taskToken=[IO.File]::ReadAllText($taskConfig.token_file).Trim();$taskReady=$false
for($taskAttempt=0;$taskAttempt -lt 40;$taskAttempt++) {if (Test-BridgeStartupHealth 37779 $taskToken) {$taskReady=$true;break};if($taskNew.HasExited){break};Start-Sleep -Milliseconds 250}
if (-not $taskReady) {throw 'Luna_bridge_health_unconfirmed'}
$taskServer=Get-BridgeStartupListener 37779 $taskInstalled
if ($taskServer.ProcessId -ne $taskNew.Id) {throw 'Luna_listener_identity_mismatch'}
$taskHealth=Invoke-RestMethod -Uri 'http://127.0.0.1:37779/health' -Headers @{Authorization=('Bearer '+$taskToken)} -TimeoutSec 3
$taskReadSettings=Get-Content -Raw -LiteralPath $taskSettingsPath|ConvertFrom-Json
if ($taskReadSettings.CLAUDE_MEM_OPENROUTER_MODEL -ne 'gpt-6-luna' -or $taskReadSettings.CLAUDE_MEM_OPENROUTER_API_KEY -ne $taskSettings.CLAUDE_MEM_OPENROUTER_API_KEY -or (Hash $taskInstalled) -ne $taskNewHash -or (Hash $taskLauncher) -ne $taskNewLauncherHash) {throw 'Luna_readback_mismatch'}
$taskRecord=[ordered]@{pid=$taskServer.ProcessId;launcher_pid=$taskNew.Id;started_utc=$taskServer.CreationDate.ToUniversalTime().ToString('o');script=$taskInstalled;script_sha256=$taskNewHash;config=$taskConfigPath;startup='current-user-logon-limited'}
[IO.File]::WriteAllText((Join-Path $taskRoot 'bridge.pid.json'),($taskRecord|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
& $taskPowerShell -NoLogo -NoProfile -NonInteractive -File $taskLauncher -ConfigPath $taskConfigPath -PythonExe $taskPython -ExpectedBridgeHash $taskNewHash -ExpectedLauncherHash $taskNewLauncherHash -CheckOnly
if ($LASTEXITCODE -ne 0) {throw 'Luna_startup_check_failed'}
$taskReceipt=[ordered]@{state='ACTIVE';at_utc=[DateTime]::UtcNow.ToString('o');switch_epoch_ms=$taskSwitchedAt;old_pid=$taskOldPid;new_pid=$taskServer.ProcessId;base_hash=$taskOldHash;source_sha256=$taskNewHash;launcher_sha256=$taskNewLauncherHash;private_backup=$taskBackup;idle_samples=$taskIdleSamples;descendants_before_stop=$taskFinal.descendants;established_before_stop=$taskFinal.connections;settings_changed_names=@('CLAUDE_MEM_OPENROUTER_MODEL');config_changed_names=@('model');key_unchanged=$true;health=$taskHealth;queue90_preserved=$true;startup_handshake_preserved=$true;worker_restarted=$false;database_written_directly=$false;model_probe_calls=0;inherited_queue90_plus180_can_exceed_client200=$true;reboot_not_tested=$true}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'luna-switch-receipt.json'),($taskReceipt|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
[IO.File]::AppendAllText($taskMarker,("`nACTIVE "+$taskReceipt.at_utc+"; PID"+$taskServer.ProcessId+"; source"+$taskNewHash+"; startup pins"+$taskNewHash+"/"+$taskNewLauncherHash+". Settings/configmodelgpt-6-luna, private token unchanged. No worker37777 restart; real completion/persistence proof pending.`n"),[Text.UTF8Encoding]::new($false))
$taskReceipt|ConvertTo-Json -Depth 8 -Compress
