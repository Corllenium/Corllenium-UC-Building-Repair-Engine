# Claude-mem through Codex: GPT-6-Luna

The owner selected GPT-6-Luna in this chat. The shared adapter is now fixed to `gpt-6-luna`, using the existing Codex login. No Gemini fallback is enabled and no API key was copied or printed.

Installed bridge: `D:/SOFTWARE/CODEX DATA/claude-mem-codex-bridge/codex_memory_bridge.py`, SHA `d68873420f064a17a7d3efc92472e33fec6905148e0e1b9fcd42f30574201616`, PID52060. Startup launcher SHA `db6e003fd572d31f69d9205fd3b4f80f07cef0a6bb1f4fffa56a50430e9cc6b9`. The existing current-user Limited logon task pins both hashes. Config `model` and Claude-mem `CLAUDE_MEM_OPENROUTER_MODEL` are Luna. The generic compatible-provider name remains `openrouter`, but its URL points only to the authenticated loopback adapter at127.0.0.1:37779/v1.

The other active chat's queue90 and MEMORY_READY startup handshake were preserved. One inference, at most4pending requests, native1GiB/180s and3.5GiB admission remain. The inherited queue90+180 worst case can exceed an older client's200s deadline; sustained overload is not claimed solved. Reboot/logon itself was not tested.

Existing sessions that captured a6.1 request label remain compatible: only that legacy label and Luna are admitted; the CLI always requests Luna and the response reports Luna plus explicit migration metadata. Extracted real legacy parser and persistence handlers were tested, so memory metadata records the actual returned model rather than the stale session label. Unknown model labels are rejected.

Evidence:

-31 bridge tests,12 startup assertions,2 actual legacy-parser/persistence assertions and11 native-idle assertions passed before installation.
- `luna-real-completion-receipt.json`: actual compatible legacy-label request succeeded in4.9s, exact synthetic reply and response model `gpt-6-luna`.
- `luna-worker-persistence-receipt.json`: normal session-init/tool-observation capture succeeded; saved synthetic observation34055 has `generated_by_model=gpt-6-luna`. Only isolated synthetic metadata was read; no direct database writes.
- `luna-switch-receipt.json`: adapter healthy, model Luna, private token unchanged, no memory-worker37777/plugin/MCP/DB/repair restart.

A .NET null backup-path binding error stopped the already-idle old adapter before its first replacement. The tested staged files were then authenticated against unchanged originals and installed with `os.replace`; the owned adapter was restarted and checked successfully. Private backups remain outside Git. Do not rerun old switch scripts against the new runtime.

The owner explicitly authorized coordination with `Configure Taxumo reverse engineering`. That chat was asked to pause shared-adapter writes briefly and then received the verified completion. Its unrelated work may resume. Preserve Luna as the latest selected memory model.
