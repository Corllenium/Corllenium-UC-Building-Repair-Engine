$taskQualifiedV5='D:/LLM_BACKUP/Codex session/main-infra-resource-monitor-v5-20261024/05-Corllenium-UC-Building-Repair-Engine/docs/superpowers/records/MAIN-INFRA-RESOURCE-MONITOR-V5-20261024/execute-resource-guard-v5.ps1'
$taskQualifiedHash='f158802651c955b6b322140ff9567496c527cd1bac0e63598171c45eeea60e12'
if((Get-FileHash -LiteralPath $taskQualifiedV5 -Algorithm SHA256).Hash -ne $taskQualifiedHash){throw 'Qualified_native_source_changed'}
if(-not('UcE7ExecNative' -as [type])){. $taskQualifiedV5 -FunctionsOnly}

function Get-NativeBridgeIdleState([int]$RootProcessId,[int]$Port) {
    $taskRows=@([UcE7ExecNative]::Processes())
    $taskIds=[Collections.Generic.HashSet[int]]::new();$taskIds.Add($RootProcessId)|Out-Null
    do {
        $taskChanged=$false
        foreach($taskRow in $taskRows) {
            if($taskIds.Contains($taskRow.Parent) -and $taskIds.Add($taskRow.Pid)){$taskChanged=$true}
        }
    }while($taskChanged)
    $taskTcp=@([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpConnections()|Where-Object {
        $_.LocalEndPoint.Port -eq $Port -and $_.State -notin @([Net.NetworkInformation.TcpState]::Listen,[Net.NetworkInformation.TcpState]::TimeWait,[Net.NetworkInformation.TcpState]::Closed)
    })
    return [pscustomobject]@{descendants=@($taskIds|Where-Object {$_ -ne $RootProcessId}|Sort-Object);connections=$taskTcp.Count}
}

function Wait-NativeBridgeIdle {
    param([int]$RootProcessId,[int]$Port,[ValidateRange(50,120000)][int]$TimeoutMilliseconds=60000,
        [ValidateRange(150,1000)][int]$QuietMilliseconds=150,[ValidateRange(10,100)][int]$SampleMilliseconds=50)
    $taskWatch=[Diagnostics.Stopwatch]::StartNew();$taskQuietAt=$null;$taskQuietSamples=0;$taskSamples=0
    while($taskWatch.ElapsedMilliseconds -lt $TimeoutMilliseconds) {
        $taskState=Get-NativeBridgeIdleState $RootProcessId $Port;$taskSamples++
        if($taskState.descendants.Count -eq 0 -and $taskState.connections -eq 0) {
            if($null -eq $taskQuietAt){$taskQuietAt=$taskWatch.ElapsedMilliseconds}
            $taskQuietSamples++;$taskQuietElapsed=$taskWatch.ElapsedMilliseconds-$taskQuietAt
            if($taskQuietSamples -ge 3 -and $taskQuietElapsed -ge $QuietMilliseconds) {
                return [pscustomobject]@{samples=$taskSamples;quiet_samples=$taskQuietSamples;quiet_elapsed_ms=$taskQuietElapsed;final_state=$taskState}
            }
        }else{$taskQuietAt=$null;$taskQuietSamples=0}
        Start-Sleep -Milliseconds $SampleMilliseconds
    }
    throw 'Native_idle_window_not_reached'
}

function Assert-NativeBridgeIdleReady {
    param([Diagnostics.Process]$Process,[DateTime]$ExpectedBirth,[string]$ExpectedImage,[int]$Port,[array]$Pins)
    $taskHandle=$Process.Handle
    if(-not[UcE7ExecNative]::Alive($taskHandle) -or [UcE7ExecNative]::Times($taskHandle)[0].Ticks -ne $ExpectedBirth.Ticks){throw 'Held_process_lifetime_changed'}
    if(-not[string]::Equals([IO.Path]::GetFullPath([UcE7ExecNative]::Image($taskHandle)),[IO.Path]::GetFullPath($ExpectedImage),[StringComparison]::OrdinalIgnoreCase)){throw 'Held_process_image_changed'}
    foreach($taskPin in $Pins){if((Get-FileHash -LiteralPath $taskPin.path -Algorithm SHA256).Hash -ne $taskPin.sha256){throw 'Foreign_runtime_pin_changed'}}
    $taskState=Get-NativeBridgeIdleState $Process.Id $Port
    if($taskState.descendants.Count -or $taskState.connections){throw 'New_inflight_work_detected'}
    return $taskState
}
