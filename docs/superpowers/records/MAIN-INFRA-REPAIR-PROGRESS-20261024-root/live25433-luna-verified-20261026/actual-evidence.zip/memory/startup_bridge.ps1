param([string]$ConfigPath,[string]$PythonExe,[string]$ExpectedBridgeHash,[string]$ExpectedLauncherHash,[switch]$CheckOnly)
$ErrorActionPreference='Stop'

function Get-BridgeStartupDecision($ActualBridgeHash,$RequiredBridgeHash,$ActualLauncherHash,$RequiredLauncherHash,[bool]$Healthy,[bool]$PortOccupied) {
    foreach($taskHash in @($ActualBridgeHash,$RequiredBridgeHash,$ActualLauncherHash,$RequiredLauncherHash)) {
        if ([string]$taskHash -notmatch '^[0-9a-fA-F]{64}$') {throw 'invalid_integrity_hash'}
    }
    if ($ActualBridgeHash -ne $RequiredBridgeHash -or $ActualLauncherHash -ne $RequiredLauncherHash) {throw 'source_hash_mismatch'}
    if ($Healthy) {return 'reuse'}
    if ($PortOccupied) {throw 'occupied_port_unhealthy'}
    return 'start'
}

function Enter-BridgeStartupMutex([string]$Name) {
    $taskCreated=$false
    $taskMutex=[Threading.Mutex]::new($true,$Name,[ref]$taskCreated)
    return [pscustomobject]@{Mutex=$taskMutex;Acquired=$taskCreated}
}

function Exit-BridgeStartupMutex($Handle) {
    if ($null -eq $Handle) {return}
    if ($Handle.Acquired) {$Handle.Mutex.ReleaseMutex()}
    $Handle.Mutex.Dispose()
}

function Test-BridgeStartupHealth([int]$Port,[string]$Token) {
    try {
        $taskHealth=Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Headers @{Authorization=('Bearer '+$Token)} -TimeoutSec 2
        return $taskHealth.status -eq 'ok' -and $taskHealth.model -eq 'gpt-6-luna' -and $taskHealth.backend -eq 'ephemeral-codex-cli'
    } catch {return $false}
}

function Get-BridgeStartupListener([int]$Port,[string]$BridgePath) {
    $taskListeners=@(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue)
    if ($taskListeners.Count -ne 1 -or $taskListeners[0].LocalAddress -ne '127.0.0.1') {throw 'listener_identity_mismatch'}
    $taskProcess=Get-CimInstance Win32_Process -Filter ('ProcessId='+$taskListeners[0].OwningProcess)
    $taskMatch=[regex]::Match($taskProcess.CommandLine,'"([^"]*codex_memory_bridge\.py)"|(\S*codex_memory_bridge\.py)')
    if ([IO.Path]::GetFullPath($taskMatch.Groups[1].Value+$taskMatch.Groups[2].Value) -ne [IO.Path]::GetFullPath($BridgePath)) {throw 'listener_identity_mismatch'}
    return $taskProcess
}

function Write-BridgeStartupEvent([string]$Root,[string]$Status,$ServerId) {
    $taskEvent=[ordered]@{timestamp_utc=[DateTime]::UtcNow.ToString('o');status=$Status;server_pid=$ServerId;check_only=[bool]$CheckOnly}
    [IO.File]::AppendAllText((Join-Path $Root 'startup-events.jsonl'),(($taskEvent|ConvertTo-Json -Compress)+[Environment]::NewLine),[Text.UTF8Encoding]::new($false))
}

function Invoke-BridgeLogonStartup {
    $taskLock=$null
    $taskRoot=Split-Path -Parent ([IO.Path]::GetFullPath($ConfigPath))
    try {
        $taskConfig=Get-Content -Raw -LiteralPath $ConfigPath|ConvertFrom-Json
        if ($taskConfig.model -ne 'gpt-6-luna' -or $taskConfig.port -lt 1 -or $taskConfig.port -gt 65535) {throw 'invalid_fixed_route_config'}
        $taskBridge=Join-Path $taskRoot 'codex_memory_bridge.py'
        $taskActualBridge=(Get-FileHash -LiteralPath $taskBridge -Algorithm SHA256).Hash
        $taskActualLauncher=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash
        Get-BridgeStartupDecision $taskActualBridge $ExpectedBridgeHash $taskActualLauncher $ExpectedLauncherHash $false $false|Out-Null
        $taskRootPrefix=[IO.Path]::GetFullPath($taskRoot).TrimEnd('\')+'\'
        $taskTokenPath=[IO.Path]::GetFullPath($taskConfig.token_file)
        if (-not $taskTokenPath.StartsWith($taskRootPrefix,[StringComparison]::OrdinalIgnoreCase)) {throw 'unsafe_token_file_path'}
        $taskLock=Enter-BridgeStartupMutex ('Local\CorlleniumCodexMemoryBridge-'+$ExpectedBridgeHash.Substring(0,16))
        if (-not $taskLock.Acquired) {Write-BridgeStartupEvent $taskRoot 'another_launcher_active' $null;return 0}
        $taskToken=[IO.File]::ReadAllText($taskTokenPath).Trim()
        if (-not $taskToken) {throw 'missing_private_token'}
        $taskHealthy=Test-BridgeStartupHealth $taskConfig.port $taskToken
        $taskOccupied=@(Get-NetTCPConnection -State Listen -LocalPort $taskConfig.port -ErrorAction SilentlyContinue).Count -gt 0
        $taskDecision=Get-BridgeStartupDecision $taskActualBridge $ExpectedBridgeHash $taskActualLauncher $ExpectedLauncherHash $taskHealthy $taskOccupied
        if ($taskDecision -eq 'reuse') {
            $taskServer=Get-BridgeStartupListener $taskConfig.port $taskBridge
            Write-BridgeStartupEvent $taskRoot 'already_running' $taskServer.ProcessId
            return 0
        }
        if ($CheckOnly) {Write-BridgeStartupEvent $taskRoot 'check_only_not_running' $null;return 3}
        if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) {throw 'python_runtime_missing'}
        $taskProcess=Start-Process -FilePath $PythonExe -ArgumentList @('-B',('"'+$taskBridge+'"'),'--config',('"'+$ConfigPath+'"')) -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskRoot 'bridge-startup.stdout.log') -RedirectStandardError (Join-Path $taskRoot 'bridge-startup.stderr.log')
        $taskReady=$false
        for ($taskAttempt=0;$taskAttempt -lt 30;$taskAttempt++) {
            if (Test-BridgeStartupHealth $taskConfig.port $taskToken) {$taskReady=$true;break}
            if ($taskProcess.HasExited) {break}
            Start-Sleep -Milliseconds 250
        }
        if (-not $taskReady) {throw 'started_bridge_not_healthy'}
        $taskServer=Get-BridgeStartupListener $taskConfig.port $taskBridge
        if ($taskServer.ProcessId -ne $taskProcess.Id -and $taskServer.ParentProcessId -ne $taskProcess.Id) {throw 'listener_identity_mismatch'}
        $taskRecord=[ordered]@{pid=$taskServer.ProcessId;launcher_pid=$taskProcess.Id;started_utc=$taskServer.CreationDate.ToUniversalTime().ToString('o');script=$taskBridge;script_sha256=$taskActualBridge;config=$ConfigPath;startup='current-user-logon-limited'}
        [IO.File]::WriteAllText((Join-Path $taskRoot 'bridge.pid.json'),($taskRecord|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
        Write-BridgeStartupEvent $taskRoot 'started' $taskServer.ProcessId
        Wait-Process -Id $taskProcess.Id -ErrorAction SilentlyContinue
        return 0
    } catch {
        $taskKnown=@('invalid_integrity_hash','source_hash_mismatch','occupied_port_unhealthy','listener_identity_mismatch','invalid_fixed_route_config','unsafe_token_file_path','missing_private_token','python_runtime_missing','started_bridge_not_healthy')
        $taskReason=if ($_.Exception.Message -in $taskKnown) {$_.Exception.Message} else {'startup_failed'}
        try {Write-BridgeStartupEvent $taskRoot $taskReason $null} catch {}
        return 1
    } finally {Exit-BridgeStartupMutex $taskLock}
}

if ($MyInvocation.InvocationName -ne '.') {exit (Invoke-BridgeLogonStartup)}
