
from pathlib import Path
import json,hashlib,os
r=Path('D:/SOFTWARE/CODEX DATA/claude-mem-codex-bridge');settings=Path('C:/Users/Future26/.claude-mem/settings.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(r/'codex_memory_bridge.py')=='f23210eaca467f1e45946263ab0e42be5593f63b98ca8c4e0342817cc9a5b9fb'
assert sha(r/'startup_bridge.ps1')=='be797dffad28e7ceb05358e2aaa0040076970ffd5fc06232dadd41f281eb28a1'
assert sha(r/'config.json')=='cbcbbd712a9002402b557b64f54288bb08f11221951a75048eb6bb9fdbd3689f'
assert sha(r/'codex_memory_bridge.luna-pending.py')=='d68873420f064a17a7d3efc92472e33fec6905148e0e1b9fcd42f30574201616'
assert sha(r/'startup_bridge.luna-pending.ps1')=='db6e003fd572d31f69d9205fd3b4f80f07cef0a6bb1f4fffa56a50430e9cc6b9'
a=json.loads((r/'config.json').read_text());b=json.loads((r/'config.luna-pending.json').read_text());assert b==dict(a,model='gpt-6-luna')
a=json.loads(settings.read_text());choices=[]
for q in settings.parent.glob('settings.luna-pending-*.json'):
 b=json.loads(q.read_text())
 if b==dict(a,CLAUDE_MEM_OPENROUTER_MODEL='gpt-6-luna'):choices.append(q)
assert len(choices)==1
for stage,target in [(r/'codex_memory_bridge.luna-pending.py',r/'codex_memory_bridge.py'),(r/'startup_bridge.luna-pending.ps1',r/'startup_bridge.ps1'),(r/'config.luna-pending.json',r/'config.json'),(choices[0],settings)]:os.replace(stage,target)
print('Verified four staged replacements; only model settings changed')
