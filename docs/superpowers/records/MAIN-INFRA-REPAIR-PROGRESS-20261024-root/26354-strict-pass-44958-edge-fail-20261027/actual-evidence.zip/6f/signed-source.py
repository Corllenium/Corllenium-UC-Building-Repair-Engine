"""Full signed current26354 validation with unchanged paid settings and CBR scope."""
import argparse
import json
from pathlib import Path
from tools import main_infra_6f_26127_signed as paid
from tools import main_infra_6f26354_independent as base
from tools import main_infra_6f26354_native as native

ROOT=base.ROOT
need,read,sha=base.need,base.read,base.sha
GRANT=paid.GRANT
PAID_SETTINGS=paid.PAID_SETTINGS
grant_boundary,target_boundary,settings=paid.grant_boundary,paid.target_boundary,paid.settings


def native_boundary(doc,source,reference):
    need(doc['job_id']==base.JOB and doc['floor']=='6F' and doc['passed'] is True
         and doc['source_control_passed'] is True and doc['qualified']==dict(views=33,different_pixels=0)
         and doc['diagnostic']['views']==13 and doc['candidate_source_sha256']==source
         and doc['reference_source_sha256']==reference and doc['marker_selection_sha256']==base.ancestor.AUTH
         and doc['acceptance'] is False,'Actual scoped current26354 native PASS required')
    return True


def load(path,expected):
    need(sha(path)==expected,'Fullsigned invocation differs');s=read(path)
    need(s['job_id']==base.JOB and s['acceptance'] is False and Path(s['out']).resolve()==ROOT/'data/iv6j/fullsigned','Owned current26354 fullsigned namespace required')
    p=s['pins']
    for pin in p.values():need(sha(pin['path'])==pin['sha256'],'Fullsigned input changed: '+pin['path'])
    for key,digest in (('grant',GRANT),('paid_settings',PAID_SETTINGS),('guard',native.STRICT),('readback',native.READBACK)):
        need(p[key]['sha256']==digest,'Actual independent prerequisite differs: '+key)
    need(Path(p['paid_settings']['path']).resolve()==ROOT/'tools/main_infra_7f_validation.py'
         and Path(p['executing_targets']['path']).resolve()==ROOT/'engine/validate/targets.json','Executing default context differs')
    invocation=p['invocation'];model,scope=base.context(invocation['path'],invocation['sha256']);refs=model['refs']
    model.update(_path=invocation['path'],_sha256=invocation['sha256'])
    native.strict_prerequisite(read(p['guard']['path']),model,read(p['readback']['path']))
    report=read(p['native']['path']);native_boundary(report,refs['source']['sha256'],refs['reference_source']['sha256'])
    directory=Path(p['native']['path']).parent;files=report['files']
    need(len(files)==len({row['path'] for row in files})==290,'Complete actual saved native cohort required')
    for row in files:
        f=(directory/row['path']).resolve()
        need(f.is_relative_to(directory.resolve()) and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],'Saved current native evidence changed')
    grant_boundary(read(p['grant']['path']))
    targets=target_boundary(Path(p['authoritative_targets']['path']).read_bytes(),Path(p['executing_targets']['path']).read_bytes())
    return s,model,scope,targets


def run(path,expected):
    s,model,scope,targets=load(path,expected);out=Path(s['out']);need(not out.exists(),'Exclusive fullsigned output required')
    from engine.io.mtl import parse_mtl
    from engine.validate.checks import default_targets_path,load_looks,load_targets,validate
    from engine.validate.evidence import write_evidence
    source,frame,original,before,after,provenance=base.load_pair(model,scope)
    refs=model['refs'];need((before.n_faces,after.n_faces)==(34838,26354),'Actual current26354 owner-reference/candidate counts differ')
    sources=[]
    for mesh,role in ((original,'original_engine'),(after,'engine')):
        directory=Path(refs[role]['path']).parent;sources.append((parse_mtl(directory/mesh.mtllib),directory))
    looks=load_looks(s['pins']['materials']['path'],sources)
    need(default_targets_path().resolve()==Path(s['pins']['executing_targets']['path']).resolve(),'Validator default targets path differs')
    shown=[-1]
    def progress(done,total):
        tenth=int(10*done/max(total,1))
        if tenth!=shown[0]:shown[0]=tenth;print(json.dumps(dict(samples_done=done,samples_total=total)),flush=True)
    result=validate(before,after,looks,targets=load_targets(),settings=settings(),progress=progress)
    out.mkdir();write_evidence(result,out);report=result.report
    load(path,expected)
    report['inputs']=dict(before=refs['reference_engine']['path'],after=refs['engine']['path'],
        before_sha256=refs['reference_engine']['sha256'],after_sha256=refs['engine']['sha256'],
        materials=s['pins']['materials']['path'],targets=str(default_targets_path()),source_context=refs,prerequisites=s['pins'],
        target_checkout=targets,marker_selection_sha256=base.ancestor.AUTH,raw_physical_quanta=list(original.physical_quanta),
        source_to_engine=provenance['source_to_engine'],invocation_sha256=expected)
    def write(p,value):
        with p.open('x',encoding='utf8') as stream:json.dump(value,stream,indent=2,allow_nan=False)
    write(out/'validation.json',report);checks=report['checks']
    preservation=checks['textures']['status']=='PASS' and checks['nothing_deleted']['status']=='PASS'
    files=[dict(path=str(p.relative_to(out)),sha256=sha(p),bytes=p.stat().st_size) for p in sorted(out.rglob('*')) if p.is_file()]
    review=dict(job_id=base.JOB,floor='6F',validator_passed=result.passed,preservation_passed=preservation,
        strict_guard_passed=True,native_preservation_passed=True,protected_original_count=4284,
        forced_floor_preservation_passed=checks['nothing_deleted']['floor']['status']=='PASS',
        verdict=report['verdict'],checks=checks,files=files,validation_json_sha256=sha(out/'validation.json'),
        candidate_source_sha256=refs['source']['sha256'],candidate_engine_sha256=refs['engine']['sha256'],
        marker_selection_sha256=base.ancestor.AUTH,invocation_sha256=expected,floor_accepted=False,acceptance=False)
    write(out/'independent-review.json',review)
    print(json.dumps(dict(verdict=report['verdict'],preservation_passed=preservation,
        validation_sha256=review['validation_json_sha256'],review_sha256=sha(out/'independent-review.json'),acceptance=False)),flush=True)
    return 0 if result.passed else 2

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('phase',choices=('metadata','run'))
    p.add_argument('--spec',type=Path,required=True);p.add_argument('--spec-sha256',required=True);a=p.parse_args()
    if a.phase=='run':return run(a.spec,a.spec_sha256)
    s,model,scope,targets=load(a.spec,a.spec_sha256)
    print(json.dumps(dict(geometry_loaded=False,reference_triangles=34838,candidate_triangles=26354,protected_originals=4284,
        targets=targets,allowed_changes=[grant_boundary(read(s['pins']['grant']['path']))],acceptance=False)));return 0


if __name__=='__main__':raise SystemExit(main())
