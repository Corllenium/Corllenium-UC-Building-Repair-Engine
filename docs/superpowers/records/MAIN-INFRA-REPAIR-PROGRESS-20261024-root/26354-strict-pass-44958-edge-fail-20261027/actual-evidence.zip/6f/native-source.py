"""Current26354 prerequisite boundary around the unchanged paid native renderer."""
from pathlib import Path
from tools import main_infra_6f_25433_native as paid
from tools import main_infra_6f26354_independent as base

ROOT = base.ROOT
need, read, sha = base.need, base.read, base.sha
STRICT = '84186c2aa8303c1a96a0248be043a4b9ac9d9b479023290b7af395ac2a42dfd2'
READBACK = '0e3b4d7794ef5d4299c4f28b629ee43ebd7e053574558624c4f89b0e1c1d28e9'


def strict_prerequisite(guard, model, saved):
    refs = model['refs']; scope = guard['scope']
    need(guard['guard']['passed'] is True and guard['candidate_source_sha256'] == refs['source']['sha256'] == base.SOURCE
        and guard['candidate_engine_sha256'] == refs['engine']['sha256'] == base.ENGINE
        and guard['reference_engine_sha256'] == refs['reference_engine']['sha256']
        and (scope['candidate_triangles'], scope['reference_triangles'], scope['protected_original_count']) == (26354, 34838, 4284)
        and saved['whole_originals_verified'] == 4284 and saved['assets_verified'] == 12
        and saved['actual_output_triangles'] == 26354 and saved['candidate_source_sha256'] == base.SOURCE
        and saved['candidate_engine_sha256'] == base.ENGINE and saved['acceptance'] is False,
        'Actual current26354 strict/readback prerequisites required')
    return True


def load(path, expected):
    need(sha(path) == expected, 'Native invocation differs'); spec = read(path)
    need(spec['job_id'] == base.JOB and spec['acceptance'] is False
        and Path(spec['out']).resolve() == ROOT/'data/iv6j/native', 'Owned current26354 native namespace required')
    pins = spec['pins']
    for pin in pins.values():
        need(sha(pin['path']) == pin['sha256'], 'Native pin changed: ' + pin['path'])
    invocation = pins['invocation']; model, scope = base.context(invocation['path'], invocation['sha256'])
    need(pins['guard']['sha256'] == STRICT and pins['saved_readback']['sha256'] == READBACK, 'Actual current26354 independent prerequisites differ')
    strict_prerequisite(read(pins['guard']['path']), model, read(pins['saved_readback']['path']))
    need(pins['renderer']['sha256'] == '065989bc85dfc713ce74ed766428b4a1c23789209796d5913e59224c9d6a7472'
        and pins['png_reader']['sha256'] == 'fca870ab6a51c2c5d15a4ae23a7214972b723a844566acc8c66fec2480296676', 'Exact paid native renderer/PNG reader required')
    planned, qualified = paid.poses(read(pins['outside']['path']), read(pins['walks']['path'])['poses'], read(pins['camera']['path']))
    return spec, model, planned, qualified


def main():
    base.AUTH = base.ancestor.AUTH
    paid.base, paid.ROOT, paid.load = base, ROOT, load
    return paid.main()


if __name__ == '__main__':
    raise SystemExit(main())
