$ErrorActionPreference='Stop'
function Assert-SingleOwner([bool]$Value,[string]$Message){if(-not $Value){throw $Message}}
function Read-SingleOwnerJson([string]$Path,[string]$Sha){
 Assert-SingleOwner ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower() -ceq $Sha) ('Pinned profile input changed: '+$Path)
 return Get-Content -Raw -LiteralPath $Path|ConvertFrom-Json -DateKind String
}
function Assert-SingleOwnerDocuments($Profile,$Envelope,$Approval,$Coordination,$Phase,[string]$ProfileSha){
 $main='D:\PROJECTS\05-Corllenium-UC-Building-Repair-Engine'
 Assert-SingleOwner ($Profile.schema_version -eq 1 -and $Profile.mode -ceq 'MAIN_INFRA_SINGLE_OWNER_8GIB' -and $Profile.main_root -ieq $main) 'Exact MAIN INFRA operational profile required'
 Assert-SingleOwner ($Profile.minimum_launch_headroom_bytes -eq 8GB -and $Profile.maximum_owned_private_or_peak_bytes -eq 3GB -and $Profile.minimum_running_system_headroom_bytes -eq 3.5GB -and $Profile.maximum_heavy_phases -eq 1 -and $Profile.fresh_launch_samples -eq 3) 'Approved operational bounds differ'
 Assert-SingleOwner ($Profile.lease_path -ieq (Join-Path $main 'data/siege-live-20261026/single-owner-8gib.lock')) 'Global exclusive lease path differs'
 Assert-SingleOwner ($Approval.human_approved -ceq $true -and $Approval.profile_sha256 -ceq $ProfileSha -and $Approval.mode -ceq $Profile.mode -and $Approval.maximum_heavy_phases -eq 1 -and $Approval.no_model_guard_changes -ceq $true) 'Explicit human approval for this exact 8GiB profile required'
 Assert-SingleOwner ($Envelope.schema_version -eq 1 -and $Envelope.profile_sha256 -ceq $ProfileSha -and $Envelope.Root_FULL_source_phase_GO -ceq $true -and $Envelope.acceptance -ceq $false) 'Exact reviewed phase envelope required'
 $allowed=@($Profile.allowed_original_phases|Where-Object {$_.path -ieq $Envelope.original_phase.path -and $_.sha256 -ceq $Envelope.original_phase.sha256 -and $_.job_id -ceq $Envelope.original_job_id -and $_.HEAD -ceq $Phase.HEAD -and $_.worktree -ieq $Envelope.original_worktree})
 Assert-SingleOwner ($allowed.Count -eq 1 -and $Envelope.original_job_id -clike 'MAIN-INFRA-*' -and $Envelope.original_HEAD -ceq $Phase.HEAD -and (-not $Phase.job_id -or $Phase.job_id -ceq $Envelope.original_job_id)) 'Original reviewed MAIN INFRA phase or HEAD differs'
 Assert-SingleOwner ([IO.Path]::GetFullPath($Envelope.original_worktree).StartsWith($main+'\.claude\worktrees\',[StringComparison]::OrdinalIgnoreCase) -and (-not $Phase.cwd -or ($Phase.cwd -ieq $Phase.PYTHONPATH -and $Phase.cwd -ieq $Envelope.original_worktree)) -and $Phase.gate_8gib -ceq $true -and (-not $Phase.PSObject.Properties['acceptance'] -or $Phase.acceptance -ceq $false)) 'Owned original worktree scope differs'
 Assert-SingleOwner ($Phase.resource_contract.minimum_launch_headroom_bytes -eq 12GB -and $Phase.resource_contract.maximum_owned_private_or_peak_bytes -eq 3GB -and $Phase.resource_contract.minimum_running_system_headroom_bytes -eq 3.5GB) 'Original 12GiB phase contract changed'
 Assert-SingleOwner ($Envelope.original_args.Count -eq $Phase.args.Count -and $Envelope.original_pins.Count -eq $Phase.pins.Count) 'Original argument or pin counts differ'
 for($i=0;$i -lt $Phase.args.Count;$i++){Assert-SingleOwner ($Envelope.original_args[$i] -ceq $Phase.args[$i]) 'Original argument vector differs'}
 for($i=0;$i -lt $Phase.pins.Count;$i++){
  $a=$Envelope.original_pins[$i];$b=$Phase.pins[$i]
  Assert-SingleOwner ($a.path -ceq $b.path -and $a.sha256 -ceq $b.sha256 -and $a.bytes -eq $b.bytes) 'Original phase pin vector differs'
 }
 $age=([DateTime]::UtcNow-[DateTime]::Parse($Coordination.observed_utc).ToUniversalTime()).TotalSeconds
 Assert-SingleOwner ($Coordination.coordinator -ceq '/root' -and $Coordination.all_model_operators_paused -ceq $true -and $Coordination.active_owner_geometry_workers.Count -eq 0 -and $Coordination.phase_sha256 -ceq $Envelope.original_phase.sha256 -and $age -ge -5 -and $age -le 30 -and $Coordination.exclusive_operator -and $Coordination.nonce) 'Fresh Root coordination of all model operators required'
}
function Enter-SingleOwnerLease([string]$Path){
 $lease=[IO.File]::Open($Path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 try{
  if($lease.Length){$buffer=[byte[]]::new($lease.Length);$null=$lease.Read($buffer,0,$buffer.Length);$prior=[Text.Encoding]::UTF8.GetString($buffer)|ConvertFrom-Json -DateKind String;Assert-SingleOwner ($prior.lease_released -ceq $true) 'Previous exclusive owner has no verified release; Root audit required'}
  return $lease
 }catch{$lease.Dispose();throw}
}
function Test-SingleOwnerLaunchSamples($HeadroomBytes){
 return $HeadroomBytes.Count -eq 3 -and @($HeadroomBytes|Where-Object {$_ -lt 8GB}).Count -eq 0
}
function Enter-SingleOwnerProfile([string]$EnvelopePath,[string]$EnvelopeSha,[string]$ApprovalPath,[string]$ApprovalSha,[string]$CoordinationPath,[string]$CoordinationSha){
 $e=Read-SingleOwnerJson $EnvelopePath $EnvelopeSha
 $profile=Read-SingleOwnerJson $e.profile_path $e.profile_sha256
 foreach($code in @($profile.launcher,$profile.helper,$profile.original_wrapper,$profile.native_observer)){Assert-SingleOwner ((Get-FileHash -LiteralPath $code.path -Algorithm SHA256).Hash.ToLower() -ceq $code.sha256) 'Operational source pin changed'}
 $a=Read-SingleOwnerJson $ApprovalPath $ApprovalSha;$c=Read-SingleOwnerJson $CoordinationPath $CoordinationSha
 $p=Read-SingleOwnerJson $e.original_phase.path $e.original_phase.sha256
 Assert-SingleOwnerDocuments $profile $e $a $c $p $e.profile_sha256
 $binding=Read-SingleOwnerJson $e.original_binding.path $e.original_binding.sha256
 $bindingIndex=[Array]::IndexOf([object[]]$p.args,'--binding');$shaIndex=[Array]::IndexOf([object[]]$p.args,'--binding-sha256')
 Assert-SingleOwner ($bindingIndex -ge 0 -and $shaIndex -ge 0 -and $p.args[$bindingIndex+1] -ceq $e.original_binding.path -and $p.args[$shaIndex+1] -ceq $e.original_binding.sha256 -and $binding.job_id -ceq $e.original_job_id) 'Original owner binding differs'
 Assert-SingleOwner ([IO.Path]::GetFullPath((Get-Location).Path) -ieq [IO.Path]::GetFullPath($e.original_worktree)) 'Launch from original pinned worktree required'
 $lease=Enter-SingleOwnerLease $profile.lease_path
 try{
  Assert-SingleOwnerDocuments $profile $e $a $c $p $e.profile_sha256
  $owner=@{monitor_pid=$PID;monitor_creation_utc=[Diagnostics.Process]::GetCurrentProcess().StartTime.ToUniversalTime().ToString('o');original_phase_sha256=$e.original_phase.sha256;profile_sha256=$e.profile_sha256;coordination_sha256=$CoordinationSha;exclusive_operator=$c.exclusive_operator;nonce=$c.nonce;lease_acquired_utc=[DateTime]::UtcNow.ToString('o');lease_released=$false}
  $data=[Text.Encoding]::UTF8.GetBytes(($owner|ConvertTo-Json -Compress));$lease.Position=0;$lease.SetLength(0);$lease.Write($data,0,$data.Length);$lease.Flush($true)
  return [pscustomobject]@{Lease=$lease;PhasePlan=$e.original_phase.path;PhasePlanSha=$e.original_phase.sha256;Profile=$profile;Envelope=$e;Approval=$a;Coordination=$c;Owner=$owner;FrozenFiles=@(@{path=$EnvelopePath;sha=$EnvelopeSha},@{path=$e.profile_path;sha=$e.profile_sha256},@{path=$ApprovalPath;sha=$ApprovalSha},@{path=$CoordinationPath;sha=$CoordinationSha})}
 }catch{$lease.Dispose();throw}
}
function Assert-SingleOwnerFrozen($Context){
 foreach($file in $Context.FrozenFiles){Assert-SingleOwner ((Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLower() -ceq $file.sha) 'Operational approval or coordination changed'}
}
function Exit-SingleOwnerProfile($Context,[bool]$AllOwnedGone){
 try{
  $Context.Owner.lease_released=$AllOwnedGone;$Context.Owner.ended_utc=[DateTime]::UtcNow.ToString('o')
  $data=[Text.Encoding]::UTF8.GetBytes(($Context.Owner|ConvertTo-Json -Compress));$Context.Lease.Position=0;$Context.Lease.SetLength(0);$Context.Lease.Write($data,0,$data.Length);$Context.Lease.Flush($true)
 }finally{$Context.Lease.Dispose()}
}
