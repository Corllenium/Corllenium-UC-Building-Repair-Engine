$ErrorActionPreference='Stop'
$root=Split-Path (Split-Path $PSScriptRoot)
. (Join-Path $root 'tools/main-infra-single-owner-profile.ps1')
$out=Join-Path $root 'data/single-owner-8gib-prep/tests'
New-Item -ItemType Directory -Force -Path $out|Out-Null
$passed=[Collections.Generic.List[string]]::new()
function Must-Reject([scriptblock]$Action){$rejected=$false;try{&$Action}catch{$rejected=$true};if(-not $rejected){throw 'Expected rejection'}}
function Case([string]$Name,[scriptblock]$Action){&$Action;$passed.Add($Name)}
$main='D:\PROJECTS\05-Corllenium-UC-Building-Repair-Engine'
$phase=[pscustomobject]@{job_id='MAIN-INFRA-SYNTHETIC-NONOWNER';HEAD=('a'*40);args=@('-B','-u','-m','tools.synthetic_nonowner');pins=@([pscustomobject]@{path='not-loaded.obj';sha256=('d'*64);bytes=1});cwd="$main\.claude\worktrees\synthetic";PYTHONPATH="$main\.claude\worktrees\synthetic";gate_8gib=$true;acceptance=$false}
$phase|Add-Member resource_contract ([pscustomobject]@{minimum_launch_headroom_bytes=12GB;maximum_owned_private_or_peak_bytes=3GB;minimum_running_system_headroom_bytes=3.5GB})
$original=[pscustomobject]@{path="$main\data\synthetic-phase.json";sha256=('b'*64)}
$profile=[pscustomobject]@{schema_version=1;mode='MAIN_INFRA_SINGLE_OWNER_8GIB';main_root=$main;minimum_launch_headroom_bytes=8GB;maximum_owned_private_or_peak_bytes=3GB;minimum_running_system_headroom_bytes=3.5GB;maximum_heavy_phases=1;fresh_launch_samples=3;lease_path="$main\data\siege-live-20261026\single-owner-8gib.lock";allowed_original_phases=@([pscustomobject]@{path=$original.path;sha256=$original.sha256;job_id=$phase.job_id;HEAD=$phase.HEAD})}
$envelope=[pscustomobject]@{schema_version=1;profile_sha256=('c'*64);original_phase=$original;original_HEAD=$phase.HEAD;original_job_id=$phase.job_id;original_args=$phase.args;original_pins=$phase.pins;Root_FULL_source_phase_GO=$true;acceptance=$false}
$approval=[pscustomobject]@{human_approved=$true;profile_sha256=('c'*64);mode=$profile.mode;maximum_heavy_phases=1;no_model_guard_changes=$true}
$coord=[pscustomobject]@{coordinator='/root';observed_utc=[DateTime]::UtcNow.ToString('o');all_model_operators_paused=$true;active_owner_geometry_workers=@();phase_sha256=$original.sha256;exclusive_operator='synthetic-nonowner-test';nonce='fixture-only'}
$envelope|Add-Member original_worktree $phase.cwd
$profile.allowed_original_phases[0]|Add-Member worktree $phase.cwd
function Check{Assert-SingleOwnerDocuments $profile $envelope $approval $coord $phase ('c'*64)}
Case 'approved synthetic scope accepted, no executable called' {Check}
Case 'human approval false blocks' {$approval.human_approved=$false;Must-Reject {Check};$approval.human_approved=$true}
Case 'tampered original phase outside allowlist blocks' {$original.sha256='e'*64;Must-Reject {Check};$original.sha256='b'*64}
Case 'different HEAD blocks' {$envelope.original_HEAD='f'*40;Must-Reject {Check};$envelope.original_HEAD=$phase.HEAD}
Case 'different worktree blocks' {$envelope.original_worktree="$main\.claude\worktrees\other";Must-Reject {Check};$envelope.original_worktree=$phase.cwd}
Case 'different arguments block' {$envelope.original_args=@('-m','tools.other');Must-Reject {Check};$envelope.original_args=$phase.args}
Case 'different pin vector blocks' {$envelope.original_pins=@();Must-Reject {Check};$envelope.original_pins=$phase.pins}
Case 'another owner worker blocks' {$coord.active_owner_geometry_workers=@(123);Must-Reject {Check};$coord.active_owner_geometry_workers=@()}
Case 'stale coordination blocks' {$coord.observed_utc=[DateTime]::UtcNow.AddSeconds(-31).ToString('o');Must-Reject {Check};$coord.observed_utc=[DateTime]::UtcNow.ToString('o')}
Case 'exclusive file lease excludes simultaneous contender and releases' {$path=Join-Path $out 'synthetic.lock';$lease=Enter-SingleOwnerLease $path;try{Must-Reject {$second=Enter-SingleOwnerLease $path;$second.Dispose()}}finally{$lease.Dispose()};$again=Enter-SingleOwnerLease $path;$again.Dispose()}
Case 'crashed owner lease is fail closed until verified release' {$path=Join-Path $out 'unreleased.lock';[IO.File]::WriteAllText($path,'{"lease_released":false}');Must-Reject {$bad=Enter-SingleOwnerLease $path;$bad.Dispose()};[IO.File]::WriteAllText($path,'{"lease_released":true}');$good=Enter-SingleOwnerLease $path;$good.Dispose()}
Case 'terminal lease readback only releases verified all-gone owner' {
 $path=Join-Path $out 'terminal.lock';[IO.File]::WriteAllText($path,'')
 $context=[pscustomobject]@{Lease=(Enter-SingleOwnerLease $path);Owner=@{lease_released=$false}}
 Exit-SingleOwnerProfile $context $false;Must-Reject {$blocked=Enter-SingleOwnerLease $path;$blocked.Dispose()}
 [IO.File]::WriteAllText($path,'{"lease_released":true}')
 $context.Lease=Enter-SingleOwnerLease $path;Exit-SingleOwnerProfile $context $true
 $read=Get-Content -Raw -LiteralPath $path|ConvertFrom-Json
 if($read.lease_released -cne $true){throw 'Terminal lease did not round-trip'}
 $next=Enter-SingleOwnerLease $path;$next.Dispose()
}
Case 'three samples all at eight GiB admit' {if(-not(Test-SingleOwnerLaunchSamples @(8GB,8GB,8GB))){throw '8GiB boundary rejected'}}
Case 'one lower sample or wrong sample count holds' {if((Test-SingleOwnerLaunchSamples @(8GB,8GB,(8GB-1))) -or (Test-SingleOwnerLaunchSamples @(9GB,9GB))){throw 'Unsafe admission'}}
Case 'paid resource assertions reject own/global breaches' {
 $native='D:/LLM_BACKUP/Codex session/main-infra-resource-monitor-v5-20261024/05-Corllenium-UC-Building-Repair-Engine/docs/superpowers/records/MAIN-INFRA-RESOURCE-MONITOR-V5-20261024/execute-resource-guard-v5.ps1'
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($native,[ref]$tokens,[ref]$errors)
 $fn=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Assert-ExecResources'},$true)
 Invoke-Expression $fn.Extent.Text
 Assert-ExecResources @(10GB,14GB,1GB) 2GB 3GB 3GB
 Must-Reject {Assert-ExecResources @(10GB,14GB,1GB) (3GB+1) (3GB+1) (3GB+1)}
 Must-Reject {Assert-ExecResources @(10GB,13GB,1GB) 0 0 0}
 Must-Reject {Assert-ExecResources @(10GB,14GB,1GB) 2GB 1GB 2GB}
}
Case 'resource limits unchanged in paid wrapper and new profile' {
 $paid=Get-Content -Raw -LiteralPath (Join-Path $main 'data/siege-live-20261026/canvas-build/run-proof-12gib.ps1')
 $body=Get-Content -Raw -LiteralPath (Join-Path $root 'tools/run-main-infra-single-owner-8gib.ps1')
 foreach($needle in @('Assert-ExecResources $m $pm[0] $pm[1] $treePrivate','if($pm[0] -ge 3GB -or $pm[1] -ge 3GB -or $treePrivate -ge 3GB)')){if(-not $paid.Contains($needle) -or -not $body.Contains($needle)){throw 'Paid owned bound changed'}}
 if($profile.maximum_owned_private_or_peak_bytes -ne 3GB -or $profile.minimum_running_system_headroom_bytes -ne 3.5GB){throw 'Runtime bound changed'}
}
@{synthetic_non_owner=$true;model_loaded=$false;model_executed=$false;passed=$passed.Count;cases=@($passed)}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $out 'readback.json') -Encoding utf8
Write-Output ("PASS "+$passed.Count+' synthetic non-owner cases')
