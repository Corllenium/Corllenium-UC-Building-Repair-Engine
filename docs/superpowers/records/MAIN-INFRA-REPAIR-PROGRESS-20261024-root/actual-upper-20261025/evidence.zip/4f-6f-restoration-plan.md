# Upper 4F-6F Checked Restoration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task after Root releases it. Steps use checkbox syntax for tracking. No implementation or real-floor phase is authorized by this document.

**Goal:** Extend the measured 7F checked E3-to-E5 survivor replay to separate 4F, 5F and 6F profiles, restoring whole donor sites only where actual evidence identifies their original source faces.

**Architecture:** Reuse the existing 7F partition verifier, ancestry remap, source-derived E5 key context, default checked kernel and checkpoint-first original-source writer. Isolate only the floor-specific identity/count/cohort data; preserve the current 7F default. A floor with a missing contributor cohort remains an unsealed draft and cannot prepare or execute.

**Tech Stack:** Python 3.12, existing NumPy/engine types, existing native V5 resource wrappers; no new dependencies.

**Spec:** AGENTS.md sections 3-6 and 9; records/MAIN-INFRA-UPPER-FLOOR-RETENTION-20261024/brief.md; controller grant bbeb6a7f and atomic claim e1b4cdbc; Root's Oct25 continuation instruction. The 7F executed code is 9f236a048ea3e9526e1e486f21e0fb0dff12ff97. Its records-only archive descendant is de7c49c6126717576a8c499af00756482022e59a.

## Global Constraints

- Plan/code preparation only. No actual 4F-6F parse, detector, ray, kernel, render or repair until the actual 7F independent result is reviewed and Root grants the exact next phase.
- Preserve the transferred claim, old Claude checkout, source, candidates and proof files. Each real floor gets exclusive new output/checkpoint/worker paths.
- Do not alter guards, signed targets, FixProfile, SiteJudge, existing tests, camera cohorts or any tolerance/cap.
- E5 opts into only recorded coincident_backface_removed. Strict26 CBR extension is not approved. Do not import the old 78d4 validator tree, E4 replay, material-priority rules or border-cut policies.
- All donor proposals, original kept/rolled partitions and their order remain authenticated. A restored site is excluded as a whole; historical rollback sites remain excluded. Fresh site checks and fresh rollbacks remain active.
- E5 input precision is derived independently from each floor's pinned SOURCE-forward frame. Never copy 7F's literal 14-to-15 values. Only a measured metadata-only transition may connect CP3 outcome to CP5 input.
- A saved structural candidate or preservation pass does not meet the owner's signed problem targets. No repaired/accepted claim until independent validation and owner confirmation.
- Certified V5 only: metadata250MiB, synthetic/default-kernel1GiB, actual floor3GiB; fresh3x8GiB/system3.5GiB; phase pins and Root resource scheduling. No PID-only observer.

## Measured starting state

Snapshot: ../records/MAIN-INFRA-UPPER-FLOOR-RETENTION-20261024/upper4-6-retained-metadata-20261025.json, SHA256 88ffe0b0efa53fe11942c5e3273825a376bb7d3f91f3d89d99341bf00e28d443. All108 retained file pins were freshly rehashed with zero mismatches. Only JSON/log metadata and file bytes were read; no geometry loader ran.

| Floor | Original -> saved E3 -> saved E5 | E3 proposed/kept/rolled | E5 proposed/kept/rolled | Retained preservation evidence |
| --- | --- | --- | --- | --- |
| 4F | 78160 -> 52865 -> 47752 | 3319/3053/266 | 876/785/91 | E3 strict PASS; signed textures/coverage PASS, targets FAIL; native16 walking views differ5 pixels; E5 strict absent |
| 5F | 56368 -> 38113 -> 33482 | 2367/2331/36 | 837/782/55 | E3 strict PASS; signed textures/coverage PASS, targets FAIL; native16 differs2; E5 strict FAIL14 material +302 moved |
| 6F | 34862 -> 27108 -> 24378 | 1497/1319/178 | 608/547/61 | E3 strict PASS; signed textures/coverage PASS, targets FAIL; native16 differs3; E5 strict FAIL2 material +9 moved +3 ties |

These native totals describe the retained16 walking views, not a newly qualified46-view cohort. Existing E5 strict receipts contain view totals rather than pixel/face witnesses. No E5 full signed report was found in the retained independent-validator E5 validation paths. None of these candidates is accepted.

Historical E3 target residuals (diff/same/reversed/cracks): 4F8868/11223/0/14425; 5F4976/6500/1/10623; 6F3236/4934/0/6659. These counts belong to the exact saved E3 candidates, not to a future restored replay.

**Unsealed input:** restoration E3 sites, restoration E5 sites and protected original faces are NULL for all three floors. Pixel totals, residual error examples and 7F face IDs are insufficient attribution. No requested output count is calculated from an unsealed set.

## Review Focus

- A changed pixel may come from an E3 removal, E5 removal or precision/tie behaviour; aggregate counts cannot select a site. Task1 refuses an absent measured contributor map.
- A contributor may be E5-local; Task2 composes saved E3 ancestry before excluding its complete donor site, including neighbours that did not themselves fail.
- A fresh E3 rollback changes E5 local indices; Task3 rebinds every donor E5 key against the actual ancestry before selecting the retained subset.
- Equal numeric arrays may still have a different key precision context; Task3 derives the historical context from SOURCE+Frame and proves every allowed transition/digest link.
- A floor/report/asset may be swapped with another valid floor; Tasks1 and3 require exact floor/role/source/audit/code pins and exclusive namespaces.

### Task1: Bind one measured floor and its complete failure cohort

**Files:** Create tools/main_infra_upper_restore_profiles.py and tools/tests/test_main_infra_upper_restore_profiles.py. Create one versioned input JSON per released floor in the owned record namespace. Modify no engine files.

**Interfaces:** immutable RestorationProfile holds floor, source/donor count tuples, externally pinned evidence/cohort identity and complete restored-site maps. An absent map is None and sealed is False. Existing 7F constants become the explicit default profile only after parity tests; no arbitrary floor/plugin registry.

- [ ] Write test_unsealed_profile_cannot_prepare with the actual4F/5F/6F metadata: all three drafts must refuse prepare/execute rather than treat NULL as an empty restore set.
- [ ] Write wrong-floor/hash/duplicate/unknown-site and omitted-contributor negatives. A coherent count-preserving face relabel must fail against the externally pinned full measured cohort.
- [ ] Run the new metadata tests through the certified tiny phase and retain genuine RED. Implement only the explicit profile/binding checks; run GREEN and commit named files.
- [ ] Before sealing a positive floor profile, obtain Root-reviewed actual contributor evidence. First inspect retained saved pixel/buffer/image witnesses; if absent, submit a separate bounded read-only diagnostic packet. This plan neither creates nor executes that diagnostic. Native footprints must include conservative whole-pixel candidates and explicit CPU/GPU limits; strict witness attribution must preserve its actual source/ray semantics.
- [ ] Bind the complete raw cohort and actual source/after/camera/helper hashes. Keep any unresolved attribution fail closed. Do not rewrite historical reports or reinterpret native changes as PASS.

### Task2: Derive whole-site retention with exact donor partitions

**Files:** Modify only floor-data routing in tools/main_infra_7f_restore_plan.py; add tools/tests/test_main_infra_upper_restore_plan.py. Existing 7F tests remain unchanged.

**Interfaces:** plan_records(data, profile=SEVEN_F_PROFILE) returns the current plan schema plus explicit floor/evidence identity. Reuse _stage(data, stage, expected) and remap_e5_rows unchanged where their behaviour already suffices.

- [ ] Write tests using exact retained JSON schemas: proposed=kept+rolled, unique sites/faces, saved ancestry equals all kept removals, E5 audit chains to exact E3, and original rollback vectors cannot change.
- [ ] Write a multi-face contributor fixture proving that one failed original restores its whole E3 or E5 site. E5-local attribution must map through saved E3 survivors to originals; no partial-site face editing is allowed.
- [ ] Write original-row-order/typed-selection and cross-floor substitution negatives. A contributor already absent after E3 cannot be attributed silently to E5; unknown/ambiguous first absence refuses sealing.
- [ ] Retain genuine RED, implement only the profile routing/cohort-to-whole-site set difference, run GREEN through existing resource classes and commit named files. Compare default7F plan output against the frozen actual7F plan; do not rerun the actual floor.

### Task3: Reuse the checked runner and checkpoint-first writer per floor

**Files:** Modify tools/main_infra_7f_restore.py and tools/main_infra_7f_checked_restore.py only where floor/count/namespace data must be explicit. Add tools/tests/test_main_infra_upper_restore_runtime.py. No whole-runner copy.

**Interfaces:** existing prepare/execute entry points accept an explicit profile/input SHA while preserving their current7F default; run_e5_rows, save_checked_stage and save_cumulative_stage retain their exact checked/writer contracts. Worker JSON reports actual floor, native PID/birth, literal E3/E5 stage and measured selected/kept/rolled counts.

- [ ] Write a real tiny-kernel fixture: fresh E3 rollback changes ancestry, every donor E5 row is remapped and K1-verified, excluded donor rollbacks remain excluded, selected typed objects/order reach the unchanged default kernel.
- [ ] Write a source-context fixture where historical SOURCE-forward metadata differs, plus table/UV/material/physical-quanta drift negatives. Require eight-array identity and only a source-derived coord_decimals tightening; a no-op context needs an explicit identity-chain case rather than an invented decimal change.
- [ ] Write checkpoint-before-writer and cumulative local/original survivor tests. Protect the entire sealed original set and preserve all original position/UV/normal tables and face material/corner/object/group records.
- [ ] Retain RED/GREEN under c54/V5 for default-kernel fixtures. Keep all existing tests unchanged; use the new metadata tests for floor routing. Commit named files and freeze exact code/components/input/phase pins for independent review.

### Task4: Release one actual floor only after independent7F disposition

**Files:** Versioned preparation/execute configs and readbacks under new per-floor owned namespaces; independent validator's own branch and output paths. This task is a future gate, not current permission to run.

- [ ] Root chooses the next floor after7F independent results. A proposed small-to-large order is6F,5F,4F; this is scheduling only and cannot bypass missing contributor evidence.
- [ ] Root/IV review the sealed floor profile, exact hashes, current lease/source admission, inherited bytes and resource config. Actual prepare must validate all donor keys against its real floor and save a P before execution is considered.
- [ ] Root separately reviews the real P and execute config. Rehash pins, require fresh native0other geometry and fresh3x8 admission; use the unchanged3GiB V5 class. Stop on any drift, K1 mismatch or resource abort; no blind retries.
- [ ] Save both checkpoints before source serialization, actual SOURCE/ENGINE pair, exact ancestry/assets/worker/native terminal, postpins and durable archive. Requested counts are never represented as actual output counts.
- [ ] A nonbuilder runs default strict26, qualified native33+diagnostic13 and unchanged signed validation on the actual pair. Only actual results determine preservation and problem-target state. Publish/accept only within Root/owner authority; target residuals remain explicit and further relevant engine work is required when targets fail.

## Plan disposition

This is a code-only continuation plan. No 4F-6F engine change, model operation, contributor set, future verdict, acceptance or publication is supplied by it. The existing7F engine run is saved18716, but independent strict/native/signed/error measurements remain pending at the time of this plan. Implementation waits Root review; real work remains independently gated.
