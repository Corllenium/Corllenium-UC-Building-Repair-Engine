from dataclasses import replace
import numpy as np
import pytest
from engine.model import MeshData
from engine.repair.types import Edit

def mesh():
    return MeshData('source',np.array([[0.,0.,0.],[2.,0.,0.],[0.,2.,0.],[1.,0.,0.]]),np.empty((0,2)),np.empty((0,3)),np.array([[0,1,2]]),np.full((1,3),-1),np.full((1,3),-1),np.array([0]),np.array([1]),['wall'],None,15,17)

def edit():
    return Edit('E7','cut',(0,),np.array([[0,3,2],[3,1,2]]),None,0,'existing exact-edge T-junction threading',{})

def qualify(source=None,before=None,rows=None,edits=None,mandatory=(),locked=()):
    from tools.main_infra_10571_e7_plan import qualify_proposals
    source=source if source is not None else mesh();before=before if before is not None else source
    return qualify_proposals(source,before,rows or [dict(output_face=0,original_source_triangle=42,kind='unchanged')],edits or [edit()],mandatory,locked)

def test_exact_existing_vertex_partition_is_admitted_without_mutation():
    m=mesh();position=m.positions.tobytes();r=qualify(m)
    assert r['admitted_indices']==[0] and r['planned']==1 and r['kernel_called'] is False
    assert r['sites'][0]['original_source_parent']==42 and m.positions.tobytes()==position

@pytest.mark.parametrize('kind',['unchanged','cut'])
def test_mandatory_original_blocks_every_descendant(kind):
    r=qualify(rows=[dict(output_face=0,original_source_triangle=42,kind=kind)],mandatory=[42])
    assert r['admitted_indices']==[] and r['sites'][0]['reason']=='mandatory_original_parent'

def test_priority_anchor_blocks_even_when_original_is_not_mandatory():
    r=qualify(locked=[0]);assert r['admitted_indices']==[] and r['sites'][0]['reason']=='locked_source_priority_face'

def test_exact_source_offplane_is_refused_even_when_engine_partition_is_valid():
    s=mesh();s.positions[3,2]=1e-12
    r=qualify(source=s,before=mesh());assert r['admitted_indices']==[] and 'off exact source plane' in r['sites'][0]['reason']

def test_cut_child_ancestry_is_kept_for_unprotected_parent():
    r=qualify(rows=[dict(output_face=0,original_source_triangle=42,kind='cut')])
    assert r['admitted_indices']==[0] and r['sites'][0]['inherited_kind']=='cut'

@pytest.mark.parametrize('change',[lambda e:replace(e,engine='E5'),lambda e:replace(e,new_points=np.array([[1.,0.,0.]])),lambda e:replace(e,faces=(0,0)),lambda e:replace(e,site=1)])
def test_invalid_scope_fails_closed(change):
    with pytest.raises(ValueError):qualify(edits=[change(edit())])

def test_duplicate_sites_fail_closed():
    with pytest.raises(ValueError):qualify(edits=[edit(),edit()])

def test_unordered_composed_ancestry_fails_closed():
    with pytest.raises(ValueError):qualify(rows=[dict(output_face=1,original_source_triangle=42,kind='unchanged')])
