"""Measure fresh existing-vertex E7 proposals on the preserved10571 pair; never execute edits."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from engine.fixes.pipeline import FixProfile
from engine.repair.engines.e7_thread import E7Thread, _source_weights
from engine.repair.types import RepairContext, UnitState
from tools.main_infra_e3 import _source_digest
from tools.main_infra_e7_checkpoint import typed_plan_digest
from tools.main_infra_e7_serialization import _encode, _prove_exact_source_coverage, _tables

def need(value,message):
    if not value:raise ValueError(message)

def qualify_proposals(source,before,rows,edits,mandatory,locked):
    need(source.n_faces==before.n_faces==len(rows),'Complete composed ancestry required')
    need(all(r['output_face']==i and type(r['original_source_triangle']) is int and r['original_source_triangle']>=0 for i,r in enumerate(rows)), 'Ordered composed ancestry differs')
    need(len({e.site for e in edits})==len(edits),'Unique fresh sites required')
    mandatory,locked=set(mandatory),set(locked)
    need(all(type(i) is int and 0<=i<before.n_faces for i in locked),'Locked face index differs')
    original=(_source_digest(source),_source_digest(before));sites=[];admitted=[]
    for index,e in enumerate(edits):
        need(e.engine=='E7' and e.kind=='cut' and not e.legacy and e.new_points is None and len(e.faces)==1 and e.site==e.faces[0] and type(e.site) is int and 0<=e.site<before.n_faces,'Existing-vertex disjoint E7 scope required')
        parent=rows[e.site];reason=None
        if parent['original_source_triangle'] in mandatory:reason='mandatory_original_parent'
        elif e.site in locked:reason='locked_source_priority_face'
        else:
            try:
                _source_weights(before,e.site,e.new_faces)
                _prove_exact_source_coverage(source,e.site,e.new_faces)
            except ValueError as exc:reason=str(exc)
        if reason is None:admitted.append(index)
        sites.append(dict(index=index,site=e.site,original_source_parent=parent['original_source_triangle'],inherited_kind=parent['kind'],admitted=reason is None,reason=reason,new_faces=e.new_faces.tolist()))
    need(original==(_source_digest(source),_source_digest(before)),'Plan-only inspection mutated input')
    return dict(schema_version=1,planned=len(edits),admitted_indices=admitted,sites=sites,typed_plan_digest=typed_plan_digest(edits),admitted_typed_plan_digest=typed_plan_digest([edits[i] for i in admitted]),kernel_called=False,model_mutated=False,acceptance=False)

def read_bound(ref):
    p=Path(ref['path']);raw=p.read_bytes();need(hashlib.sha256(raw).hexdigest()==ref['sha256'],'Input hash differs: '+str(p));return raw

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',required=True,type=Path);args=parser.parse_args(argv)
    plan=json.loads(args.input.read_bytes());need(set(plan)=={'schema_version','mode','refs','output'} and plan['schema_version']==1 and plan['mode']=='1F10571_fresh_E7_plan_only','Explicit plan-only input required')
    refs=plan['refs'];raw={k:read_bound(v) for k,v in refs.items()}
    need(refs['reference']['sha256']=='0b2c81f959ee35fe4a14f96077f4e81cd554f441911f29945508fdb4eb4c5ec0','Authentic saved10571 input reference required')
    r=json.loads(raw['reference']);p=json.loads(raw['prepared-v2.json']);rows=json.loads(raw['lineage'])['faces'];signed=json.loads(raw['validation'])
    for key in ('source','engine','lineage','checkpoint','arrays','result','typed_log','run_receipt','batch_plan','prepared-v2.json'):
        need(refs[key]=={k:r['files'][key][k] for k in ('path','sha256')},'Unchanged original reference role required: '+key)
    need(refs['source']['sha256']==p['source_after_sha256']=='d8ee718ff223049dc8eaa888b9be34a2448919f7d76910e4d15a43329ec7bdff' and refs['engine']['sha256']==p['after_sha256']=='604b30ea35027c3475a2a3779ffb60b7d082fb216f21a908c06dd8c65c86e477','Specific saved10571 pair required')
    need(refs['validation']['sha256']=='ec233f6d178c5e71755a61d360ecd92db5f6eca35e602bc3facc04480e755a80' and signed['inputs']['after_sha256']==p['after_sha256'] and signed['checks']['textures']['status']==signed['checks']['nothing_deleted']['status']=='PASS','Current independent signed preservation required')
    need(p['output_triangles']==10571 and p['mandatory_unchanged_original_parents']==r['mandatory_originals'] and len(r['mandatory_originals'])==754 and p['output_locked_faces']==r['current_locked_faces'] and len(r['current_locked_faces'])==829 and p['output_anchor_faces']==r['current_anchor_faces'] and len(r['current_anchor_faces'])==100,'Whole original/anchor context required')
    from engine.io.minecraft_floor import Frame,parse_floor
    from engine.io.obj_reader import read_obj
    from tools.main_infra_1f_e5_validation import typed_after
    from tools.main_infra_physical_validation import _same_mesh
    mesh,data,cp=typed_after(refs['checkpoint']['path'],'b9f8f990d34ef1079c22b07d6438ccb7e1a3c7d233c25a7fc3721dd49e795565','actual_checked_e5_empty_remainder')
    need(cp['after_digest']==p['checkpoint_after_digest'] and mesh.n_faces==10571 and cp['planned']==102 and cp['kept']==80 and cp['rolled_back']==22,'Actual typed output context differs')
    _tables(read_obj(refs['engine']['path']),mesh)
    source=parse_floor(raw['source'].decode('utf-8'));provenance=json.loads(raw['provenance'])
    _same_mesh(source.in_frame(Frame(1000/25.4,provenance['frame_evidence'])).mesh,mesh)
    need(len(rows)==10571 and all(row['output_face']==i and row['vertex_ids']==source.mesh.face_v[i].tolist() and row['source_uv']==source.mesh.face_vt[i].tolist() and row['material']==source.mesh.materials[int(source.mesh.face_material[i])] for i,row in enumerate(rows)),'Exact source corner/composed lineage differs')
    required=[row for row in rows if row['original_source_triangle'] in set(r['mandatory_originals'])]
    need(len(required)==754 and all(row['kind']=='unchanged' for row in required),'Literal protected parents required')
    planner=E7Thread();edits=planner.plan(UnitState(mesh,None,{},None),RepairContext(FixProfile(),None,None))
    report=qualify_proposals(source.mesh,mesh,rows,edits,r['mandatory_originals'],r['current_locked_faces'])
    report.update(mode=plan['mode'],input_refs=refs,output_triangles=mesh.n_faces,source_digest=_source_digest(source.mesh).hex(),engine_digest=_source_digest(mesh).hex(),mandatory_originals=r['mandatory_originals'],locked_current_faces=r['current_locked_faces'],planner_report=planner.report,edits=[dict(_encode(e),decision=e.decision) for e in edits],independent_input_preservation_passed=True,new_output_saved=False)
    for ref in refs.values():read_bound(ref)
    out=Path(plan['output']);need(out.resolve().is_relative_to(Path(__file__).resolve().parents[1]/'data') and not out.exists(),'Exclusive owned output required');out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(dict(planned=len(edits),admitted=len(report['admitted_indices']),planner=planner.report,report=str(out),report_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),kernel_called=False,new_output_saved=False,acceptance=False)))
    return 0

if __name__=='__main__':raise SystemExit(main())
