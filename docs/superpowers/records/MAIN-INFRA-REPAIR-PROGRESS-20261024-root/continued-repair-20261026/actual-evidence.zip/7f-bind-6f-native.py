from pathlib import Path
import hashlib,json,sys
root=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine')
sys.path.insert(0,str(root/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
deployment=json.loads((root/'data/siege-live-20261026/signed-19695-deployment.log').read_text(encoding='utf-8-sig').strip())
assert deployment['files_per_root']==deployment['http_hashes']==5 and deployment['preservation_passed'] is True
assert deployment['remaining_target_counts']==8701 and deployment['accepted'] is False
six=root/'data/6f-delivery-readback-20261026'
def bound(name,sha):
    b=(six/name).read_bytes();assert hashlib.sha256(b).hexdigest()==sha;return json.loads(b)
t=bound('actual-native-terminal.json','0624ba82b45d7a2dec1df8ee16f2fc90a3ec515f5651987d7ef41869b6951a0a')
n=bound('native-diagnostic.json','6e0de6def9413dad0145ff8cdb8aa48d1809c3c5e0f4e0a9e6f42d9b30374dbd')
assert t['actual_pid']==12168 and t['actual_exit_code']==0 and t['all_owned_exited'] is True and t['abort_reason'] is None
assert n['source_control_passed'] is True and n['acceptance'] is False
path=root/'data/main-infra-fresh/current.json';doc=load_progress(path);now=utc_now()
other=json.dumps({k:v for k,v in doc['floors'].items() if k not in ('6F','7F')},sort_keys=True)
f=doc['floors']['7F'];assert f['output_triangles']==19695 and f['signed_validation_sha256']=='5abac22a931e88626ecff754c3fa065c8350c00c6434ac63efc865bb22d22750'
prefix=deployment['preview'].rsplit('/',1)[0]+'/evidence-signed-19695-20261026/'
f.update(candidate_preview=deployment['preview'],validator_ref=prefix+'validation.json',evidence_refs=list(dict.fromkeys(f.get('evidence_refs',[])+[prefix+x for x in ('validation.json','terminal.json','render-fields-equivalence.json','fullsigned-evidence.zip')])),
    step='7F19695 saved E5 model, original textures and seven measured filters live. Completed independent signed evidence published: texture and visible preservation PASS; signed problem targets FAIL8701.',
    blocker='1522 different-look overlaps,2629 same-look overlaps and4550 cracks remain. Final clean model not accepted; completed validation report and evidence available.',last_work_event_at=now)
f.setdefault('activity_events',[]).append(dict(at=now,phase='signed_19695_evidence_published',message='Five immutable signed evidence/preview files verified in both static roots and HTTP. Completed default Validator exit2/noabort with preservation PASS and targets FAIL8701; original resource-abort evidence retained. No model or detector rerun.'))
f=doc['floors']['6F'];assert f['output_triangles']==27108
f.update(state='blocked',worker_pid=12168,worker_start_utc=t['actual_creation_utc'],worker_alive=False,worker_observed_at=t['ended_utc'],worker_cpu_seconds=None,last_work_event_at=t['ended_utc'],
    step='6F fresh independent native33 check complete: all raw-source control pairs exact; historical27108 candidate differs at5 pixels across5 views. Whole-site retention repair is next after5F.',
    blocker='Five measured candidate pixel discrepancies remain: walking784/747/760 and outside(-1,-1,1)/(0,0,1). New protected engine candidate not yet saved.',
    native_diagnostic_changed_pixels=5,native_diagnostic_changed_views=5,native_diagnostic_sha256='6e0de6def9413dad0145ff8cdb8aa48d1809c3c5e0f4e0a9e6f42d9b30374dbd')
f.setdefault('worker_events',[]).append(dict(engine='Validator',run_id='MAIN-INFRA-6F-NATIVE-RETENTION-20261026',pid=12168,start_utc=t['actual_creation_utc'],observed_at=t['ended_utc'],phase='native33_5pixels_complete',message='Actual native diagnostic exit0/noabort/allgone. RAW fresh source versus normalized source33exact pairs; historicalE3candidate5changedpixels across5views. Diagnostic zero exit certifies source control only; preservation discrepancy unresolved.'))
assert other==json.dumps({k:v for k,v in doc['floors'].items() if k not in ('6F','7F')},sort_keys=True)
assert all(f['accepted_preview'] is None and f['owner_decision_ref'] is None for f in doc['floors'].values())
doc['updated_at']=now;doc['last_work_event_at']=now;write_progress(path,doc)
print(json.dumps(dict(floor7_preview=deployment['preview'],floor7_evidence='completed',floor6_native_changed_pixels=5,other_floors_unchanged=True,accepted=False)))
