from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,struct
R=Path('D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine');D=R/'data/5f-4641-marker-poststage-20261026'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
p=R/'.claude/worktrees/r5g/data/r5g-preflight/marker-selection-draft.json';assert sha(p)=='d375a80f1fb1c19ae0617d2ed3e7e7a22fb278a264a1baf71a130694f86db5fc'
s=read(p)
for k,v in s.items():
    if isinstance(v,dict) and 'path' in v and 'sha256' in v:assert sha(v['path'])==v['sha256'],k
base=read(s['base_authority']['path']);old=next(r for r in base['floors'] if r['floor']=='5F')
lineage=read(s['current_original_ancestry']['path']);parents=lineage['source_faces'];protected=read(s['saved_builder_readback']['path'])['protected_originals']
assert s['approved_original']==old['selected_original']==list(range(56344,56368))
assert len(parents)==len(set(parents))==35367 and all(type(i)is int and 0<=i<56368 for i in parents)
inverse={p:i for i,p in enumerate(parents)};assert s['selected_current']==sorted(inverse[i]for i in s['approved_original'])==list(range(35343,35367))
assert len(protected)==len(set(protected))==4641 and set(protected)<=set(parents) and not set(protected)&set(s['approved_original'])
def obj(path):
    tables={k:[]for k in ('v','vt','vn')};faces=[];material=object_name=group=''
    for raw in Path(path).read_text(encoding='utf-8').splitlines():
        tokens=raw.split('#',1)[0].split()
        if not tokens:continue
        key=tokens[0]
        if key in tables:
            values=tuple(float(x) for x in tokens[1:]);assert all(math.isfinite(x)for x in values)
            tables[key].append(b''.join(struct.pack('<d',v)for v in values))
        elif key=='usemtl':material=' '.join(tokens[1:])
        elif key=='o':object_name=' '.join(tokens[1:])
        elif key=='g':group=' '.join(tokens[1:])
        elif key=='f':
            assert len(tokens)==4
            faces.append((tuple(tokens[1:]),material,object_name,group))
    return tables,faces
before,original=obj(s['original_source']['path']);after,current=obj(s['current_source']['path'])
assert len(original)==56368 and len(current)==35367
assert before==after,'Actual saved Source v/vt/vn tables differ'
assert all(current[i]==original[parent]for i,parent in enumerate(parents)),'Saved corner/UV/normal/material/object/group ancestry differs'
assert all(current[i]==original[parents[i]]for i in s['selected_current'])
readback=dict(reviewer='Root',actual_source_tables_float64_byte_exact=True,all_35367_corner_material_group_parents_exact=True,
    original_triangles=56368,current_triangles=35367,selected_original=s['approved_original'],selected_current=s['selected_current'],
    protected_originals=4641,protected_marker_intersection=[],full_floor_validation=False,acceptance=False)
rp=D/'root-selection-independent-readback.json';assert not rp.exists();rp.write_text(json.dumps(readback,indent=2)+'\n')
s.update(kind='Root_sealed_exact5F_marker_poststage_selection',selection_reviewer='Root',selection_approved=True,
    selection_reviewed_at=datetime.now(timezone.utc).isoformat(),independent_selection_readback=dict(path=str(rp),sha256=sha(rp)))
out=D/'root-sealed-selection.json';assert not out.exists();out.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),selected=24,expected_output=35343,protected_originals=4641,all_actual_parent_faces_verified=True,acceptance=False)))
