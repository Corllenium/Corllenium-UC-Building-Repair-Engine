import fs from 'node:fs';
import {parseFreshMainInfraStatus} from '../../.claude/worktrees/SIEGE-MAIN-INFRA-LIVE-20261023/dashboard/lib/buildings/freshMainInfraStatus.ts';
const path=process.argv[2]??new URL('../main-infra-fresh/current.json',import.meta.url);
const doc=parseFreshMainInfraStatus(JSON.parse(fs.readFileSync(path,'utf8')));
if(!doc)throw new Error('Actual live status rejected by existing dashboard parser');
for(const id of ['1F','2F','3F','4F','5F','6F','7F'])if(doc.floors[id].accepted_preview!==null)throw new Error('Unexpected acceptance');
console.log(JSON.stringify({valid:true,floors:7,pending6F:doc.floors['6F'].pending_output_triangles,displayed6F:doc.floors['6F'].output_triangles}));
