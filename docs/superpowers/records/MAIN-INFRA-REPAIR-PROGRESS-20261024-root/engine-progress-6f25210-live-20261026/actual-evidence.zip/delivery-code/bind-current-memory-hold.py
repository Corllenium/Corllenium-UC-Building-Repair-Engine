from pathlib import Path
import hashlib,json,sys,time,subprocess
R=Path(__file__).resolve().parents[2]
def read(p): return json.loads(Path(p).read_bytes())
def checked(p,expected):
    data=Path(p).read_bytes();assert hashlib.sha256(data).hexdigest()==expected;return json.loads(data)
proof=checked(R/'.claude/worktrees/v6g/data/iv6g/independent-saved-readback.json','85d21d75e6272a5bb796963a90e0285470e6807e2bad6556b67c2640c38347f9')
assert proof['protected_original_count']==3323 and not proof['acceptance']
cp=checked(R/'.claude/worktrees/r3e/data/3f-e5-checked/run-20261026/checked-outcome/checkpoint-receipt.json','1a6d6f598671e95b67b7a7366b0ee738ff7412d52479c646683ca4b3bc6e7ea2')
assert (cp['kept'],cp['rolled_back'],cp['output_triangles'])==(14,2,44953)
samples=read(R/'data/siege-live-20261026/memory-fluctuation-0846.json')['samples']
assert len(samples)==20 and min(x['headroom'] for x in samples)<3.5*1024**3
sys.path.insert(0,str(R/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
path=R/'data/main-infra-fresh/current.json';d=load_progress(path);now=utc_now()
messages={
 '6F':'New orange-free 6F candidate saved: 25,210 triangles; all 3,323 protected originals and 12 assets independently checked. Fresh error maps and visual guard queued. After currently shows the earlier 27,084 candidate until the new assets are published.',
 '3F':'Engine checked 16 exact border cuts: 14 kept, 2 rolled back; 44,953-triangle checkpoint saved. Final OBJ serialization is queued; After still shows the earlier 44,948 candidate.'}
for floor,message in messages.items():
    f=d['floors'][floor];assert f['accepted_preview'] is None and f['owner_decision_ref'] is None
    f.update(state='blocked',step=message,blocker='Memory hold: Agent Hub status daemon repeatedly consumes about 14 GiB; validation launch gate requires stable 8 GiB headroom. No geometry worker is running.',worker_alive=False,last_work_event_at=now)
    prior=f.setdefault('worker_events',[])
    f['worker_events']=[e for e in prior if e.get('phase')!='memory_hold_after_saved_artifact']
    pid,birth,run=(43372,'2026-10-26T08:08:11.2461914Z','MAIN-INFRA-6F-MARKER-POSTSTAGE-20261026') if floor=='6F' else (52532,'2026-10-26T08:11:41.4287378Z','MAIN-INFRA-3F-E5-CONTINUATION-20261026')
    f['worker_events'].append(dict(engine='E5',run_id=run,pid=pid,start_utc=birth,phase='memory_hold_after_saved_artifact',observed_at=now,message=message+' This historical worker has exited. Native memory trace measured 2.4–16.6 GiB headroom; no model acceptance.'))
f=d['floors']['6F'];f['pending_output_triangles']=25210
f['pending_saved_candidate']=dict(triangles=25210,source_sha256='fe1fc27eb387a64c47e63c8b14b442bb1399a48d7a0c922b4ac3ce844b791b47',engine_sha256='f657065a2213aabc05395abe73b65010d63bfe7c5da6b6f6f977c2d9c5cc3b9b',marker_removal='EXACT_24_ONLY_PASS',protected_originals=3323,independent_saved_readback_sha256='85d21d75e6272a5bb796963a90e0285470e6807e2bad6556b67c2640c38347f9',independent_visual_validation='PENDING',default_error_census='PENDING',acceptance=False)
d.update(updated_at=now,last_work_event_at=now,step='6F orange-free candidate saved; 3F checked geometry saved. Fresh validation and final serialization waiting for stable Windows memory.',next_action='Resume 6F fresh census and strict guard, then serialize the saved 3F checkpoint. Preserve existing cuts, facades, textures and all required originals.')
draft=R/'data/siege-live-20261026/current-memory-hold-draft.json';draft.write_text(json.dumps(d,indent=2)+'\n')
subprocess.run(['node',str(R/'data/siege-live-20261026/check-status-current.mjs'),str(draft)],check=True,capture_output=True)
for attempt in range(6):
    try:write_progress(path,d);break
    except PermissionError:
        if attempt==5:raise
        time.sleep(.1)
actual=load_progress(path);assert actual['floors']['6F']['pending_output_triangles']==25210 and actual['floors']['6F']['output_triangles']==27084
receipt=dict(at=now,pending_6f=25210,displayed_6f=27084,saved_3f_checkpoint=44953,actual_geometry_workers_running=False,accepted=False)
(R/'data/siege-live-20261026/current-memory-hold-readback.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
