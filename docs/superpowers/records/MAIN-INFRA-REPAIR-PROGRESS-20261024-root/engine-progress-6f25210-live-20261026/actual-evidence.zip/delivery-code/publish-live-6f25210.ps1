$ErrorActionPreference='Stop'
$taskSite='devenvir@sv70.ifastnet.com'
$taskCommon=@('-i','C:/Users/Future26/.ssh/corllenium_siege_ed25519','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=1','-o','LogLevel=ERROR','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=deploy/known_hosts')
$taskRoot='D:/PROJECTS/05-Corllenium-UC-Building-Repair-Engine'
$taskRows=@(
 @{Source="$taskRoot/data/live-6f25210/models.tar.gz";Name='main-infra-6f25210.tar.gz';Sha='4f4a014068f0462caeb24696c97a24238afb584856173165a4e58db064ddf67f'},
 @{Source="$taskRoot/data/live-6f25210/package.json";Name='main-infra-6f25210.json';Sha='04a253d1fa4d5fa6872d1e0b545c2d97dc873fea39116b94d75f37638ee94f38'},
 @{Source="$taskRoot/data/siege-live-20261026/publish-live-6f25210.py";Name='publish-live-6f25210.py';Sha='9a75085138830816ff9ca31103e8727c40b36d8e13a1e4aaecfddb03acaeda40'}
)
foreach($taskRow in $taskRows){
 if((Get-FileHash -Algorithm SHA256 -LiteralPath $taskRow.Source).Hash.ToLowerInvariant() -ne $taskRow.Sha){throw 'Publication input changed'}
 & scp -q -P 27015 @taskCommon $taskRow.Source ($taskSite+':/tmp/'+$taskRow.Name)
 if($LASTEXITCODE -ne 0){throw ('Upload failed: '+$taskRow.Name)}
}
$taskRemote='python3 -c "import hashlib,runpy; p=''/tmp/publish-live-6f25210.py''; assert hashlib.sha256(open(p,''rb'').read()).hexdigest()==''9a75085138830816ff9ca31103e8727c40b36d8e13a1e4aaecfddb03acaeda40''; runpy.run_path(p,run_name=''__main__'')"'
& ssh -p 27015 @taskCommon $taskSite $taskRemote | Tee-Object -FilePath "$taskRoot/data/live-6f25210/deployment.log"
if($LASTEXITCODE -ne 0){throw 'Inspection assets not verified; current live model selection stays unchanged'}
