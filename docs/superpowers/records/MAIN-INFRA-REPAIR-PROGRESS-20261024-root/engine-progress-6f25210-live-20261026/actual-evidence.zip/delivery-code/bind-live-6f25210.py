from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
package=R/'data/live-6f25210/package.json';assert sha(package)=='04a253d1fa4d5fa6872d1e0b545c2d97dc873fea39116b94d75f37638ee94f38'
m=read(package);candidate=m['results']['candidate'];deployed=json.loads((R/'data/live-6f25210/deployment.log').read_text(encoding='utf-8-sig').strip())
assert deployed['files_per_root']==deployed['http_hashes']==18 and deployed['archive_sha256']==m['archive_sha256'] and not deployed['accepted']
qa=read(R/'data/live-6f25210/client-preview-qa.json');assert qa['actualTriangles']==25210 and qa['errorKinds']==7 and qa['staleMapRejected'] and qa['corruptModelRejected']
t=read(R/'.claude/worktrees/v6g/data/v6g-preflight/monitor-6F-independent25210-census-v3-20261026T085404/result.json')
assert t['actual_pid']==11516 and t['actual_exit_code']==0 and t['all_owned_exited'] and t['abort_reason'] is None
sys.path.insert(0,str(R/'.claude/worktrees/MAIN-INFRA-CLEAN-20261023'))
from tools.main_infra_progress import load_progress,write_progress,utc_now
p=R/'data/main-infra-fresh/current.json';d=load_progress(p);f=d['floors']['6F'];now=utc_now()
assert f['output_triangles'] in (27084,25210) and f['accepted_preview'] is None and f['owner_decision_ref'] is None
f.setdefault('inspection_manifest_history',[]).append(dict(at=now,source=f['source_preview'],candidate=f['candidate_preview'],reason='New actual 25210 guarded repair and matching fresh detector maps'))
f.update(candidate_preview=candidate['preview'],output_triangles=25210,pending_output_triangles=None,evidence_refs=m['evidence_refs'],validator_ref=None,
    state='validating',step='After now shows the new 6F orange-free repair candidate: 25,210 triangles, with matching seven error filters. Independent visual validation continues.',
    blocker='11,763 target instances remain: 1,786 different-look overlaps, 3,583 same-look overlaps and 6,394 cracks. Exact approved marker removal and 3,323 retained originals passed saved-file checks; whole-floor visual/native/signed validation remains pending. Not accepted.',
    worker_alive=False,worker_pid=11516,worker_start_utc=t['actual_creation_utc'],worker_observed_at=t['ended_utc'],last_work_event_at=now)
f.pop('worker_cpu_seconds',None);f.pop('validation_proof',None);f.pop('acceptance_proof',None)
f['latest_saved_candidate']=dict(triangles=25210,source_candidate_sha256=candidate['obj_sha256'],engine_candidate_sha256='f657065a2213aabc05395abe73b65010d63bfe7c5da6b6f6f977c2d9c5cc3b9b',candidate_preview=candidate['preview'],strict26='PENDING',native='PENDING',full_signed='PENDING',marker_dropout='EXACT_24_ONLY_PASS',protected_originals=3323,acceptance=False)
f.pop('pending_saved_candidate',None)
f.setdefault('worker_events',[]).append(dict(engine='Validator',run_id='MAIN-INFRA-6F-25210-INDEPENDENT-20261026',pid=11516,start_utc=t['actual_creation_utc'],observed_at=now,phase='new25210_model_and_matching_maps_published',message='Actual fresh census exited0/noabort/allownedgone: original34,862 and candidate25,210 measured. New model,12 unchanged assets and seven maps now published to both static roots; all18 HTTP hashes and real dashboard loader checks passed. 11,763 signed target instances remain; no acceptance.'))
d.update(updated_at=now,last_work_event_at=now)
draft=R/'data/live-6f25210/current-draft.json';draft.write_text(json.dumps(d,indent=2)+'\n')
subprocess.run(['node',str(R/'data/siege-live-20261026/check-status-current.mjs'),str(draft)],capture_output=True,check=True)
for attempt in range(6):
    try:write_progress(p,d);break
    except PermissionError:
        if attempt==5:raise
        time.sleep(.1)
actual=load_progress(p);assert actual['floors']['6F']['output_triangles']==25210 and actual['floors']['6F']['candidate_preview']==candidate['preview']
result=dict(at=now,floor='6F',output_triangles=25210,candidate_preview=candidate['preview'],remaining_target_instances=11763,all18_HTTP_verified=True,actual_client_loader_passed=True,accepted=False)
(R/'data/live-6f25210/canonical-readback.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
