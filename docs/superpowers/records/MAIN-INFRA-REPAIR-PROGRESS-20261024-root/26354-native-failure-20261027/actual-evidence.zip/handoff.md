# Independent 6F26354 â€” native preservation FAIL

Actual candidate: SOURCE f385f9f8ed363de03c7c14b94e96735ca3f9966bd2d5b116b391409c840db885; ENGINE4f82b5529940c2cfca207b2352e52e004b1a06e83b1c55fbe4b53e0d691a0feb. Builder checkpoint6e321319803b80e67d4d41633bb1f3c049fc882ab4a5dcf4fca53cd731c6a376. Original34862, exact24-marker reference34838, candidate26354.

- Saved independent readback PASS: actual captured182 kept/44rolled E7, exact existing-position SOURCE partitions and attributes, all4284whole originals, all12assets.
- Unchanged default census:2147different-look overlaps,4159same-look overlaps,0reversed,6567cracks =12873signed target instances. Other detector instances:hidden6863,loose0,openedges7636.
- Strict26 PASS:26views,4791106modelpixels,all gating violations0;1report-only zfighttie. RAW-derived tolerance5.9055118110236214e-05in.
- Native FAIL: RAW/source normalization all46views have0RGBA changes; candidate33qualified views have83changed pixels across19views.13diagnostic views have31changed pixels across6views. Fullsigned NOT RUN because native prerequisite failed. No previous PASS transferred or exception expanded.

Readback/census/strict executed committedb82251d3; nativedc118841. All four phase workers and their launchers are terminal; no resource abort. Native58576 ended2026-10-26T21:07:29.8449490Z,exit2; allownedexited. Native report SHA1b7cd304addb029ec579485d56cf2e655e639951b2763560bdb3f7c952d7e045.

Artifacts: data/iv6j/attempt1/{independent-saved-readback.json,independent-guard.json,census/}; data/iv6j/native/{native-preservation.json,candidate/,source_control/}; docs/superpowers/records/MAIN-INFRA-6F-26354-INDEPENDENT-20261027/{native-posthash-readback.json,DELIVERY-MANIFEST.json,DELIVERY-ARCHIVE-RECEIPT.json}. Archives are preserved locally under data/iv6j/delivery-20261027; every ZIP member CRC/SHA was reread. No model or archive was uploaded.

Viewed candidate/all-views.png and full eye1probe840 before/after/diff plus top-view diff. Wall/floor silhouettes align at contact-sheet scale; native saved differences are sparse isolated pixels. Exact cause/affected E7 sites remain UNMEASURED. No visual preservation PASS is claimed.

Canonical6F status was updated using paid progress writer, raw-byte SHA compare and actual production parser. All six otherfloor rows, displayedAfter26127 and its refs remained unchanged. This26354candidate is NOT published, repaired, Unity-ready or owneraccepted.

Next: separate claimed/locked read-only attribution of the83qualified nativepixels to actual E7 parent sites using paid native-footprint/camera machinery. Root source/phase review before any new geometry parse/rays; no renderer/camera/threshold/guard changes.
